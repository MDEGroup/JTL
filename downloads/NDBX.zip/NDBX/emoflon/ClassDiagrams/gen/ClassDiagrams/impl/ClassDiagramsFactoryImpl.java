/**
 */
package ClassDiagrams.impl;

import ClassDiagrams.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ClassDiagramsFactoryImpl extends EFactoryImpl implements ClassDiagramsFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ClassDiagramsFactory init() {
		try {
			ClassDiagramsFactory theClassDiagramsFactory = (ClassDiagramsFactory) EPackage.Registry.INSTANCE
					.getEFactory(ClassDiagramsPackage.eNS_URI);
			if (theClassDiagramsFactory != null) {
				return theClassDiagramsFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new ClassDiagramsFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClassDiagramsFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case ClassDiagramsPackage.CD_PACKAGE:
			return createCDPackage();
		case ClassDiagramsPackage.CD_CLASS:
			return createCDClass();
		case ClassDiagramsPackage.CD_ATTRIBUTE:
			return createCDAttribute();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CDPackage createCDPackage() {
		CDPackageImpl cdPackage = new CDPackageImpl();
		return cdPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CDClass createCDClass() {
		CDClassImpl cdClass = new CDClassImpl();
		return cdClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CDAttribute createCDAttribute() {
		CDAttributeImpl cdAttribute = new CDAttributeImpl();
		return cdAttribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClassDiagramsPackage getClassDiagramsPackage() {
		return (ClassDiagramsPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static ClassDiagramsPackage getPackage() {
		return ClassDiagramsPackage.eINSTANCE;
	}

} //ClassDiagramsFactoryImpl
