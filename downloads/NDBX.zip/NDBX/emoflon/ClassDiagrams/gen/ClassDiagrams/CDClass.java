/**
 */
package ClassDiagrams;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>CD Class</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link ClassDiagrams.CDClass#getSuperClass <em>Super Class</em>}</li>
 *   <li>{@link ClassDiagrams.CDClass#getName <em>Name</em>}</li>
 *   <li>{@link ClassDiagrams.CDClass#getAttributes <em>Attributes</em>}</li>
 * </ul>
 * </p>
 *
 * @see ClassDiagrams.ClassDiagramsPackage#getCDClass()
 * @model
 * @generated
 */
public interface CDClass extends EObject {
	/**
	 * Returns the value of the '<em><b>Super Class</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Super Class</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Super Class</em>' reference.
	 * @see #setSuperClass(CDClass)
	 * @see ClassDiagrams.ClassDiagramsPackage#getCDClass_SuperClass()
	 * @model
	 * @generated
	 */
	CDClass getSuperClass();

	/**
	 * Sets the value of the '{@link ClassDiagrams.CDClass#getSuperClass <em>Super Class</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Super Class</em>' reference.
	 * @see #getSuperClass()
	 * @generated
	 */
	void setSuperClass(CDClass value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see ClassDiagrams.ClassDiagramsPackage#getCDClass_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link ClassDiagrams.CDClass#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Attributes</b></em>' containment reference list.
	 * The list contents are of type {@link ClassDiagrams.CDAttribute}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Attributes</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attributes</em>' containment reference list.
	 * @see ClassDiagrams.ClassDiagramsPackage#getCDClass_Attributes()
	 * @model containment="true"
	 * @generated
	 */
	EList<CDAttribute> getAttributes();
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // CDClass
