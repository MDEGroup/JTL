/**
 */
package ClassDiagrams;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see ClassDiagrams.ClassDiagramsPackage
 * @generated
 */
public interface ClassDiagramsFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ClassDiagramsFactory eINSTANCE = ClassDiagrams.impl.ClassDiagramsFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>CD Package</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>CD Package</em>'.
	 * @generated
	 */
	CDPackage createCDPackage();

	/**
	 * Returns a new object of class '<em>CD Class</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>CD Class</em>'.
	 * @generated
	 */
	CDClass createCDClass();

	/**
	 * Returns a new object of class '<em>CD Attribute</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>CD Attribute</em>'.
	 * @generated
	 */
	CDAttribute createCDAttribute();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	ClassDiagramsPackage getClassDiagramsPackage();

} //ClassDiagramsFactory
