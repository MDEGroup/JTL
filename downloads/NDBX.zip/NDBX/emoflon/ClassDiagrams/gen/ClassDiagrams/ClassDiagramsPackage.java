/**
 */
package ClassDiagrams;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see ClassDiagrams.ClassDiagramsFactory
 * @model kind="package"
 * @generated
 */
public interface ClassDiagramsPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "ClassDiagrams";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "platform:/plugin/ClassDiagrams/model/ClassDiagrams.ecore";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "ClassDiagrams";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ClassDiagramsPackage eINSTANCE = ClassDiagrams.impl.ClassDiagramsPackageImpl.init();

	/**
	 * The meta object id for the '{@link ClassDiagrams.impl.CDPackageImpl <em>CD Package</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ClassDiagrams.impl.CDPackageImpl
	 * @see ClassDiagrams.impl.ClassDiagramsPackageImpl#getCDPackage()
	 * @generated
	 */
	int CD_PACKAGE = 0;

	/**
	 * The feature id for the '<em><b>Classes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CD_PACKAGE__CLASSES = 0;

	/**
	 * The number of structural features of the '<em>CD Package</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CD_PACKAGE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>CD Package</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CD_PACKAGE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ClassDiagrams.impl.CDClassImpl <em>CD Class</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ClassDiagrams.impl.CDClassImpl
	 * @see ClassDiagrams.impl.ClassDiagramsPackageImpl#getCDClass()
	 * @generated
	 */
	int CD_CLASS = 1;

	/**
	 * The feature id for the '<em><b>Super Class</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CD_CLASS__SUPER_CLASS = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CD_CLASS__NAME = 1;

	/**
	 * The feature id for the '<em><b>Attributes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CD_CLASS__ATTRIBUTES = 2;

	/**
	 * The number of structural features of the '<em>CD Class</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CD_CLASS_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>CD Class</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CD_CLASS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link ClassDiagrams.impl.CDAttributeImpl <em>CD Attribute</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see ClassDiagrams.impl.CDAttributeImpl
	 * @see ClassDiagrams.impl.ClassDiagramsPackageImpl#getCDAttribute()
	 * @generated
	 */
	int CD_ATTRIBUTE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CD_ATTRIBUTE__NAME = 0;

	/**
	 * The number of structural features of the '<em>CD Attribute</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CD_ATTRIBUTE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>CD Attribute</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CD_ATTRIBUTE_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link ClassDiagrams.CDPackage <em>CD Package</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>CD Package</em>'.
	 * @see ClassDiagrams.CDPackage
	 * @generated
	 */
	EClass getCDPackage();

	/**
	 * Returns the meta object for the containment reference list '{@link ClassDiagrams.CDPackage#getClasses <em>Classes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Classes</em>'.
	 * @see ClassDiagrams.CDPackage#getClasses()
	 * @see #getCDPackage()
	 * @generated
	 */
	EReference getCDPackage_Classes();

	/**
	 * Returns the meta object for class '{@link ClassDiagrams.CDClass <em>CD Class</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>CD Class</em>'.
	 * @see ClassDiagrams.CDClass
	 * @generated
	 */
	EClass getCDClass();

	/**
	 * Returns the meta object for the reference '{@link ClassDiagrams.CDClass#getSuperClass <em>Super Class</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Super Class</em>'.
	 * @see ClassDiagrams.CDClass#getSuperClass()
	 * @see #getCDClass()
	 * @generated
	 */
	EReference getCDClass_SuperClass();

	/**
	 * Returns the meta object for the attribute '{@link ClassDiagrams.CDClass#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ClassDiagrams.CDClass#getName()
	 * @see #getCDClass()
	 * @generated
	 */
	EAttribute getCDClass_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link ClassDiagrams.CDClass#getAttributes <em>Attributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Attributes</em>'.
	 * @see ClassDiagrams.CDClass#getAttributes()
	 * @see #getCDClass()
	 * @generated
	 */
	EReference getCDClass_Attributes();

	/**
	 * Returns the meta object for class '{@link ClassDiagrams.CDAttribute <em>CD Attribute</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>CD Attribute</em>'.
	 * @see ClassDiagrams.CDAttribute
	 * @generated
	 */
	EClass getCDAttribute();

	/**
	 * Returns the meta object for the attribute '{@link ClassDiagrams.CDAttribute#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see ClassDiagrams.CDAttribute#getName()
	 * @see #getCDAttribute()
	 * @generated
	 */
	EAttribute getCDAttribute_Name();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ClassDiagramsFactory getClassDiagramsFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link ClassDiagrams.impl.CDPackageImpl <em>CD Package</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ClassDiagrams.impl.CDPackageImpl
		 * @see ClassDiagrams.impl.ClassDiagramsPackageImpl#getCDPackage()
		 * @generated
		 */
		EClass CD_PACKAGE = eINSTANCE.getCDPackage();

		/**
		 * The meta object literal for the '<em><b>Classes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CD_PACKAGE__CLASSES = eINSTANCE.getCDPackage_Classes();

		/**
		 * The meta object literal for the '{@link ClassDiagrams.impl.CDClassImpl <em>CD Class</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ClassDiagrams.impl.CDClassImpl
		 * @see ClassDiagrams.impl.ClassDiagramsPackageImpl#getCDClass()
		 * @generated
		 */
		EClass CD_CLASS = eINSTANCE.getCDClass();

		/**
		 * The meta object literal for the '<em><b>Super Class</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CD_CLASS__SUPER_CLASS = eINSTANCE.getCDClass_SuperClass();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CD_CLASS__NAME = eINSTANCE.getCDClass_Name();

		/**
		 * The meta object literal for the '<em><b>Attributes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CD_CLASS__ATTRIBUTES = eINSTANCE.getCDClass_Attributes();

		/**
		 * The meta object literal for the '{@link ClassDiagrams.impl.CDAttributeImpl <em>CD Attribute</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see ClassDiagrams.impl.CDAttributeImpl
		 * @see ClassDiagrams.impl.ClassDiagramsPackageImpl#getCDAttribute()
		 * @generated
		 */
		EClass CD_ATTRIBUTE = eINSTANCE.getCDAttribute();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CD_ATTRIBUTE__NAME = eINSTANCE.getCDAttribute_Name();

	}

} //ClassDiagramsPackage
