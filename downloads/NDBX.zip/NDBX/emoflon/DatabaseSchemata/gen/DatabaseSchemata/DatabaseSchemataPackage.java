/**
 */
package DatabaseSchemata;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see DatabaseSchemata.DatabaseSchemataFactory
 * @model kind="package"
 * @generated
 */
public interface DatabaseSchemataPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "DatabaseSchemata";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "platform:/plugin/DatabaseSchemata/model/DatabaseSchemata.ecore";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "DatabaseSchemata";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	DatabaseSchemataPackage eINSTANCE = DatabaseSchemata.impl.DatabaseSchemataPackageImpl.init();

	/**
	 * The meta object id for the '{@link DatabaseSchemata.impl.DBSchemaImpl <em>DB Schema</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see DatabaseSchemata.impl.DBSchemaImpl
	 * @see DatabaseSchemata.impl.DatabaseSchemataPackageImpl#getDBSchema()
	 * @generated
	 */
	int DB_SCHEMA = 0;

	/**
	 * The feature id for the '<em><b>Tables</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_SCHEMA__TABLES = 0;

	/**
	 * The number of structural features of the '<em>DB Schema</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_SCHEMA_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>DB Schema</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_SCHEMA_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link DatabaseSchemata.impl.DBTableImpl <em>DB Table</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see DatabaseSchemata.impl.DBTableImpl
	 * @see DatabaseSchemata.impl.DatabaseSchemataPackageImpl#getDBTable()
	 * @generated
	 */
	int DB_TABLE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_TABLE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Cols</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_TABLE__COLS = 1;

	/**
	 * The number of structural features of the '<em>DB Table</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_TABLE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>DB Table</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_TABLE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link DatabaseSchemata.impl.DBColumnImpl <em>DB Column</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see DatabaseSchemata.impl.DBColumnImpl
	 * @see DatabaseSchemata.impl.DatabaseSchemataPackageImpl#getDBColumn()
	 * @generated
	 */
	int DB_COLUMN = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_COLUMN__NAME = 0;

	/**
	 * The number of structural features of the '<em>DB Column</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_COLUMN_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>DB Column</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DB_COLUMN_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link DatabaseSchemata.DBSchema <em>DB Schema</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>DB Schema</em>'.
	 * @see DatabaseSchemata.DBSchema
	 * @generated
	 */
	EClass getDBSchema();

	/**
	 * Returns the meta object for the containment reference list '{@link DatabaseSchemata.DBSchema#getTables <em>Tables</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Tables</em>'.
	 * @see DatabaseSchemata.DBSchema#getTables()
	 * @see #getDBSchema()
	 * @generated
	 */
	EReference getDBSchema_Tables();

	/**
	 * Returns the meta object for class '{@link DatabaseSchemata.DBTable <em>DB Table</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>DB Table</em>'.
	 * @see DatabaseSchemata.DBTable
	 * @generated
	 */
	EClass getDBTable();

	/**
	 * Returns the meta object for the attribute '{@link DatabaseSchemata.DBTable#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see DatabaseSchemata.DBTable#getName()
	 * @see #getDBTable()
	 * @generated
	 */
	EAttribute getDBTable_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link DatabaseSchemata.DBTable#getCols <em>Cols</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cols</em>'.
	 * @see DatabaseSchemata.DBTable#getCols()
	 * @see #getDBTable()
	 * @generated
	 */
	EReference getDBTable_Cols();

	/**
	 * Returns the meta object for class '{@link DatabaseSchemata.DBColumn <em>DB Column</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>DB Column</em>'.
	 * @see DatabaseSchemata.DBColumn
	 * @generated
	 */
	EClass getDBColumn();

	/**
	 * Returns the meta object for the attribute '{@link DatabaseSchemata.DBColumn#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see DatabaseSchemata.DBColumn#getName()
	 * @see #getDBColumn()
	 * @generated
	 */
	EAttribute getDBColumn_Name();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	DatabaseSchemataFactory getDatabaseSchemataFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link DatabaseSchemata.impl.DBSchemaImpl <em>DB Schema</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see DatabaseSchemata.impl.DBSchemaImpl
		 * @see DatabaseSchemata.impl.DatabaseSchemataPackageImpl#getDBSchema()
		 * @generated
		 */
		EClass DB_SCHEMA = eINSTANCE.getDBSchema();

		/**
		 * The meta object literal for the '<em><b>Tables</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DB_SCHEMA__TABLES = eINSTANCE.getDBSchema_Tables();

		/**
		 * The meta object literal for the '{@link DatabaseSchemata.impl.DBTableImpl <em>DB Table</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see DatabaseSchemata.impl.DBTableImpl
		 * @see DatabaseSchemata.impl.DatabaseSchemataPackageImpl#getDBTable()
		 * @generated
		 */
		EClass DB_TABLE = eINSTANCE.getDBTable();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DB_TABLE__NAME = eINSTANCE.getDBTable_Name();

		/**
		 * The meta object literal for the '<em><b>Cols</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DB_TABLE__COLS = eINSTANCE.getDBTable_Cols();

		/**
		 * The meta object literal for the '{@link DatabaseSchemata.impl.DBColumnImpl <em>DB Column</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see DatabaseSchemata.impl.DBColumnImpl
		 * @see DatabaseSchemata.impl.DatabaseSchemataPackageImpl#getDBColumn()
		 * @generated
		 */
		EClass DB_COLUMN = eINSTANCE.getDBColumn();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DB_COLUMN__NAME = eINSTANCE.getDBColumn_Name();

	}

} //DatabaseSchemataPackage
