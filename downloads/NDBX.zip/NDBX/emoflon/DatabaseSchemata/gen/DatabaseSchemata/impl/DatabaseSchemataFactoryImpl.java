/**
 */
package DatabaseSchemata.impl;

import DatabaseSchemata.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class DatabaseSchemataFactoryImpl extends EFactoryImpl implements DatabaseSchemataFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static DatabaseSchemataFactory init() {
		try {
			DatabaseSchemataFactory theDatabaseSchemataFactory = (DatabaseSchemataFactory) EPackage.Registry.INSTANCE
					.getEFactory(DatabaseSchemataPackage.eNS_URI);
			if (theDatabaseSchemataFactory != null) {
				return theDatabaseSchemataFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new DatabaseSchemataFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DatabaseSchemataFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case DatabaseSchemataPackage.DB_SCHEMA:
			return createDBSchema();
		case DatabaseSchemataPackage.DB_TABLE:
			return createDBTable();
		case DatabaseSchemataPackage.DB_COLUMN:
			return createDBColumn();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DBSchema createDBSchema() {
		DBSchemaImpl dbSchema = new DBSchemaImpl();
		return dbSchema;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DBTable createDBTable() {
		DBTableImpl dbTable = new DBTableImpl();
		return dbTable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DBColumn createDBColumn() {
		DBColumnImpl dbColumn = new DBColumnImpl();
		return dbColumn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DatabaseSchemataPackage getDatabaseSchemataPackage() {
		return (DatabaseSchemataPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static DatabaseSchemataPackage getPackage() {
		return DatabaseSchemataPackage.eINSTANCE;
	}

} //DatabaseSchemataFactoryImpl
