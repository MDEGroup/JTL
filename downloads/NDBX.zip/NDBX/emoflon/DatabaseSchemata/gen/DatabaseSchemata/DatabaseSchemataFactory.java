/**
 */
package DatabaseSchemata;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see DatabaseSchemata.DatabaseSchemataPackage
 * @generated
 */
public interface DatabaseSchemataFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	DatabaseSchemataFactory eINSTANCE = DatabaseSchemata.impl.DatabaseSchemataFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>DB Schema</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>DB Schema</em>'.
	 * @generated
	 */
	DBSchema createDBSchema();

	/**
	 * Returns a new object of class '<em>DB Table</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>DB Table</em>'.
	 * @generated
	 */
	DBTable createDBTable();

	/**
	 * Returns a new object of class '<em>DB Column</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>DB Column</em>'.
	 * @generated
	 */
	DBColumn createDBColumn();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	DatabaseSchemataPackage getDatabaseSchemataPackage();

} //DatabaseSchemataFactory
