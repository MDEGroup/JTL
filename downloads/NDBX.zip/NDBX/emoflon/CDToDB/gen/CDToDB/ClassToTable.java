/**
 */
package CDToDB;

import ClassDiagrams.CDClass;

import DatabaseSchemata.DBTable;

import org.eclipse.emf.ecore.EObject;

import org.moflon.tgg.runtime.AbstractCorrespondence;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Class To Table</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CDToDB.ClassToTable#getSource <em>Source</em>}</li>
 *   <li>{@link CDToDB.ClassToTable#getTarget <em>Target</em>}</li>
 * </ul>
 * </p>
 *
 * @see CDToDB.CDToDBPackage#getClassToTable()
 * @model
 * @generated
 */
public interface ClassToTable extends EObject, AbstractCorrespondence {
	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(CDClass)
	 * @see CDToDB.CDToDBPackage#getClassToTable_Source()
	 * @model required="true"
	 * @generated
	 */
	CDClass getSource();

	/**
	 * Sets the value of the '{@link CDToDB.ClassToTable#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(CDClass value);

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Target</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference.
	 * @see #setTarget(DBTable)
	 * @see CDToDB.CDToDBPackage#getClassToTable_Target()
	 * @model required="true"
	 * @generated
	 */
	DBTable getTarget();

	/**
	 * Sets the value of the '{@link CDToDB.ClassToTable#getTarget <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target</em>' reference.
	 * @see #getTarget()
	 * @generated
	 */
	void setTarget(DBTable value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // ClassToTable
