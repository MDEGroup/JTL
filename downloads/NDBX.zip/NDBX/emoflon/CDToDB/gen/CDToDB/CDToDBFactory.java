/**
 */
package CDToDB;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see CDToDB.CDToDBPackage
 * @generated
 */
public interface CDToDBFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	CDToDBFactory eINSTANCE = CDToDB.impl.CDToDBFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Package To Schema</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Package To Schema</em>'.
	 * @generated
	 */
	PackageToSchema createPackageToSchema();

	/**
	 * Returns a new object of class '<em>Class To Table</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Class To Table</em>'.
	 * @generated
	 */
	ClassToTable createClassToTable();

	/**
	 * Returns a new object of class '<em>Super Class To Table</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Super Class To Table</em>'.
	 * @generated
	 */
	SuperClassToTable createSuperClassToTable();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	CDToDBPackage getCDToDBPackage();

} //CDToDBFactory
