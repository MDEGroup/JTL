/**
 */
package CDToDB.Rules.impl;

import CDToDB.CDToDBFactory;
import CDToDB.ClassToTable;
import CDToDB.PackageToSchema;

import CDToDB.Rules.ClassToTableRule;
import CDToDB.Rules.RulesPackage;

import ClassDiagrams.CDClass;
import ClassDiagrams.CDPackage;
import ClassDiagrams.ClassDiagramsFactory;

import DatabaseSchemata.DBSchema;
import DatabaseSchemata.DBTable;
import DatabaseSchemata.DatabaseSchemataFactory;

import java.lang.Iterable;

import java.lang.reflect.InvocationTargetException;

import java.util.LinkedList;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EOperation;

import org.moflon.tgg.language.csp.CSP;

import org.moflon.tgg.language.modelgenerator.RuleEntryContainer;
import org.moflon.tgg.language.modelgenerator.RuleEntryList;

import org.moflon.tgg.runtime.AttributeConstraintsRuleResult;
import org.moflon.tgg.runtime.CCMatch;
import org.moflon.tgg.runtime.EMoflonEdge;
import org.moflon.tgg.runtime.EObjectContainer;
import org.moflon.tgg.runtime.IsApplicableMatch;
import org.moflon.tgg.runtime.IsApplicableRuleResult;
import org.moflon.tgg.runtime.Match;
import org.moflon.tgg.runtime.ModelgeneratorRuleResult;
import org.moflon.tgg.runtime.PerformRuleResult;
import org.moflon.tgg.runtime.RuntimeFactory;
import org.moflon.tgg.runtime.TripleMatch;

import org.moflon.tgg.runtime.impl.AbstractRuleImpl;
// <-- [user defined imports]
import org.moflon.tgg.csp.*;
import CDToDB.csp.constraints.*;
import org.moflon.tgg.csp.constraints.*;
import org.moflon.tgg.language.csp.*;
import org.moflon.tgg.runtime.TripleMatchNodeMapping;
import java.util.Optional;
import org.moflon.tgg.algorithm.delta.attribute.CheckAttributeHelper;
import SDMLanguage.expressions.ComparingOperator;
import org.moflon.tgg.runtime.TripleMatchNodeMapping;
import java.util.Optional;
import org.moflon.tgg.algorithm.delta.attribute.CheckAttributeHelper;
import SDMLanguage.expressions.ComparingOperator;
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Class To Table Rule</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class ClassToTableRuleImpl extends AbstractRuleImpl implements ClassToTableRule {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ClassToTableRuleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RulesPackage.eINSTANCE.getClassToTableRule();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_FWD(Match match, CDClass c, CDPackage p) {

		Object[] result1_black = ClassToTableRuleImpl.pattern_ClassToTableRule_0_1_initialbindings_blackBBBB(this,
				match, c, p);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[match] = " + match + ", " + "[c] = " + c + ", " + "[p] = " + p + ".");
		}

		Object[] result2_bindingAndBlack = ClassToTableRuleImpl
				.pattern_ClassToTableRule_0_2_SolveCSP_bindingAndBlackFBBBB(this, match, c, p);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[match] = " + match + ", " + "[c] = " + c + ", " + "[p] = " + p + ".");
		}
		CSP csp = (CSP) result2_bindingAndBlack[0];
		// 
		if (ClassToTableRuleImpl.pattern_ClassToTableRule_0_3_CheckCSP_expressionFBB(this, csp)) {

			Object[] result4_black = ClassToTableRuleImpl
					.pattern_ClassToTableRule_0_4_collectelementstobetranslated_blackBBB(match, c, p);
			if (result4_black == null) {
				throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match + ", "
						+ "[c] = " + c + ", " + "[p] = " + p + ".");
			}
			ClassToTableRuleImpl.pattern_ClassToTableRule_0_4_collectelementstobetranslated_greenBBBF(match, c, p);
			//nothing EMoflonEdge p__c____classes = (EMoflonEdge) result4_green[3];

			Object[] result5_black = ClassToTableRuleImpl
					.pattern_ClassToTableRule_0_5_collectcontextelements_blackBBB(match, c, p);
			if (result5_black == null) {
				throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match + ", "
						+ "[c] = " + c + ", " + "[p] = " + p + ".");
			}
			ClassToTableRuleImpl.pattern_ClassToTableRule_0_5_collectcontextelements_greenBB(match, p);

			// 
			ClassToTableRuleImpl.pattern_ClassToTableRule_0_6_registerobjectstomatch_expressionBBBB(this, match, c, p);
			return ClassToTableRuleImpl.pattern_ClassToTableRule_0_7_expressionF();
		} else {
			return ClassToTableRuleImpl.pattern_ClassToTableRule_0_8_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformRuleResult perform_FWD(IsApplicableMatch isApplicableMatch) {

		Object[] result1_bindingAndBlack = ClassToTableRuleImpl
				.pattern_ClassToTableRule_1_1_performtransformation_bindingAndBlackFFFFFBB(this, isApplicableMatch);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[isApplicableMatch] = " + isApplicableMatch + ".");
		}
		CDClass c = (CDClass) result1_bindingAndBlack[0];
		PackageToSchema p2s = (PackageToSchema) result1_bindingAndBlack[1];
		DBSchema s = (DBSchema) result1_bindingAndBlack[2];
		CDPackage p = (CDPackage) result1_bindingAndBlack[3];
		CSP csp = (CSP) result1_bindingAndBlack[4];
		Object[] result1_green = ClassToTableRuleImpl.pattern_ClassToTableRule_1_1_performtransformation_greenFBFBB(c,
				s, csp);
		DBTable t = (DBTable) result1_green[0];
		ClassToTable c2t = (ClassToTable) result1_green[2];

		Object[] result2_black = ClassToTableRuleImpl.pattern_ClassToTableRule_1_2_collecttranslatedelements_blackBBB(t,
				c, c2t);
		if (result2_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[t] = " + t + ", " + "[c] = " + c
					+ ", " + "[c2t] = " + c2t + ".");
		}
		Object[] result2_green = ClassToTableRuleImpl
				.pattern_ClassToTableRule_1_2_collecttranslatedelements_greenFBBB(t, c, c2t);
		PerformRuleResult ruleresult = (PerformRuleResult) result2_green[0];

		Object[] result3_black = ClassToTableRuleImpl
				.pattern_ClassToTableRule_1_3_bookkeepingforedges_blackBBBBBBB(ruleresult, t, c, c2t, p2s, s, p);
		if (result3_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[ruleresult] = " + ruleresult
					+ ", " + "[t] = " + t + ", " + "[c] = " + c + ", " + "[c2t] = " + c2t + ", " + "[p2s] = " + p2s
					+ ", " + "[s] = " + s + ", " + "[p] = " + p + ".");
		}
		ClassToTableRuleImpl.pattern_ClassToTableRule_1_3_bookkeepingforedges_greenBBBBBBFFFF(ruleresult, t, c, c2t, s,
				p);
		//nothing EMoflonEdge c2t__t____target = (EMoflonEdge) result3_green[6];
		//nothing EMoflonEdge s__t____tables = (EMoflonEdge) result3_green[7];
		//nothing EMoflonEdge c2t__c____source = (EMoflonEdge) result3_green[8];
		//nothing EMoflonEdge p__c____classes = (EMoflonEdge) result3_green[9];

		// 
		// 
		ClassToTableRuleImpl.pattern_ClassToTableRule_1_5_registerobjects_expressionBBBBBBBB(this, ruleresult, t, c,
				c2t, p2s, s, p);
		return ClassToTableRuleImpl.pattern_ClassToTableRule_1_6_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_FWD(Match match) {

		Object[] result1_bindingAndBlack = ClassToTableRuleImpl
				.pattern_ClassToTableRule_2_1_preparereturnvalue_bindingAndBlackFFB(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		EOperation performOperation = (EOperation) result1_bindingAndBlack[0];
		//nothing EClass eClass = (EClass) result1_bindingAndBlack[1];
		Object[] result1_green = ClassToTableRuleImpl
				.pattern_ClassToTableRule_2_1_preparereturnvalue_greenBF(performOperation);
		IsApplicableRuleResult ruleresult = (IsApplicableRuleResult) result1_green[1];

		// ForEach 
		Object[] result2_binding = ClassToTableRuleImpl.pattern_ClassToTableRule_2_2_corematch_bindingFFB(match);
		if (result2_binding == null) {
			throw new RuntimeException(
					"Binding in node core match failed." + " Variables: " + "[match] = " + match + ".");
		}
		CDClass c = (CDClass) result2_binding[0];
		CDPackage p = (CDPackage) result2_binding[1];
		for (Object[] result2_black : ClassToTableRuleImpl.pattern_ClassToTableRule_2_2_corematch_blackBFFBB(c, p,
				match)) {
			PackageToSchema p2s = (PackageToSchema) result2_black[1];
			DBSchema s = (DBSchema) result2_black[2];
			// ForEach 
			for (Object[] result3_black : ClassToTableRuleImpl.pattern_ClassToTableRule_2_3_findcontext_blackBBBB(c,
					p2s, s, p)) {
				Object[] result3_green = ClassToTableRuleImpl.pattern_ClassToTableRule_2_3_findcontext_greenBBBBFFFF(c,
						p2s, s, p);
				IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result3_green[4];
				//nothing EMoflonEdge p2s__s____target = (EMoflonEdge) result3_green[5];
				//nothing EMoflonEdge p__c____classes = (EMoflonEdge) result3_green[6];
				//nothing EMoflonEdge p2s__p____source = (EMoflonEdge) result3_green[7];

				Object[] result4_bindingAndBlack = ClassToTableRuleImpl
						.pattern_ClassToTableRule_2_4_solveCSP_bindingAndBlackFBBBBBB(this, isApplicableMatch, c, p2s,
								s, p);
				if (result4_bindingAndBlack == null) {
					throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
							+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[c] = " + c + ", " + "[p2s] = "
							+ p2s + ", " + "[s] = " + s + ", " + "[p] = " + p + ".");
				}
				CSP csp = (CSP) result4_bindingAndBlack[0];
				// 
				if (ClassToTableRuleImpl.pattern_ClassToTableRule_2_5_checkCSP_expressionFBB(this, csp)) {

					Object[] result6_black = ClassToTableRuleImpl
							.pattern_ClassToTableRule_2_6_addmatchtoruleresult_blackBB(ruleresult, isApplicableMatch);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[ruleresult] = "
								+ ruleresult + ", " + "[isApplicableMatch] = " + isApplicableMatch + ".");
					}
					ClassToTableRuleImpl.pattern_ClassToTableRule_2_6_addmatchtoruleresult_greenBB(ruleresult,
							isApplicableMatch);

				} else {
				}

			}

		}
		return ClassToTableRuleImpl.pattern_ClassToTableRule_2_7_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjectsToMatch_FWD(Match match, CDClass c, CDPackage p) {
		match.registerObject("c", c);
		match.registerObject("p", p);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isAppropriate_solveCsp_FWD(Match match, CDClass c, CDPackage p) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables

		// Create unbound variables

		// Create constraints

		// Solve CSP
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_checkCsp_FWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_FWD(IsApplicableMatch isApplicableMatch, CDClass c, PackageToSchema p2s,
			DBSchema s, CDPackage p) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables
		Variable var_c_name = CSPFactoryHelper.eINSTANCE.createVariable("c.name", true, csp);
		var_c_name.setValue(c.getName());
		var_c_name.setType("String");

		// Create unbound variables
		Variable var_t_name = CSPFactoryHelper.eINSTANCE.createVariable("t.name", csp);
		var_t_name.setType("String");

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_c_name, var_t_name);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("c", c);
		isApplicableMatch.registerObject("p2s", p2s);
		isApplicableMatch.registerObject("s", s);
		isApplicableMatch.registerObject("p", p);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_FWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjects_FWD(PerformRuleResult ruleresult, EObject t, EObject c, EObject c2t, EObject p2s,
			EObject s, EObject p) {
		ruleresult.registerObject("t", t);
		ruleresult.registerObject("c", c);
		ruleresult.registerObject("c2t", c2t);
		ruleresult.registerObject("p2s", p2s);
		ruleresult.registerObject("s", s);
		ruleresult.registerObject("p", p);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkTypes_FWD(Match match) {
		return true && org.moflon.util.eMoflonSDMUtil.getFQN(match.getObject("c").eClass())
				.equals("ClassDiagrams.CDClass.");
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_BWD(Match match, DBTable t, DBSchema s) {

		Object[] result1_black = ClassToTableRuleImpl.pattern_ClassToTableRule_10_1_initialbindings_blackBBBB(this,
				match, t, s);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[match] = " + match + ", " + "[t] = " + t + ", " + "[s] = " + s + ".");
		}

		Object[] result2_bindingAndBlack = ClassToTableRuleImpl
				.pattern_ClassToTableRule_10_2_SolveCSP_bindingAndBlackFBBBB(this, match, t, s);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[match] = " + match + ", " + "[t] = " + t + ", " + "[s] = " + s + ".");
		}
		CSP csp = (CSP) result2_bindingAndBlack[0];
		// 
		if (ClassToTableRuleImpl.pattern_ClassToTableRule_10_3_CheckCSP_expressionFBB(this, csp)) {

			Object[] result4_black = ClassToTableRuleImpl
					.pattern_ClassToTableRule_10_4_collectelementstobetranslated_blackBBB(match, t, s);
			if (result4_black == null) {
				throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match + ", "
						+ "[t] = " + t + ", " + "[s] = " + s + ".");
			}
			ClassToTableRuleImpl.pattern_ClassToTableRule_10_4_collectelementstobetranslated_greenBBBF(match, t, s);
			//nothing EMoflonEdge s__t____tables = (EMoflonEdge) result4_green[3];

			Object[] result5_black = ClassToTableRuleImpl
					.pattern_ClassToTableRule_10_5_collectcontextelements_blackBBB(match, t, s);
			if (result5_black == null) {
				throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match + ", "
						+ "[t] = " + t + ", " + "[s] = " + s + ".");
			}
			ClassToTableRuleImpl.pattern_ClassToTableRule_10_5_collectcontextelements_greenBB(match, s);

			// 
			ClassToTableRuleImpl.pattern_ClassToTableRule_10_6_registerobjectstomatch_expressionBBBB(this, match, t, s);
			return ClassToTableRuleImpl.pattern_ClassToTableRule_10_7_expressionF();
		} else {
			return ClassToTableRuleImpl.pattern_ClassToTableRule_10_8_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformRuleResult perform_BWD(IsApplicableMatch isApplicableMatch) {

		Object[] result1_bindingAndBlack = ClassToTableRuleImpl
				.pattern_ClassToTableRule_11_1_performtransformation_bindingAndBlackFFFFFBB(this, isApplicableMatch);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[isApplicableMatch] = " + isApplicableMatch + ".");
		}
		DBTable t = (DBTable) result1_bindingAndBlack[0];
		PackageToSchema p2s = (PackageToSchema) result1_bindingAndBlack[1];
		DBSchema s = (DBSchema) result1_bindingAndBlack[2];
		CDPackage p = (CDPackage) result1_bindingAndBlack[3];
		CSP csp = (CSP) result1_bindingAndBlack[4];
		Object[] result1_green = ClassToTableRuleImpl.pattern_ClassToTableRule_11_1_performtransformation_greenBFFBB(t,
				p, csp);
		CDClass c = (CDClass) result1_green[1];
		ClassToTable c2t = (ClassToTable) result1_green[2];

		Object[] result2_black = ClassToTableRuleImpl
				.pattern_ClassToTableRule_11_2_collecttranslatedelements_blackBBB(t, c, c2t);
		if (result2_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[t] = " + t + ", " + "[c] = " + c
					+ ", " + "[c2t] = " + c2t + ".");
		}
		Object[] result2_green = ClassToTableRuleImpl
				.pattern_ClassToTableRule_11_2_collecttranslatedelements_greenFBBB(t, c, c2t);
		PerformRuleResult ruleresult = (PerformRuleResult) result2_green[0];

		Object[] result3_black = ClassToTableRuleImpl
				.pattern_ClassToTableRule_11_3_bookkeepingforedges_blackBBBBBBB(ruleresult, t, c, c2t, p2s, s, p);
		if (result3_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[ruleresult] = " + ruleresult
					+ ", " + "[t] = " + t + ", " + "[c] = " + c + ", " + "[c2t] = " + c2t + ", " + "[p2s] = " + p2s
					+ ", " + "[s] = " + s + ", " + "[p] = " + p + ".");
		}
		ClassToTableRuleImpl.pattern_ClassToTableRule_11_3_bookkeepingforedges_greenBBBBBBFFFF(ruleresult, t, c, c2t, s,
				p);
		//nothing EMoflonEdge c2t__t____target = (EMoflonEdge) result3_green[6];
		//nothing EMoflonEdge s__t____tables = (EMoflonEdge) result3_green[7];
		//nothing EMoflonEdge c2t__c____source = (EMoflonEdge) result3_green[8];
		//nothing EMoflonEdge p__c____classes = (EMoflonEdge) result3_green[9];

		// 
		// 
		ClassToTableRuleImpl.pattern_ClassToTableRule_11_5_registerobjects_expressionBBBBBBBB(this, ruleresult, t, c,
				c2t, p2s, s, p);
		return ClassToTableRuleImpl.pattern_ClassToTableRule_11_6_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_BWD(Match match) {

		Object[] result1_bindingAndBlack = ClassToTableRuleImpl
				.pattern_ClassToTableRule_12_1_preparereturnvalue_bindingAndBlackFFB(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		EOperation performOperation = (EOperation) result1_bindingAndBlack[0];
		//nothing EClass eClass = (EClass) result1_bindingAndBlack[1];
		Object[] result1_green = ClassToTableRuleImpl
				.pattern_ClassToTableRule_12_1_preparereturnvalue_greenBF(performOperation);
		IsApplicableRuleResult ruleresult = (IsApplicableRuleResult) result1_green[1];

		// ForEach 
		Object[] result2_binding = ClassToTableRuleImpl.pattern_ClassToTableRule_12_2_corematch_bindingFFB(match);
		if (result2_binding == null) {
			throw new RuntimeException(
					"Binding in node core match failed." + " Variables: " + "[match] = " + match + ".");
		}
		DBTable t = (DBTable) result2_binding[0];
		DBSchema s = (DBSchema) result2_binding[1];
		for (Object[] result2_black : ClassToTableRuleImpl.pattern_ClassToTableRule_12_2_corematch_blackBFBFB(t, s,
				match)) {
			PackageToSchema p2s = (PackageToSchema) result2_black[1];
			CDPackage p = (CDPackage) result2_black[3];
			// ForEach 
			for (Object[] result3_black : ClassToTableRuleImpl.pattern_ClassToTableRule_12_3_findcontext_blackBBBB(t,
					p2s, s, p)) {
				Object[] result3_green = ClassToTableRuleImpl.pattern_ClassToTableRule_12_3_findcontext_greenBBBBFFFF(t,
						p2s, s, p);
				IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result3_green[4];
				//nothing EMoflonEdge s__t____tables = (EMoflonEdge) result3_green[5];
				//nothing EMoflonEdge p2s__s____target = (EMoflonEdge) result3_green[6];
				//nothing EMoflonEdge p2s__p____source = (EMoflonEdge) result3_green[7];

				Object[] result4_bindingAndBlack = ClassToTableRuleImpl
						.pattern_ClassToTableRule_12_4_solveCSP_bindingAndBlackFBBBBBB(this, isApplicableMatch, t, p2s,
								s, p);
				if (result4_bindingAndBlack == null) {
					throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
							+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[t] = " + t + ", " + "[p2s] = "
							+ p2s + ", " + "[s] = " + s + ", " + "[p] = " + p + ".");
				}
				CSP csp = (CSP) result4_bindingAndBlack[0];
				// 
				if (ClassToTableRuleImpl.pattern_ClassToTableRule_12_5_checkCSP_expressionFBB(this, csp)) {

					Object[] result6_black = ClassToTableRuleImpl
							.pattern_ClassToTableRule_12_6_addmatchtoruleresult_blackBB(ruleresult, isApplicableMatch);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[ruleresult] = "
								+ ruleresult + ", " + "[isApplicableMatch] = " + isApplicableMatch + ".");
					}
					ClassToTableRuleImpl.pattern_ClassToTableRule_12_6_addmatchtoruleresult_greenBB(ruleresult,
							isApplicableMatch);

				} else {
				}

			}

		}
		return ClassToTableRuleImpl.pattern_ClassToTableRule_12_7_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjectsToMatch_BWD(Match match, DBTable t, DBSchema s) {
		match.registerObject("t", t);
		match.registerObject("s", s);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isAppropriate_solveCsp_BWD(Match match, DBTable t, DBSchema s) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables

		// Create unbound variables

		// Create constraints

		// Solve CSP
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_BWD(IsApplicableMatch isApplicableMatch, DBTable t, PackageToSchema p2s,
			DBSchema s, CDPackage p) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables
		Variable var_t_name = CSPFactoryHelper.eINSTANCE.createVariable("t.name", true, csp);
		var_t_name.setValue(t.getName());
		var_t_name.setType("String");

		// Create unbound variables
		Variable var_c_name = CSPFactoryHelper.eINSTANCE.createVariable("c.name", csp);
		var_c_name.setType("String");

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_c_name, var_t_name);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("t", t);
		isApplicableMatch.registerObject("p2s", p2s);
		isApplicableMatch.registerObject("s", s);
		isApplicableMatch.registerObject("p", p);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjects_BWD(PerformRuleResult ruleresult, EObject t, EObject c, EObject c2t, EObject p2s,
			EObject s, EObject p) {
		ruleresult.registerObject("t", t);
		ruleresult.registerObject("c", c);
		ruleresult.registerObject("c2t", c2t);
		ruleresult.registerObject("p2s", p2s);
		ruleresult.registerObject("s", s);
		ruleresult.registerObject("p", p);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkTypes_BWD(Match match) {
		return true && org.moflon.util.eMoflonSDMUtil.getFQN(match.getObject("t").eClass())
				.equals("DatabaseSchemata.DBTable.");
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObjectContainer isAppropriate_FWD_EMoflonEdge_1(EMoflonEdge _edge_classes) {

		Object[] result1_bindingAndBlack = ClassToTableRuleImpl
				.pattern_ClassToTableRule_20_1_preparereturnvalue_bindingAndBlackFFBF(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		EOperation __performOperation = (EOperation) result1_bindingAndBlack[0];
		EClass __eClass = (EClass) result1_bindingAndBlack[1];
		EOperation isApplicableCC = (EOperation) result1_bindingAndBlack[3];
		Object[] result1_green = ClassToTableRuleImpl.pattern_ClassToTableRule_20_1_preparereturnvalue_greenF();
		EObjectContainer __result = (EObjectContainer) result1_green[0];

		// ForEach 
		for (Object[] result2_black : ClassToTableRuleImpl
				.pattern_ClassToTableRule_20_2_testcorematchandDECs_blackFFB(_edge_classes)) {
			CDClass c = (CDClass) result2_black[0];
			CDPackage p = (CDPackage) result2_black[1];
			Object[] result2_green = ClassToTableRuleImpl
					.pattern_ClassToTableRule_20_2_testcorematchandDECs_greenFB(__eClass);
			Match match = (Match) result2_green[0];

			// 
			if (ClassToTableRuleImpl
					.pattern_ClassToTableRule_20_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBB(this,
							match, c, p)) {
				// 
				if (ClassToTableRuleImpl
						.pattern_ClassToTableRule_20_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(this,
								match)) {

					Object[] result5_black = ClassToTableRuleImpl
							.pattern_ClassToTableRule_20_5_Addmatchtoruleresult_blackBBBB(match, __performOperation,
									__result, isApplicableCC);
					if (result5_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match
								+ ", " + "[__performOperation] = " + __performOperation + ", " + "[__result] = "
								+ __result + ", " + "[isApplicableCC] = " + isApplicableCC + ".");
					}
					ClassToTableRuleImpl.pattern_ClassToTableRule_20_5_Addmatchtoruleresult_greenBBBB(match,
							__performOperation, __result, isApplicableCC);

				} else {
				}

			} else {
			}

		}
		return ClassToTableRuleImpl.pattern_ClassToTableRule_20_6_expressionFB(__result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObjectContainer isAppropriate_BWD_EMoflonEdge_1(EMoflonEdge _edge_tables) {

		Object[] result1_bindingAndBlack = ClassToTableRuleImpl
				.pattern_ClassToTableRule_21_1_preparereturnvalue_bindingAndBlackFFBF(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		EOperation __performOperation = (EOperation) result1_bindingAndBlack[0];
		EClass __eClass = (EClass) result1_bindingAndBlack[1];
		EOperation isApplicableCC = (EOperation) result1_bindingAndBlack[3];
		Object[] result1_green = ClassToTableRuleImpl.pattern_ClassToTableRule_21_1_preparereturnvalue_greenF();
		EObjectContainer __result = (EObjectContainer) result1_green[0];

		// ForEach 
		for (Object[] result2_black : ClassToTableRuleImpl
				.pattern_ClassToTableRule_21_2_testcorematchandDECs_blackFFB(_edge_tables)) {
			DBTable t = (DBTable) result2_black[0];
			DBSchema s = (DBSchema) result2_black[1];
			Object[] result2_green = ClassToTableRuleImpl
					.pattern_ClassToTableRule_21_2_testcorematchandDECs_greenFB(__eClass);
			Match match = (Match) result2_green[0];

			// 
			if (ClassToTableRuleImpl
					.pattern_ClassToTableRule_21_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBB(this,
							match, t, s)) {
				// 
				if (ClassToTableRuleImpl
						.pattern_ClassToTableRule_21_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(this,
								match)) {

					Object[] result5_black = ClassToTableRuleImpl
							.pattern_ClassToTableRule_21_5_Addmatchtoruleresult_blackBBBB(match, __performOperation,
									__result, isApplicableCC);
					if (result5_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match
								+ ", " + "[__performOperation] = " + __performOperation + ", " + "[__result] = "
								+ __result + ", " + "[isApplicableCC] = " + isApplicableCC + ".");
					}
					ClassToTableRuleImpl.pattern_ClassToTableRule_21_5_Addmatchtoruleresult_greenBBBB(match,
							__performOperation, __result, isApplicableCC);

				} else {
				}

			} else {
			}

		}
		return ClassToTableRuleImpl.pattern_ClassToTableRule_21_6_expressionFB(__result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeConstraintsRuleResult checkAttributes_FWD(TripleMatch __tripleMatch) {
		AttributeConstraintsRuleResult ruleResult = org.moflon.tgg.runtime.RuntimeFactory.eINSTANCE
				.createAttributeConstraintsRuleResult();
		ruleResult.setRule("ClassToTableRule");
		ruleResult.setSuccess(true);

		CSP csp = CspFactory.eINSTANCE.createCSP();

		CheckAttributeHelper __helper = new CheckAttributeHelper(__tripleMatch);

		Variable var_t_name = CSPFactoryHelper.eINSTANCE.createVariable("t", true, csp);
		var_t_name.setValue(__helper.getValue("t", "name"));
		var_t_name.setType("String");

		Variable var_c_name = CSPFactoryHelper.eINSTANCE.createVariable("c", true, csp);
		var_c_name.setValue(__helper.getValue("c", "name"));
		var_c_name.setType("String");

		Eq eq0 = new Eq();
		csp.getConstraints().add(eq0);

		eq0.setRuleName("ClassToTableRule");
		eq0.solve(var_c_name, var_t_name);

		if (csp.check()) {
			ruleResult.setSuccess(true);
		} else {
			var_t_name.setBound(false);
			eq0.solve(var_c_name, var_t_name);
			if (csp.check()) {
				ruleResult.setSuccess(true);
				ruleResult.setRequiredChange(true);
				__helper.setValue("t", "name", var_t_name.getValue());
			} else {
				ruleResult.setSuccess(false);
				return ruleResult;
			}
		}

		return ruleResult;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeConstraintsRuleResult checkAttributes_BWD(TripleMatch __tripleMatch) {
		AttributeConstraintsRuleResult ruleResult = org.moflon.tgg.runtime.RuntimeFactory.eINSTANCE
				.createAttributeConstraintsRuleResult();
		ruleResult.setRule("ClassToTableRule");
		ruleResult.setSuccess(true);

		CSP csp = CspFactory.eINSTANCE.createCSP();

		CheckAttributeHelper __helper = new CheckAttributeHelper(__tripleMatch);

		Variable var_t_name = CSPFactoryHelper.eINSTANCE.createVariable("t", true, csp);
		var_t_name.setValue(__helper.getValue("t", "name"));
		var_t_name.setType("String");

		Variable var_c_name = CSPFactoryHelper.eINSTANCE.createVariable("c", true, csp);
		var_c_name.setValue(__helper.getValue("c", "name"));
		var_c_name.setType("String");

		Eq eq0 = new Eq();
		csp.getConstraints().add(eq0);

		eq0.setRuleName("ClassToTableRule");
		eq0.solve(var_c_name, var_t_name);

		if (csp.check()) {
			ruleResult.setSuccess(true);
		} else {
			var_c_name.setBound(false);
			eq0.solve(var_c_name, var_t_name);
			if (csp.check()) {
				ruleResult.setSuccess(true);
				ruleResult.setRequiredChange(true);
				__helper.setValue("c", "name", var_c_name.getValue());
			} else {
				ruleResult.setSuccess(false);
				return ruleResult;
			}
		}

		return ruleResult;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_CC(Match sourceMatch, Match targetMatch) {

		Object[] result1_black = ClassToTableRuleImpl.pattern_ClassToTableRule_24_1_prepare_blackB(this);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		Object[] result1_green = ClassToTableRuleImpl.pattern_ClassToTableRule_24_1_prepare_greenF();
		IsApplicableRuleResult result = (IsApplicableRuleResult) result1_green[0];

		Object[] result2_bindingAndBlack = ClassToTableRuleImpl
				.pattern_ClassToTableRule_24_2_matchsrctrgcontext_bindingAndBlackFFFFBB(sourceMatch, targetMatch);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[sourceMatch] = " + sourceMatch
					+ ", " + "[targetMatch] = " + targetMatch + ".");
		}
		DBTable t = (DBTable) result2_bindingAndBlack[0];
		CDClass c = (CDClass) result2_bindingAndBlack[1];
		DBSchema s = (DBSchema) result2_bindingAndBlack[2];
		CDPackage p = (CDPackage) result2_bindingAndBlack[3];

		Object[] result3_bindingAndBlack = ClassToTableRuleImpl
				.pattern_ClassToTableRule_24_3_solvecsp_bindingAndBlackFBBBBBBB(this, t, c, s, p, sourceMatch,
						targetMatch);
		if (result3_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[t] = " + t + ", " + "[c] = " + c + ", " + "[s] = " + s + ", " + "[p] = " + p + ", "
					+ "[sourceMatch] = " + sourceMatch + ", " + "[targetMatch] = " + targetMatch + ".");
		}
		CSP csp = (CSP) result3_bindingAndBlack[0];
		// 
		if (ClassToTableRuleImpl.pattern_ClassToTableRule_24_4_checkCSP_expressionFB(csp)) {
			// ForEach 
			for (Object[] result5_black : ClassToTableRuleImpl
					.pattern_ClassToTableRule_24_5_matchcorrcontext_blackFBBBB(s, p, sourceMatch, targetMatch)) {
				PackageToSchema p2s = (PackageToSchema) result5_black[0];
				Object[] result5_green = ClassToTableRuleImpl
						.pattern_ClassToTableRule_24_5_matchcorrcontext_greenBBBF(p2s, sourceMatch, targetMatch);
				CCMatch ccMatch = (CCMatch) result5_green[3];

				Object[] result6_black = ClassToTableRuleImpl
						.pattern_ClassToTableRule_24_6_createcorrespondence_blackBBBBB(t, c, s, p, ccMatch);
				if (result6_black == null) {
					throw new RuntimeException(
							"Pattern matching failed." + " Variables: " + "[t] = " + t + ", " + "[c] = " + c + ", "
									+ "[s] = " + s + ", " + "[p] = " + p + ", " + "[ccMatch] = " + ccMatch + ".");
				}
				ClassToTableRuleImpl.pattern_ClassToTableRule_24_6_createcorrespondence_greenBBFB(t, c, ccMatch);
				//nothing ClassToTable c2t = (ClassToTable) result6_green[2];

				Object[] result7_black = ClassToTableRuleImpl
						.pattern_ClassToTableRule_24_7_addtoreturnedresult_blackBB(result, ccMatch);
				if (result7_black == null) {
					throw new RuntimeException("Pattern matching failed." + " Variables: " + "[result] = " + result
							+ ", " + "[ccMatch] = " + ccMatch + ".");
				}
				ClassToTableRuleImpl.pattern_ClassToTableRule_24_7_addtoreturnedresult_greenBB(result, ccMatch);

			}

		} else {
		}
		return ClassToTableRuleImpl.pattern_ClassToTableRule_24_8_expressionFB(result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_CC(DBTable t, CDClass c, DBSchema s, CDPackage p, Match sourceMatch,
			Match targetMatch) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables
		Variable var_c_name = CSPFactoryHelper.eINSTANCE.createVariable("c.name", true, csp);
		var_c_name.setValue(c.getName());
		var_c_name.setType("String");
		Variable var_t_name = CSPFactoryHelper.eINSTANCE.createVariable("t.name", true, csp);
		var_t_name.setValue(t.getName());
		var_t_name.setType("String");

		// Create unbound variables

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_c_name, var_t_name);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_CC(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkDEC_FWD(CDClass c, CDPackage p) {// 
		Object[] result1_black = ClassToTableRuleImpl.pattern_ClassToTableRule_27_1_matchtggpattern_blackBB(c, p);
		if (result1_black != null) {
			return ClassToTableRuleImpl.pattern_ClassToTableRule_27_2_expressionF();
		} else {
			return ClassToTableRuleImpl.pattern_ClassToTableRule_27_3_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkDEC_BWD(DBTable t, DBSchema s) {// 
		Object[] result1_black = ClassToTableRuleImpl.pattern_ClassToTableRule_28_1_matchtggpattern_blackBB(t, s);
		if (result1_black != null) {
			return ClassToTableRuleImpl.pattern_ClassToTableRule_28_2_expressionF();
		} else {
			return ClassToTableRuleImpl.pattern_ClassToTableRule_28_3_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ModelgeneratorRuleResult generateModel(RuleEntryContainer ruleEntryContainer, PackageToSchema p2sParameter) {

		Object[] result1_black = ClassToTableRuleImpl.pattern_ClassToTableRule_29_1_createresult_blackB(this);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		Object[] result1_green = ClassToTableRuleImpl.pattern_ClassToTableRule_29_1_createresult_greenFF();
		IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result1_green[0];
		ModelgeneratorRuleResult ruleResult = (ModelgeneratorRuleResult) result1_green[1];

		// ForEach 
		for (Object[] result2_black : ClassToTableRuleImpl
				.pattern_ClassToTableRule_29_2_isapplicablecore_blackFFFFBB(ruleEntryContainer, ruleResult)) {
			//nothing RuleEntryList p2sList = (RuleEntryList) result2_black[0];
			PackageToSchema p2s = (PackageToSchema) result2_black[1];
			DBSchema s = (DBSchema) result2_black[2];
			CDPackage p = (CDPackage) result2_black[3];

			Object[] result3_bindingAndBlack = ClassToTableRuleImpl
					.pattern_ClassToTableRule_29_3_solveCSP_bindingAndBlackFBBBBBB(this, isApplicableMatch, p2s, s, p,
							ruleResult);
			if (result3_bindingAndBlack == null) {
				throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
						+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[p2s] = " + p2s + ", " + "[s] = " + s
						+ ", " + "[p] = " + p + ", " + "[ruleResult] = " + ruleResult + ".");
			}
			CSP csp = (CSP) result3_bindingAndBlack[0];
			// 
			if (ClassToTableRuleImpl.pattern_ClassToTableRule_29_4_checkCSP_expressionFBB(this, csp)) {
				// 
				Object[] result5_black = ClassToTableRuleImpl.pattern_ClassToTableRule_29_5_checknacs_blackBBB(p2s, s,
						p);
				if (result5_black != null) {

					Object[] result6_black = ClassToTableRuleImpl.pattern_ClassToTableRule_29_6_perform_blackBBBB(p2s,
							s, p, ruleResult);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[p2s] = " + p2s + ", "
								+ "[s] = " + s + ", " + "[p] = " + p + ", " + "[ruleResult] = " + ruleResult + ".");
					}
					ClassToTableRuleImpl.pattern_ClassToTableRule_29_6_perform_greenFFFBBBB(s, p, ruleResult, csp);
					//nothing DBTable t = (DBTable) result6_green[0];
					//nothing CDClass c = (CDClass) result6_green[1];
					//nothing ClassToTable c2t = (ClassToTable) result6_green[2];

				} else {
				}

			} else {
			}

		}
		return ClassToTableRuleImpl.pattern_ClassToTableRule_29_7_expressionFB(ruleResult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP generateModel_solveCsp_BWD(IsApplicableMatch isApplicableMatch, PackageToSchema p2s, DBSchema s,
			CDPackage p, ModelgeneratorRuleResult ruleResult) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables

		// Create unbound variables
		Variable var_c_name = CSPFactoryHelper.eINSTANCE.createVariable("c.name", csp);
		var_c_name.setType("String");
		Variable var_t_name = CSPFactoryHelper.eINSTANCE.createVariable("t.name", csp);
		var_t_name.setType("String");

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_c_name, var_t_name);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("p2s", p2s);
		isApplicableMatch.registerObject("s", s);
		isApplicableMatch.registerObject("p", p);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean generateModel_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case RulesPackage.CLASS_TO_TABLE_RULE___IS_APPROPRIATE_FWD__MATCH_CDCLASS_CDPACKAGE:
			return isAppropriate_FWD((Match) arguments.get(0), (CDClass) arguments.get(1),
					(CDPackage) arguments.get(2));
		case RulesPackage.CLASS_TO_TABLE_RULE___PERFORM_FWD__ISAPPLICABLEMATCH:
			return perform_FWD((IsApplicableMatch) arguments.get(0));
		case RulesPackage.CLASS_TO_TABLE_RULE___IS_APPLICABLE_FWD__MATCH:
			return isApplicable_FWD((Match) arguments.get(0));
		case RulesPackage.CLASS_TO_TABLE_RULE___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_CDCLASS_CDPACKAGE:
			registerObjectsToMatch_FWD((Match) arguments.get(0), (CDClass) arguments.get(1),
					(CDPackage) arguments.get(2));
			return null;
		case RulesPackage.CLASS_TO_TABLE_RULE___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_CDCLASS_CDPACKAGE:
			return isAppropriate_solveCsp_FWD((Match) arguments.get(0), (CDClass) arguments.get(1),
					(CDPackage) arguments.get(2));
		case RulesPackage.CLASS_TO_TABLE_RULE___IS_APPROPRIATE_CHECK_CSP_FWD__CSP:
			return isAppropriate_checkCsp_FWD((CSP) arguments.get(0));
		case RulesPackage.CLASS_TO_TABLE_RULE___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_CDCLASS_PACKAGETOSCHEMA_DBSCHEMA_CDPACKAGE:
			return isApplicable_solveCsp_FWD((IsApplicableMatch) arguments.get(0), (CDClass) arguments.get(1),
					(PackageToSchema) arguments.get(2), (DBSchema) arguments.get(3), (CDPackage) arguments.get(4));
		case RulesPackage.CLASS_TO_TABLE_RULE___IS_APPLICABLE_CHECK_CSP_FWD__CSP:
			return isApplicable_checkCsp_FWD((CSP) arguments.get(0));
		case RulesPackage.CLASS_TO_TABLE_RULE___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT:
			registerObjects_FWD((PerformRuleResult) arguments.get(0), (EObject) arguments.get(1),
					(EObject) arguments.get(2), (EObject) arguments.get(3), (EObject) arguments.get(4),
					(EObject) arguments.get(5), (EObject) arguments.get(6));
			return null;
		case RulesPackage.CLASS_TO_TABLE_RULE___CHECK_TYPES_FWD__MATCH:
			return checkTypes_FWD((Match) arguments.get(0));
		case RulesPackage.CLASS_TO_TABLE_RULE___IS_APPROPRIATE_BWD__MATCH_DBTABLE_DBSCHEMA:
			return isAppropriate_BWD((Match) arguments.get(0), (DBTable) arguments.get(1), (DBSchema) arguments.get(2));
		case RulesPackage.CLASS_TO_TABLE_RULE___PERFORM_BWD__ISAPPLICABLEMATCH:
			return perform_BWD((IsApplicableMatch) arguments.get(0));
		case RulesPackage.CLASS_TO_TABLE_RULE___IS_APPLICABLE_BWD__MATCH:
			return isApplicable_BWD((Match) arguments.get(0));
		case RulesPackage.CLASS_TO_TABLE_RULE___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_DBTABLE_DBSCHEMA:
			registerObjectsToMatch_BWD((Match) arguments.get(0), (DBTable) arguments.get(1),
					(DBSchema) arguments.get(2));
			return null;
		case RulesPackage.CLASS_TO_TABLE_RULE___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_DBTABLE_DBSCHEMA:
			return isAppropriate_solveCsp_BWD((Match) arguments.get(0), (DBTable) arguments.get(1),
					(DBSchema) arguments.get(2));
		case RulesPackage.CLASS_TO_TABLE_RULE___IS_APPROPRIATE_CHECK_CSP_BWD__CSP:
			return isAppropriate_checkCsp_BWD((CSP) arguments.get(0));
		case RulesPackage.CLASS_TO_TABLE_RULE___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_DBTABLE_PACKAGETOSCHEMA_DBSCHEMA_CDPACKAGE:
			return isApplicable_solveCsp_BWD((IsApplicableMatch) arguments.get(0), (DBTable) arguments.get(1),
					(PackageToSchema) arguments.get(2), (DBSchema) arguments.get(3), (CDPackage) arguments.get(4));
		case RulesPackage.CLASS_TO_TABLE_RULE___IS_APPLICABLE_CHECK_CSP_BWD__CSP:
			return isApplicable_checkCsp_BWD((CSP) arguments.get(0));
		case RulesPackage.CLASS_TO_TABLE_RULE___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT:
			registerObjects_BWD((PerformRuleResult) arguments.get(0), (EObject) arguments.get(1),
					(EObject) arguments.get(2), (EObject) arguments.get(3), (EObject) arguments.get(4),
					(EObject) arguments.get(5), (EObject) arguments.get(6));
			return null;
		case RulesPackage.CLASS_TO_TABLE_RULE___CHECK_TYPES_BWD__MATCH:
			return checkTypes_BWD((Match) arguments.get(0));
		case RulesPackage.CLASS_TO_TABLE_RULE___IS_APPROPRIATE_FWD_EMOFLON_EDGE_1__EMOFLONEDGE:
			return isAppropriate_FWD_EMoflonEdge_1((EMoflonEdge) arguments.get(0));
		case RulesPackage.CLASS_TO_TABLE_RULE___IS_APPROPRIATE_BWD_EMOFLON_EDGE_1__EMOFLONEDGE:
			return isAppropriate_BWD_EMoflonEdge_1((EMoflonEdge) arguments.get(0));
		case RulesPackage.CLASS_TO_TABLE_RULE___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH:
			return checkAttributes_FWD((TripleMatch) arguments.get(0));
		case RulesPackage.CLASS_TO_TABLE_RULE___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH:
			return checkAttributes_BWD((TripleMatch) arguments.get(0));
		case RulesPackage.CLASS_TO_TABLE_RULE___IS_APPLICABLE_CC__MATCH_MATCH:
			return isApplicable_CC((Match) arguments.get(0), (Match) arguments.get(1));
		case RulesPackage.CLASS_TO_TABLE_RULE___IS_APPLICABLE_SOLVE_CSP_CC__DBTABLE_CDCLASS_DBSCHEMA_CDPACKAGE_MATCH_MATCH:
			return isApplicable_solveCsp_CC((DBTable) arguments.get(0), (CDClass) arguments.get(1),
					(DBSchema) arguments.get(2), (CDPackage) arguments.get(3), (Match) arguments.get(4),
					(Match) arguments.get(5));
		case RulesPackage.CLASS_TO_TABLE_RULE___IS_APPLICABLE_CHECK_CSP_CC__CSP:
			return isApplicable_checkCsp_CC((CSP) arguments.get(0));
		case RulesPackage.CLASS_TO_TABLE_RULE___CHECK_DEC_FWD__CDCLASS_CDPACKAGE:
			return checkDEC_FWD((CDClass) arguments.get(0), (CDPackage) arguments.get(1));
		case RulesPackage.CLASS_TO_TABLE_RULE___CHECK_DEC_BWD__DBTABLE_DBSCHEMA:
			return checkDEC_BWD((DBTable) arguments.get(0), (DBSchema) arguments.get(1));
		case RulesPackage.CLASS_TO_TABLE_RULE___GENERATE_MODEL__RULEENTRYCONTAINER_PACKAGETOSCHEMA:
			return generateModel((RuleEntryContainer) arguments.get(0), (PackageToSchema) arguments.get(1));
		case RulesPackage.CLASS_TO_TABLE_RULE___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_PACKAGETOSCHEMA_DBSCHEMA_CDPACKAGE_MODELGENERATORRULERESULT:
			return generateModel_solveCsp_BWD((IsApplicableMatch) arguments.get(0), (PackageToSchema) arguments.get(1),
					(DBSchema) arguments.get(2), (CDPackage) arguments.get(3),
					(ModelgeneratorRuleResult) arguments.get(4));
		case RulesPackage.CLASS_TO_TABLE_RULE___GENERATE_MODEL_CHECK_CSP_BWD__CSP:
			return generateModel_checkCsp_BWD((CSP) arguments.get(0));
		}
		return super.eInvoke(operationID, arguments);
	}

	public static final Object[] pattern_ClassToTableRule_0_1_initialbindings_blackBBBB(ClassToTableRule _this,
			Match match, CDClass c, CDPackage p) {
		return new Object[] { _this, match, c, p };
	}

	public static final Object[] pattern_ClassToTableRule_0_2_SolveCSP_bindingFBBBB(ClassToTableRule _this, Match match,
			CDClass c, CDPackage p) {
		CSP _localVariable_0 = _this.isAppropriate_solveCsp_FWD(match, c, p);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, match, c, p };
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_0_2_SolveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_ClassToTableRule_0_2_SolveCSP_bindingAndBlackFBBBB(ClassToTableRule _this,
			Match match, CDClass c, CDPackage p) {
		Object[] result_pattern_ClassToTableRule_0_2_SolveCSP_binding = pattern_ClassToTableRule_0_2_SolveCSP_bindingFBBBB(
				_this, match, c, p);
		if (result_pattern_ClassToTableRule_0_2_SolveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_ClassToTableRule_0_2_SolveCSP_binding[0];

			Object[] result_pattern_ClassToTableRule_0_2_SolveCSP_black = pattern_ClassToTableRule_0_2_SolveCSP_blackB(
					csp);
			if (result_pattern_ClassToTableRule_0_2_SolveCSP_black != null) {

				return new Object[] { csp, _this, match, c, p };
			}
		}
		return null;
	}

	public static final boolean pattern_ClassToTableRule_0_3_CheckCSP_expressionFBB(ClassToTableRule _this, CSP csp) {
		boolean _localVariable_0 = _this.isAppropriate_checkCsp_FWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_0_4_collectelementstobetranslated_blackBBB(Match match,
			CDClass c, CDPackage p) {
		return new Object[] { match, c, p };
	}

	public static final Object[] pattern_ClassToTableRule_0_4_collectelementstobetranslated_greenBBBF(Match match,
			CDClass c, CDPackage p) {
		EMoflonEdge p__c____classes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getToBeTranslatedNodes().add(c);
		String p__c____classes_name_prime = "classes";
		p__c____classes.setSrc(p);
		p__c____classes.setTrg(c);
		match.getToBeTranslatedEdges().add(p__c____classes);
		p__c____classes.setName(p__c____classes_name_prime);
		return new Object[] { match, c, p, p__c____classes };
	}

	public static final Object[] pattern_ClassToTableRule_0_5_collectcontextelements_blackBBB(Match match, CDClass c,
			CDPackage p) {
		return new Object[] { match, c, p };
	}

	public static final Object[] pattern_ClassToTableRule_0_5_collectcontextelements_greenBB(Match match, CDPackage p) {
		match.getContextNodes().add(p);
		return new Object[] { match, p };
	}

	public static final void pattern_ClassToTableRule_0_6_registerobjectstomatch_expressionBBBB(ClassToTableRule _this,
			Match match, CDClass c, CDPackage p) {
		_this.registerObjectsToMatch_FWD(match, c, p);

	}

	public static final boolean pattern_ClassToTableRule_0_7_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_ClassToTableRule_0_8_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_1_1_performtransformation_bindingFFFFB(
			IsApplicableMatch isApplicableMatch) {
		EObject _localVariable_0 = isApplicableMatch.getObject("c");
		EObject _localVariable_1 = isApplicableMatch.getObject("p2s");
		EObject _localVariable_2 = isApplicableMatch.getObject("s");
		EObject _localVariable_3 = isApplicableMatch.getObject("p");
		EObject tmpC = _localVariable_0;
		EObject tmpP2s = _localVariable_1;
		EObject tmpS = _localVariable_2;
		EObject tmpP = _localVariable_3;
		if (tmpC instanceof CDClass) {
			CDClass c = (CDClass) tmpC;
			if (tmpP2s instanceof PackageToSchema) {
				PackageToSchema p2s = (PackageToSchema) tmpP2s;
				if (tmpS instanceof DBSchema) {
					DBSchema s = (DBSchema) tmpS;
					if (tmpP instanceof CDPackage) {
						CDPackage p = (CDPackage) tmpP;
						return new Object[] { c, p2s, s, p, isApplicableMatch };
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_1_1_performtransformation_blackBBBBFBB(CDClass c,
			PackageToSchema p2s, DBSchema s, CDPackage p, ClassToTableRule _this, IsApplicableMatch isApplicableMatch) {
		for (EObject tmpCsp : isApplicableMatch.getAttributeInfo()) {
			if (tmpCsp instanceof CSP) {
				CSP csp = (CSP) tmpCsp;
				return new Object[] { c, p2s, s, p, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_1_1_performtransformation_bindingAndBlackFFFFFBB(
			ClassToTableRule _this, IsApplicableMatch isApplicableMatch) {
		Object[] result_pattern_ClassToTableRule_1_1_performtransformation_binding = pattern_ClassToTableRule_1_1_performtransformation_bindingFFFFB(
				isApplicableMatch);
		if (result_pattern_ClassToTableRule_1_1_performtransformation_binding != null) {
			CDClass c = (CDClass) result_pattern_ClassToTableRule_1_1_performtransformation_binding[0];
			PackageToSchema p2s = (PackageToSchema) result_pattern_ClassToTableRule_1_1_performtransformation_binding[1];
			DBSchema s = (DBSchema) result_pattern_ClassToTableRule_1_1_performtransformation_binding[2];
			CDPackage p = (CDPackage) result_pattern_ClassToTableRule_1_1_performtransformation_binding[3];

			Object[] result_pattern_ClassToTableRule_1_1_performtransformation_black = pattern_ClassToTableRule_1_1_performtransformation_blackBBBBFBB(
					c, p2s, s, p, _this, isApplicableMatch);
			if (result_pattern_ClassToTableRule_1_1_performtransformation_black != null) {
				CSP csp = (CSP) result_pattern_ClassToTableRule_1_1_performtransformation_black[4];

				return new Object[] { c, p2s, s, p, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_1_1_performtransformation_greenFBFBB(CDClass c, DBSchema s,
			CSP csp) {
		DBTable t = DatabaseSchemataFactory.eINSTANCE.createDBTable();
		ClassToTable c2t = CDToDBFactory.eINSTANCE.createClassToTable();
		Object _localVariable_0 = csp.getValue("t", "name");
		s.getTables().add(t);
		c2t.setTarget(t);
		c2t.setSource(c);
		String t_name_prime = (String) _localVariable_0;
		t.setName(t_name_prime);
		return new Object[] { t, c, c2t, s, csp };
	}

	public static final Object[] pattern_ClassToTableRule_1_2_collecttranslatedelements_blackBBB(DBTable t, CDClass c,
			ClassToTable c2t) {
		return new Object[] { t, c, c2t };
	}

	public static final Object[] pattern_ClassToTableRule_1_2_collecttranslatedelements_greenFBBB(DBTable t, CDClass c,
			ClassToTable c2t) {
		PerformRuleResult ruleresult = RuntimeFactory.eINSTANCE.createPerformRuleResult();
		ruleresult.getCreatedElements().add(t);
		ruleresult.getTranslatedElements().add(c);
		ruleresult.getCreatedLinkElements().add(c2t);
		return new Object[] { ruleresult, t, c, c2t };
	}

	public static final Object[] pattern_ClassToTableRule_1_3_bookkeepingforedges_blackBBBBBBB(
			PerformRuleResult ruleresult, EObject t, EObject c, EObject c2t, EObject p2s, EObject s, EObject p) {
		if (!c.equals(t)) {
			if (!c.equals(c2t)) {
				if (!c.equals(p2s)) {
					if (!c.equals(s)) {
						if (!c.equals(p)) {
							if (!c2t.equals(t)) {
								if (!c2t.equals(p2s)) {
									if (!c2t.equals(s)) {
										if (!c2t.equals(p)) {
											if (!p2s.equals(t)) {
												if (!p2s.equals(s)) {
													if (!s.equals(t)) {
														if (!p.equals(t)) {
															if (!p.equals(p2s)) {
																if (!p.equals(s)) {
																	return new Object[] { ruleresult, t, c, c2t, p2s, s,
																			p };
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_1_3_bookkeepingforedges_greenBBBBBBFFFF(
			PerformRuleResult ruleresult, EObject t, EObject c, EObject c2t, EObject s, EObject p) {
		EMoflonEdge c2t__t____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s__t____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge c2t__c____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p__c____classes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String ruleresult_ruleName_prime = "ClassToTableRule";
		String c2t__t____target_name_prime = "target";
		String s__t____tables_name_prime = "tables";
		String c2t__c____source_name_prime = "source";
		String p__c____classes_name_prime = "classes";
		c2t__t____target.setSrc(c2t);
		c2t__t____target.setTrg(t);
		ruleresult.getCreatedEdges().add(c2t__t____target);
		s__t____tables.setSrc(s);
		s__t____tables.setTrg(t);
		ruleresult.getCreatedEdges().add(s__t____tables);
		c2t__c____source.setSrc(c2t);
		c2t__c____source.setTrg(c);
		ruleresult.getCreatedEdges().add(c2t__c____source);
		p__c____classes.setSrc(p);
		p__c____classes.setTrg(c);
		ruleresult.getTranslatedEdges().add(p__c____classes);
		ruleresult.setRuleName(ruleresult_ruleName_prime);
		c2t__t____target.setName(c2t__t____target_name_prime);
		s__t____tables.setName(s__t____tables_name_prime);
		c2t__c____source.setName(c2t__c____source_name_prime);
		p__c____classes.setName(p__c____classes_name_prime);
		return new Object[] { ruleresult, t, c, c2t, s, p, c2t__t____target, s__t____tables, c2t__c____source,
				p__c____classes };
	}

	public static final void pattern_ClassToTableRule_1_5_registerobjects_expressionBBBBBBBB(ClassToTableRule _this,
			PerformRuleResult ruleresult, EObject t, EObject c, EObject c2t, EObject p2s, EObject s, EObject p) {
		_this.registerObjects_FWD(ruleresult, t, c, c2t, p2s, s, p);

	}

	public static final PerformRuleResult pattern_ClassToTableRule_1_6_expressionFB(PerformRuleResult ruleresult) {
		PerformRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_2_1_preparereturnvalue_bindingFB(ClassToTableRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass eClass = _localVariable_0;
		if (eClass != null) {
			return new Object[] { eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_2_1_preparereturnvalue_blackFBB(EClass eClass,
			ClassToTableRule _this) {
		for (EOperation performOperation : eClass.getEOperations()) {
			String performOperation_name = performOperation.getName();
			if (performOperation_name.equals("perform_FWD")) {
				return new Object[] { performOperation, eClass, _this };
			}

		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_2_1_preparereturnvalue_bindingAndBlackFFB(
			ClassToTableRule _this) {
		Object[] result_pattern_ClassToTableRule_2_1_preparereturnvalue_binding = pattern_ClassToTableRule_2_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_ClassToTableRule_2_1_preparereturnvalue_binding != null) {
			EClass eClass = (EClass) result_pattern_ClassToTableRule_2_1_preparereturnvalue_binding[0];

			Object[] result_pattern_ClassToTableRule_2_1_preparereturnvalue_black = pattern_ClassToTableRule_2_1_preparereturnvalue_blackFBB(
					eClass, _this);
			if (result_pattern_ClassToTableRule_2_1_preparereturnvalue_black != null) {
				EOperation performOperation = (EOperation) result_pattern_ClassToTableRule_2_1_preparereturnvalue_black[0];

				return new Object[] { performOperation, eClass, _this };
			}
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_2_1_preparereturnvalue_greenBF(EOperation performOperation) {
		IsApplicableRuleResult ruleresult = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		boolean ruleresult_success_prime = Boolean.valueOf(false);
		String ruleresult_rule_prime = "ClassToTableRule";
		ruleresult.setPerformOperation(performOperation);
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		ruleresult.setRule(ruleresult_rule_prime);
		return new Object[] { performOperation, ruleresult };
	}

	public static final Object[] pattern_ClassToTableRule_2_2_corematch_bindingFFB(Match match) {
		EObject _localVariable_0 = match.getObject("c");
		EObject _localVariable_1 = match.getObject("p");
		EObject tmpC = _localVariable_0;
		EObject tmpP = _localVariable_1;
		if (tmpC instanceof CDClass) {
			CDClass c = (CDClass) tmpC;
			if (tmpP instanceof CDPackage) {
				CDPackage p = (CDPackage) tmpP;
				return new Object[] { c, p, match };
			}
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_ClassToTableRule_2_2_corematch_blackBFFBB(CDClass c, CDPackage p,
			Match match) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		for (PackageToSchema p2s : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(p,
				PackageToSchema.class, "source")) {
			DBSchema s = p2s.getTarget();
			if (s != null) {
				_result.add(new Object[] { c, p2s, s, p, match });
			}

		}
		return _result;
	}

	public static final Iterable<Object[]> pattern_ClassToTableRule_2_3_findcontext_blackBBBB(CDClass c,
			PackageToSchema p2s, DBSchema s, CDPackage p) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (s.equals(p2s.getTarget())) {
			if (p.getClasses().contains(c)) {
				if (p.equals(p2s.getSource())) {
					_result.add(new Object[] { c, p2s, s, p });
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_2_3_findcontext_greenBBBBFFFF(CDClass c, PackageToSchema p2s,
			DBSchema s, CDPackage p) {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		EMoflonEdge p2s__s____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p__c____classes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p2s__p____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String p2s__s____target_name_prime = "target";
		String p__c____classes_name_prime = "classes";
		String p2s__p____source_name_prime = "source";
		isApplicableMatch.getAllContextElements().add(c);
		isApplicableMatch.getAllContextElements().add(p2s);
		isApplicableMatch.getAllContextElements().add(s);
		isApplicableMatch.getAllContextElements().add(p);
		p2s__s____target.setSrc(p2s);
		p2s__s____target.setTrg(s);
		isApplicableMatch.getAllContextElements().add(p2s__s____target);
		p__c____classes.setSrc(p);
		p__c____classes.setTrg(c);
		isApplicableMatch.getAllContextElements().add(p__c____classes);
		p2s__p____source.setSrc(p2s);
		p2s__p____source.setTrg(p);
		isApplicableMatch.getAllContextElements().add(p2s__p____source);
		p2s__s____target.setName(p2s__s____target_name_prime);
		p__c____classes.setName(p__c____classes_name_prime);
		p2s__p____source.setName(p2s__p____source_name_prime);
		return new Object[] { c, p2s, s, p, isApplicableMatch, p2s__s____target, p__c____classes, p2s__p____source };
	}

	public static final Object[] pattern_ClassToTableRule_2_4_solveCSP_bindingFBBBBBB(ClassToTableRule _this,
			IsApplicableMatch isApplicableMatch, CDClass c, PackageToSchema p2s, DBSchema s, CDPackage p) {
		CSP _localVariable_0 = _this.isApplicable_solveCsp_FWD(isApplicableMatch, c, p2s, s, p);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, c, p2s, s, p };
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_2_4_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_ClassToTableRule_2_4_solveCSP_bindingAndBlackFBBBBBB(ClassToTableRule _this,
			IsApplicableMatch isApplicableMatch, CDClass c, PackageToSchema p2s, DBSchema s, CDPackage p) {
		Object[] result_pattern_ClassToTableRule_2_4_solveCSP_binding = pattern_ClassToTableRule_2_4_solveCSP_bindingFBBBBBB(
				_this, isApplicableMatch, c, p2s, s, p);
		if (result_pattern_ClassToTableRule_2_4_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_ClassToTableRule_2_4_solveCSP_binding[0];

			Object[] result_pattern_ClassToTableRule_2_4_solveCSP_black = pattern_ClassToTableRule_2_4_solveCSP_blackB(
					csp);
			if (result_pattern_ClassToTableRule_2_4_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, c, p2s, s, p };
			}
		}
		return null;
	}

	public static final boolean pattern_ClassToTableRule_2_5_checkCSP_expressionFBB(ClassToTableRule _this, CSP csp) {
		boolean _localVariable_0 = _this.isApplicable_checkCsp_FWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_2_6_addmatchtoruleresult_blackBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final Object[] pattern_ClassToTableRule_2_6_addmatchtoruleresult_greenBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		ruleresult.getIsApplicableMatch().add(isApplicableMatch);
		boolean ruleresult_success_prime = Boolean.valueOf(true);
		String isApplicableMatch_ruleName_prime = "ClassToTableRule";
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		isApplicableMatch.setRuleName(isApplicableMatch_ruleName_prime);
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final IsApplicableRuleResult pattern_ClassToTableRule_2_7_expressionFB(
			IsApplicableRuleResult ruleresult) {
		IsApplicableRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_10_1_initialbindings_blackBBBB(ClassToTableRule _this,
			Match match, DBTable t, DBSchema s) {
		return new Object[] { _this, match, t, s };
	}

	public static final Object[] pattern_ClassToTableRule_10_2_SolveCSP_bindingFBBBB(ClassToTableRule _this,
			Match match, DBTable t, DBSchema s) {
		CSP _localVariable_0 = _this.isAppropriate_solveCsp_BWD(match, t, s);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, match, t, s };
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_10_2_SolveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_ClassToTableRule_10_2_SolveCSP_bindingAndBlackFBBBB(ClassToTableRule _this,
			Match match, DBTable t, DBSchema s) {
		Object[] result_pattern_ClassToTableRule_10_2_SolveCSP_binding = pattern_ClassToTableRule_10_2_SolveCSP_bindingFBBBB(
				_this, match, t, s);
		if (result_pattern_ClassToTableRule_10_2_SolveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_ClassToTableRule_10_2_SolveCSP_binding[0];

			Object[] result_pattern_ClassToTableRule_10_2_SolveCSP_black = pattern_ClassToTableRule_10_2_SolveCSP_blackB(
					csp);
			if (result_pattern_ClassToTableRule_10_2_SolveCSP_black != null) {

				return new Object[] { csp, _this, match, t, s };
			}
		}
		return null;
	}

	public static final boolean pattern_ClassToTableRule_10_3_CheckCSP_expressionFBB(ClassToTableRule _this, CSP csp) {
		boolean _localVariable_0 = _this.isAppropriate_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_10_4_collectelementstobetranslated_blackBBB(Match match,
			DBTable t, DBSchema s) {
		return new Object[] { match, t, s };
	}

	public static final Object[] pattern_ClassToTableRule_10_4_collectelementstobetranslated_greenBBBF(Match match,
			DBTable t, DBSchema s) {
		EMoflonEdge s__t____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getToBeTranslatedNodes().add(t);
		String s__t____tables_name_prime = "tables";
		s__t____tables.setSrc(s);
		s__t____tables.setTrg(t);
		match.getToBeTranslatedEdges().add(s__t____tables);
		s__t____tables.setName(s__t____tables_name_prime);
		return new Object[] { match, t, s, s__t____tables };
	}

	public static final Object[] pattern_ClassToTableRule_10_5_collectcontextelements_blackBBB(Match match, DBTable t,
			DBSchema s) {
		return new Object[] { match, t, s };
	}

	public static final Object[] pattern_ClassToTableRule_10_5_collectcontextelements_greenBB(Match match, DBSchema s) {
		match.getContextNodes().add(s);
		return new Object[] { match, s };
	}

	public static final void pattern_ClassToTableRule_10_6_registerobjectstomatch_expressionBBBB(ClassToTableRule _this,
			Match match, DBTable t, DBSchema s) {
		_this.registerObjectsToMatch_BWD(match, t, s);

	}

	public static final boolean pattern_ClassToTableRule_10_7_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_ClassToTableRule_10_8_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_11_1_performtransformation_bindingFFFFB(
			IsApplicableMatch isApplicableMatch) {
		EObject _localVariable_0 = isApplicableMatch.getObject("t");
		EObject _localVariable_1 = isApplicableMatch.getObject("p2s");
		EObject _localVariable_2 = isApplicableMatch.getObject("s");
		EObject _localVariable_3 = isApplicableMatch.getObject("p");
		EObject tmpT = _localVariable_0;
		EObject tmpP2s = _localVariable_1;
		EObject tmpS = _localVariable_2;
		EObject tmpP = _localVariable_3;
		if (tmpT instanceof DBTable) {
			DBTable t = (DBTable) tmpT;
			if (tmpP2s instanceof PackageToSchema) {
				PackageToSchema p2s = (PackageToSchema) tmpP2s;
				if (tmpS instanceof DBSchema) {
					DBSchema s = (DBSchema) tmpS;
					if (tmpP instanceof CDPackage) {
						CDPackage p = (CDPackage) tmpP;
						return new Object[] { t, p2s, s, p, isApplicableMatch };
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_11_1_performtransformation_blackBBBBFBB(DBTable t,
			PackageToSchema p2s, DBSchema s, CDPackage p, ClassToTableRule _this, IsApplicableMatch isApplicableMatch) {
		for (EObject tmpCsp : isApplicableMatch.getAttributeInfo()) {
			if (tmpCsp instanceof CSP) {
				CSP csp = (CSP) tmpCsp;
				return new Object[] { t, p2s, s, p, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_11_1_performtransformation_bindingAndBlackFFFFFBB(
			ClassToTableRule _this, IsApplicableMatch isApplicableMatch) {
		Object[] result_pattern_ClassToTableRule_11_1_performtransformation_binding = pattern_ClassToTableRule_11_1_performtransformation_bindingFFFFB(
				isApplicableMatch);
		if (result_pattern_ClassToTableRule_11_1_performtransformation_binding != null) {
			DBTable t = (DBTable) result_pattern_ClassToTableRule_11_1_performtransformation_binding[0];
			PackageToSchema p2s = (PackageToSchema) result_pattern_ClassToTableRule_11_1_performtransformation_binding[1];
			DBSchema s = (DBSchema) result_pattern_ClassToTableRule_11_1_performtransformation_binding[2];
			CDPackage p = (CDPackage) result_pattern_ClassToTableRule_11_1_performtransformation_binding[3];

			Object[] result_pattern_ClassToTableRule_11_1_performtransformation_black = pattern_ClassToTableRule_11_1_performtransformation_blackBBBBFBB(
					t, p2s, s, p, _this, isApplicableMatch);
			if (result_pattern_ClassToTableRule_11_1_performtransformation_black != null) {
				CSP csp = (CSP) result_pattern_ClassToTableRule_11_1_performtransformation_black[4];

				return new Object[] { t, p2s, s, p, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_11_1_performtransformation_greenBFFBB(DBTable t, CDPackage p,
			CSP csp) {
		CDClass c = ClassDiagramsFactory.eINSTANCE.createCDClass();
		ClassToTable c2t = CDToDBFactory.eINSTANCE.createClassToTable();
		Object _localVariable_0 = csp.getValue("c", "name");
		p.getClasses().add(c);
		c2t.setTarget(t);
		c2t.setSource(c);
		String c_name_prime = (String) _localVariable_0;
		c.setName(c_name_prime);
		return new Object[] { t, c, c2t, p, csp };
	}

	public static final Object[] pattern_ClassToTableRule_11_2_collecttranslatedelements_blackBBB(DBTable t, CDClass c,
			ClassToTable c2t) {
		return new Object[] { t, c, c2t };
	}

	public static final Object[] pattern_ClassToTableRule_11_2_collecttranslatedelements_greenFBBB(DBTable t, CDClass c,
			ClassToTable c2t) {
		PerformRuleResult ruleresult = RuntimeFactory.eINSTANCE.createPerformRuleResult();
		ruleresult.getTranslatedElements().add(t);
		ruleresult.getCreatedElements().add(c);
		ruleresult.getCreatedLinkElements().add(c2t);
		return new Object[] { ruleresult, t, c, c2t };
	}

	public static final Object[] pattern_ClassToTableRule_11_3_bookkeepingforedges_blackBBBBBBB(
			PerformRuleResult ruleresult, EObject t, EObject c, EObject c2t, EObject p2s, EObject s, EObject p) {
		if (!c.equals(t)) {
			if (!c.equals(c2t)) {
				if (!c.equals(p2s)) {
					if (!c.equals(s)) {
						if (!c.equals(p)) {
							if (!c2t.equals(t)) {
								if (!c2t.equals(p2s)) {
									if (!c2t.equals(s)) {
										if (!c2t.equals(p)) {
											if (!p2s.equals(t)) {
												if (!p2s.equals(s)) {
													if (!s.equals(t)) {
														if (!p.equals(t)) {
															if (!p.equals(p2s)) {
																if (!p.equals(s)) {
																	return new Object[] { ruleresult, t, c, c2t, p2s, s,
																			p };
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_11_3_bookkeepingforedges_greenBBBBBBFFFF(
			PerformRuleResult ruleresult, EObject t, EObject c, EObject c2t, EObject s, EObject p) {
		EMoflonEdge c2t__t____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s__t____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge c2t__c____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p__c____classes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String ruleresult_ruleName_prime = "ClassToTableRule";
		String c2t__t____target_name_prime = "target";
		String s__t____tables_name_prime = "tables";
		String c2t__c____source_name_prime = "source";
		String p__c____classes_name_prime = "classes";
		c2t__t____target.setSrc(c2t);
		c2t__t____target.setTrg(t);
		ruleresult.getCreatedEdges().add(c2t__t____target);
		s__t____tables.setSrc(s);
		s__t____tables.setTrg(t);
		ruleresult.getTranslatedEdges().add(s__t____tables);
		c2t__c____source.setSrc(c2t);
		c2t__c____source.setTrg(c);
		ruleresult.getCreatedEdges().add(c2t__c____source);
		p__c____classes.setSrc(p);
		p__c____classes.setTrg(c);
		ruleresult.getCreatedEdges().add(p__c____classes);
		ruleresult.setRuleName(ruleresult_ruleName_prime);
		c2t__t____target.setName(c2t__t____target_name_prime);
		s__t____tables.setName(s__t____tables_name_prime);
		c2t__c____source.setName(c2t__c____source_name_prime);
		p__c____classes.setName(p__c____classes_name_prime);
		return new Object[] { ruleresult, t, c, c2t, s, p, c2t__t____target, s__t____tables, c2t__c____source,
				p__c____classes };
	}

	public static final void pattern_ClassToTableRule_11_5_registerobjects_expressionBBBBBBBB(ClassToTableRule _this,
			PerformRuleResult ruleresult, EObject t, EObject c, EObject c2t, EObject p2s, EObject s, EObject p) {
		_this.registerObjects_BWD(ruleresult, t, c, c2t, p2s, s, p);

	}

	public static final PerformRuleResult pattern_ClassToTableRule_11_6_expressionFB(PerformRuleResult ruleresult) {
		PerformRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_12_1_preparereturnvalue_bindingFB(ClassToTableRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass eClass = _localVariable_0;
		if (eClass != null) {
			return new Object[] { eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_12_1_preparereturnvalue_blackFBB(EClass eClass,
			ClassToTableRule _this) {
		for (EOperation performOperation : eClass.getEOperations()) {
			String performOperation_name = performOperation.getName();
			if (performOperation_name.equals("perform_BWD")) {
				return new Object[] { performOperation, eClass, _this };
			}

		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_12_1_preparereturnvalue_bindingAndBlackFFB(
			ClassToTableRule _this) {
		Object[] result_pattern_ClassToTableRule_12_1_preparereturnvalue_binding = pattern_ClassToTableRule_12_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_ClassToTableRule_12_1_preparereturnvalue_binding != null) {
			EClass eClass = (EClass) result_pattern_ClassToTableRule_12_1_preparereturnvalue_binding[0];

			Object[] result_pattern_ClassToTableRule_12_1_preparereturnvalue_black = pattern_ClassToTableRule_12_1_preparereturnvalue_blackFBB(
					eClass, _this);
			if (result_pattern_ClassToTableRule_12_1_preparereturnvalue_black != null) {
				EOperation performOperation = (EOperation) result_pattern_ClassToTableRule_12_1_preparereturnvalue_black[0];

				return new Object[] { performOperation, eClass, _this };
			}
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_12_1_preparereturnvalue_greenBF(EOperation performOperation) {
		IsApplicableRuleResult ruleresult = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		boolean ruleresult_success_prime = Boolean.valueOf(false);
		String ruleresult_rule_prime = "ClassToTableRule";
		ruleresult.setPerformOperation(performOperation);
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		ruleresult.setRule(ruleresult_rule_prime);
		return new Object[] { performOperation, ruleresult };
	}

	public static final Object[] pattern_ClassToTableRule_12_2_corematch_bindingFFB(Match match) {
		EObject _localVariable_0 = match.getObject("t");
		EObject _localVariable_1 = match.getObject("s");
		EObject tmpT = _localVariable_0;
		EObject tmpS = _localVariable_1;
		if (tmpT instanceof DBTable) {
			DBTable t = (DBTable) tmpT;
			if (tmpS instanceof DBSchema) {
				DBSchema s = (DBSchema) tmpS;
				return new Object[] { t, s, match };
			}
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_ClassToTableRule_12_2_corematch_blackBFBFB(DBTable t, DBSchema s,
			Match match) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		for (PackageToSchema p2s : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(s,
				PackageToSchema.class, "target")) {
			CDPackage p = p2s.getSource();
			if (p != null) {
				_result.add(new Object[] { t, p2s, s, p, match });
			}

		}
		return _result;
	}

	public static final Iterable<Object[]> pattern_ClassToTableRule_12_3_findcontext_blackBBBB(DBTable t,
			PackageToSchema p2s, DBSchema s, CDPackage p) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (s.getTables().contains(t)) {
			if (s.equals(p2s.getTarget())) {
				if (p.equals(p2s.getSource())) {
					_result.add(new Object[] { t, p2s, s, p });
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_12_3_findcontext_greenBBBBFFFF(DBTable t, PackageToSchema p2s,
			DBSchema s, CDPackage p) {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		EMoflonEdge s__t____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p2s__s____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p2s__p____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String s__t____tables_name_prime = "tables";
		String p2s__s____target_name_prime = "target";
		String p2s__p____source_name_prime = "source";
		isApplicableMatch.getAllContextElements().add(t);
		isApplicableMatch.getAllContextElements().add(p2s);
		isApplicableMatch.getAllContextElements().add(s);
		isApplicableMatch.getAllContextElements().add(p);
		s__t____tables.setSrc(s);
		s__t____tables.setTrg(t);
		isApplicableMatch.getAllContextElements().add(s__t____tables);
		p2s__s____target.setSrc(p2s);
		p2s__s____target.setTrg(s);
		isApplicableMatch.getAllContextElements().add(p2s__s____target);
		p2s__p____source.setSrc(p2s);
		p2s__p____source.setTrg(p);
		isApplicableMatch.getAllContextElements().add(p2s__p____source);
		s__t____tables.setName(s__t____tables_name_prime);
		p2s__s____target.setName(p2s__s____target_name_prime);
		p2s__p____source.setName(p2s__p____source_name_prime);
		return new Object[] { t, p2s, s, p, isApplicableMatch, s__t____tables, p2s__s____target, p2s__p____source };
	}

	public static final Object[] pattern_ClassToTableRule_12_4_solveCSP_bindingFBBBBBB(ClassToTableRule _this,
			IsApplicableMatch isApplicableMatch, DBTable t, PackageToSchema p2s, DBSchema s, CDPackage p) {
		CSP _localVariable_0 = _this.isApplicable_solveCsp_BWD(isApplicableMatch, t, p2s, s, p);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, t, p2s, s, p };
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_12_4_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_ClassToTableRule_12_4_solveCSP_bindingAndBlackFBBBBBB(ClassToTableRule _this,
			IsApplicableMatch isApplicableMatch, DBTable t, PackageToSchema p2s, DBSchema s, CDPackage p) {
		Object[] result_pattern_ClassToTableRule_12_4_solveCSP_binding = pattern_ClassToTableRule_12_4_solveCSP_bindingFBBBBBB(
				_this, isApplicableMatch, t, p2s, s, p);
		if (result_pattern_ClassToTableRule_12_4_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_ClassToTableRule_12_4_solveCSP_binding[0];

			Object[] result_pattern_ClassToTableRule_12_4_solveCSP_black = pattern_ClassToTableRule_12_4_solveCSP_blackB(
					csp);
			if (result_pattern_ClassToTableRule_12_4_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, t, p2s, s, p };
			}
		}
		return null;
	}

	public static final boolean pattern_ClassToTableRule_12_5_checkCSP_expressionFBB(ClassToTableRule _this, CSP csp) {
		boolean _localVariable_0 = _this.isApplicable_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_12_6_addmatchtoruleresult_blackBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final Object[] pattern_ClassToTableRule_12_6_addmatchtoruleresult_greenBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		ruleresult.getIsApplicableMatch().add(isApplicableMatch);
		boolean ruleresult_success_prime = Boolean.valueOf(true);
		String isApplicableMatch_ruleName_prime = "ClassToTableRule";
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		isApplicableMatch.setRuleName(isApplicableMatch_ruleName_prime);
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final IsApplicableRuleResult pattern_ClassToTableRule_12_7_expressionFB(
			IsApplicableRuleResult ruleresult) {
		IsApplicableRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_20_1_preparereturnvalue_bindingFB(ClassToTableRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass __eClass = _localVariable_0;
		if (__eClass != null) {
			return new Object[] { __eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_20_1_preparereturnvalue_blackFBBF(EClass __eClass,
			ClassToTableRule _this) {
		for (EOperation __performOperation : __eClass.getEOperations()) {
			String __performOperation_name = __performOperation.getName();
			if (__performOperation_name.equals("isApplicable_FWD")) {
				for (EOperation isApplicableCC : __eClass.getEOperations()) {
					if (!__performOperation.equals(isApplicableCC)) {
						String isApplicableCC_name = isApplicableCC.getName();
						if (isApplicableCC_name.equals("isApplicable_CC")) {
							return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
						}

					}
				}
			}

		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_20_1_preparereturnvalue_bindingAndBlackFFBF(
			ClassToTableRule _this) {
		Object[] result_pattern_ClassToTableRule_20_1_preparereturnvalue_binding = pattern_ClassToTableRule_20_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_ClassToTableRule_20_1_preparereturnvalue_binding != null) {
			EClass __eClass = (EClass) result_pattern_ClassToTableRule_20_1_preparereturnvalue_binding[0];

			Object[] result_pattern_ClassToTableRule_20_1_preparereturnvalue_black = pattern_ClassToTableRule_20_1_preparereturnvalue_blackFBBF(
					__eClass, _this);
			if (result_pattern_ClassToTableRule_20_1_preparereturnvalue_black != null) {
				EOperation __performOperation = (EOperation) result_pattern_ClassToTableRule_20_1_preparereturnvalue_black[0];
				EOperation isApplicableCC = (EOperation) result_pattern_ClassToTableRule_20_1_preparereturnvalue_black[3];

				return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
			}
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_20_1_preparereturnvalue_greenF() {
		EObjectContainer __result = RuntimeFactory.eINSTANCE.createEObjectContainer();
		return new Object[] { __result };
	}

	public static final Object[] pattern_ClassToTableRule_20_2_testcorematchandDECs_black_nac_0B(CDClass c) {
		CDClass __DEC_c_superClass_853738 = c.getSuperClass();
		if (__DEC_c_superClass_853738 != null) {
			if (!c.equals(__DEC_c_superClass_853738)) {
				return new Object[] { c };
			}
		}

		return null;
	}

	public static final Iterable<Object[]> pattern_ClassToTableRule_20_2_testcorematchandDECs_blackFFB(
			EMoflonEdge _edge_classes) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		EObject tmpP = _edge_classes.getSrc();
		if (tmpP instanceof CDPackage) {
			CDPackage p = (CDPackage) tmpP;
			EObject tmpC = _edge_classes.getTrg();
			if (tmpC instanceof CDClass) {
				CDClass c = (CDClass) tmpC;
				if (p.getClasses().contains(c)) {
					if (pattern_ClassToTableRule_20_2_testcorematchandDECs_black_nac_0B(c) == null) {
						_result.add(new Object[] { c, p, _edge_classes });
					}
				}
			}

		}

		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_20_2_testcorematchandDECs_greenFB(EClass __eClass) {
		Match match = RuntimeFactory.eINSTANCE.createMatch();
		String __eClass_name = __eClass.getName();
		String match_ruleName_prime = __eClass_name;
		match.setRuleName(match_ruleName_prime);
		return new Object[] { match, __eClass };

	}

	public static final boolean pattern_ClassToTableRule_20_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBB(
			ClassToTableRule _this, Match match, CDClass c, CDPackage p) {
		boolean _localVariable_0 = _this.isAppropriate_FWD(match, c, p);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final boolean pattern_ClassToTableRule_20_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
			ClassToTableRule _this, Match match) {
		boolean _localVariable_0 = _this.checkTypes_FWD(match);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_20_5_Addmatchtoruleresult_blackBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		if (!__performOperation.equals(isApplicableCC)) {
			return new Object[] { match, __performOperation, __result, isApplicableCC };
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_20_5_Addmatchtoruleresult_greenBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		__result.getContents().add(match);
		match.setIsApplicableOperation(__performOperation);
		match.setIsApplicableCCOperation(isApplicableCC);
		return new Object[] { match, __performOperation, __result, isApplicableCC };
	}

	public static final EObjectContainer pattern_ClassToTableRule_20_6_expressionFB(EObjectContainer __result) {
		EObjectContainer _result = __result;
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_21_1_preparereturnvalue_bindingFB(ClassToTableRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass __eClass = _localVariable_0;
		if (__eClass != null) {
			return new Object[] { __eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_21_1_preparereturnvalue_blackFBBF(EClass __eClass,
			ClassToTableRule _this) {
		for (EOperation __performOperation : __eClass.getEOperations()) {
			String __performOperation_name = __performOperation.getName();
			if (__performOperation_name.equals("isApplicable_BWD")) {
				for (EOperation isApplicableCC : __eClass.getEOperations()) {
					if (!__performOperation.equals(isApplicableCC)) {
						String isApplicableCC_name = isApplicableCC.getName();
						if (isApplicableCC_name.equals("isApplicable_CC")) {
							return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
						}

					}
				}
			}

		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_21_1_preparereturnvalue_bindingAndBlackFFBF(
			ClassToTableRule _this) {
		Object[] result_pattern_ClassToTableRule_21_1_preparereturnvalue_binding = pattern_ClassToTableRule_21_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_ClassToTableRule_21_1_preparereturnvalue_binding != null) {
			EClass __eClass = (EClass) result_pattern_ClassToTableRule_21_1_preparereturnvalue_binding[0];

			Object[] result_pattern_ClassToTableRule_21_1_preparereturnvalue_black = pattern_ClassToTableRule_21_1_preparereturnvalue_blackFBBF(
					__eClass, _this);
			if (result_pattern_ClassToTableRule_21_1_preparereturnvalue_black != null) {
				EOperation __performOperation = (EOperation) result_pattern_ClassToTableRule_21_1_preparereturnvalue_black[0];
				EOperation isApplicableCC = (EOperation) result_pattern_ClassToTableRule_21_1_preparereturnvalue_black[3];

				return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
			}
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_21_1_preparereturnvalue_greenF() {
		EObjectContainer __result = RuntimeFactory.eINSTANCE.createEObjectContainer();
		return new Object[] { __result };
	}

	public static final Iterable<Object[]> pattern_ClassToTableRule_21_2_testcorematchandDECs_blackFFB(
			EMoflonEdge _edge_tables) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		EObject tmpS = _edge_tables.getSrc();
		if (tmpS instanceof DBSchema) {
			DBSchema s = (DBSchema) tmpS;
			EObject tmpT = _edge_tables.getTrg();
			if (tmpT instanceof DBTable) {
				DBTable t = (DBTable) tmpT;
				if (s.getTables().contains(t)) {
					_result.add(new Object[] { t, s, _edge_tables });
				}
			}

		}

		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_21_2_testcorematchandDECs_greenFB(EClass __eClass) {
		Match match = RuntimeFactory.eINSTANCE.createMatch();
		String __eClass_name = __eClass.getName();
		String match_ruleName_prime = __eClass_name;
		match.setRuleName(match_ruleName_prime);
		return new Object[] { match, __eClass };

	}

	public static final boolean pattern_ClassToTableRule_21_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBB(
			ClassToTableRule _this, Match match, DBTable t, DBSchema s) {
		boolean _localVariable_0 = _this.isAppropriate_BWD(match, t, s);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final boolean pattern_ClassToTableRule_21_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
			ClassToTableRule _this, Match match) {
		boolean _localVariable_0 = _this.checkTypes_BWD(match);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_21_5_Addmatchtoruleresult_blackBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		if (!__performOperation.equals(isApplicableCC)) {
			return new Object[] { match, __performOperation, __result, isApplicableCC };
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_21_5_Addmatchtoruleresult_greenBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		__result.getContents().add(match);
		match.setIsApplicableOperation(__performOperation);
		match.setIsApplicableCCOperation(isApplicableCC);
		return new Object[] { match, __performOperation, __result, isApplicableCC };
	}

	public static final EObjectContainer pattern_ClassToTableRule_21_6_expressionFB(EObjectContainer __result) {
		EObjectContainer _result = __result;
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_24_1_prepare_blackB(ClassToTableRule _this) {
		return new Object[] { _this };
	}

	public static final Object[] pattern_ClassToTableRule_24_1_prepare_greenF() {
		IsApplicableRuleResult result = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		return new Object[] { result };
	}

	public static final Object[] pattern_ClassToTableRule_24_2_matchsrctrgcontext_bindingFFFFBB(Match targetMatch,
			Match sourceMatch) {
		EObject _localVariable_0 = targetMatch.getObject("t");
		EObject _localVariable_1 = sourceMatch.getObject("c");
		EObject _localVariable_2 = targetMatch.getObject("s");
		EObject _localVariable_3 = sourceMatch.getObject("p");
		EObject tmpT = _localVariable_0;
		EObject tmpC = _localVariable_1;
		EObject tmpS = _localVariable_2;
		EObject tmpP = _localVariable_3;
		if (tmpT instanceof DBTable) {
			DBTable t = (DBTable) tmpT;
			if (tmpC instanceof CDClass) {
				CDClass c = (CDClass) tmpC;
				if (tmpS instanceof DBSchema) {
					DBSchema s = (DBSchema) tmpS;
					if (tmpP instanceof CDPackage) {
						CDPackage p = (CDPackage) tmpP;
						return new Object[] { t, c, s, p, targetMatch, sourceMatch };
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_24_2_matchsrctrgcontext_blackBBBBBB(DBTable t, CDClass c,
			DBSchema s, CDPackage p, Match sourceMatch, Match targetMatch) {
		if (!sourceMatch.equals(targetMatch)) {
			return new Object[] { t, c, s, p, sourceMatch, targetMatch };
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_24_2_matchsrctrgcontext_bindingAndBlackFFFFBB(
			Match sourceMatch, Match targetMatch) {
		Object[] result_pattern_ClassToTableRule_24_2_matchsrctrgcontext_binding = pattern_ClassToTableRule_24_2_matchsrctrgcontext_bindingFFFFBB(
				targetMatch, sourceMatch);
		if (result_pattern_ClassToTableRule_24_2_matchsrctrgcontext_binding != null) {
			DBTable t = (DBTable) result_pattern_ClassToTableRule_24_2_matchsrctrgcontext_binding[0];
			CDClass c = (CDClass) result_pattern_ClassToTableRule_24_2_matchsrctrgcontext_binding[1];
			DBSchema s = (DBSchema) result_pattern_ClassToTableRule_24_2_matchsrctrgcontext_binding[2];
			CDPackage p = (CDPackage) result_pattern_ClassToTableRule_24_2_matchsrctrgcontext_binding[3];

			Object[] result_pattern_ClassToTableRule_24_2_matchsrctrgcontext_black = pattern_ClassToTableRule_24_2_matchsrctrgcontext_blackBBBBBB(
					t, c, s, p, sourceMatch, targetMatch);
			if (result_pattern_ClassToTableRule_24_2_matchsrctrgcontext_black != null) {

				return new Object[] { t, c, s, p, sourceMatch, targetMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_24_3_solvecsp_bindingFBBBBBBB(ClassToTableRule _this,
			DBTable t, CDClass c, DBSchema s, CDPackage p, Match sourceMatch, Match targetMatch) {
		CSP _localVariable_4 = _this.isApplicable_solveCsp_CC(t, c, s, p, sourceMatch, targetMatch);
		CSP csp = _localVariable_4;
		if (csp != null) {
			return new Object[] { csp, _this, t, c, s, p, sourceMatch, targetMatch };
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_24_3_solvecsp_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_ClassToTableRule_24_3_solvecsp_bindingAndBlackFBBBBBBB(ClassToTableRule _this,
			DBTable t, CDClass c, DBSchema s, CDPackage p, Match sourceMatch, Match targetMatch) {
		Object[] result_pattern_ClassToTableRule_24_3_solvecsp_binding = pattern_ClassToTableRule_24_3_solvecsp_bindingFBBBBBBB(
				_this, t, c, s, p, sourceMatch, targetMatch);
		if (result_pattern_ClassToTableRule_24_3_solvecsp_binding != null) {
			CSP csp = (CSP) result_pattern_ClassToTableRule_24_3_solvecsp_binding[0];

			Object[] result_pattern_ClassToTableRule_24_3_solvecsp_black = pattern_ClassToTableRule_24_3_solvecsp_blackB(
					csp);
			if (result_pattern_ClassToTableRule_24_3_solvecsp_black != null) {

				return new Object[] { csp, _this, t, c, s, p, sourceMatch, targetMatch };
			}
		}
		return null;
	}

	public static final boolean pattern_ClassToTableRule_24_4_checkCSP_expressionFB(CSP csp) {
		boolean _localVariable_0 = csp.check();
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Iterable<Object[]> pattern_ClassToTableRule_24_5_matchcorrcontext_blackFBBBB(DBSchema s,
			CDPackage p, Match sourceMatch, Match targetMatch) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!sourceMatch.equals(targetMatch)) {
			for (PackageToSchema p2s : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(s,
					PackageToSchema.class, "target")) {
				if (p.equals(p2s.getSource())) {
					_result.add(new Object[] { p2s, s, p, sourceMatch, targetMatch });
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_24_5_matchcorrcontext_greenBBBF(PackageToSchema p2s,
			Match sourceMatch, Match targetMatch) {
		CCMatch ccMatch = RuntimeFactory.eINSTANCE.createCCMatch();
		String ccMatch_ruleName_prime = "ClassToTableRule";
		ccMatch.setSourceMatch(sourceMatch);
		ccMatch.setTargetMatch(targetMatch);
		ccMatch.getAllContextElements().add(p2s);
		ccMatch.setRuleName(ccMatch_ruleName_prime);
		return new Object[] { p2s, sourceMatch, targetMatch, ccMatch };
	}

	public static final Object[] pattern_ClassToTableRule_24_6_createcorrespondence_blackBBBBB(DBTable t, CDClass c,
			DBSchema s, CDPackage p, CCMatch ccMatch) {
		return new Object[] { t, c, s, p, ccMatch };
	}

	public static final Object[] pattern_ClassToTableRule_24_6_createcorrespondence_greenBBFB(DBTable t, CDClass c,
			CCMatch ccMatch) {
		ClassToTable c2t = CDToDBFactory.eINSTANCE.createClassToTable();
		c2t.setTarget(t);
		c2t.setSource(c);
		ccMatch.getCreateCorr().add(c2t);
		return new Object[] { t, c, c2t, ccMatch };
	}

	public static final Object[] pattern_ClassToTableRule_24_7_addtoreturnedresult_blackBB(
			IsApplicableRuleResult result, CCMatch ccMatch) {
		return new Object[] { result, ccMatch };
	}

	public static final Object[] pattern_ClassToTableRule_24_7_addtoreturnedresult_greenBB(
			IsApplicableRuleResult result, CCMatch ccMatch) {
		result.getIsApplicableMatch().add(ccMatch);
		boolean result_success_prime = Boolean.valueOf(true);
		String ccMatch_ruleName_prime = "ClassToTableRule";
		result.setSuccess(Boolean.valueOf(result_success_prime));
		ccMatch.setRuleName(ccMatch_ruleName_prime);
		return new Object[] { result, ccMatch };
	}

	public static final IsApplicableRuleResult pattern_ClassToTableRule_24_8_expressionFB(
			IsApplicableRuleResult result) {
		IsApplicableRuleResult _result = result;
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_27_1_matchtggpattern_black_nac_0B(CDClass c) {
		CDClass __DEC_c_superClass_481584 = c.getSuperClass();
		if (__DEC_c_superClass_481584 != null) {
			if (!c.equals(__DEC_c_superClass_481584)) {
				return new Object[] { c };
			}
		}

		return null;
	}

	public static final Object[] pattern_ClassToTableRule_27_1_matchtggpattern_blackBB(CDClass c, CDPackage p) {
		if (p.getClasses().contains(c)) {
			if (pattern_ClassToTableRule_27_1_matchtggpattern_black_nac_0B(c) == null) {
				return new Object[] { c, p };
			}
		}
		return null;
	}

	public static final boolean pattern_ClassToTableRule_27_2_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_ClassToTableRule_27_3_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_28_1_matchtggpattern_blackBB(DBTable t, DBSchema s) {
		if (s.getTables().contains(t)) {
			return new Object[] { t, s };
		}
		return null;
	}

	public static final boolean pattern_ClassToTableRule_28_2_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_ClassToTableRule_28_3_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_29_1_createresult_blackB(ClassToTableRule _this) {
		return new Object[] { _this };
	}

	public static final Object[] pattern_ClassToTableRule_29_1_createresult_greenFF() {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		ModelgeneratorRuleResult ruleResult = RuntimeFactory.eINSTANCE.createModelgeneratorRuleResult();
		boolean ruleResult_success_prime = Boolean.valueOf(false);
		ruleResult.setSuccess(Boolean.valueOf(ruleResult_success_prime));
		return new Object[] { isApplicableMatch, ruleResult };
	}

	public static final Object[] pattern_ClassToTableRule_29_2_isapplicablecore_black_nac_0BB(
			ModelgeneratorRuleResult ruleResult, PackageToSchema p2s) {
		if (ruleResult.getCorrObjects().contains(p2s)) {
			return new Object[] { ruleResult, p2s };
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_29_2_isapplicablecore_black_nac_1BB(
			ModelgeneratorRuleResult ruleResult, DBSchema s) {
		if (ruleResult.getTargetObjects().contains(s)) {
			return new Object[] { ruleResult, s };
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_29_2_isapplicablecore_black_nac_2BB(
			ModelgeneratorRuleResult ruleResult, CDPackage p) {
		if (ruleResult.getSourceObjects().contains(p)) {
			return new Object[] { ruleResult, p };
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_ClassToTableRule_29_2_isapplicablecore_blackFFFFBB(
			RuleEntryContainer ruleEntryContainer, ModelgeneratorRuleResult ruleResult) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		for (RuleEntryList p2sList : ruleEntryContainer.getRuleEntryList()) {
			for (EObject tmpP2s : p2sList.getEntryObjects()) {
				if (tmpP2s instanceof PackageToSchema) {
					PackageToSchema p2s = (PackageToSchema) tmpP2s;
					DBSchema s = p2s.getTarget();
					if (s != null) {
						CDPackage p = p2s.getSource();
						if (p != null) {
							if (pattern_ClassToTableRule_29_2_isapplicablecore_black_nac_0BB(ruleResult, p2s) == null) {
								if (pattern_ClassToTableRule_29_2_isapplicablecore_black_nac_1BB(ruleResult,
										s) == null) {
									if (pattern_ClassToTableRule_29_2_isapplicablecore_black_nac_2BB(ruleResult,
											p) == null) {
										_result.add(
												new Object[] { p2sList, p2s, s, p, ruleEntryContainer, ruleResult });
									}
								}
							}
						}

					}

				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_29_3_solveCSP_bindingFBBBBBB(ClassToTableRule _this,
			IsApplicableMatch isApplicableMatch, PackageToSchema p2s, DBSchema s, CDPackage p,
			ModelgeneratorRuleResult ruleResult) {
		CSP _localVariable_0 = _this.generateModel_solveCsp_BWD(isApplicableMatch, p2s, s, p, ruleResult);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, p2s, s, p, ruleResult };
		}
		return null;
	}

	public static final Object[] pattern_ClassToTableRule_29_3_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_ClassToTableRule_29_3_solveCSP_bindingAndBlackFBBBBBB(ClassToTableRule _this,
			IsApplicableMatch isApplicableMatch, PackageToSchema p2s, DBSchema s, CDPackage p,
			ModelgeneratorRuleResult ruleResult) {
		Object[] result_pattern_ClassToTableRule_29_3_solveCSP_binding = pattern_ClassToTableRule_29_3_solveCSP_bindingFBBBBBB(
				_this, isApplicableMatch, p2s, s, p, ruleResult);
		if (result_pattern_ClassToTableRule_29_3_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_ClassToTableRule_29_3_solveCSP_binding[0];

			Object[] result_pattern_ClassToTableRule_29_3_solveCSP_black = pattern_ClassToTableRule_29_3_solveCSP_blackB(
					csp);
			if (result_pattern_ClassToTableRule_29_3_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, p2s, s, p, ruleResult };
			}
		}
		return null;
	}

	public static final boolean pattern_ClassToTableRule_29_4_checkCSP_expressionFBB(ClassToTableRule _this, CSP csp) {
		boolean _localVariable_0 = _this.generateModel_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_ClassToTableRule_29_5_checknacs_blackBBB(PackageToSchema p2s, DBSchema s,
			CDPackage p) {
		return new Object[] { p2s, s, p };
	}

	public static final Object[] pattern_ClassToTableRule_29_6_perform_blackBBBB(PackageToSchema p2s, DBSchema s,
			CDPackage p, ModelgeneratorRuleResult ruleResult) {
		return new Object[] { p2s, s, p, ruleResult };
	}

	public static final Object[] pattern_ClassToTableRule_29_6_perform_greenFFFBBBB(DBSchema s, CDPackage p,
			ModelgeneratorRuleResult ruleResult, CSP csp) {
		DBTable t = DatabaseSchemataFactory.eINSTANCE.createDBTable();
		CDClass c = ClassDiagramsFactory.eINSTANCE.createCDClass();
		ClassToTable c2t = CDToDBFactory.eINSTANCE.createClassToTable();
		Object _localVariable_0 = csp.getValue("t", "name");
		Object _localVariable_1 = csp.getValue("c", "name");
		boolean ruleResult_success_prime = Boolean.valueOf(true);
		int _localVariable_2 = ruleResult.getIncrementedPerformCount();
		s.getTables().add(t);
		ruleResult.getTargetObjects().add(t);
		p.getClasses().add(c);
		ruleResult.getSourceObjects().add(c);
		c2t.setTarget(t);
		c2t.setSource(c);
		ruleResult.getCorrObjects().add(c2t);
		String t_name_prime = (String) _localVariable_0;
		String c_name_prime = (String) _localVariable_1;
		ruleResult.setSuccess(Boolean.valueOf(ruleResult_success_prime));
		int ruleResult_performCount_prime = Integer.valueOf(_localVariable_2);
		t.setName(t_name_prime);
		c.setName(c_name_prime);
		ruleResult.setPerformCount(Integer.valueOf(ruleResult_performCount_prime));
		return new Object[] { t, c, c2t, s, p, ruleResult, csp };
	}

	public static final ModelgeneratorRuleResult pattern_ClassToTableRule_29_7_expressionFB(
			ModelgeneratorRuleResult ruleResult) {
		ModelgeneratorRuleResult _result = ruleResult;
		return _result;
	}

	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //ClassToTableRuleImpl
