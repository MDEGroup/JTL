/**
 */
package CDToDB.Rules.util;

import CDToDB.Rules.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

import org.moflon.tgg.runtime.AbstractRule;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see CDToDB.Rules.RulesPackage
 * @generated
 */
public class RulesAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static RulesPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RulesAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = RulesPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RulesSwitch<Adapter> modelSwitch = new RulesSwitch<Adapter>() {
		@Override
		public Adapter caseTransferColsRule(TransferColsRule object) {
			return createTransferColsRuleAdapter();
		}

		@Override
		public Adapter caseClassToTableRule(ClassToTableRule object) {
			return createClassToTableRuleAdapter();
		}

		@Override
		public Adapter caseTransitiveCorrsAbove(TransitiveCorrsAbove object) {
			return createTransitiveCorrsAboveAdapter();
		}

		@Override
		public Adapter caseCreateInheritanceRule(CreateInheritanceRule object) {
			return createCreateInheritanceRuleAdapter();
		}

		@Override
		public Adapter casePackageToSchemaRule(PackageToSchemaRule object) {
			return createPackageToSchemaRuleAdapter();
		}

		@Override
		public Adapter caseTransitiveAttributeRule(TransitiveAttributeRule object) {
			return createTransitiveAttributeRuleAdapter();
		}

		@Override
		public Adapter caseCreateAttributeRule(CreateAttributeRule object) {
			return createCreateAttributeRuleAdapter();
		}

		@Override
		public Adapter caseAbstractRule(AbstractRule object) {
			return createAbstractRuleAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link CDToDB.Rules.TransferColsRule <em>Transfer Cols Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CDToDB.Rules.TransferColsRule
	 * @generated
	 */
	public Adapter createTransferColsRuleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CDToDB.Rules.ClassToTableRule <em>Class To Table Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CDToDB.Rules.ClassToTableRule
	 * @generated
	 */
	public Adapter createClassToTableRuleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CDToDB.Rules.TransitiveCorrsAbove <em>Transitive Corrs Above</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CDToDB.Rules.TransitiveCorrsAbove
	 * @generated
	 */
	public Adapter createTransitiveCorrsAboveAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CDToDB.Rules.CreateInheritanceRule <em>Create Inheritance Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CDToDB.Rules.CreateInheritanceRule
	 * @generated
	 */
	public Adapter createCreateInheritanceRuleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CDToDB.Rules.PackageToSchemaRule <em>Package To Schema Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CDToDB.Rules.PackageToSchemaRule
	 * @generated
	 */
	public Adapter createPackageToSchemaRuleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CDToDB.Rules.TransitiveAttributeRule <em>Transitive Attribute Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CDToDB.Rules.TransitiveAttributeRule
	 * @generated
	 */
	public Adapter createTransitiveAttributeRuleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link CDToDB.Rules.CreateAttributeRule <em>Create Attribute Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see CDToDB.Rules.CreateAttributeRule
	 * @generated
	 */
	public Adapter createCreateAttributeRuleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link org.moflon.tgg.runtime.AbstractRule <em>Abstract Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see org.moflon.tgg.runtime.AbstractRule
	 * @generated
	 */
	public Adapter createAbstractRuleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //RulesAdapterFactory
