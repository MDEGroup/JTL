/**
 */
package CDToDB.Rules.impl;

import CDToDB.CDToDBPackage;

import CDToDB.Rules.RulesFactory;
import CDToDB.Rules.RulesPackage;

import CDToDB.impl.CDToDBPackageImpl;

import ClassDiagrams.ClassDiagramsPackage;

import DatabaseSchemata.DatabaseSchemataPackage;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.moflon.tgg.language.LanguagePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class RulesPackageImpl extends EPackageImpl implements RulesPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass transferColsRuleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass classToTableRuleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass transitiveCorrsAboveEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass createInheritanceRuleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass packageToSchemaRuleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass transitiveAttributeRuleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass createAttributeRuleEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see CDToDB.Rules.RulesPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private RulesPackageImpl() {
		super(eNS_URI, RulesFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link RulesPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @generated
	 */
	public static RulesPackage init() {
		if (isInited)
			return (RulesPackage) EPackage.Registry.INSTANCE.getEPackage(RulesPackage.eNS_URI);

		// Obtain or create and register package
		RulesPackageImpl theRulesPackage = (RulesPackageImpl) (EPackage.Registry.INSTANCE
				.get(eNS_URI) instanceof RulesPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI)
						: new RulesPackageImpl());

		isInited = true;

		// Initialize simple dependencies
		ClassDiagramsPackage.eINSTANCE.eClass();
		DatabaseSchemataPackage.eINSTANCE.eClass();
		LanguagePackage.eINSTANCE.eClass();

		// Obtain or create and register interdependencies
		CDToDBPackageImpl theCDToDBPackage = (CDToDBPackageImpl) (EPackage.Registry.INSTANCE
				.getEPackage(CDToDBPackage.eNS_URI) instanceof CDToDBPackageImpl
						? EPackage.Registry.INSTANCE.getEPackage(CDToDBPackage.eNS_URI) : CDToDBPackage.eINSTANCE);

		// Load packages
		theCDToDBPackage.loadPackage();

		// Fix loaded packages
		theRulesPackage.fixPackageContents();
		theCDToDBPackage.fixPackageContents();

		// Mark meta-data to indicate it can't be changed
		theRulesPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(RulesPackage.eNS_URI, theRulesPackage);
		return theRulesPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTransferColsRule() {
		if (transferColsRuleEClass == null) {
			transferColsRuleEClass = (EClass) EPackage.Registry.INSTANCE.getEPackage(RulesPackage.eNS_URI)
					.getEClassifiers().get(0);
		}
		return transferColsRuleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__IsAppropriate_FWD__Match_CDClass_CDClass_CDPackage() {
		return getTransferColsRule().getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__Perform_FWD__IsApplicableMatch() {
		return getTransferColsRule().getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__IsApplicable_FWD__Match() {
		return getTransferColsRule().getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__RegisterObjectsToMatch_FWD__Match_CDClass_CDClass_CDPackage() {
		return getTransferColsRule().getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__IsAppropriate_solveCsp_FWD__Match_CDClass_CDClass_CDPackage() {
		return getTransferColsRule().getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__IsAppropriate_checkCsp_FWD__CSP() {
		return getTransferColsRule().getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__IsApplicable_solveCsp_FWD__IsApplicableMatch_DBTable_DBColumn_DBTable_SuperClassToTable_ClassToTable_ClassToTable_CDClass_PackageToSchema_CDClass_CDPackage_DBSchema() {
		return getTransferColsRule().getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__IsApplicable_checkCsp_FWD__CSP() {
		return getTransferColsRule().getEOperations().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject() {
		return getTransferColsRule().getEOperations().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__CheckTypes_FWD__Match() {
		return getTransferColsRule().getEOperations().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__IsAppropriate_BWD__Match_DBTable_DBColumn_DBColumn_DBTable_DBSchema() {
		return getTransferColsRule().getEOperations().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__Perform_BWD__IsApplicableMatch() {
		return getTransferColsRule().getEOperations().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__IsApplicable_BWD__Match() {
		return getTransferColsRule().getEOperations().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__RegisterObjectsToMatch_BWD__Match_DBTable_DBColumn_DBColumn_DBTable_DBSchema() {
		return getTransferColsRule().getEOperations().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__IsAppropriate_solveCsp_BWD__Match_DBTable_DBColumn_DBColumn_DBTable_DBSchema() {
		return getTransferColsRule().getEOperations().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__IsAppropriate_checkCsp_BWD__CSP() {
		return getTransferColsRule().getEOperations().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__IsApplicable_solveCsp_BWD__IsApplicableMatch_DBTable_DBColumn_DBColumn_DBTable_SuperClassToTable_ClassToTable_ClassToTable_CDClass_PackageToSchema_CDClass_CDPackage_DBSchema() {
		return getTransferColsRule().getEOperations().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__IsApplicable_checkCsp_BWD__CSP() {
		return getTransferColsRule().getEOperations().get(17);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject() {
		return getTransferColsRule().getEOperations().get(18);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__CheckTypes_BWD__Match() {
		return getTransferColsRule().getEOperations().get(19);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__IsAppropriate_FWD_EMoflonEdge_0__EMoflonEdge() {
		return getTransferColsRule().getEOperations().get(20);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__IsAppropriate_BWD_EMoflonEdge_0__EMoflonEdge() {
		return getTransferColsRule().getEOperations().get(21);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__CheckAttributes_FWD__TripleMatch() {
		return getTransferColsRule().getEOperations().get(22);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__CheckAttributes_BWD__TripleMatch() {
		return getTransferColsRule().getEOperations().get(23);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__IsApplicable_CC__Match_Match() {
		return getTransferColsRule().getEOperations().get(24);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__IsApplicable_solveCsp_CC__DBTable_DBColumn_DBColumn_DBTable_CDClass_CDClass_CDPackage_DBSchema_Match_Match() {
		return getTransferColsRule().getEOperations().get(25);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__IsApplicable_checkCsp_CC__CSP() {
		return getTransferColsRule().getEOperations().get(26);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__CheckDEC_FWD__CDClass_CDClass_CDPackage() {
		return getTransferColsRule().getEOperations().get(27);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__CheckDEC_BWD__DBTable_DBColumn_DBColumn_DBTable_DBSchema() {
		return getTransferColsRule().getEOperations().get(28);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__GenerateModel__RuleEntryContainer_SuperClassToTable() {
		return getTransferColsRule().getEOperations().get(29);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__GenerateModel_solveCsp_BWD__IsApplicableMatch_DBTable_DBColumn_DBTable_SuperClassToTable_ClassToTable_ClassToTable_CDClass_PackageToSchema_CDClass_CDPackage_DBSchema_ModelgeneratorRuleResult() {
		return getTransferColsRule().getEOperations().get(30);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransferColsRule__GenerateModel_checkCsp_BWD__CSP() {
		return getTransferColsRule().getEOperations().get(31);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getClassToTableRule() {
		if (classToTableRuleEClass == null) {
			classToTableRuleEClass = (EClass) EPackage.Registry.INSTANCE.getEPackage(RulesPackage.eNS_URI)
					.getEClassifiers().get(1);
		}
		return classToTableRuleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__IsAppropriate_FWD__Match_CDClass_CDPackage() {
		return getClassToTableRule().getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__Perform_FWD__IsApplicableMatch() {
		return getClassToTableRule().getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__IsApplicable_FWD__Match() {
		return getClassToTableRule().getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__RegisterObjectsToMatch_FWD__Match_CDClass_CDPackage() {
		return getClassToTableRule().getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__IsAppropriate_solveCsp_FWD__Match_CDClass_CDPackage() {
		return getClassToTableRule().getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__IsAppropriate_checkCsp_FWD__CSP() {
		return getClassToTableRule().getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__IsApplicable_solveCsp_FWD__IsApplicableMatch_CDClass_PackageToSchema_DBSchema_CDPackage() {
		return getClassToTableRule().getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__IsApplicable_checkCsp_FWD__CSP() {
		return getClassToTableRule().getEOperations().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject() {
		return getClassToTableRule().getEOperations().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__CheckTypes_FWD__Match() {
		return getClassToTableRule().getEOperations().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__IsAppropriate_BWD__Match_DBTable_DBSchema() {
		return getClassToTableRule().getEOperations().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__Perform_BWD__IsApplicableMatch() {
		return getClassToTableRule().getEOperations().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__IsApplicable_BWD__Match() {
		return getClassToTableRule().getEOperations().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__RegisterObjectsToMatch_BWD__Match_DBTable_DBSchema() {
		return getClassToTableRule().getEOperations().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__IsAppropriate_solveCsp_BWD__Match_DBTable_DBSchema() {
		return getClassToTableRule().getEOperations().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__IsAppropriate_checkCsp_BWD__CSP() {
		return getClassToTableRule().getEOperations().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__IsApplicable_solveCsp_BWD__IsApplicableMatch_DBTable_PackageToSchema_DBSchema_CDPackage() {
		return getClassToTableRule().getEOperations().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__IsApplicable_checkCsp_BWD__CSP() {
		return getClassToTableRule().getEOperations().get(17);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject() {
		return getClassToTableRule().getEOperations().get(18);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__CheckTypes_BWD__Match() {
		return getClassToTableRule().getEOperations().get(19);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__IsAppropriate_FWD_EMoflonEdge_1__EMoflonEdge() {
		return getClassToTableRule().getEOperations().get(20);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__IsAppropriate_BWD_EMoflonEdge_1__EMoflonEdge() {
		return getClassToTableRule().getEOperations().get(21);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__CheckAttributes_FWD__TripleMatch() {
		return getClassToTableRule().getEOperations().get(22);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__CheckAttributes_BWD__TripleMatch() {
		return getClassToTableRule().getEOperations().get(23);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__IsApplicable_CC__Match_Match() {
		return getClassToTableRule().getEOperations().get(24);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__IsApplicable_solveCsp_CC__DBTable_CDClass_DBSchema_CDPackage_Match_Match() {
		return getClassToTableRule().getEOperations().get(25);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__IsApplicable_checkCsp_CC__CSP() {
		return getClassToTableRule().getEOperations().get(26);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__CheckDEC_FWD__CDClass_CDPackage() {
		return getClassToTableRule().getEOperations().get(27);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__CheckDEC_BWD__DBTable_DBSchema() {
		return getClassToTableRule().getEOperations().get(28);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__GenerateModel__RuleEntryContainer_PackageToSchema() {
		return getClassToTableRule().getEOperations().get(29);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__GenerateModel_solveCsp_BWD__IsApplicableMatch_PackageToSchema_DBSchema_CDPackage_ModelgeneratorRuleResult() {
		return getClassToTableRule().getEOperations().get(30);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getClassToTableRule__GenerateModel_checkCsp_BWD__CSP() {
		return getClassToTableRule().getEOperations().get(31);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTransitiveCorrsAbove() {
		if (transitiveCorrsAboveEClass == null) {
			transitiveCorrsAboveEClass = (EClass) EPackage.Registry.INSTANCE.getEPackage(RulesPackage.eNS_URI)
					.getEClassifiers().get(2);
		}
		return transitiveCorrsAboveEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__IsAppropriate_FWD__Match_CDClass_CDPackage_CDClass_CDClass() {
		return getTransitiveCorrsAbove().getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__Perform_FWD__IsApplicableMatch() {
		return getTransitiveCorrsAbove().getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__IsApplicable_FWD__Match() {
		return getTransitiveCorrsAbove().getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__RegisterObjectsToMatch_FWD__Match_CDClass_CDPackage_CDClass_CDClass() {
		return getTransitiveCorrsAbove().getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__IsAppropriate_solveCsp_FWD__Match_CDClass_CDPackage_CDClass_CDClass() {
		return getTransitiveCorrsAbove().getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__IsAppropriate_checkCsp_FWD__CSP() {
		return getTransitiveCorrsAbove().getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__IsApplicable_solveCsp_FWD__IsApplicableMatch_DBTable_CDClass_CDPackage_DBTable_SuperClassToTable_SuperClassToTable_ClassToTable_ClassToTable_CDClass_PackageToSchema_CDClass_DBSchema() {
		return getTransitiveCorrsAbove().getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__IsApplicable_checkCsp_FWD__CSP() {
		return getTransitiveCorrsAbove().getEOperations().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject() {
		return getTransitiveCorrsAbove().getEOperations().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__CheckTypes_FWD__Match() {
		return getTransitiveCorrsAbove().getEOperations().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__IsAppropriate_BWD__Match_DBTable_DBTable_DBSchema() {
		return getTransitiveCorrsAbove().getEOperations().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__Perform_BWD__IsApplicableMatch() {
		return getTransitiveCorrsAbove().getEOperations().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__IsApplicable_BWD__Match() {
		return getTransitiveCorrsAbove().getEOperations().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__RegisterObjectsToMatch_BWD__Match_DBTable_DBTable_DBSchema() {
		return getTransitiveCorrsAbove().getEOperations().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__IsAppropriate_solveCsp_BWD__Match_DBTable_DBTable_DBSchema() {
		return getTransitiveCorrsAbove().getEOperations().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__IsAppropriate_checkCsp_BWD__CSP() {
		return getTransitiveCorrsAbove().getEOperations().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__IsApplicable_solveCsp_BWD__IsApplicableMatch_DBTable_CDClass_CDPackage_DBTable_SuperClassToTable_SuperClassToTable_ClassToTable_ClassToTable_CDClass_PackageToSchema_CDClass_DBSchema() {
		return getTransitiveCorrsAbove().getEOperations().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__IsApplicable_checkCsp_BWD__CSP() {
		return getTransitiveCorrsAbove().getEOperations().get(17);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject() {
		return getTransitiveCorrsAbove().getEOperations().get(18);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__CheckTypes_BWD__Match() {
		return getTransitiveCorrsAbove().getEOperations().get(19);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__IsAppropriate_FWD_EMoflonEdge_2__EMoflonEdge() {
		return getTransitiveCorrsAbove().getEOperations().get(20);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__IsAppropriate_BWD_EMoflonEdge_2__EMoflonEdge() {
		return getTransitiveCorrsAbove().getEOperations().get(21);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__CheckAttributes_FWD__TripleMatch() {
		return getTransitiveCorrsAbove().getEOperations().get(22);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__CheckAttributes_BWD__TripleMatch() {
		return getTransitiveCorrsAbove().getEOperations().get(23);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__IsApplicable_CC__Match_Match() {
		return getTransitiveCorrsAbove().getEOperations().get(24);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__IsApplicable_solveCsp_CC__DBTable_CDClass_CDPackage_DBTable_CDClass_CDClass_DBSchema_Match_Match() {
		return getTransitiveCorrsAbove().getEOperations().get(25);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__IsApplicable_checkCsp_CC__CSP() {
		return getTransitiveCorrsAbove().getEOperations().get(26);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__CheckDEC_FWD__CDClass_CDPackage_CDClass_CDClass() {
		return getTransitiveCorrsAbove().getEOperations().get(27);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__CheckDEC_BWD__DBTable_DBTable_DBSchema() {
		return getTransitiveCorrsAbove().getEOperations().get(28);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__GenerateModel__RuleEntryContainer_SuperClassToTable() {
		return getTransitiveCorrsAbove().getEOperations().get(29);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__GenerateModel_solveCsp_BWD__IsApplicableMatch_DBTable_CDClass_CDPackage_DBTable_SuperClassToTable_SuperClassToTable_ClassToTable_ClassToTable_CDClass_PackageToSchema_CDClass_DBSchema_ModelgeneratorRuleResult() {
		return getTransitiveCorrsAbove().getEOperations().get(30);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveCorrsAbove__GenerateModel_checkCsp_BWD__CSP() {
		return getTransitiveCorrsAbove().getEOperations().get(31);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCreateInheritanceRule() {
		if (createInheritanceRuleEClass == null) {
			createInheritanceRuleEClass = (EClass) EPackage.Registry.INSTANCE.getEPackage(RulesPackage.eNS_URI)
					.getEClassifiers().get(3);
		}
		return createInheritanceRuleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__IsAppropriate_FWD__Match_CDClass_CDClass_CDPackage() {
		return getCreateInheritanceRule().getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__Perform_FWD__IsApplicableMatch() {
		return getCreateInheritanceRule().getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__IsApplicable_FWD__Match() {
		return getCreateInheritanceRule().getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__RegisterObjectsToMatch_FWD__Match_CDClass_CDClass_CDPackage() {
		return getCreateInheritanceRule().getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__IsAppropriate_solveCsp_FWD__Match_CDClass_CDClass_CDPackage() {
		return getCreateInheritanceRule().getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__IsAppropriate_checkCsp_FWD__CSP() {
		return getCreateInheritanceRule().getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__IsApplicable_solveCsp_FWD__IsApplicableMatch_ClassToTable_DBTable_CDClass_PackageToSchema_CDClass_CDPackage_DBSchema() {
		return getCreateInheritanceRule().getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__IsApplicable_checkCsp_FWD__CSP() {
		return getCreateInheritanceRule().getEOperations().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject() {
		return getCreateInheritanceRule().getEOperations().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__CheckTypes_FWD__Match() {
		return getCreateInheritanceRule().getEOperations().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__IsAppropriate_BWD__Match_DBTable_DBTable_DBSchema() {
		return getCreateInheritanceRule().getEOperations().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__Perform_BWD__IsApplicableMatch() {
		return getCreateInheritanceRule().getEOperations().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__IsApplicable_BWD__Match() {
		return getCreateInheritanceRule().getEOperations().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__RegisterObjectsToMatch_BWD__Match_DBTable_DBTable_DBSchema() {
		return getCreateInheritanceRule().getEOperations().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__IsAppropriate_solveCsp_BWD__Match_DBTable_DBTable_DBSchema() {
		return getCreateInheritanceRule().getEOperations().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__IsAppropriate_checkCsp_BWD__CSP() {
		return getCreateInheritanceRule().getEOperations().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__IsApplicable_solveCsp_BWD__IsApplicableMatch_ClassToTable_DBTable_CDClass_DBTable_PackageToSchema_CDPackage_DBSchema() {
		return getCreateInheritanceRule().getEOperations().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__IsApplicable_checkCsp_BWD__CSP() {
		return getCreateInheritanceRule().getEOperations().get(17);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject() {
		return getCreateInheritanceRule().getEOperations().get(18);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__CheckTypes_BWD__Match() {
		return getCreateInheritanceRule().getEOperations().get(19);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__IsAppropriate_FWD_EMoflonEdge_3__EMoflonEdge() {
		return getCreateInheritanceRule().getEOperations().get(20);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__IsAppropriate_BWD_EMoflonEdge_3__EMoflonEdge() {
		return getCreateInheritanceRule().getEOperations().get(21);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__CheckAttributes_FWD__TripleMatch() {
		return getCreateInheritanceRule().getEOperations().get(22);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__CheckAttributes_BWD__TripleMatch() {
		return getCreateInheritanceRule().getEOperations().get(23);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__IsApplicable_CC__Match_Match() {
		return getCreateInheritanceRule().getEOperations().get(24);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__IsApplicable_solveCsp_CC__DBTable_CDClass_DBTable_CDClass_CDPackage_DBSchema_Match_Match() {
		return getCreateInheritanceRule().getEOperations().get(25);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__IsApplicable_checkCsp_CC__CSP() {
		return getCreateInheritanceRule().getEOperations().get(26);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__CheckDEC_FWD__CDClass_CDClass_CDPackage() {
		return getCreateInheritanceRule().getEOperations().get(27);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__CheckDEC_BWD__DBTable_DBTable_DBSchema() {
		return getCreateInheritanceRule().getEOperations().get(28);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__GenerateModel__RuleEntryContainer_ClassToTable() {
		return getCreateInheritanceRule().getEOperations().get(29);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__GenerateModel_solveCsp_BWD__IsApplicableMatch_ClassToTable_DBTable_CDClass_PackageToSchema_CDPackage_DBSchema_ModelgeneratorRuleResult() {
		return getCreateInheritanceRule().getEOperations().get(30);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateInheritanceRule__GenerateModel_checkCsp_BWD__CSP() {
		return getCreateInheritanceRule().getEOperations().get(31);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPackageToSchemaRule() {
		if (packageToSchemaRuleEClass == null) {
			packageToSchemaRuleEClass = (EClass) EPackage.Registry.INSTANCE.getEPackage(RulesPackage.eNS_URI)
					.getEClassifiers().get(4);
		}
		return packageToSchemaRuleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__IsAppropriate_FWD__Match_CDPackage() {
		return getPackageToSchemaRule().getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__Perform_FWD__IsApplicableMatch() {
		return getPackageToSchemaRule().getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__IsApplicable_FWD__Match() {
		return getPackageToSchemaRule().getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__RegisterObjectsToMatch_FWD__Match_CDPackage() {
		return getPackageToSchemaRule().getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__IsAppropriate_solveCsp_FWD__Match_CDPackage() {
		return getPackageToSchemaRule().getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__IsAppropriate_checkCsp_FWD__CSP() {
		return getPackageToSchemaRule().getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__IsApplicable_solveCsp_FWD__IsApplicableMatch_CDPackage() {
		return getPackageToSchemaRule().getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__IsApplicable_checkCsp_FWD__CSP() {
		return getPackageToSchemaRule().getEOperations().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject() {
		return getPackageToSchemaRule().getEOperations().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__CheckTypes_FWD__Match() {
		return getPackageToSchemaRule().getEOperations().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__IsAppropriate_BWD__Match_DBSchema() {
		return getPackageToSchemaRule().getEOperations().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__Perform_BWD__IsApplicableMatch() {
		return getPackageToSchemaRule().getEOperations().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__IsApplicable_BWD__Match() {
		return getPackageToSchemaRule().getEOperations().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__RegisterObjectsToMatch_BWD__Match_DBSchema() {
		return getPackageToSchemaRule().getEOperations().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__IsAppropriate_solveCsp_BWD__Match_DBSchema() {
		return getPackageToSchemaRule().getEOperations().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__IsAppropriate_checkCsp_BWD__CSP() {
		return getPackageToSchemaRule().getEOperations().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__IsApplicable_solveCsp_BWD__IsApplicableMatch_DBSchema() {
		return getPackageToSchemaRule().getEOperations().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__IsApplicable_checkCsp_BWD__CSP() {
		return getPackageToSchemaRule().getEOperations().get(17);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject() {
		return getPackageToSchemaRule().getEOperations().get(18);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__CheckTypes_BWD__Match() {
		return getPackageToSchemaRule().getEOperations().get(19);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__IsAppropriate_FWD_CDPackage_0__CDPackage() {
		return getPackageToSchemaRule().getEOperations().get(20);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__IsAppropriate_BWD_DBSchema_0__DBSchema() {
		return getPackageToSchemaRule().getEOperations().get(21);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__CheckAttributes_FWD__TripleMatch() {
		return getPackageToSchemaRule().getEOperations().get(22);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__CheckAttributes_BWD__TripleMatch() {
		return getPackageToSchemaRule().getEOperations().get(23);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__IsApplicable_CC__Match_Match() {
		return getPackageToSchemaRule().getEOperations().get(24);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__IsApplicable_solveCsp_CC__DBSchema_CDPackage_Match_Match() {
		return getPackageToSchemaRule().getEOperations().get(25);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__IsApplicable_checkCsp_CC__CSP() {
		return getPackageToSchemaRule().getEOperations().get(26);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__CheckDEC_FWD__CDPackage() {
		return getPackageToSchemaRule().getEOperations().get(27);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__CheckDEC_BWD__DBSchema() {
		return getPackageToSchemaRule().getEOperations().get(28);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__GenerateModel__RuleEntryContainer() {
		return getPackageToSchemaRule().getEOperations().get(29);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__GenerateModel_solveCsp_BWD__IsApplicableMatch_ModelgeneratorRuleResult() {
		return getPackageToSchemaRule().getEOperations().get(30);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPackageToSchemaRule__GenerateModel_checkCsp_BWD__CSP() {
		return getPackageToSchemaRule().getEOperations().get(31);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTransitiveAttributeRule() {
		if (transitiveAttributeRuleEClass == null) {
			transitiveAttributeRuleEClass = (EClass) EPackage.Registry.INSTANCE.getEPackage(RulesPackage.eNS_URI)
					.getEClassifiers().get(5);
		}
		return transitiveAttributeRuleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__IsAppropriate_FWD__Match_CDClass_CDAttribute() {
		return getTransitiveAttributeRule().getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__Perform_FWD__IsApplicableMatch() {
		return getTransitiveAttributeRule().getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__IsApplicable_FWD__Match() {
		return getTransitiveAttributeRule().getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__RegisterObjectsToMatch_FWD__Match_CDClass_CDAttribute() {
		return getTransitiveAttributeRule().getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__IsAppropriate_solveCsp_FWD__Match_CDClass_CDAttribute() {
		return getTransitiveAttributeRule().getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__IsAppropriate_checkCsp_FWD__CSP() {
		return getTransitiveAttributeRule().getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__IsApplicable_solveCsp_FWD__IsApplicableMatch_DBSchema_DBTable_DBColumn_SuperClassToTable_CDClass_DBTable_ClassToTable_CDAttribute() {
		return getTransitiveAttributeRule().getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__IsApplicable_checkCsp_FWD__CSP() {
		return getTransitiveAttributeRule().getEOperations().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject() {
		return getTransitiveAttributeRule().getEOperations().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__CheckTypes_FWD__Match() {
		return getTransitiveAttributeRule().getEOperations().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__IsAppropriate_BWD__Match_DBSchema_DBTable_DBColumn_DBColumn_DBTable() {
		return getTransitiveAttributeRule().getEOperations().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__Perform_BWD__IsApplicableMatch() {
		return getTransitiveAttributeRule().getEOperations().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__IsApplicable_BWD__Match() {
		return getTransitiveAttributeRule().getEOperations().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__RegisterObjectsToMatch_BWD__Match_DBSchema_DBTable_DBColumn_DBColumn_DBTable() {
		return getTransitiveAttributeRule().getEOperations().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__IsAppropriate_solveCsp_BWD__Match_DBSchema_DBTable_DBColumn_DBColumn_DBTable() {
		return getTransitiveAttributeRule().getEOperations().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__IsAppropriate_checkCsp_BWD__CSP() {
		return getTransitiveAttributeRule().getEOperations().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__IsApplicable_solveCsp_BWD__IsApplicableMatch_DBSchema_DBTable_DBColumn_SuperClassToTable_CDClass_DBColumn_DBTable_ClassToTable_CDAttribute() {
		return getTransitiveAttributeRule().getEOperations().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__IsApplicable_checkCsp_BWD__CSP() {
		return getTransitiveAttributeRule().getEOperations().get(17);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject() {
		return getTransitiveAttributeRule().getEOperations().get(18);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__CheckTypes_BWD__Match() {
		return getTransitiveAttributeRule().getEOperations().get(19);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__IsAppropriate_FWD_EMoflonEdge_4__EMoflonEdge() {
		return getTransitiveAttributeRule().getEOperations().get(20);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__IsAppropriate_BWD_EMoflonEdge_4__EMoflonEdge() {
		return getTransitiveAttributeRule().getEOperations().get(21);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__CheckAttributes_FWD__TripleMatch() {
		return getTransitiveAttributeRule().getEOperations().get(22);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__CheckAttributes_BWD__TripleMatch() {
		return getTransitiveAttributeRule().getEOperations().get(23);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__IsApplicable_CC__Match_Match() {
		return getTransitiveAttributeRule().getEOperations().get(24);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__IsApplicable_solveCsp_CC__DBSchema_DBTable_DBColumn_CDClass_DBColumn_DBTable_CDAttribute_Match_Match() {
		return getTransitiveAttributeRule().getEOperations().get(25);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__IsApplicable_checkCsp_CC__CSP() {
		return getTransitiveAttributeRule().getEOperations().get(26);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__CheckDEC_FWD__CDClass_CDAttribute() {
		return getTransitiveAttributeRule().getEOperations().get(27);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__CheckDEC_BWD__DBSchema_DBTable_DBColumn_DBColumn_DBTable() {
		return getTransitiveAttributeRule().getEOperations().get(28);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__GenerateModel__RuleEntryContainer_ClassToTable() {
		return getTransitiveAttributeRule().getEOperations().get(29);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__GenerateModel_solveCsp_BWD__IsApplicableMatch_DBSchema_DBTable_DBColumn_SuperClassToTable_CDClass_DBTable_ClassToTable_CDAttribute_ModelgeneratorRuleResult() {
		return getTransitiveAttributeRule().getEOperations().get(30);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getTransitiveAttributeRule__GenerateModel_checkCsp_BWD__CSP() {
		return getTransitiveAttributeRule().getEOperations().get(31);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCreateAttributeRule() {
		if (createAttributeRuleEClass == null) {
			createAttributeRuleEClass = (EClass) EPackage.Registry.INSTANCE.getEPackage(RulesPackage.eNS_URI)
					.getEClassifiers().get(6);
		}
		return createAttributeRuleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__IsAppropriate_FWD__Match_CDAttribute_CDClass() {
		return getCreateAttributeRule().getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__Perform_FWD__IsApplicableMatch() {
		return getCreateAttributeRule().getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__IsApplicable_FWD__Match() {
		return getCreateAttributeRule().getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__RegisterObjectsToMatch_FWD__Match_CDAttribute_CDClass() {
		return getCreateAttributeRule().getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__IsAppropriate_solveCsp_FWD__Match_CDAttribute_CDClass() {
		return getCreateAttributeRule().getEOperations().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__IsAppropriate_checkCsp_FWD__CSP() {
		return getCreateAttributeRule().getEOperations().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__IsApplicable_solveCsp_FWD__IsApplicableMatch_ClassToTable_CDAttribute_CDClass_DBTable() {
		return getCreateAttributeRule().getEOperations().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__IsApplicable_checkCsp_FWD__CSP() {
		return getCreateAttributeRule().getEOperations().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject() {
		return getCreateAttributeRule().getEOperations().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__CheckTypes_FWD__Match() {
		return getCreateAttributeRule().getEOperations().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__IsAppropriate_BWD__Match_DBTable_DBColumn() {
		return getCreateAttributeRule().getEOperations().get(10);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__Perform_BWD__IsApplicableMatch() {
		return getCreateAttributeRule().getEOperations().get(11);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__IsApplicable_BWD__Match() {
		return getCreateAttributeRule().getEOperations().get(12);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__RegisterObjectsToMatch_BWD__Match_DBTable_DBColumn() {
		return getCreateAttributeRule().getEOperations().get(13);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__IsAppropriate_solveCsp_BWD__Match_DBTable_DBColumn() {
		return getCreateAttributeRule().getEOperations().get(14);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__IsAppropriate_checkCsp_BWD__CSP() {
		return getCreateAttributeRule().getEOperations().get(15);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__IsApplicable_solveCsp_BWD__IsApplicableMatch_ClassToTable_CDClass_DBTable_DBColumn() {
		return getCreateAttributeRule().getEOperations().get(16);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__IsApplicable_checkCsp_BWD__CSP() {
		return getCreateAttributeRule().getEOperations().get(17);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject() {
		return getCreateAttributeRule().getEOperations().get(18);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__CheckTypes_BWD__Match() {
		return getCreateAttributeRule().getEOperations().get(19);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__IsAppropriate_FWD_EMoflonEdge_5__EMoflonEdge() {
		return getCreateAttributeRule().getEOperations().get(20);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__IsAppropriate_BWD_EMoflonEdge_5__EMoflonEdge() {
		return getCreateAttributeRule().getEOperations().get(21);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__CheckAttributes_FWD__TripleMatch() {
		return getCreateAttributeRule().getEOperations().get(22);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__CheckAttributes_BWD__TripleMatch() {
		return getCreateAttributeRule().getEOperations().get(23);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__IsApplicable_CC__Match_Match() {
		return getCreateAttributeRule().getEOperations().get(24);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__IsApplicable_solveCsp_CC__CDAttribute_CDClass_DBTable_DBColumn_Match_Match() {
		return getCreateAttributeRule().getEOperations().get(25);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__IsApplicable_checkCsp_CC__CSP() {
		return getCreateAttributeRule().getEOperations().get(26);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__CheckDEC_FWD__CDAttribute_CDClass() {
		return getCreateAttributeRule().getEOperations().get(27);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__CheckDEC_BWD__DBTable_DBColumn() {
		return getCreateAttributeRule().getEOperations().get(28);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__GenerateModel__RuleEntryContainer_ClassToTable() {
		return getCreateAttributeRule().getEOperations().get(29);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__GenerateModel_solveCsp_BWD__IsApplicableMatch_ClassToTable_CDClass_DBTable_ModelgeneratorRuleResult() {
		return getCreateAttributeRule().getEOperations().get(30);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getCreateAttributeRule__GenerateModel_checkCsp_BWD__CSP() {
		return getCreateAttributeRule().getEOperations().get(31);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RulesFactory getRulesFactory() {
		return (RulesFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isFixed = false;

	/**
	 * Fixes up the loaded package, to make it appear as if it had been programmatically built.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void fixPackageContents() {
		if (isFixed)
			return;
		isFixed = true;
		fixEClassifiers();
	}

	/**
	 * Sets the instance class on the given classifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void fixInstanceClass(EClassifier eClassifier) {
		if (eClassifier.getInstanceClassName() == null) {
			eClassifier.setInstanceClassName("CDToDB.Rules." + eClassifier.getName());
			setGeneratedClassName(eClassifier);
		}
	}

} //RulesPackageImpl
