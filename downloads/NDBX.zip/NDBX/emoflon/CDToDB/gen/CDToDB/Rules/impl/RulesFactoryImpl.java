/**
 */
package CDToDB.Rules.impl;

import CDToDB.Rules.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class RulesFactoryImpl extends EFactoryImpl implements RulesFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static RulesFactory init() {
		try {
			RulesFactory theRulesFactory = (RulesFactory) EPackage.Registry.INSTANCE.getEFactory(RulesPackage.eNS_URI);
			if (theRulesFactory != null) {
				return theRulesFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new RulesFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RulesFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case RulesPackage.TRANSFER_COLS_RULE:
			return createTransferColsRule();
		case RulesPackage.CLASS_TO_TABLE_RULE:
			return createClassToTableRule();
		case RulesPackage.TRANSITIVE_CORRS_ABOVE:
			return createTransitiveCorrsAbove();
		case RulesPackage.CREATE_INHERITANCE_RULE:
			return createCreateInheritanceRule();
		case RulesPackage.PACKAGE_TO_SCHEMA_RULE:
			return createPackageToSchemaRule();
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE:
			return createTransitiveAttributeRule();
		case RulesPackage.CREATE_ATTRIBUTE_RULE:
			return createCreateAttributeRule();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TransferColsRule createTransferColsRule() {
		TransferColsRuleImpl transferColsRule = new TransferColsRuleImpl();
		return transferColsRule;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ClassToTableRule createClassToTableRule() {
		ClassToTableRuleImpl classToTableRule = new ClassToTableRuleImpl();
		return classToTableRule;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TransitiveCorrsAbove createTransitiveCorrsAbove() {
		TransitiveCorrsAboveImpl transitiveCorrsAbove = new TransitiveCorrsAboveImpl();
		return transitiveCorrsAbove;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CreateInheritanceRule createCreateInheritanceRule() {
		CreateInheritanceRuleImpl createInheritanceRule = new CreateInheritanceRuleImpl();
		return createInheritanceRule;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PackageToSchemaRule createPackageToSchemaRule() {
		PackageToSchemaRuleImpl packageToSchemaRule = new PackageToSchemaRuleImpl();
		return packageToSchemaRule;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TransitiveAttributeRule createTransitiveAttributeRule() {
		TransitiveAttributeRuleImpl transitiveAttributeRule = new TransitiveAttributeRuleImpl();
		return transitiveAttributeRule;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CreateAttributeRule createCreateAttributeRule() {
		CreateAttributeRuleImpl createAttributeRule = new CreateAttributeRuleImpl();
		return createAttributeRule;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RulesPackage getRulesPackage() {
		return (RulesPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static RulesPackage getPackage() {
		return RulesPackage.eINSTANCE;
	}

} //RulesFactoryImpl
