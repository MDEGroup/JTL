/**
 */
package CDToDB.Rules.impl;

import CDToDB.CDToDBFactory;
import CDToDB.ClassToTable;
import CDToDB.PackageToSchema;

import CDToDB.Rules.RulesPackage;
import CDToDB.Rules.TransitiveCorrsAbove;

import CDToDB.SuperClassToTable;

import ClassDiagrams.CDClass;
import ClassDiagrams.CDPackage;

import DatabaseSchemata.DBSchema;
import DatabaseSchemata.DBTable;

import java.lang.Iterable;

import java.lang.reflect.InvocationTargetException;

import java.util.LinkedList;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EOperation;

import org.moflon.tgg.language.csp.CSP;

import org.moflon.tgg.language.modelgenerator.RuleEntryContainer;
import org.moflon.tgg.language.modelgenerator.RuleEntryList;

import org.moflon.tgg.runtime.AttributeConstraintsRuleResult;
import org.moflon.tgg.runtime.CCMatch;
import org.moflon.tgg.runtime.EMoflonEdge;
import org.moflon.tgg.runtime.EObjectContainer;
import org.moflon.tgg.runtime.IsApplicableMatch;
import org.moflon.tgg.runtime.IsApplicableRuleResult;
import org.moflon.tgg.runtime.Match;
import org.moflon.tgg.runtime.ModelgeneratorRuleResult;
import org.moflon.tgg.runtime.PerformRuleResult;
import org.moflon.tgg.runtime.RuntimeFactory;
import org.moflon.tgg.runtime.TripleMatch;

import org.moflon.tgg.runtime.impl.AbstractRuleImpl;
// <-- [user defined imports]
import org.moflon.tgg.csp.*;
import CDToDB.csp.constraints.*;
import org.moflon.tgg.csp.constraints.*;
import org.moflon.tgg.language.csp.*;
import org.moflon.tgg.runtime.TripleMatchNodeMapping;
import java.util.Optional;
import org.moflon.tgg.algorithm.delta.attribute.CheckAttributeHelper;
import SDMLanguage.expressions.ComparingOperator;
import org.moflon.tgg.runtime.TripleMatchNodeMapping;
import java.util.Optional;
import org.moflon.tgg.algorithm.delta.attribute.CheckAttributeHelper;
import SDMLanguage.expressions.ComparingOperator;
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Transitive Corrs Above</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class TransitiveCorrsAboveImpl extends AbstractRuleImpl implements TransitiveCorrsAbove {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TransitiveCorrsAboveImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RulesPackage.eINSTANCE.getTransitiveCorrsAbove();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_FWD(Match match, CDClass transitiveSuperClass, CDPackage p, CDClass superClass,
			CDClass subClass) {

		Object[] result1_black = TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_0_1_initialbindings_blackBBBBBB(
				this, match, transitiveSuperClass, p, superClass, subClass);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[match] = " + match + ", " + "[transitiveSuperClass] = " + transitiveSuperClass + ", " + "[p] = "
					+ p + ", " + "[superClass] = " + superClass + ", " + "[subClass] = " + subClass + ".");
		}

		Object[] result2_bindingAndBlack = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_0_2_SolveCSP_bindingAndBlackFBBBBBB(this, match, transitiveSuperClass, p,
						superClass, subClass);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[match] = " + match + ", " + "[transitiveSuperClass] = " + transitiveSuperClass + ", " + "[p] = "
					+ p + ", " + "[superClass] = " + superClass + ", " + "[subClass] = " + subClass + ".");
		}
		CSP csp = (CSP) result2_bindingAndBlack[0];
		// 
		if (TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_0_3_CheckCSP_expressionFBB(this, csp)) {

			Object[] result4_black = TransitiveCorrsAboveImpl
					.pattern_TransitiveCorrsAbove_0_4_collectelementstobetranslated_blackBBBBB(match,
							transitiveSuperClass, p, superClass, subClass);
			if (result4_black == null) {
				throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match + ", "
						+ "[transitiveSuperClass] = " + transitiveSuperClass + ", " + "[p] = " + p + ", "
						+ "[superClass] = " + superClass + ", " + "[subClass] = " + subClass + ".");
			}

			Object[] result5_black = TransitiveCorrsAboveImpl
					.pattern_TransitiveCorrsAbove_0_5_collectcontextelements_blackBBBBB(match, transitiveSuperClass, p,
							superClass, subClass);
			if (result5_black == null) {
				throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match + ", "
						+ "[transitiveSuperClass] = " + transitiveSuperClass + ", " + "[p] = " + p + ", "
						+ "[superClass] = " + superClass + ", " + "[subClass] = " + subClass + ".");
			}
			TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_0_5_collectcontextelements_greenBBBBBFFFF(match,
					transitiveSuperClass, p, superClass, subClass);
			//nothing EMoflonEdge p__transitiveSuperClass____classes = (EMoflonEdge) result5_green[5];
			//nothing EMoflonEdge subClass__superClass____superClass = (EMoflonEdge) result5_green[6];
			//nothing EMoflonEdge p__subClass____classes = (EMoflonEdge) result5_green[7];
			//nothing EMoflonEdge p__superClass____classes = (EMoflonEdge) result5_green[8];

			// 
			TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_0_6_registerobjectstomatch_expressionBBBBBB(this,
					match, transitiveSuperClass, p, superClass, subClass);
			return TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_0_7_expressionF();
		} else {
			return TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_0_8_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformRuleResult perform_FWD(IsApplicableMatch isApplicableMatch) {

		Object[] result1_bindingAndBlack = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_1_1_performtransformation_bindingAndBlackFFFFFFFFFFFFFBB(this,
						isApplicableMatch);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[isApplicableMatch] = " + isApplicableMatch + ".");
		}
		DBTable subTable = (DBTable) result1_bindingAndBlack[0];
		CDClass transitiveSuperClass = (CDClass) result1_bindingAndBlack[1];
		CDPackage p = (CDPackage) result1_bindingAndBlack[2];
		DBTable superTable = (DBTable) result1_bindingAndBlack[3];
		SuperClassToTable transCorr = (SuperClassToTable) result1_bindingAndBlack[4];
		SuperClassToTable transitiveCorr = (SuperClassToTable) result1_bindingAndBlack[5];
		ClassToTable subCorr = (ClassToTable) result1_bindingAndBlack[6];
		ClassToTable supCorr = (ClassToTable) result1_bindingAndBlack[7];
		CDClass superClass = (CDClass) result1_bindingAndBlack[8];
		PackageToSchema p2s = (PackageToSchema) result1_bindingAndBlack[9];
		CDClass subClass = (CDClass) result1_bindingAndBlack[10];
		DBSchema s = (DBSchema) result1_bindingAndBlack[11];
		//nothing CSP csp = (CSP) result1_bindingAndBlack[12];
		Object[] result1_green = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_1_1_performtransformation_greenBBF(subTable, transitiveSuperClass);
		SuperClassToTable extraTransCorr = (SuperClassToTable) result1_green[2];

		Object[] result2_black = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_1_2_collecttranslatedelements_blackB(extraTransCorr);
		if (result2_black == null) {
			throw new RuntimeException(
					"Pattern matching failed." + " Variables: " + "[extraTransCorr] = " + extraTransCorr + ".");
		}
		Object[] result2_green = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_1_2_collecttranslatedelements_greenFB(extraTransCorr);
		PerformRuleResult ruleresult = (PerformRuleResult) result2_green[0];

		Object[] result3_black = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_1_3_bookkeepingforedges_blackBBBBBBBBBBBBBB(ruleresult, subTable,
						transitiveSuperClass, p, extraTransCorr, superTable, transCorr, transitiveCorr, subCorr,
						supCorr, superClass, p2s, subClass, s);
		if (result3_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[ruleresult] = " + ruleresult
					+ ", " + "[subTable] = " + subTable + ", " + "[transitiveSuperClass] = " + transitiveSuperClass
					+ ", " + "[p] = " + p + ", " + "[extraTransCorr] = " + extraTransCorr + ", " + "[superTable] = "
					+ superTable + ", " + "[transCorr] = " + transCorr + ", " + "[transitiveCorr] = " + transitiveCorr
					+ ", " + "[subCorr] = " + subCorr + ", " + "[supCorr] = " + supCorr + ", " + "[superClass] = "
					+ superClass + ", " + "[p2s] = " + p2s + ", " + "[subClass] = " + subClass + ", " + "[s] = " + s
					+ ".");
		}
		TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_1_3_bookkeepingforedges_greenBBBBFF(ruleresult, subTable,
				transitiveSuperClass, extraTransCorr);
		//nothing EMoflonEdge extraTransCorr__subTable____target = (EMoflonEdge) result3_green[4];
		//nothing EMoflonEdge extraTransCorr__transitiveSuperClass____source = (EMoflonEdge) result3_green[5];

		// 
		// 
		TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_1_5_registerobjects_expressionBBBBBBBBBBBBBBB(this,
				ruleresult, subTable, transitiveSuperClass, p, extraTransCorr, superTable, transCorr, transitiveCorr,
				subCorr, supCorr, superClass, p2s, subClass, s);
		return TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_1_6_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_FWD(Match match) {

		Object[] result1_bindingAndBlack = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_2_1_preparereturnvalue_bindingAndBlackFFB(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		EOperation performOperation = (EOperation) result1_bindingAndBlack[0];
		//nothing EClass eClass = (EClass) result1_bindingAndBlack[1];
		Object[] result1_green = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_2_1_preparereturnvalue_greenBF(performOperation);
		IsApplicableRuleResult ruleresult = (IsApplicableRuleResult) result1_green[1];

		// ForEach 
		Object[] result2_binding = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_2_2_corematch_bindingFFFFB(match);
		if (result2_binding == null) {
			throw new RuntimeException(
					"Binding in node core match failed." + " Variables: " + "[match] = " + match + ".");
		}
		CDClass transitiveSuperClass = (CDClass) result2_binding[0];
		CDPackage p = (CDPackage) result2_binding[1];
		CDClass superClass = (CDClass) result2_binding[2];
		CDClass subClass = (CDClass) result2_binding[3];
		for (Object[] result2_black : TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_2_2_corematch_blackFBBFFFFFBFBFB(transitiveSuperClass, p, superClass,
						subClass, match)) {
			DBTable subTable = (DBTable) result2_black[0];
			DBTable superTable = (DBTable) result2_black[3];
			SuperClassToTable transCorr = (SuperClassToTable) result2_black[4];
			SuperClassToTable transitiveCorr = (SuperClassToTable) result2_black[5];
			ClassToTable subCorr = (ClassToTable) result2_black[6];
			ClassToTable supCorr = (ClassToTable) result2_black[7];
			PackageToSchema p2s = (PackageToSchema) result2_black[9];
			DBSchema s = (DBSchema) result2_black[11];
			// ForEach 
			for (Object[] result3_black : TransitiveCorrsAboveImpl
					.pattern_TransitiveCorrsAbove_2_3_findcontext_blackBBBBBBBBBBBB(subTable, transitiveSuperClass, p,
							superTable, transCorr, transitiveCorr, subCorr, supCorr, superClass, p2s, subClass, s)) {
				Object[] result3_green = TransitiveCorrsAboveImpl
						.pattern_TransitiveCorrsAbove_2_3_findcontext_greenBBBBBBBBBBBBFFFFFFFFFFFFFFFFF(subTable,
								transitiveSuperClass, p, superTable, transCorr, transitiveCorr, subCorr, supCorr,
								superClass, p2s, subClass, s);
				IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result3_green[12];
				//nothing EMoflonEdge transCorr__transitiveSuperClass____source = (EMoflonEdge) result3_green[13];
				//nothing EMoflonEdge p__transitiveSuperClass____classes = (EMoflonEdge) result3_green[14];
				//nothing EMoflonEdge transCorr__superTable____target = (EMoflonEdge) result3_green[15];
				//nothing EMoflonEdge transitiveCorr__superClass____source = (EMoflonEdge) result3_green[16];
				//nothing EMoflonEdge transitiveCorr__subTable____target = (EMoflonEdge) result3_green[17];
				//nothing EMoflonEdge subCorr__subClass____source = (EMoflonEdge) result3_green[18];
				//nothing EMoflonEdge subCorr__subTable____target = (EMoflonEdge) result3_green[19];
				//nothing EMoflonEdge supCorr__superTable____target = (EMoflonEdge) result3_green[20];
				//nothing EMoflonEdge supCorr__superClass____source = (EMoflonEdge) result3_green[21];
				//nothing EMoflonEdge p2s__p____source = (EMoflonEdge) result3_green[22];
				//nothing EMoflonEdge p2s__s____target = (EMoflonEdge) result3_green[23];
				//nothing EMoflonEdge subClass__superClass____superClass = (EMoflonEdge) result3_green[24];
				//nothing EMoflonEdge p__subClass____classes = (EMoflonEdge) result3_green[25];
				//nothing EMoflonEdge p__superClass____classes = (EMoflonEdge) result3_green[26];
				//nothing EMoflonEdge s__superTable____tables = (EMoflonEdge) result3_green[27];
				//nothing EMoflonEdge s__subTable____tables = (EMoflonEdge) result3_green[28];

				Object[] result4_bindingAndBlack = TransitiveCorrsAboveImpl
						.pattern_TransitiveCorrsAbove_2_4_solveCSP_bindingAndBlackFBBBBBBBBBBBBBB(this,
								isApplicableMatch, subTable, transitiveSuperClass, p, superTable, transCorr,
								transitiveCorr, subCorr, supCorr, superClass, p2s, subClass, s);
				if (result4_bindingAndBlack == null) {
					throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
							+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[subTable] = " + subTable + ", "
							+ "[transitiveSuperClass] = " + transitiveSuperClass + ", " + "[p] = " + p + ", "
							+ "[superTable] = " + superTable + ", " + "[transCorr] = " + transCorr + ", "
							+ "[transitiveCorr] = " + transitiveCorr + ", " + "[subCorr] = " + subCorr + ", "
							+ "[supCorr] = " + supCorr + ", " + "[superClass] = " + superClass + ", " + "[p2s] = " + p2s
							+ ", " + "[subClass] = " + subClass + ", " + "[s] = " + s + ".");
				}
				CSP csp = (CSP) result4_bindingAndBlack[0];
				// 
				if (TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_2_5_checkCSP_expressionFBB(this, csp)) {

					Object[] result6_black = TransitiveCorrsAboveImpl
							.pattern_TransitiveCorrsAbove_2_6_addmatchtoruleresult_blackBB(ruleresult,
									isApplicableMatch);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[ruleresult] = "
								+ ruleresult + ", " + "[isApplicableMatch] = " + isApplicableMatch + ".");
					}
					TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_2_6_addmatchtoruleresult_greenBB(ruleresult,
							isApplicableMatch);

				} else {
				}

			}

		}
		return TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_2_7_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjectsToMatch_FWD(Match match, CDClass transitiveSuperClass, CDPackage p, CDClass superClass,
			CDClass subClass) {
		match.registerObject("transitiveSuperClass", transitiveSuperClass);
		match.registerObject("p", p);
		match.registerObject("superClass", superClass);
		match.registerObject("subClass", subClass);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isAppropriate_solveCsp_FWD(Match match, CDClass transitiveSuperClass, CDPackage p, CDClass superClass,
			CDClass subClass) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables

		// Create unbound variables

		// Create constraints

		// Solve CSP
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_checkCsp_FWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_FWD(IsApplicableMatch isApplicableMatch, DBTable subTable,
			CDClass transitiveSuperClass, CDPackage p, DBTable superTable, SuperClassToTable transCorr,
			SuperClassToTable transitiveCorr, ClassToTable subCorr, ClassToTable supCorr, CDClass superClass,
			PackageToSchema p2s, CDClass subClass, DBSchema s) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables
		Variable var_subClass_name = CSPFactoryHelper.eINSTANCE.createVariable("subClass.name", true, csp);
		var_subClass_name.setValue(subClass.getName());
		var_subClass_name.setType("String");
		Variable var_subTable_name = CSPFactoryHelper.eINSTANCE.createVariable("subTable.name", true, csp);
		var_subTable_name.setValue(subTable.getName());
		var_subTable_name.setType("String");

		// Create unbound variables

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_subClass_name, var_subTable_name);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("subTable", subTable);
		isApplicableMatch.registerObject("transitiveSuperClass", transitiveSuperClass);
		isApplicableMatch.registerObject("p", p);
		isApplicableMatch.registerObject("superTable", superTable);
		isApplicableMatch.registerObject("transCorr", transCorr);
		isApplicableMatch.registerObject("transitiveCorr", transitiveCorr);
		isApplicableMatch.registerObject("subCorr", subCorr);
		isApplicableMatch.registerObject("supCorr", supCorr);
		isApplicableMatch.registerObject("superClass", superClass);
		isApplicableMatch.registerObject("p2s", p2s);
		isApplicableMatch.registerObject("subClass", subClass);
		isApplicableMatch.registerObject("s", s);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_FWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjects_FWD(PerformRuleResult ruleresult, EObject subTable, EObject transitiveSuperClass,
			EObject p, EObject extraTransCorr, EObject superTable, EObject transCorr, EObject transitiveCorr,
			EObject subCorr, EObject supCorr, EObject superClass, EObject p2s, EObject subClass, EObject s) {
		ruleresult.registerObject("subTable", subTable);
		ruleresult.registerObject("transitiveSuperClass", transitiveSuperClass);
		ruleresult.registerObject("p", p);
		ruleresult.registerObject("extraTransCorr", extraTransCorr);
		ruleresult.registerObject("superTable", superTable);
		ruleresult.registerObject("transCorr", transCorr);
		ruleresult.registerObject("transitiveCorr", transitiveCorr);
		ruleresult.registerObject("subCorr", subCorr);
		ruleresult.registerObject("supCorr", supCorr);
		ruleresult.registerObject("superClass", superClass);
		ruleresult.registerObject("p2s", p2s);
		ruleresult.registerObject("subClass", subClass);
		ruleresult.registerObject("s", s);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkTypes_FWD(Match match) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_BWD(Match match, DBTable subTable, DBTable superTable, DBSchema s) {

		Object[] result1_black = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_10_1_initialbindings_blackBBBBB(this, match, subTable, superTable, s);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[match] = " + match + ", " + "[subTable] = " + subTable + ", " + "[superTable] = " + superTable
					+ ", " + "[s] = " + s + ".");
		}

		Object[] result2_bindingAndBlack = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_10_2_SolveCSP_bindingAndBlackFBBBBB(this, match, subTable, superTable, s);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[match] = " + match + ", " + "[subTable] = " + subTable + ", " + "[superTable] = " + superTable
					+ ", " + "[s] = " + s + ".");
		}
		CSP csp = (CSP) result2_bindingAndBlack[0];
		// 
		if (TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_10_3_CheckCSP_expressionFBB(this, csp)) {

			Object[] result4_black = TransitiveCorrsAboveImpl
					.pattern_TransitiveCorrsAbove_10_4_collectelementstobetranslated_blackBBBB(match, subTable,
							superTable, s);
			if (result4_black == null) {
				throw new RuntimeException(
						"Pattern matching failed." + " Variables: " + "[match] = " + match + ", " + "[subTable] = "
								+ subTable + ", " + "[superTable] = " + superTable + ", " + "[s] = " + s + ".");
			}

			Object[] result5_black = TransitiveCorrsAboveImpl
					.pattern_TransitiveCorrsAbove_10_5_collectcontextelements_blackBBBB(match, subTable, superTable, s);
			if (result5_black == null) {
				throw new RuntimeException(
						"Pattern matching failed." + " Variables: " + "[match] = " + match + ", " + "[subTable] = "
								+ subTable + ", " + "[superTable] = " + superTable + ", " + "[s] = " + s + ".");
			}
			TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_10_5_collectcontextelements_greenBBBBFF(match,
					subTable, superTable, s);
			//nothing EMoflonEdge s__superTable____tables = (EMoflonEdge) result5_green[4];
			//nothing EMoflonEdge s__subTable____tables = (EMoflonEdge) result5_green[5];

			// 
			TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_10_6_registerobjectstomatch_expressionBBBBB(this,
					match, subTable, superTable, s);
			return TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_10_7_expressionF();
		} else {
			return TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_10_8_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformRuleResult perform_BWD(IsApplicableMatch isApplicableMatch) {

		Object[] result1_bindingAndBlack = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_11_1_performtransformation_bindingAndBlackFFFFFFFFFFFFFBB(this,
						isApplicableMatch);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[isApplicableMatch] = " + isApplicableMatch + ".");
		}
		DBTable subTable = (DBTable) result1_bindingAndBlack[0];
		CDClass transitiveSuperClass = (CDClass) result1_bindingAndBlack[1];
		CDPackage p = (CDPackage) result1_bindingAndBlack[2];
		DBTable superTable = (DBTable) result1_bindingAndBlack[3];
		SuperClassToTable transCorr = (SuperClassToTable) result1_bindingAndBlack[4];
		SuperClassToTable transitiveCorr = (SuperClassToTable) result1_bindingAndBlack[5];
		ClassToTable subCorr = (ClassToTable) result1_bindingAndBlack[6];
		ClassToTable supCorr = (ClassToTable) result1_bindingAndBlack[7];
		CDClass superClass = (CDClass) result1_bindingAndBlack[8];
		PackageToSchema p2s = (PackageToSchema) result1_bindingAndBlack[9];
		CDClass subClass = (CDClass) result1_bindingAndBlack[10];
		DBSchema s = (DBSchema) result1_bindingAndBlack[11];
		//nothing CSP csp = (CSP) result1_bindingAndBlack[12];
		Object[] result1_green = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_11_1_performtransformation_greenBBF(subTable, transitiveSuperClass);
		SuperClassToTable extraTransCorr = (SuperClassToTable) result1_green[2];

		Object[] result2_black = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_11_2_collecttranslatedelements_blackB(extraTransCorr);
		if (result2_black == null) {
			throw new RuntimeException(
					"Pattern matching failed." + " Variables: " + "[extraTransCorr] = " + extraTransCorr + ".");
		}
		Object[] result2_green = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_11_2_collecttranslatedelements_greenFB(extraTransCorr);
		PerformRuleResult ruleresult = (PerformRuleResult) result2_green[0];

		Object[] result3_black = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_11_3_bookkeepingforedges_blackBBBBBBBBBBBBBB(ruleresult, subTable,
						transitiveSuperClass, p, extraTransCorr, superTable, transCorr, transitiveCorr, subCorr,
						supCorr, superClass, p2s, subClass, s);
		if (result3_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[ruleresult] = " + ruleresult
					+ ", " + "[subTable] = " + subTable + ", " + "[transitiveSuperClass] = " + transitiveSuperClass
					+ ", " + "[p] = " + p + ", " + "[extraTransCorr] = " + extraTransCorr + ", " + "[superTable] = "
					+ superTable + ", " + "[transCorr] = " + transCorr + ", " + "[transitiveCorr] = " + transitiveCorr
					+ ", " + "[subCorr] = " + subCorr + ", " + "[supCorr] = " + supCorr + ", " + "[superClass] = "
					+ superClass + ", " + "[p2s] = " + p2s + ", " + "[subClass] = " + subClass + ", " + "[s] = " + s
					+ ".");
		}
		TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_11_3_bookkeepingforedges_greenBBBBFF(ruleresult, subTable,
				transitiveSuperClass, extraTransCorr);
		//nothing EMoflonEdge extraTransCorr__subTable____target = (EMoflonEdge) result3_green[4];
		//nothing EMoflonEdge extraTransCorr__transitiveSuperClass____source = (EMoflonEdge) result3_green[5];

		// 
		// 
		TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_11_5_registerobjects_expressionBBBBBBBBBBBBBBB(this,
				ruleresult, subTable, transitiveSuperClass, p, extraTransCorr, superTable, transCorr, transitiveCorr,
				subCorr, supCorr, superClass, p2s, subClass, s);
		return TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_11_6_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_BWD(Match match) {

		Object[] result1_bindingAndBlack = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_12_1_preparereturnvalue_bindingAndBlackFFB(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		EOperation performOperation = (EOperation) result1_bindingAndBlack[0];
		//nothing EClass eClass = (EClass) result1_bindingAndBlack[1];
		Object[] result1_green = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_12_1_preparereturnvalue_greenBF(performOperation);
		IsApplicableRuleResult ruleresult = (IsApplicableRuleResult) result1_green[1];

		// ForEach 
		Object[] result2_binding = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_12_2_corematch_bindingFFFB(match);
		if (result2_binding == null) {
			throw new RuntimeException(
					"Binding in node core match failed." + " Variables: " + "[match] = " + match + ".");
		}
		DBTable subTable = (DBTable) result2_binding[0];
		DBTable superTable = (DBTable) result2_binding[1];
		DBSchema s = (DBSchema) result2_binding[2];
		for (Object[] result2_black : TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_12_2_corematch_blackBFFBFFFFFFFBB(subTable, superTable, s, match)) {
			CDClass transitiveSuperClass = (CDClass) result2_black[1];
			CDPackage p = (CDPackage) result2_black[2];
			SuperClassToTable transCorr = (SuperClassToTable) result2_black[4];
			SuperClassToTable transitiveCorr = (SuperClassToTable) result2_black[5];
			ClassToTable subCorr = (ClassToTable) result2_black[6];
			ClassToTable supCorr = (ClassToTable) result2_black[7];
			CDClass superClass = (CDClass) result2_black[8];
			PackageToSchema p2s = (PackageToSchema) result2_black[9];
			CDClass subClass = (CDClass) result2_black[10];
			// ForEach 
			for (Object[] result3_black : TransitiveCorrsAboveImpl
					.pattern_TransitiveCorrsAbove_12_3_findcontext_blackBBBBBBBBBBBB(subTable, transitiveSuperClass, p,
							superTable, transCorr, transitiveCorr, subCorr, supCorr, superClass, p2s, subClass, s)) {
				Object[] result3_green = TransitiveCorrsAboveImpl
						.pattern_TransitiveCorrsAbove_12_3_findcontext_greenBBBBBBBBBBBBFFFFFFFFFFFFFFFFF(subTable,
								transitiveSuperClass, p, superTable, transCorr, transitiveCorr, subCorr, supCorr,
								superClass, p2s, subClass, s);
				IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result3_green[12];
				//nothing EMoflonEdge transCorr__transitiveSuperClass____source = (EMoflonEdge) result3_green[13];
				//nothing EMoflonEdge p__transitiveSuperClass____classes = (EMoflonEdge) result3_green[14];
				//nothing EMoflonEdge transCorr__superTable____target = (EMoflonEdge) result3_green[15];
				//nothing EMoflonEdge transitiveCorr__superClass____source = (EMoflonEdge) result3_green[16];
				//nothing EMoflonEdge transitiveCorr__subTable____target = (EMoflonEdge) result3_green[17];
				//nothing EMoflonEdge subCorr__subClass____source = (EMoflonEdge) result3_green[18];
				//nothing EMoflonEdge subCorr__subTable____target = (EMoflonEdge) result3_green[19];
				//nothing EMoflonEdge supCorr__superTable____target = (EMoflonEdge) result3_green[20];
				//nothing EMoflonEdge supCorr__superClass____source = (EMoflonEdge) result3_green[21];
				//nothing EMoflonEdge p2s__p____source = (EMoflonEdge) result3_green[22];
				//nothing EMoflonEdge p2s__s____target = (EMoflonEdge) result3_green[23];
				//nothing EMoflonEdge subClass__superClass____superClass = (EMoflonEdge) result3_green[24];
				//nothing EMoflonEdge p__subClass____classes = (EMoflonEdge) result3_green[25];
				//nothing EMoflonEdge p__superClass____classes = (EMoflonEdge) result3_green[26];
				//nothing EMoflonEdge s__superTable____tables = (EMoflonEdge) result3_green[27];
				//nothing EMoflonEdge s__subTable____tables = (EMoflonEdge) result3_green[28];

				Object[] result4_bindingAndBlack = TransitiveCorrsAboveImpl
						.pattern_TransitiveCorrsAbove_12_4_solveCSP_bindingAndBlackFBBBBBBBBBBBBBB(this,
								isApplicableMatch, subTable, transitiveSuperClass, p, superTable, transCorr,
								transitiveCorr, subCorr, supCorr, superClass, p2s, subClass, s);
				if (result4_bindingAndBlack == null) {
					throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
							+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[subTable] = " + subTable + ", "
							+ "[transitiveSuperClass] = " + transitiveSuperClass + ", " + "[p] = " + p + ", "
							+ "[superTable] = " + superTable + ", " + "[transCorr] = " + transCorr + ", "
							+ "[transitiveCorr] = " + transitiveCorr + ", " + "[subCorr] = " + subCorr + ", "
							+ "[supCorr] = " + supCorr + ", " + "[superClass] = " + superClass + ", " + "[p2s] = " + p2s
							+ ", " + "[subClass] = " + subClass + ", " + "[s] = " + s + ".");
				}
				CSP csp = (CSP) result4_bindingAndBlack[0];
				// 
				if (TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_12_5_checkCSP_expressionFBB(this, csp)) {

					Object[] result6_black = TransitiveCorrsAboveImpl
							.pattern_TransitiveCorrsAbove_12_6_addmatchtoruleresult_blackBB(ruleresult,
									isApplicableMatch);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[ruleresult] = "
								+ ruleresult + ", " + "[isApplicableMatch] = " + isApplicableMatch + ".");
					}
					TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_12_6_addmatchtoruleresult_greenBB(ruleresult,
							isApplicableMatch);

				} else {
				}

			}

		}
		return TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_12_7_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjectsToMatch_BWD(Match match, DBTable subTable, DBTable superTable, DBSchema s) {
		match.registerObject("subTable", subTable);
		match.registerObject("superTable", superTable);
		match.registerObject("s", s);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isAppropriate_solveCsp_BWD(Match match, DBTable subTable, DBTable superTable, DBSchema s) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables

		// Create unbound variables

		// Create constraints

		// Solve CSP
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_BWD(IsApplicableMatch isApplicableMatch, DBTable subTable,
			CDClass transitiveSuperClass, CDPackage p, DBTable superTable, SuperClassToTable transCorr,
			SuperClassToTable transitiveCorr, ClassToTable subCorr, ClassToTable supCorr, CDClass superClass,
			PackageToSchema p2s, CDClass subClass, DBSchema s) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables
		Variable var_subClass_name = CSPFactoryHelper.eINSTANCE.createVariable("subClass.name", true, csp);
		var_subClass_name.setValue(subClass.getName());
		var_subClass_name.setType("String");
		Variable var_subTable_name = CSPFactoryHelper.eINSTANCE.createVariable("subTable.name", true, csp);
		var_subTable_name.setValue(subTable.getName());
		var_subTable_name.setType("String");

		// Create unbound variables

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_subClass_name, var_subTable_name);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("subTable", subTable);
		isApplicableMatch.registerObject("transitiveSuperClass", transitiveSuperClass);
		isApplicableMatch.registerObject("p", p);
		isApplicableMatch.registerObject("superTable", superTable);
		isApplicableMatch.registerObject("transCorr", transCorr);
		isApplicableMatch.registerObject("transitiveCorr", transitiveCorr);
		isApplicableMatch.registerObject("subCorr", subCorr);
		isApplicableMatch.registerObject("supCorr", supCorr);
		isApplicableMatch.registerObject("superClass", superClass);
		isApplicableMatch.registerObject("p2s", p2s);
		isApplicableMatch.registerObject("subClass", subClass);
		isApplicableMatch.registerObject("s", s);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjects_BWD(PerformRuleResult ruleresult, EObject subTable, EObject transitiveSuperClass,
			EObject p, EObject extraTransCorr, EObject superTable, EObject transCorr, EObject transitiveCorr,
			EObject subCorr, EObject supCorr, EObject superClass, EObject p2s, EObject subClass, EObject s) {
		ruleresult.registerObject("subTable", subTable);
		ruleresult.registerObject("transitiveSuperClass", transitiveSuperClass);
		ruleresult.registerObject("p", p);
		ruleresult.registerObject("extraTransCorr", extraTransCorr);
		ruleresult.registerObject("superTable", superTable);
		ruleresult.registerObject("transCorr", transCorr);
		ruleresult.registerObject("transitiveCorr", transitiveCorr);
		ruleresult.registerObject("subCorr", subCorr);
		ruleresult.registerObject("supCorr", supCorr);
		ruleresult.registerObject("superClass", superClass);
		ruleresult.registerObject("p2s", p2s);
		ruleresult.registerObject("subClass", subClass);
		ruleresult.registerObject("s", s);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkTypes_BWD(Match match) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObjectContainer isAppropriate_FWD_EMoflonEdge_2(EMoflonEdge _edge_classes) {

		Object[] result1_bindingAndBlack = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_20_1_preparereturnvalue_bindingAndBlackFFBF(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		EOperation __performOperation = (EOperation) result1_bindingAndBlack[0];
		EClass __eClass = (EClass) result1_bindingAndBlack[1];
		EOperation isApplicableCC = (EOperation) result1_bindingAndBlack[3];
		Object[] result1_green = TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_20_1_preparereturnvalue_greenF();
		EObjectContainer __result = (EObjectContainer) result1_green[0];

		// ForEach 
		for (Object[] result2_black : TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_20_2_testcorematchandDECs_blackFFFFB(_edge_classes)) {
			CDClass transitiveSuperClass = (CDClass) result2_black[0];
			CDPackage p = (CDPackage) result2_black[1];
			CDClass superClass = (CDClass) result2_black[2];
			CDClass subClass = (CDClass) result2_black[3];
			Object[] result2_green = TransitiveCorrsAboveImpl
					.pattern_TransitiveCorrsAbove_20_2_testcorematchandDECs_greenFB(__eClass);
			Match match = (Match) result2_green[0];

			// 
			if (TransitiveCorrsAboveImpl
					.pattern_TransitiveCorrsAbove_20_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBBBB(this,
							match, transitiveSuperClass, p, superClass, subClass)) {
				// 
				if (TransitiveCorrsAboveImpl
						.pattern_TransitiveCorrsAbove_20_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
								this, match)) {

					Object[] result5_black = TransitiveCorrsAboveImpl
							.pattern_TransitiveCorrsAbove_20_5_Addmatchtoruleresult_blackBBBB(match, __performOperation,
									__result, isApplicableCC);
					if (result5_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match
								+ ", " + "[__performOperation] = " + __performOperation + ", " + "[__result] = "
								+ __result + ", " + "[isApplicableCC] = " + isApplicableCC + ".");
					}
					TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_20_5_Addmatchtoruleresult_greenBBBB(match,
							__performOperation, __result, isApplicableCC);

				} else {
				}

			} else {
			}

		}
		return TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_20_6_expressionFB(__result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObjectContainer isAppropriate_BWD_EMoflonEdge_2(EMoflonEdge _edge_tables) {

		Object[] result1_bindingAndBlack = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_21_1_preparereturnvalue_bindingAndBlackFFBF(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		EOperation __performOperation = (EOperation) result1_bindingAndBlack[0];
		EClass __eClass = (EClass) result1_bindingAndBlack[1];
		EOperation isApplicableCC = (EOperation) result1_bindingAndBlack[3];
		Object[] result1_green = TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_21_1_preparereturnvalue_greenF();
		EObjectContainer __result = (EObjectContainer) result1_green[0];

		// ForEach 
		for (Object[] result2_black : TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_21_2_testcorematchandDECs_blackFFFB(_edge_tables)) {
			DBTable subTable = (DBTable) result2_black[0];
			DBTable superTable = (DBTable) result2_black[1];
			DBSchema s = (DBSchema) result2_black[2];
			Object[] result2_green = TransitiveCorrsAboveImpl
					.pattern_TransitiveCorrsAbove_21_2_testcorematchandDECs_greenFB(__eClass);
			Match match = (Match) result2_green[0];

			// 
			if (TransitiveCorrsAboveImpl
					.pattern_TransitiveCorrsAbove_21_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBBB(this,
							match, subTable, superTable, s)) {
				// 
				if (TransitiveCorrsAboveImpl
						.pattern_TransitiveCorrsAbove_21_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
								this, match)) {

					Object[] result5_black = TransitiveCorrsAboveImpl
							.pattern_TransitiveCorrsAbove_21_5_Addmatchtoruleresult_blackBBBB(match, __performOperation,
									__result, isApplicableCC);
					if (result5_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match
								+ ", " + "[__performOperation] = " + __performOperation + ", " + "[__result] = "
								+ __result + ", " + "[isApplicableCC] = " + isApplicableCC + ".");
					}
					TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_21_5_Addmatchtoruleresult_greenBBBB(match,
							__performOperation, __result, isApplicableCC);

				} else {
				}

			} else {
			}

		}
		return TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_21_6_expressionFB(__result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeConstraintsRuleResult checkAttributes_FWD(TripleMatch __tripleMatch) {
		AttributeConstraintsRuleResult ruleResult = org.moflon.tgg.runtime.RuntimeFactory.eINSTANCE
				.createAttributeConstraintsRuleResult();
		ruleResult.setRule("TransitiveCorrsAbove");
		ruleResult.setSuccess(true);

		CSP csp = CspFactory.eINSTANCE.createCSP();

		CheckAttributeHelper __helper = new CheckAttributeHelper(__tripleMatch);

		Variable var_subTable_name = CSPFactoryHelper.eINSTANCE.createVariable("subTable", true, csp);
		var_subTable_name.setValue(__helper.getValue("subTable", "name"));
		var_subTable_name.setType("String");

		Variable var_subClass_name = CSPFactoryHelper.eINSTANCE.createVariable("subClass", true, csp);
		var_subClass_name.setValue(__helper.getValue("subClass", "name"));
		var_subClass_name.setType("String");

		Eq eq0 = new Eq();
		csp.getConstraints().add(eq0);

		eq0.setRuleName("TransitiveCorrsAbove");
		eq0.solve(var_subClass_name, var_subTable_name);

		if (csp.check()) {
			ruleResult.setSuccess(true);
		} else {
			eq0.solve(var_subClass_name, var_subTable_name);
			if (csp.check()) {
				ruleResult.setSuccess(true);
				ruleResult.setRequiredChange(true);
			} else {
				ruleResult.setSuccess(false);
				return ruleResult;
			}
		}

		return ruleResult;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeConstraintsRuleResult checkAttributes_BWD(TripleMatch __tripleMatch) {
		AttributeConstraintsRuleResult ruleResult = org.moflon.tgg.runtime.RuntimeFactory.eINSTANCE
				.createAttributeConstraintsRuleResult();
		ruleResult.setRule("TransitiveCorrsAbove");
		ruleResult.setSuccess(true);

		CSP csp = CspFactory.eINSTANCE.createCSP();

		CheckAttributeHelper __helper = new CheckAttributeHelper(__tripleMatch);

		Variable var_subTable_name = CSPFactoryHelper.eINSTANCE.createVariable("subTable", true, csp);
		var_subTable_name.setValue(__helper.getValue("subTable", "name"));
		var_subTable_name.setType("String");

		Variable var_subClass_name = CSPFactoryHelper.eINSTANCE.createVariable("subClass", true, csp);
		var_subClass_name.setValue(__helper.getValue("subClass", "name"));
		var_subClass_name.setType("String");

		Eq eq0 = new Eq();
		csp.getConstraints().add(eq0);

		eq0.setRuleName("TransitiveCorrsAbove");
		eq0.solve(var_subClass_name, var_subTable_name);

		if (csp.check()) {
			ruleResult.setSuccess(true);
		} else {
			eq0.solve(var_subClass_name, var_subTable_name);
			if (csp.check()) {
				ruleResult.setSuccess(true);
				ruleResult.setRequiredChange(true);
			} else {
				ruleResult.setSuccess(false);
				return ruleResult;
			}
		}

		return ruleResult;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_CC(Match sourceMatch, Match targetMatch) {

		Object[] result1_black = TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_24_1_prepare_blackB(this);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		Object[] result1_green = TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_24_1_prepare_greenF();
		IsApplicableRuleResult result = (IsApplicableRuleResult) result1_green[0];

		Object[] result2_bindingAndBlack = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_24_2_matchsrctrgcontext_bindingAndBlackFFFFFFFBB(sourceMatch,
						targetMatch);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[sourceMatch] = " + sourceMatch
					+ ", " + "[targetMatch] = " + targetMatch + ".");
		}
		DBTable subTable = (DBTable) result2_bindingAndBlack[0];
		CDClass transitiveSuperClass = (CDClass) result2_bindingAndBlack[1];
		CDPackage p = (CDPackage) result2_bindingAndBlack[2];
		DBTable superTable = (DBTable) result2_bindingAndBlack[3];
		CDClass superClass = (CDClass) result2_bindingAndBlack[4];
		CDClass subClass = (CDClass) result2_bindingAndBlack[5];
		DBSchema s = (DBSchema) result2_bindingAndBlack[6];

		Object[] result3_bindingAndBlack = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_24_3_solvecsp_bindingAndBlackFBBBBBBBBBB(this, subTable,
						transitiveSuperClass, p, superTable, superClass, subClass, s, sourceMatch, targetMatch);
		if (result3_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[subTable] = " + subTable + ", " + "[transitiveSuperClass] = " + transitiveSuperClass + ", "
					+ "[p] = " + p + ", " + "[superTable] = " + superTable + ", " + "[superClass] = " + superClass
					+ ", " + "[subClass] = " + subClass + ", " + "[s] = " + s + ", " + "[sourceMatch] = " + sourceMatch
					+ ", " + "[targetMatch] = " + targetMatch + ".");
		}
		CSP csp = (CSP) result3_bindingAndBlack[0];
		// 
		if (TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_24_4_checkCSP_expressionFB(csp)) {
			// ForEach 
			for (Object[] result5_black : TransitiveCorrsAboveImpl
					.pattern_TransitiveCorrsAbove_24_5_matchcorrcontext_blackBBBBFFFFBFBBBB(subTable,
							transitiveSuperClass, p, superTable, superClass, subClass, s, sourceMatch, targetMatch)) {
				SuperClassToTable transCorr = (SuperClassToTable) result5_black[4];
				SuperClassToTable transitiveCorr = (SuperClassToTable) result5_black[5];
				ClassToTable subCorr = (ClassToTable) result5_black[6];
				ClassToTable supCorr = (ClassToTable) result5_black[7];
				PackageToSchema p2s = (PackageToSchema) result5_black[9];
				Object[] result5_green = TransitiveCorrsAboveImpl
						.pattern_TransitiveCorrsAbove_24_5_matchcorrcontext_greenBBBBBBBF(transCorr, transitiveCorr,
								subCorr, supCorr, p2s, sourceMatch, targetMatch);
				CCMatch ccMatch = (CCMatch) result5_green[7];

				Object[] result6_black = TransitiveCorrsAboveImpl
						.pattern_TransitiveCorrsAbove_24_6_createcorrespondence_blackBBBBBBBB(subTable,
								transitiveSuperClass, p, superTable, superClass, subClass, s, ccMatch);
				if (result6_black == null) {
					throw new RuntimeException("Pattern matching failed." + " Variables: " + "[subTable] = " + subTable
							+ ", " + "[transitiveSuperClass] = " + transitiveSuperClass + ", " + "[p] = " + p + ", "
							+ "[superTable] = " + superTable + ", " + "[superClass] = " + superClass + ", "
							+ "[subClass] = " + subClass + ", " + "[s] = " + s + ", " + "[ccMatch] = " + ccMatch + ".");
				}
				TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_24_6_createcorrespondence_greenBBFB(subTable,
						transitiveSuperClass, ccMatch);
				//nothing SuperClassToTable extraTransCorr = (SuperClassToTable) result6_green[2];

				Object[] result7_black = TransitiveCorrsAboveImpl
						.pattern_TransitiveCorrsAbove_24_7_addtoreturnedresult_blackBB(result, ccMatch);
				if (result7_black == null) {
					throw new RuntimeException("Pattern matching failed." + " Variables: " + "[result] = " + result
							+ ", " + "[ccMatch] = " + ccMatch + ".");
				}
				TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_24_7_addtoreturnedresult_greenBB(result, ccMatch);

			}

		} else {
		}
		return TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_24_8_expressionFB(result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_CC(DBTable subTable, CDClass transitiveSuperClass, CDPackage p, DBTable superTable,
			CDClass superClass, CDClass subClass, DBSchema s, Match sourceMatch, Match targetMatch) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables
		Variable var_subClass_name = CSPFactoryHelper.eINSTANCE.createVariable("subClass.name", true, csp);
		var_subClass_name.setValue(subClass.getName());
		var_subClass_name.setType("String");
		Variable var_subTable_name = CSPFactoryHelper.eINSTANCE.createVariable("subTable.name", true, csp);
		var_subTable_name.setValue(subTable.getName());
		var_subTable_name.setType("String");

		// Create unbound variables

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_subClass_name, var_subTable_name);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_CC(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkDEC_FWD(CDClass transitiveSuperClass, CDPackage p, CDClass superClass, CDClass subClass) {// 
		Object[] result1_black = TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_27_1_matchtggpattern_blackBBBB(
				transitiveSuperClass, p, superClass, subClass);
		if (result1_black != null) {
			return TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_27_2_expressionF();
		} else {
			return TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_27_3_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkDEC_BWD(DBTable subTable, DBTable superTable, DBSchema s) {// 
		Object[] result1_black = TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_28_1_matchtggpattern_blackBBB(subTable, superTable, s);
		if (result1_black != null) {
			return TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_28_2_expressionF();
		} else {
			return TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_28_3_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ModelgeneratorRuleResult generateModel(RuleEntryContainer ruleEntryContainer,
			SuperClassToTable transitiveCorrParameter) {

		Object[] result1_black = TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_29_1_createresult_blackB(this);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		Object[] result1_green = TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_29_1_createresult_greenFF();
		IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result1_green[0];
		ModelgeneratorRuleResult ruleResult = (ModelgeneratorRuleResult) result1_green[1];

		// ForEach 
		for (Object[] result2_black : TransitiveCorrsAboveImpl
				.pattern_TransitiveCorrsAbove_29_2_isapplicablecore_blackFFFFFFFFFFFFFBB(ruleEntryContainer,
						ruleResult)) {
			//nothing RuleEntryList transitiveCorrList = (RuleEntryList) result2_black[0];
			DBTable subTable = (DBTable) result2_black[1];
			SuperClassToTable transitiveCorr = (SuperClassToTable) result2_black[2];
			CDClass superClass = (CDClass) result2_black[3];
			ClassToTable supCorr = (ClassToTable) result2_black[4];
			DBTable superTable = (DBTable) result2_black[5];
			SuperClassToTable transCorr = (SuperClassToTable) result2_black[6];
			CDClass transitiveSuperClass = (CDClass) result2_black[7];
			CDPackage p = (CDPackage) result2_black[8];
			CDClass subClass = (CDClass) result2_black[9];
			ClassToTable subCorr = (ClassToTable) result2_black[10];
			PackageToSchema p2s = (PackageToSchema) result2_black[11];
			DBSchema s = (DBSchema) result2_black[12];

			Object[] result3_bindingAndBlack = TransitiveCorrsAboveImpl
					.pattern_TransitiveCorrsAbove_29_3_solveCSP_bindingAndBlackFBBBBBBBBBBBBBBB(this, isApplicableMatch,
							subTable, transitiveSuperClass, p, superTable, transCorr, transitiveCorr, subCorr, supCorr,
							superClass, p2s, subClass, s, ruleResult);
			if (result3_bindingAndBlack == null) {
				throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
						+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[subTable] = " + subTable + ", "
						+ "[transitiveSuperClass] = " + transitiveSuperClass + ", " + "[p] = " + p + ", "
						+ "[superTable] = " + superTable + ", " + "[transCorr] = " + transCorr + ", "
						+ "[transitiveCorr] = " + transitiveCorr + ", " + "[subCorr] = " + subCorr + ", "
						+ "[supCorr] = " + supCorr + ", " + "[superClass] = " + superClass + ", " + "[p2s] = " + p2s
						+ ", " + "[subClass] = " + subClass + ", " + "[s] = " + s + ", " + "[ruleResult] = "
						+ ruleResult + ".");
			}
			CSP csp = (CSP) result3_bindingAndBlack[0];
			// 
			if (TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_29_4_checkCSP_expressionFBB(this, csp)) {
				// 
				Object[] result5_black = TransitiveCorrsAboveImpl
						.pattern_TransitiveCorrsAbove_29_5_checknacs_blackBBBBBBBBBBBB(subTable, transitiveSuperClass,
								p, superTable, transCorr, transitiveCorr, subCorr, supCorr, superClass, p2s, subClass,
								s);
				if (result5_black != null) {

					Object[] result6_black = TransitiveCorrsAboveImpl
							.pattern_TransitiveCorrsAbove_29_6_perform_blackBBBBBBBBBBBBB(subTable,
									transitiveSuperClass, p, superTable, transCorr, transitiveCorr, subCorr, supCorr,
									superClass, p2s, subClass, s, ruleResult);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[subTable] = "
								+ subTable + ", " + "[transitiveSuperClass] = " + transitiveSuperClass + ", " + "[p] = "
								+ p + ", " + "[superTable] = " + superTable + ", " + "[transCorr] = " + transCorr + ", "
								+ "[transitiveCorr] = " + transitiveCorr + ", " + "[subCorr] = " + subCorr + ", "
								+ "[supCorr] = " + supCorr + ", " + "[superClass] = " + superClass + ", " + "[p2s] = "
								+ p2s + ", " + "[subClass] = " + subClass + ", " + "[s] = " + s + ", "
								+ "[ruleResult] = " + ruleResult + ".");
					}
					TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_29_6_perform_greenBBFB(subTable,
							transitiveSuperClass, ruleResult);
					//nothing SuperClassToTable extraTransCorr = (SuperClassToTable) result6_green[2];

				} else {
				}

			} else {
			}

		}
		return TransitiveCorrsAboveImpl.pattern_TransitiveCorrsAbove_29_7_expressionFB(ruleResult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP generateModel_solveCsp_BWD(IsApplicableMatch isApplicableMatch, DBTable subTable,
			CDClass transitiveSuperClass, CDPackage p, DBTable superTable, SuperClassToTable transCorr,
			SuperClassToTable transitiveCorr, ClassToTable subCorr, ClassToTable supCorr, CDClass superClass,
			PackageToSchema p2s, CDClass subClass, DBSchema s, ModelgeneratorRuleResult ruleResult) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables
		Variable var_subClass_name = CSPFactoryHelper.eINSTANCE.createVariable("subClass.name", true, csp);
		var_subClass_name.setValue(subClass.getName());
		var_subClass_name.setType("String");
		Variable var_subTable_name = CSPFactoryHelper.eINSTANCE.createVariable("subTable.name", true, csp);
		var_subTable_name.setValue(subTable.getName());
		var_subTable_name.setType("String");

		// Create unbound variables

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_subClass_name, var_subTable_name);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("subTable", subTable);
		isApplicableMatch.registerObject("transitiveSuperClass", transitiveSuperClass);
		isApplicableMatch.registerObject("p", p);
		isApplicableMatch.registerObject("superTable", superTable);
		isApplicableMatch.registerObject("transCorr", transCorr);
		isApplicableMatch.registerObject("transitiveCorr", transitiveCorr);
		isApplicableMatch.registerObject("subCorr", subCorr);
		isApplicableMatch.registerObject("supCorr", supCorr);
		isApplicableMatch.registerObject("superClass", superClass);
		isApplicableMatch.registerObject("p2s", p2s);
		isApplicableMatch.registerObject("subClass", subClass);
		isApplicableMatch.registerObject("s", s);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean generateModel_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___IS_APPROPRIATE_FWD__MATCH_CDCLASS_CDPACKAGE_CDCLASS_CDCLASS:
			return isAppropriate_FWD((Match) arguments.get(0), (CDClass) arguments.get(1), (CDPackage) arguments.get(2),
					(CDClass) arguments.get(3), (CDClass) arguments.get(4));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___PERFORM_FWD__ISAPPLICABLEMATCH:
			return perform_FWD((IsApplicableMatch) arguments.get(0));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___IS_APPLICABLE_FWD__MATCH:
			return isApplicable_FWD((Match) arguments.get(0));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_CDCLASS_CDPACKAGE_CDCLASS_CDCLASS:
			registerObjectsToMatch_FWD((Match) arguments.get(0), (CDClass) arguments.get(1),
					(CDPackage) arguments.get(2), (CDClass) arguments.get(3), (CDClass) arguments.get(4));
			return null;
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_CDCLASS_CDPACKAGE_CDCLASS_CDCLASS:
			return isAppropriate_solveCsp_FWD((Match) arguments.get(0), (CDClass) arguments.get(1),
					(CDPackage) arguments.get(2), (CDClass) arguments.get(3), (CDClass) arguments.get(4));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___IS_APPROPRIATE_CHECK_CSP_FWD__CSP:
			return isAppropriate_checkCsp_FWD((CSP) arguments.get(0));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_DBTABLE_CDCLASS_CDPACKAGE_DBTABLE_SUPERCLASSTOTABLE_SUPERCLASSTOTABLE_CLASSTOTABLE_CLASSTOTABLE_CDCLASS_PACKAGETOSCHEMA_CDCLASS_DBSCHEMA:
			return isApplicable_solveCsp_FWD((IsApplicableMatch) arguments.get(0), (DBTable) arguments.get(1),
					(CDClass) arguments.get(2), (CDPackage) arguments.get(3), (DBTable) arguments.get(4),
					(SuperClassToTable) arguments.get(5), (SuperClassToTable) arguments.get(6),
					(ClassToTable) arguments.get(7), (ClassToTable) arguments.get(8), (CDClass) arguments.get(9),
					(PackageToSchema) arguments.get(10), (CDClass) arguments.get(11), (DBSchema) arguments.get(12));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___IS_APPLICABLE_CHECK_CSP_FWD__CSP:
			return isApplicable_checkCsp_FWD((CSP) arguments.get(0));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT:
			registerObjects_FWD((PerformRuleResult) arguments.get(0), (EObject) arguments.get(1),
					(EObject) arguments.get(2), (EObject) arguments.get(3), (EObject) arguments.get(4),
					(EObject) arguments.get(5), (EObject) arguments.get(6), (EObject) arguments.get(7),
					(EObject) arguments.get(8), (EObject) arguments.get(9), (EObject) arguments.get(10),
					(EObject) arguments.get(11), (EObject) arguments.get(12), (EObject) arguments.get(13));
			return null;
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___CHECK_TYPES_FWD__MATCH:
			return checkTypes_FWD((Match) arguments.get(0));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___IS_APPROPRIATE_BWD__MATCH_DBTABLE_DBTABLE_DBSCHEMA:
			return isAppropriate_BWD((Match) arguments.get(0), (DBTable) arguments.get(1), (DBTable) arguments.get(2),
					(DBSchema) arguments.get(3));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___PERFORM_BWD__ISAPPLICABLEMATCH:
			return perform_BWD((IsApplicableMatch) arguments.get(0));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___IS_APPLICABLE_BWD__MATCH:
			return isApplicable_BWD((Match) arguments.get(0));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_DBTABLE_DBTABLE_DBSCHEMA:
			registerObjectsToMatch_BWD((Match) arguments.get(0), (DBTable) arguments.get(1), (DBTable) arguments.get(2),
					(DBSchema) arguments.get(3));
			return null;
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_DBTABLE_DBTABLE_DBSCHEMA:
			return isAppropriate_solveCsp_BWD((Match) arguments.get(0), (DBTable) arguments.get(1),
					(DBTable) arguments.get(2), (DBSchema) arguments.get(3));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___IS_APPROPRIATE_CHECK_CSP_BWD__CSP:
			return isAppropriate_checkCsp_BWD((CSP) arguments.get(0));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_DBTABLE_CDCLASS_CDPACKAGE_DBTABLE_SUPERCLASSTOTABLE_SUPERCLASSTOTABLE_CLASSTOTABLE_CLASSTOTABLE_CDCLASS_PACKAGETOSCHEMA_CDCLASS_DBSCHEMA:
			return isApplicable_solveCsp_BWD((IsApplicableMatch) arguments.get(0), (DBTable) arguments.get(1),
					(CDClass) arguments.get(2), (CDPackage) arguments.get(3), (DBTable) arguments.get(4),
					(SuperClassToTable) arguments.get(5), (SuperClassToTable) arguments.get(6),
					(ClassToTable) arguments.get(7), (ClassToTable) arguments.get(8), (CDClass) arguments.get(9),
					(PackageToSchema) arguments.get(10), (CDClass) arguments.get(11), (DBSchema) arguments.get(12));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___IS_APPLICABLE_CHECK_CSP_BWD__CSP:
			return isApplicable_checkCsp_BWD((CSP) arguments.get(0));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT:
			registerObjects_BWD((PerformRuleResult) arguments.get(0), (EObject) arguments.get(1),
					(EObject) arguments.get(2), (EObject) arguments.get(3), (EObject) arguments.get(4),
					(EObject) arguments.get(5), (EObject) arguments.get(6), (EObject) arguments.get(7),
					(EObject) arguments.get(8), (EObject) arguments.get(9), (EObject) arguments.get(10),
					(EObject) arguments.get(11), (EObject) arguments.get(12), (EObject) arguments.get(13));
			return null;
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___CHECK_TYPES_BWD__MATCH:
			return checkTypes_BWD((Match) arguments.get(0));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___IS_APPROPRIATE_FWD_EMOFLON_EDGE_2__EMOFLONEDGE:
			return isAppropriate_FWD_EMoflonEdge_2((EMoflonEdge) arguments.get(0));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___IS_APPROPRIATE_BWD_EMOFLON_EDGE_2__EMOFLONEDGE:
			return isAppropriate_BWD_EMoflonEdge_2((EMoflonEdge) arguments.get(0));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH:
			return checkAttributes_FWD((TripleMatch) arguments.get(0));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH:
			return checkAttributes_BWD((TripleMatch) arguments.get(0));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___IS_APPLICABLE_CC__MATCH_MATCH:
			return isApplicable_CC((Match) arguments.get(0), (Match) arguments.get(1));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___IS_APPLICABLE_SOLVE_CSP_CC__DBTABLE_CDCLASS_CDPACKAGE_DBTABLE_CDCLASS_CDCLASS_DBSCHEMA_MATCH_MATCH:
			return isApplicable_solveCsp_CC((DBTable) arguments.get(0), (CDClass) arguments.get(1),
					(CDPackage) arguments.get(2), (DBTable) arguments.get(3), (CDClass) arguments.get(4),
					(CDClass) arguments.get(5), (DBSchema) arguments.get(6), (Match) arguments.get(7),
					(Match) arguments.get(8));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___IS_APPLICABLE_CHECK_CSP_CC__CSP:
			return isApplicable_checkCsp_CC((CSP) arguments.get(0));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___CHECK_DEC_FWD__CDCLASS_CDPACKAGE_CDCLASS_CDCLASS:
			return checkDEC_FWD((CDClass) arguments.get(0), (CDPackage) arguments.get(1), (CDClass) arguments.get(2),
					(CDClass) arguments.get(3));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___CHECK_DEC_BWD__DBTABLE_DBTABLE_DBSCHEMA:
			return checkDEC_BWD((DBTable) arguments.get(0), (DBTable) arguments.get(1), (DBSchema) arguments.get(2));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___GENERATE_MODEL__RULEENTRYCONTAINER_SUPERCLASSTOTABLE:
			return generateModel((RuleEntryContainer) arguments.get(0), (SuperClassToTable) arguments.get(1));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_DBTABLE_CDCLASS_CDPACKAGE_DBTABLE_SUPERCLASSTOTABLE_SUPERCLASSTOTABLE_CLASSTOTABLE_CLASSTOTABLE_CDCLASS_PACKAGETOSCHEMA_CDCLASS_DBSCHEMA_MODELGENERATORRULERESULT:
			return generateModel_solveCsp_BWD((IsApplicableMatch) arguments.get(0), (DBTable) arguments.get(1),
					(CDClass) arguments.get(2), (CDPackage) arguments.get(3), (DBTable) arguments.get(4),
					(SuperClassToTable) arguments.get(5), (SuperClassToTable) arguments.get(6),
					(ClassToTable) arguments.get(7), (ClassToTable) arguments.get(8), (CDClass) arguments.get(9),
					(PackageToSchema) arguments.get(10), (CDClass) arguments.get(11), (DBSchema) arguments.get(12),
					(ModelgeneratorRuleResult) arguments.get(13));
		case RulesPackage.TRANSITIVE_CORRS_ABOVE___GENERATE_MODEL_CHECK_CSP_BWD__CSP:
			return generateModel_checkCsp_BWD((CSP) arguments.get(0));
		}
		return super.eInvoke(operationID, arguments);
	}

	public static final Object[] pattern_TransitiveCorrsAbove_0_1_initialbindings_blackBBBBBB(
			TransitiveCorrsAbove _this, Match match, CDClass transitiveSuperClass, CDPackage p, CDClass superClass,
			CDClass subClass) {
		if (!superClass.equals(transitiveSuperClass)) {
			if (!subClass.equals(transitiveSuperClass)) {
				if (!subClass.equals(superClass)) {
					return new Object[] { _this, match, transitiveSuperClass, p, superClass, subClass };
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_0_2_SolveCSP_bindingFBBBBBB(TransitiveCorrsAbove _this,
			Match match, CDClass transitiveSuperClass, CDPackage p, CDClass superClass, CDClass subClass) {
		CSP _localVariable_0 = _this.isAppropriate_solveCsp_FWD(match, transitiveSuperClass, p, superClass, subClass);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, match, transitiveSuperClass, p, superClass, subClass };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_0_2_SolveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_0_2_SolveCSP_bindingAndBlackFBBBBBB(
			TransitiveCorrsAbove _this, Match match, CDClass transitiveSuperClass, CDPackage p, CDClass superClass,
			CDClass subClass) {
		Object[] result_pattern_TransitiveCorrsAbove_0_2_SolveCSP_binding = pattern_TransitiveCorrsAbove_0_2_SolveCSP_bindingFBBBBBB(
				_this, match, transitiveSuperClass, p, superClass, subClass);
		if (result_pattern_TransitiveCorrsAbove_0_2_SolveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_TransitiveCorrsAbove_0_2_SolveCSP_binding[0];

			Object[] result_pattern_TransitiveCorrsAbove_0_2_SolveCSP_black = pattern_TransitiveCorrsAbove_0_2_SolveCSP_blackB(
					csp);
			if (result_pattern_TransitiveCorrsAbove_0_2_SolveCSP_black != null) {

				return new Object[] { csp, _this, match, transitiveSuperClass, p, superClass, subClass };
			}
		}
		return null;
	}

	public static final boolean pattern_TransitiveCorrsAbove_0_3_CheckCSP_expressionFBB(TransitiveCorrsAbove _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isAppropriate_checkCsp_FWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_0_4_collectelementstobetranslated_blackBBBBB(Match match,
			CDClass transitiveSuperClass, CDPackage p, CDClass superClass, CDClass subClass) {
		if (!superClass.equals(transitiveSuperClass)) {
			if (!subClass.equals(transitiveSuperClass)) {
				if (!subClass.equals(superClass)) {
					return new Object[] { match, transitiveSuperClass, p, superClass, subClass };
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_0_5_collectcontextelements_blackBBBBB(Match match,
			CDClass transitiveSuperClass, CDPackage p, CDClass superClass, CDClass subClass) {
		if (!superClass.equals(transitiveSuperClass)) {
			if (!subClass.equals(transitiveSuperClass)) {
				if (!subClass.equals(superClass)) {
					return new Object[] { match, transitiveSuperClass, p, superClass, subClass };
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_0_5_collectcontextelements_greenBBBBBFFFF(Match match,
			CDClass transitiveSuperClass, CDPackage p, CDClass superClass, CDClass subClass) {
		EMoflonEdge p__transitiveSuperClass____classes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge subClass__superClass____superClass = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p__subClass____classes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p__superClass____classes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getContextNodes().add(transitiveSuperClass);
		match.getContextNodes().add(p);
		match.getContextNodes().add(superClass);
		match.getContextNodes().add(subClass);
		String p__transitiveSuperClass____classes_name_prime = "classes";
		String subClass__superClass____superClass_name_prime = "superClass";
		String p__subClass____classes_name_prime = "classes";
		String p__superClass____classes_name_prime = "classes";
		p__transitiveSuperClass____classes.setSrc(p);
		p__transitiveSuperClass____classes.setTrg(transitiveSuperClass);
		match.getContextEdges().add(p__transitiveSuperClass____classes);
		subClass__superClass____superClass.setSrc(subClass);
		subClass__superClass____superClass.setTrg(superClass);
		match.getContextEdges().add(subClass__superClass____superClass);
		p__subClass____classes.setSrc(p);
		p__subClass____classes.setTrg(subClass);
		match.getContextEdges().add(p__subClass____classes);
		p__superClass____classes.setSrc(p);
		p__superClass____classes.setTrg(superClass);
		match.getContextEdges().add(p__superClass____classes);
		p__transitiveSuperClass____classes.setName(p__transitiveSuperClass____classes_name_prime);
		subClass__superClass____superClass.setName(subClass__superClass____superClass_name_prime);
		p__subClass____classes.setName(p__subClass____classes_name_prime);
		p__superClass____classes.setName(p__superClass____classes_name_prime);
		return new Object[] { match, transitiveSuperClass, p, superClass, subClass, p__transitiveSuperClass____classes,
				subClass__superClass____superClass, p__subClass____classes, p__superClass____classes };
	}

	public static final void pattern_TransitiveCorrsAbove_0_6_registerobjectstomatch_expressionBBBBBB(
			TransitiveCorrsAbove _this, Match match, CDClass transitiveSuperClass, CDPackage p, CDClass superClass,
			CDClass subClass) {
		_this.registerObjectsToMatch_FWD(match, transitiveSuperClass, p, superClass, subClass);

	}

	public static final boolean pattern_TransitiveCorrsAbove_0_7_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_TransitiveCorrsAbove_0_8_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_1_1_performtransformation_bindingFFFFFFFFFFFFB(
			IsApplicableMatch isApplicableMatch) {
		EObject _localVariable_0 = isApplicableMatch.getObject("subTable");
		EObject _localVariable_1 = isApplicableMatch.getObject("transitiveSuperClass");
		EObject _localVariable_2 = isApplicableMatch.getObject("p");
		EObject _localVariable_3 = isApplicableMatch.getObject("superTable");
		EObject _localVariable_4 = isApplicableMatch.getObject("transCorr");
		EObject _localVariable_5 = isApplicableMatch.getObject("transitiveCorr");
		EObject _localVariable_6 = isApplicableMatch.getObject("subCorr");
		EObject _localVariable_7 = isApplicableMatch.getObject("supCorr");
		EObject _localVariable_8 = isApplicableMatch.getObject("superClass");
		EObject _localVariable_9 = isApplicableMatch.getObject("p2s");
		EObject _localVariable_10 = isApplicableMatch.getObject("subClass");
		EObject _localVariable_11 = isApplicableMatch.getObject("s");
		EObject tmpSubTable = _localVariable_0;
		EObject tmpTransitiveSuperClass = _localVariable_1;
		EObject tmpP = _localVariable_2;
		EObject tmpSuperTable = _localVariable_3;
		EObject tmpTransCorr = _localVariable_4;
		EObject tmpTransitiveCorr = _localVariable_5;
		EObject tmpSubCorr = _localVariable_6;
		EObject tmpSupCorr = _localVariable_7;
		EObject tmpSuperClass = _localVariable_8;
		EObject tmpP2s = _localVariable_9;
		EObject tmpSubClass = _localVariable_10;
		EObject tmpS = _localVariable_11;
		if (tmpSubTable instanceof DBTable) {
			DBTable subTable = (DBTable) tmpSubTable;
			if (tmpTransitiveSuperClass instanceof CDClass) {
				CDClass transitiveSuperClass = (CDClass) tmpTransitiveSuperClass;
				if (tmpP instanceof CDPackage) {
					CDPackage p = (CDPackage) tmpP;
					if (tmpSuperTable instanceof DBTable) {
						DBTable superTable = (DBTable) tmpSuperTable;
						if (tmpTransCorr instanceof SuperClassToTable) {
							SuperClassToTable transCorr = (SuperClassToTable) tmpTransCorr;
							if (tmpTransitiveCorr instanceof SuperClassToTable) {
								SuperClassToTable transitiveCorr = (SuperClassToTable) tmpTransitiveCorr;
								if (tmpSubCorr instanceof ClassToTable) {
									ClassToTable subCorr = (ClassToTable) tmpSubCorr;
									if (tmpSupCorr instanceof ClassToTable) {
										ClassToTable supCorr = (ClassToTable) tmpSupCorr;
										if (tmpSuperClass instanceof CDClass) {
											CDClass superClass = (CDClass) tmpSuperClass;
											if (tmpP2s instanceof PackageToSchema) {
												PackageToSchema p2s = (PackageToSchema) tmpP2s;
												if (tmpSubClass instanceof CDClass) {
													CDClass subClass = (CDClass) tmpSubClass;
													if (tmpS instanceof DBSchema) {
														DBSchema s = (DBSchema) tmpS;
														return new Object[] { subTable, transitiveSuperClass, p,
																superTable, transCorr, transitiveCorr, subCorr, supCorr,
																superClass, p2s, subClass, s, isApplicableMatch };
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_1_1_performtransformation_blackBBBBBBBBBBBBFBB(
			DBTable subTable, CDClass transitiveSuperClass, CDPackage p, DBTable superTable,
			SuperClassToTable transCorr, SuperClassToTable transitiveCorr, ClassToTable subCorr, ClassToTable supCorr,
			CDClass superClass, PackageToSchema p2s, CDClass subClass, DBSchema s, TransitiveCorrsAbove _this,
			IsApplicableMatch isApplicableMatch) {
		if (!subTable.equals(superTable)) {
			if (!transCorr.equals(transitiveCorr)) {
				if (!subCorr.equals(supCorr)) {
					if (!superClass.equals(transitiveSuperClass)) {
						if (!subClass.equals(transitiveSuperClass)) {
							if (!subClass.equals(superClass)) {
								for (EObject tmpCsp : isApplicableMatch.getAttributeInfo()) {
									if (tmpCsp instanceof CSP) {
										CSP csp = (CSP) tmpCsp;
										return new Object[] { subTable, transitiveSuperClass, p, superTable, transCorr,
												transitiveCorr, subCorr, supCorr, superClass, p2s, subClass, s, csp,
												_this, isApplicableMatch };
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_1_1_performtransformation_bindingAndBlackFFFFFFFFFFFFFBB(
			TransitiveCorrsAbove _this, IsApplicableMatch isApplicableMatch) {
		Object[] result_pattern_TransitiveCorrsAbove_1_1_performtransformation_binding = pattern_TransitiveCorrsAbove_1_1_performtransformation_bindingFFFFFFFFFFFFB(
				isApplicableMatch);
		if (result_pattern_TransitiveCorrsAbove_1_1_performtransformation_binding != null) {
			DBTable subTable = (DBTable) result_pattern_TransitiveCorrsAbove_1_1_performtransformation_binding[0];
			CDClass transitiveSuperClass = (CDClass) result_pattern_TransitiveCorrsAbove_1_1_performtransformation_binding[1];
			CDPackage p = (CDPackage) result_pattern_TransitiveCorrsAbove_1_1_performtransformation_binding[2];
			DBTable superTable = (DBTable) result_pattern_TransitiveCorrsAbove_1_1_performtransformation_binding[3];
			SuperClassToTable transCorr = (SuperClassToTable) result_pattern_TransitiveCorrsAbove_1_1_performtransformation_binding[4];
			SuperClassToTable transitiveCorr = (SuperClassToTable) result_pattern_TransitiveCorrsAbove_1_1_performtransformation_binding[5];
			ClassToTable subCorr = (ClassToTable) result_pattern_TransitiveCorrsAbove_1_1_performtransformation_binding[6];
			ClassToTable supCorr = (ClassToTable) result_pattern_TransitiveCorrsAbove_1_1_performtransformation_binding[7];
			CDClass superClass = (CDClass) result_pattern_TransitiveCorrsAbove_1_1_performtransformation_binding[8];
			PackageToSchema p2s = (PackageToSchema) result_pattern_TransitiveCorrsAbove_1_1_performtransformation_binding[9];
			CDClass subClass = (CDClass) result_pattern_TransitiveCorrsAbove_1_1_performtransformation_binding[10];
			DBSchema s = (DBSchema) result_pattern_TransitiveCorrsAbove_1_1_performtransformation_binding[11];

			Object[] result_pattern_TransitiveCorrsAbove_1_1_performtransformation_black = pattern_TransitiveCorrsAbove_1_1_performtransformation_blackBBBBBBBBBBBBFBB(
					subTable, transitiveSuperClass, p, superTable, transCorr, transitiveCorr, subCorr, supCorr,
					superClass, p2s, subClass, s, _this, isApplicableMatch);
			if (result_pattern_TransitiveCorrsAbove_1_1_performtransformation_black != null) {
				CSP csp = (CSP) result_pattern_TransitiveCorrsAbove_1_1_performtransformation_black[12];

				return new Object[] { subTable, transitiveSuperClass, p, superTable, transCorr, transitiveCorr, subCorr,
						supCorr, superClass, p2s, subClass, s, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_1_1_performtransformation_greenBBF(DBTable subTable,
			CDClass transitiveSuperClass) {
		SuperClassToTable extraTransCorr = CDToDBFactory.eINSTANCE.createSuperClassToTable();
		extraTransCorr.setTarget(subTable);
		extraTransCorr.setSource(transitiveSuperClass);
		return new Object[] { subTable, transitiveSuperClass, extraTransCorr };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_1_2_collecttranslatedelements_blackB(
			SuperClassToTable extraTransCorr) {
		return new Object[] { extraTransCorr };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_1_2_collecttranslatedelements_greenFB(
			SuperClassToTable extraTransCorr) {
		PerformRuleResult ruleresult = RuntimeFactory.eINSTANCE.createPerformRuleResult();
		ruleresult.getCreatedLinkElements().add(extraTransCorr);
		return new Object[] { ruleresult, extraTransCorr };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_1_3_bookkeepingforedges_blackBBBBBBBBBBBBBB(
			PerformRuleResult ruleresult, EObject subTable, EObject transitiveSuperClass, EObject p,
			EObject extraTransCorr, EObject superTable, EObject transCorr, EObject transitiveCorr, EObject subCorr,
			EObject supCorr, EObject superClass, EObject p2s, EObject subClass, EObject s) {
		if (!subTable.equals(transitiveSuperClass)) {
			if (!subTable.equals(superTable)) {
				if (!subTable.equals(transCorr)) {
					if (!subTable.equals(transitiveCorr)) {
						if (!subTable.equals(supCorr)) {
							if (!subTable.equals(superClass)) {
								if (!p.equals(subTable)) {
									if (!p.equals(transitiveSuperClass)) {
										if (!p.equals(superTable)) {
											if (!p.equals(transCorr)) {
												if (!p.equals(transitiveCorr)) {
													if (!p.equals(subCorr)) {
														if (!p.equals(supCorr)) {
															if (!p.equals(superClass)) {
																if (!p.equals(p2s)) {
																	if (!p.equals(subClass)) {
																		if (!p.equals(s)) {
																			if (!extraTransCorr.equals(subTable)) {
																				if (!extraTransCorr
																						.equals(transitiveSuperClass)) {
																					if (!extraTransCorr.equals(p)) {
																						if (!extraTransCorr
																								.equals(superTable)) {
																							if (!extraTransCorr.equals(
																									transCorr)) {
																								if (!extraTransCorr
																										.equals(transitiveCorr)) {
																									if (!extraTransCorr
																											.equals(subCorr)) {
																										if (!extraTransCorr
																												.equals(supCorr)) {
																											if (!extraTransCorr
																													.equals(superClass)) {
																												if (!extraTransCorr
																														.equals(p2s)) {
																													if (!extraTransCorr
																															.equals(subClass)) {
																														if (!extraTransCorr
																																.equals(s)) {
																															if (!superTable
																																	.equals(transitiveSuperClass)) {
																																if (!superTable
																																		.equals(transCorr)) {
																																	if (!superTable
																																			.equals(transitiveCorr)) {
																																		if (!transCorr
																																				.equals(transitiveSuperClass)) {
																																			if (!transCorr
																																					.equals(transitiveCorr)) {
																																				if (!transitiveCorr
																																						.equals(transitiveSuperClass)) {
																																					if (!subCorr
																																							.equals(subTable)) {
																																						if (!subCorr
																																								.equals(transitiveSuperClass)) {
																																							if (!subCorr
																																									.equals(superTable)) {
																																								if (!subCorr
																																										.equals(transCorr)) {
																																									if (!subCorr
																																											.equals(transitiveCorr)) {
																																										if (!subCorr
																																												.equals(supCorr)) {
																																											if (!subCorr
																																													.equals(superClass)) {
																																												if (!supCorr
																																														.equals(transitiveSuperClass)) {
																																													if (!supCorr
																																															.equals(superTable)) {
																																														if (!supCorr
																																																.equals(transCorr)) {
																																															if (!supCorr
																																																	.equals(transitiveCorr)) {
																																																if (!supCorr
																																																		.equals(superClass)) {
																																																	if (!superClass
																																																			.equals(transitiveSuperClass)) {
																																																		if (!superClass
																																																				.equals(superTable)) {
																																																			if (!superClass
																																																					.equals(transCorr)) {
																																																				if (!superClass
																																																						.equals(transitiveCorr)) {
																																																					if (!p2s.equals(
																																																							subTable)) {
																																																						if (!p2s.equals(
																																																								transitiveSuperClass)) {
																																																							if (!p2s.equals(
																																																									superTable)) {
																																																								if (!p2s.equals(
																																																										transCorr)) {
																																																									if (!p2s.equals(
																																																											transitiveCorr)) {
																																																										if (!p2s.equals(
																																																												subCorr)) {
																																																											if (!p2s.equals(
																																																													supCorr)) {
																																																												if (!p2s.equals(
																																																														superClass)) {
																																																													if (!p2s.equals(
																																																															subClass)) {
																																																														if (!p2s.equals(
																																																																s)) {
																																																															if (!subClass
																																																																	.equals(subTable)) {
																																																																if (!subClass
																																																																		.equals(transitiveSuperClass)) {
																																																																	if (!subClass
																																																																			.equals(superTable)) {
																																																																		if (!subClass
																																																																				.equals(transCorr)) {
																																																																			if (!subClass
																																																																					.equals(transitiveCorr)) {
																																																																				if (!subClass
																																																																						.equals(subCorr)) {
																																																																					if (!subClass
																																																																							.equals(supCorr)) {
																																																																						if (!subClass
																																																																								.equals(superClass)) {
																																																																							if (!s.equals(
																																																																									subTable)) {
																																																																								if (!s.equals(
																																																																										transitiveSuperClass)) {
																																																																									if (!s.equals(
																																																																											superTable)) {
																																																																										if (!s.equals(
																																																																												transCorr)) {
																																																																											if (!s.equals(
																																																																													transitiveCorr)) {
																																																																												if (!s.equals(
																																																																														subCorr)) {
																																																																													if (!s.equals(
																																																																															supCorr)) {
																																																																														if (!s.equals(
																																																																																superClass)) {
																																																																															if (!s.equals(
																																																																																	subClass)) {
																																																																																return new Object[] {
																																																																																		ruleresult,
																																																																																		subTable,
																																																																																		transitiveSuperClass,
																																																																																		p,
																																																																																		extraTransCorr,
																																																																																		superTable,
																																																																																		transCorr,
																																																																																		transitiveCorr,
																																																																																		subCorr,
																																																																																		supCorr,
																																																																																		superClass,
																																																																																		p2s,
																																																																																		subClass,
																																																																																		s };
																																																																															}
																																																																														}
																																																																													}
																																																																												}
																																																																											}
																																																																										}
																																																																									}
																																																																								}
																																																																							}
																																																																						}
																																																																					}
																																																																				}
																																																																			}
																																																																		}
																																																																	}
																																																																}
																																																															}
																																																														}
																																																													}
																																																												}
																																																											}
																																																										}
																																																									}
																																																								}
																																																							}
																																																						}
																																																					}
																																																				}
																																																			}
																																																		}
																																																	}
																																																}
																																															}
																																														}
																																													}
																																												}
																																											}
																																										}
																																									}
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_1_3_bookkeepingforedges_greenBBBBFF(
			PerformRuleResult ruleresult, EObject subTable, EObject transitiveSuperClass, EObject extraTransCorr) {
		EMoflonEdge extraTransCorr__subTable____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge extraTransCorr__transitiveSuperClass____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String ruleresult_ruleName_prime = "TransitiveCorrsAbove";
		String extraTransCorr__subTable____target_name_prime = "target";
		String extraTransCorr__transitiveSuperClass____source_name_prime = "source";
		extraTransCorr__subTable____target.setSrc(extraTransCorr);
		extraTransCorr__subTable____target.setTrg(subTable);
		ruleresult.getCreatedEdges().add(extraTransCorr__subTable____target);
		extraTransCorr__transitiveSuperClass____source.setSrc(extraTransCorr);
		extraTransCorr__transitiveSuperClass____source.setTrg(transitiveSuperClass);
		ruleresult.getCreatedEdges().add(extraTransCorr__transitiveSuperClass____source);
		ruleresult.setRuleName(ruleresult_ruleName_prime);
		extraTransCorr__subTable____target.setName(extraTransCorr__subTable____target_name_prime);
		extraTransCorr__transitiveSuperClass____source
				.setName(extraTransCorr__transitiveSuperClass____source_name_prime);
		return new Object[] { ruleresult, subTable, transitiveSuperClass, extraTransCorr,
				extraTransCorr__subTable____target, extraTransCorr__transitiveSuperClass____source };
	}

	public static final void pattern_TransitiveCorrsAbove_1_5_registerobjects_expressionBBBBBBBBBBBBBBB(
			TransitiveCorrsAbove _this, PerformRuleResult ruleresult, EObject subTable, EObject transitiveSuperClass,
			EObject p, EObject extraTransCorr, EObject superTable, EObject transCorr, EObject transitiveCorr,
			EObject subCorr, EObject supCorr, EObject superClass, EObject p2s, EObject subClass, EObject s) {
		_this.registerObjects_FWD(ruleresult, subTable, transitiveSuperClass, p, extraTransCorr, superTable, transCorr,
				transitiveCorr, subCorr, supCorr, superClass, p2s, subClass, s);

	}

	public static final PerformRuleResult pattern_TransitiveCorrsAbove_1_6_expressionFB(PerformRuleResult ruleresult) {
		PerformRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_2_1_preparereturnvalue_bindingFB(
			TransitiveCorrsAbove _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass eClass = _localVariable_0;
		if (eClass != null) {
			return new Object[] { eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_2_1_preparereturnvalue_blackFBB(EClass eClass,
			TransitiveCorrsAbove _this) {
		for (EOperation performOperation : eClass.getEOperations()) {
			String performOperation_name = performOperation.getName();
			if (performOperation_name.equals("perform_FWD")) {
				return new Object[] { performOperation, eClass, _this };
			}

		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_2_1_preparereturnvalue_bindingAndBlackFFB(
			TransitiveCorrsAbove _this) {
		Object[] result_pattern_TransitiveCorrsAbove_2_1_preparereturnvalue_binding = pattern_TransitiveCorrsAbove_2_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_TransitiveCorrsAbove_2_1_preparereturnvalue_binding != null) {
			EClass eClass = (EClass) result_pattern_TransitiveCorrsAbove_2_1_preparereturnvalue_binding[0];

			Object[] result_pattern_TransitiveCorrsAbove_2_1_preparereturnvalue_black = pattern_TransitiveCorrsAbove_2_1_preparereturnvalue_blackFBB(
					eClass, _this);
			if (result_pattern_TransitiveCorrsAbove_2_1_preparereturnvalue_black != null) {
				EOperation performOperation = (EOperation) result_pattern_TransitiveCorrsAbove_2_1_preparereturnvalue_black[0];

				return new Object[] { performOperation, eClass, _this };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_2_1_preparereturnvalue_greenBF(
			EOperation performOperation) {
		IsApplicableRuleResult ruleresult = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		boolean ruleresult_success_prime = Boolean.valueOf(false);
		String ruleresult_rule_prime = "TransitiveCorrsAbove";
		ruleresult.setPerformOperation(performOperation);
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		ruleresult.setRule(ruleresult_rule_prime);
		return new Object[] { performOperation, ruleresult };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_2_2_corematch_bindingFFFFB(Match match) {
		EObject _localVariable_0 = match.getObject("transitiveSuperClass");
		EObject _localVariable_1 = match.getObject("p");
		EObject _localVariable_2 = match.getObject("superClass");
		EObject _localVariable_3 = match.getObject("subClass");
		EObject tmpTransitiveSuperClass = _localVariable_0;
		EObject tmpP = _localVariable_1;
		EObject tmpSuperClass = _localVariable_2;
		EObject tmpSubClass = _localVariable_3;
		if (tmpTransitiveSuperClass instanceof CDClass) {
			CDClass transitiveSuperClass = (CDClass) tmpTransitiveSuperClass;
			if (tmpP instanceof CDPackage) {
				CDPackage p = (CDPackage) tmpP;
				if (tmpSuperClass instanceof CDClass) {
					CDClass superClass = (CDClass) tmpSuperClass;
					if (tmpSubClass instanceof CDClass) {
						CDClass subClass = (CDClass) tmpSubClass;
						return new Object[] { transitiveSuperClass, p, superClass, subClass, match };
					}
				}
			}
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_TransitiveCorrsAbove_2_2_corematch_blackFBBFFFFFBFBFB(
			CDClass transitiveSuperClass, CDPackage p, CDClass superClass, CDClass subClass, Match match) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!superClass.equals(transitiveSuperClass)) {
			if (!subClass.equals(transitiveSuperClass)) {
				if (!subClass.equals(superClass)) {
					for (SuperClassToTable transCorr : org.moflon.core.utilities.eMoflonEMFUtil
							.getOppositeReferenceTyped(transitiveSuperClass, SuperClassToTable.class, "source")) {
						DBTable superTable = transCorr.getTarget();
						if (superTable != null) {
							for (SuperClassToTable transitiveCorr : org.moflon.core.utilities.eMoflonEMFUtil
									.getOppositeReferenceTyped(superClass, SuperClassToTable.class, "source")) {
								if (!transCorr.equals(transitiveCorr)) {
									DBTable subTable = transitiveCorr.getTarget();
									if (subTable != null) {
										if (!subTable.equals(superTable)) {
											for (ClassToTable subCorr : org.moflon.core.utilities.eMoflonEMFUtil
													.getOppositeReferenceTyped(subClass, ClassToTable.class,
															"source")) {
												if (subTable.equals(subCorr.getTarget())) {
													for (ClassToTable supCorr : org.moflon.core.utilities.eMoflonEMFUtil
															.getOppositeReferenceTyped(superClass, ClassToTable.class,
																	"source")) {
														if (!subCorr.equals(supCorr)) {
															if (superTable.equals(supCorr.getTarget())) {
																for (PackageToSchema p2s : org.moflon.core.utilities.eMoflonEMFUtil
																		.getOppositeReferenceTyped(p,
																				PackageToSchema.class, "source")) {
																	DBSchema s = p2s.getTarget();
																	if (s != null) {
																		_result.add(new Object[] { subTable,
																				transitiveSuperClass, p, superTable,
																				transCorr, transitiveCorr, subCorr,
																				supCorr, superClass, p2s, subClass, s,
																				match });
																	}

																}
															}
														}
													}
												}
											}
										}
									}

								}
							}
						}

					}
				}
			}
		}
		return _result;
	}

	public static final Iterable<Object[]> pattern_TransitiveCorrsAbove_2_3_findcontext_blackBBBBBBBBBBBB(
			DBTable subTable, CDClass transitiveSuperClass, CDPackage p, DBTable superTable,
			SuperClassToTable transCorr, SuperClassToTable transitiveCorr, ClassToTable subCorr, ClassToTable supCorr,
			CDClass superClass, PackageToSchema p2s, CDClass subClass, DBSchema s) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!subTable.equals(superTable)) {
			if (!transCorr.equals(transitiveCorr)) {
				if (!subCorr.equals(supCorr)) {
					if (!superClass.equals(transitiveSuperClass)) {
						if (!subClass.equals(transitiveSuperClass)) {
							if (!subClass.equals(superClass)) {
								if (transitiveSuperClass.equals(transCorr.getSource())) {
									if (p.getClasses().contains(transitiveSuperClass)) {
										if (superTable.equals(transCorr.getTarget())) {
											if (superClass.equals(transitiveCorr.getSource())) {
												if (subTable.equals(transitiveCorr.getTarget())) {
													if (subClass.equals(subCorr.getSource())) {
														if (subTable.equals(subCorr.getTarget())) {
															if (superTable.equals(supCorr.getTarget())) {
																if (superClass.equals(supCorr.getSource())) {
																	if (p.equals(p2s.getSource())) {
																		if (s.equals(p2s.getTarget())) {
																			if (superClass
																					.equals(subClass.getSuperClass())) {
																				if (p.getClasses().contains(subClass)) {
																					if (p.getClasses()
																							.contains(superClass)) {
																						if (s.getTables()
																								.contains(superTable)) {
																							if (s.getTables().contains(
																									subTable)) {
																								_result.add(
																										new Object[] {
																												subTable,
																												transitiveSuperClass,
																												p,
																												superTable,
																												transCorr,
																												transitiveCorr,
																												subCorr,
																												supCorr,
																												superClass,
																												p2s,
																												subClass,
																												s });
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_2_3_findcontext_greenBBBBBBBBBBBBFFFFFFFFFFFFFFFFF(
			DBTable subTable, CDClass transitiveSuperClass, CDPackage p, DBTable superTable,
			SuperClassToTable transCorr, SuperClassToTable transitiveCorr, ClassToTable subCorr, ClassToTable supCorr,
			CDClass superClass, PackageToSchema p2s, CDClass subClass, DBSchema s) {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		EMoflonEdge transCorr__transitiveSuperClass____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p__transitiveSuperClass____classes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge transCorr__superTable____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge transitiveCorr__superClass____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge transitiveCorr__subTable____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge subCorr__subClass____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge subCorr__subTable____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge supCorr__superTable____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge supCorr__superClass____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p2s__p____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p2s__s____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge subClass__superClass____superClass = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p__subClass____classes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p__superClass____classes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s__superTable____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s__subTable____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String transCorr__transitiveSuperClass____source_name_prime = "source";
		String p__transitiveSuperClass____classes_name_prime = "classes";
		String transCorr__superTable____target_name_prime = "target";
		String transitiveCorr__superClass____source_name_prime = "source";
		String transitiveCorr__subTable____target_name_prime = "target";
		String subCorr__subClass____source_name_prime = "source";
		String subCorr__subTable____target_name_prime = "target";
		String supCorr__superTable____target_name_prime = "target";
		String supCorr__superClass____source_name_prime = "source";
		String p2s__p____source_name_prime = "source";
		String p2s__s____target_name_prime = "target";
		String subClass__superClass____superClass_name_prime = "superClass";
		String p__subClass____classes_name_prime = "classes";
		String p__superClass____classes_name_prime = "classes";
		String s__superTable____tables_name_prime = "tables";
		String s__subTable____tables_name_prime = "tables";
		isApplicableMatch.getAllContextElements().add(subTable);
		isApplicableMatch.getAllContextElements().add(transitiveSuperClass);
		isApplicableMatch.getAllContextElements().add(p);
		isApplicableMatch.getAllContextElements().add(superTable);
		isApplicableMatch.getAllContextElements().add(transCorr);
		isApplicableMatch.getAllContextElements().add(transitiveCorr);
		isApplicableMatch.getAllContextElements().add(subCorr);
		isApplicableMatch.getAllContextElements().add(supCorr);
		isApplicableMatch.getAllContextElements().add(superClass);
		isApplicableMatch.getAllContextElements().add(p2s);
		isApplicableMatch.getAllContextElements().add(subClass);
		isApplicableMatch.getAllContextElements().add(s);
		transCorr__transitiveSuperClass____source.setSrc(transCorr);
		transCorr__transitiveSuperClass____source.setTrg(transitiveSuperClass);
		isApplicableMatch.getAllContextElements().add(transCorr__transitiveSuperClass____source);
		p__transitiveSuperClass____classes.setSrc(p);
		p__transitiveSuperClass____classes.setTrg(transitiveSuperClass);
		isApplicableMatch.getAllContextElements().add(p__transitiveSuperClass____classes);
		transCorr__superTable____target.setSrc(transCorr);
		transCorr__superTable____target.setTrg(superTable);
		isApplicableMatch.getAllContextElements().add(transCorr__superTable____target);
		transitiveCorr__superClass____source.setSrc(transitiveCorr);
		transitiveCorr__superClass____source.setTrg(superClass);
		isApplicableMatch.getAllContextElements().add(transitiveCorr__superClass____source);
		transitiveCorr__subTable____target.setSrc(transitiveCorr);
		transitiveCorr__subTable____target.setTrg(subTable);
		isApplicableMatch.getAllContextElements().add(transitiveCorr__subTable____target);
		subCorr__subClass____source.setSrc(subCorr);
		subCorr__subClass____source.setTrg(subClass);
		isApplicableMatch.getAllContextElements().add(subCorr__subClass____source);
		subCorr__subTable____target.setSrc(subCorr);
		subCorr__subTable____target.setTrg(subTable);
		isApplicableMatch.getAllContextElements().add(subCorr__subTable____target);
		supCorr__superTable____target.setSrc(supCorr);
		supCorr__superTable____target.setTrg(superTable);
		isApplicableMatch.getAllContextElements().add(supCorr__superTable____target);
		supCorr__superClass____source.setSrc(supCorr);
		supCorr__superClass____source.setTrg(superClass);
		isApplicableMatch.getAllContextElements().add(supCorr__superClass____source);
		p2s__p____source.setSrc(p2s);
		p2s__p____source.setTrg(p);
		isApplicableMatch.getAllContextElements().add(p2s__p____source);
		p2s__s____target.setSrc(p2s);
		p2s__s____target.setTrg(s);
		isApplicableMatch.getAllContextElements().add(p2s__s____target);
		subClass__superClass____superClass.setSrc(subClass);
		subClass__superClass____superClass.setTrg(superClass);
		isApplicableMatch.getAllContextElements().add(subClass__superClass____superClass);
		p__subClass____classes.setSrc(p);
		p__subClass____classes.setTrg(subClass);
		isApplicableMatch.getAllContextElements().add(p__subClass____classes);
		p__superClass____classes.setSrc(p);
		p__superClass____classes.setTrg(superClass);
		isApplicableMatch.getAllContextElements().add(p__superClass____classes);
		s__superTable____tables.setSrc(s);
		s__superTable____tables.setTrg(superTable);
		isApplicableMatch.getAllContextElements().add(s__superTable____tables);
		s__subTable____tables.setSrc(s);
		s__subTable____tables.setTrg(subTable);
		isApplicableMatch.getAllContextElements().add(s__subTable____tables);
		transCorr__transitiveSuperClass____source.setName(transCorr__transitiveSuperClass____source_name_prime);
		p__transitiveSuperClass____classes.setName(p__transitiveSuperClass____classes_name_prime);
		transCorr__superTable____target.setName(transCorr__superTable____target_name_prime);
		transitiveCorr__superClass____source.setName(transitiveCorr__superClass____source_name_prime);
		transitiveCorr__subTable____target.setName(transitiveCorr__subTable____target_name_prime);
		subCorr__subClass____source.setName(subCorr__subClass____source_name_prime);
		subCorr__subTable____target.setName(subCorr__subTable____target_name_prime);
		supCorr__superTable____target.setName(supCorr__superTable____target_name_prime);
		supCorr__superClass____source.setName(supCorr__superClass____source_name_prime);
		p2s__p____source.setName(p2s__p____source_name_prime);
		p2s__s____target.setName(p2s__s____target_name_prime);
		subClass__superClass____superClass.setName(subClass__superClass____superClass_name_prime);
		p__subClass____classes.setName(p__subClass____classes_name_prime);
		p__superClass____classes.setName(p__superClass____classes_name_prime);
		s__superTable____tables.setName(s__superTable____tables_name_prime);
		s__subTable____tables.setName(s__subTable____tables_name_prime);
		return new Object[] { subTable, transitiveSuperClass, p, superTable, transCorr, transitiveCorr, subCorr,
				supCorr, superClass, p2s, subClass, s, isApplicableMatch, transCorr__transitiveSuperClass____source,
				p__transitiveSuperClass____classes, transCorr__superTable____target,
				transitiveCorr__superClass____source, transitiveCorr__subTable____target, subCorr__subClass____source,
				subCorr__subTable____target, supCorr__superTable____target, supCorr__superClass____source,
				p2s__p____source, p2s__s____target, subClass__superClass____superClass, p__subClass____classes,
				p__superClass____classes, s__superTable____tables, s__subTable____tables };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_2_4_solveCSP_bindingFBBBBBBBBBBBBBB(
			TransitiveCorrsAbove _this, IsApplicableMatch isApplicableMatch, DBTable subTable,
			CDClass transitiveSuperClass, CDPackage p, DBTable superTable, SuperClassToTable transCorr,
			SuperClassToTable transitiveCorr, ClassToTable subCorr, ClassToTable supCorr, CDClass superClass,
			PackageToSchema p2s, CDClass subClass, DBSchema s) {
		CSP _localVariable_0 = _this.isApplicable_solveCsp_FWD(isApplicableMatch, subTable, transitiveSuperClass, p,
				superTable, transCorr, transitiveCorr, subCorr, supCorr, superClass, p2s, subClass, s);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, subTable, transitiveSuperClass, p, superTable,
					transCorr, transitiveCorr, subCorr, supCorr, superClass, p2s, subClass, s };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_2_4_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_2_4_solveCSP_bindingAndBlackFBBBBBBBBBBBBBB(
			TransitiveCorrsAbove _this, IsApplicableMatch isApplicableMatch, DBTable subTable,
			CDClass transitiveSuperClass, CDPackage p, DBTable superTable, SuperClassToTable transCorr,
			SuperClassToTable transitiveCorr, ClassToTable subCorr, ClassToTable supCorr, CDClass superClass,
			PackageToSchema p2s, CDClass subClass, DBSchema s) {
		Object[] result_pattern_TransitiveCorrsAbove_2_4_solveCSP_binding = pattern_TransitiveCorrsAbove_2_4_solveCSP_bindingFBBBBBBBBBBBBBB(
				_this, isApplicableMatch, subTable, transitiveSuperClass, p, superTable, transCorr, transitiveCorr,
				subCorr, supCorr, superClass, p2s, subClass, s);
		if (result_pattern_TransitiveCorrsAbove_2_4_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_TransitiveCorrsAbove_2_4_solveCSP_binding[0];

			Object[] result_pattern_TransitiveCorrsAbove_2_4_solveCSP_black = pattern_TransitiveCorrsAbove_2_4_solveCSP_blackB(
					csp);
			if (result_pattern_TransitiveCorrsAbove_2_4_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, subTable, transitiveSuperClass, p, superTable,
						transCorr, transitiveCorr, subCorr, supCorr, superClass, p2s, subClass, s };
			}
		}
		return null;
	}

	public static final boolean pattern_TransitiveCorrsAbove_2_5_checkCSP_expressionFBB(TransitiveCorrsAbove _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isApplicable_checkCsp_FWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_2_6_addmatchtoruleresult_blackBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_2_6_addmatchtoruleresult_greenBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		ruleresult.getIsApplicableMatch().add(isApplicableMatch);
		boolean ruleresult_success_prime = Boolean.valueOf(true);
		String isApplicableMatch_ruleName_prime = "TransitiveCorrsAbove";
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		isApplicableMatch.setRuleName(isApplicableMatch_ruleName_prime);
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final IsApplicableRuleResult pattern_TransitiveCorrsAbove_2_7_expressionFB(
			IsApplicableRuleResult ruleresult) {
		IsApplicableRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_10_1_initialbindings_blackBBBBB(
			TransitiveCorrsAbove _this, Match match, DBTable subTable, DBTable superTable, DBSchema s) {
		if (!subTable.equals(superTable)) {
			return new Object[] { _this, match, subTable, superTable, s };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_10_2_SolveCSP_bindingFBBBBB(TransitiveCorrsAbove _this,
			Match match, DBTable subTable, DBTable superTable, DBSchema s) {
		CSP _localVariable_0 = _this.isAppropriate_solveCsp_BWD(match, subTable, superTable, s);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, match, subTable, superTable, s };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_10_2_SolveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_10_2_SolveCSP_bindingAndBlackFBBBBB(
			TransitiveCorrsAbove _this, Match match, DBTable subTable, DBTable superTable, DBSchema s) {
		Object[] result_pattern_TransitiveCorrsAbove_10_2_SolveCSP_binding = pattern_TransitiveCorrsAbove_10_2_SolveCSP_bindingFBBBBB(
				_this, match, subTable, superTable, s);
		if (result_pattern_TransitiveCorrsAbove_10_2_SolveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_TransitiveCorrsAbove_10_2_SolveCSP_binding[0];

			Object[] result_pattern_TransitiveCorrsAbove_10_2_SolveCSP_black = pattern_TransitiveCorrsAbove_10_2_SolveCSP_blackB(
					csp);
			if (result_pattern_TransitiveCorrsAbove_10_2_SolveCSP_black != null) {

				return new Object[] { csp, _this, match, subTable, superTable, s };
			}
		}
		return null;
	}

	public static final boolean pattern_TransitiveCorrsAbove_10_3_CheckCSP_expressionFBB(TransitiveCorrsAbove _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isAppropriate_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_10_4_collectelementstobetranslated_blackBBBB(Match match,
			DBTable subTable, DBTable superTable, DBSchema s) {
		if (!subTable.equals(superTable)) {
			return new Object[] { match, subTable, superTable, s };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_10_5_collectcontextelements_blackBBBB(Match match,
			DBTable subTable, DBTable superTable, DBSchema s) {
		if (!subTable.equals(superTable)) {
			return new Object[] { match, subTable, superTable, s };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_10_5_collectcontextelements_greenBBBBFF(Match match,
			DBTable subTable, DBTable superTable, DBSchema s) {
		EMoflonEdge s__superTable____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s__subTable____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getContextNodes().add(subTable);
		match.getContextNodes().add(superTable);
		match.getContextNodes().add(s);
		String s__superTable____tables_name_prime = "tables";
		String s__subTable____tables_name_prime = "tables";
		s__superTable____tables.setSrc(s);
		s__superTable____tables.setTrg(superTable);
		match.getContextEdges().add(s__superTable____tables);
		s__subTable____tables.setSrc(s);
		s__subTable____tables.setTrg(subTable);
		match.getContextEdges().add(s__subTable____tables);
		s__superTable____tables.setName(s__superTable____tables_name_prime);
		s__subTable____tables.setName(s__subTable____tables_name_prime);
		return new Object[] { match, subTable, superTable, s, s__superTable____tables, s__subTable____tables };
	}

	public static final void pattern_TransitiveCorrsAbove_10_6_registerobjectstomatch_expressionBBBBB(
			TransitiveCorrsAbove _this, Match match, DBTable subTable, DBTable superTable, DBSchema s) {
		_this.registerObjectsToMatch_BWD(match, subTable, superTable, s);

	}

	public static final boolean pattern_TransitiveCorrsAbove_10_7_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_TransitiveCorrsAbove_10_8_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_11_1_performtransformation_bindingFFFFFFFFFFFFB(
			IsApplicableMatch isApplicableMatch) {
		EObject _localVariable_0 = isApplicableMatch.getObject("subTable");
		EObject _localVariable_1 = isApplicableMatch.getObject("transitiveSuperClass");
		EObject _localVariable_2 = isApplicableMatch.getObject("p");
		EObject _localVariable_3 = isApplicableMatch.getObject("superTable");
		EObject _localVariable_4 = isApplicableMatch.getObject("transCorr");
		EObject _localVariable_5 = isApplicableMatch.getObject("transitiveCorr");
		EObject _localVariable_6 = isApplicableMatch.getObject("subCorr");
		EObject _localVariable_7 = isApplicableMatch.getObject("supCorr");
		EObject _localVariable_8 = isApplicableMatch.getObject("superClass");
		EObject _localVariable_9 = isApplicableMatch.getObject("p2s");
		EObject _localVariable_10 = isApplicableMatch.getObject("subClass");
		EObject _localVariable_11 = isApplicableMatch.getObject("s");
		EObject tmpSubTable = _localVariable_0;
		EObject tmpTransitiveSuperClass = _localVariable_1;
		EObject tmpP = _localVariable_2;
		EObject tmpSuperTable = _localVariable_3;
		EObject tmpTransCorr = _localVariable_4;
		EObject tmpTransitiveCorr = _localVariable_5;
		EObject tmpSubCorr = _localVariable_6;
		EObject tmpSupCorr = _localVariable_7;
		EObject tmpSuperClass = _localVariable_8;
		EObject tmpP2s = _localVariable_9;
		EObject tmpSubClass = _localVariable_10;
		EObject tmpS = _localVariable_11;
		if (tmpSubTable instanceof DBTable) {
			DBTable subTable = (DBTable) tmpSubTable;
			if (tmpTransitiveSuperClass instanceof CDClass) {
				CDClass transitiveSuperClass = (CDClass) tmpTransitiveSuperClass;
				if (tmpP instanceof CDPackage) {
					CDPackage p = (CDPackage) tmpP;
					if (tmpSuperTable instanceof DBTable) {
						DBTable superTable = (DBTable) tmpSuperTable;
						if (tmpTransCorr instanceof SuperClassToTable) {
							SuperClassToTable transCorr = (SuperClassToTable) tmpTransCorr;
							if (tmpTransitiveCorr instanceof SuperClassToTable) {
								SuperClassToTable transitiveCorr = (SuperClassToTable) tmpTransitiveCorr;
								if (tmpSubCorr instanceof ClassToTable) {
									ClassToTable subCorr = (ClassToTable) tmpSubCorr;
									if (tmpSupCorr instanceof ClassToTable) {
										ClassToTable supCorr = (ClassToTable) tmpSupCorr;
										if (tmpSuperClass instanceof CDClass) {
											CDClass superClass = (CDClass) tmpSuperClass;
											if (tmpP2s instanceof PackageToSchema) {
												PackageToSchema p2s = (PackageToSchema) tmpP2s;
												if (tmpSubClass instanceof CDClass) {
													CDClass subClass = (CDClass) tmpSubClass;
													if (tmpS instanceof DBSchema) {
														DBSchema s = (DBSchema) tmpS;
														return new Object[] { subTable, transitiveSuperClass, p,
																superTable, transCorr, transitiveCorr, subCorr, supCorr,
																superClass, p2s, subClass, s, isApplicableMatch };
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_11_1_performtransformation_blackBBBBBBBBBBBBFBB(
			DBTable subTable, CDClass transitiveSuperClass, CDPackage p, DBTable superTable,
			SuperClassToTable transCorr, SuperClassToTable transitiveCorr, ClassToTable subCorr, ClassToTable supCorr,
			CDClass superClass, PackageToSchema p2s, CDClass subClass, DBSchema s, TransitiveCorrsAbove _this,
			IsApplicableMatch isApplicableMatch) {
		if (!subTable.equals(superTable)) {
			if (!transCorr.equals(transitiveCorr)) {
				if (!subCorr.equals(supCorr)) {
					if (!superClass.equals(transitiveSuperClass)) {
						if (!subClass.equals(transitiveSuperClass)) {
							if (!subClass.equals(superClass)) {
								for (EObject tmpCsp : isApplicableMatch.getAttributeInfo()) {
									if (tmpCsp instanceof CSP) {
										CSP csp = (CSP) tmpCsp;
										return new Object[] { subTable, transitiveSuperClass, p, superTable, transCorr,
												transitiveCorr, subCorr, supCorr, superClass, p2s, subClass, s, csp,
												_this, isApplicableMatch };
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_11_1_performtransformation_bindingAndBlackFFFFFFFFFFFFFBB(
			TransitiveCorrsAbove _this, IsApplicableMatch isApplicableMatch) {
		Object[] result_pattern_TransitiveCorrsAbove_11_1_performtransformation_binding = pattern_TransitiveCorrsAbove_11_1_performtransformation_bindingFFFFFFFFFFFFB(
				isApplicableMatch);
		if (result_pattern_TransitiveCorrsAbove_11_1_performtransformation_binding != null) {
			DBTable subTable = (DBTable) result_pattern_TransitiveCorrsAbove_11_1_performtransformation_binding[0];
			CDClass transitiveSuperClass = (CDClass) result_pattern_TransitiveCorrsAbove_11_1_performtransformation_binding[1];
			CDPackage p = (CDPackage) result_pattern_TransitiveCorrsAbove_11_1_performtransformation_binding[2];
			DBTable superTable = (DBTable) result_pattern_TransitiveCorrsAbove_11_1_performtransformation_binding[3];
			SuperClassToTable transCorr = (SuperClassToTable) result_pattern_TransitiveCorrsAbove_11_1_performtransformation_binding[4];
			SuperClassToTable transitiveCorr = (SuperClassToTable) result_pattern_TransitiveCorrsAbove_11_1_performtransformation_binding[5];
			ClassToTable subCorr = (ClassToTable) result_pattern_TransitiveCorrsAbove_11_1_performtransformation_binding[6];
			ClassToTable supCorr = (ClassToTable) result_pattern_TransitiveCorrsAbove_11_1_performtransformation_binding[7];
			CDClass superClass = (CDClass) result_pattern_TransitiveCorrsAbove_11_1_performtransformation_binding[8];
			PackageToSchema p2s = (PackageToSchema) result_pattern_TransitiveCorrsAbove_11_1_performtransformation_binding[9];
			CDClass subClass = (CDClass) result_pattern_TransitiveCorrsAbove_11_1_performtransformation_binding[10];
			DBSchema s = (DBSchema) result_pattern_TransitiveCorrsAbove_11_1_performtransformation_binding[11];

			Object[] result_pattern_TransitiveCorrsAbove_11_1_performtransformation_black = pattern_TransitiveCorrsAbove_11_1_performtransformation_blackBBBBBBBBBBBBFBB(
					subTable, transitiveSuperClass, p, superTable, transCorr, transitiveCorr, subCorr, supCorr,
					superClass, p2s, subClass, s, _this, isApplicableMatch);
			if (result_pattern_TransitiveCorrsAbove_11_1_performtransformation_black != null) {
				CSP csp = (CSP) result_pattern_TransitiveCorrsAbove_11_1_performtransformation_black[12];

				return new Object[] { subTable, transitiveSuperClass, p, superTable, transCorr, transitiveCorr, subCorr,
						supCorr, superClass, p2s, subClass, s, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_11_1_performtransformation_greenBBF(DBTable subTable,
			CDClass transitiveSuperClass) {
		SuperClassToTable extraTransCorr = CDToDBFactory.eINSTANCE.createSuperClassToTable();
		extraTransCorr.setTarget(subTable);
		extraTransCorr.setSource(transitiveSuperClass);
		return new Object[] { subTable, transitiveSuperClass, extraTransCorr };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_11_2_collecttranslatedelements_blackB(
			SuperClassToTable extraTransCorr) {
		return new Object[] { extraTransCorr };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_11_2_collecttranslatedelements_greenFB(
			SuperClassToTable extraTransCorr) {
		PerformRuleResult ruleresult = RuntimeFactory.eINSTANCE.createPerformRuleResult();
		ruleresult.getCreatedLinkElements().add(extraTransCorr);
		return new Object[] { ruleresult, extraTransCorr };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_11_3_bookkeepingforedges_blackBBBBBBBBBBBBBB(
			PerformRuleResult ruleresult, EObject subTable, EObject transitiveSuperClass, EObject p,
			EObject extraTransCorr, EObject superTable, EObject transCorr, EObject transitiveCorr, EObject subCorr,
			EObject supCorr, EObject superClass, EObject p2s, EObject subClass, EObject s) {
		if (!subTable.equals(transitiveSuperClass)) {
			if (!subTable.equals(superTable)) {
				if (!subTable.equals(transCorr)) {
					if (!subTable.equals(transitiveCorr)) {
						if (!subTable.equals(supCorr)) {
							if (!subTable.equals(superClass)) {
								if (!p.equals(subTable)) {
									if (!p.equals(transitiveSuperClass)) {
										if (!p.equals(superTable)) {
											if (!p.equals(transCorr)) {
												if (!p.equals(transitiveCorr)) {
													if (!p.equals(subCorr)) {
														if (!p.equals(supCorr)) {
															if (!p.equals(superClass)) {
																if (!p.equals(p2s)) {
																	if (!p.equals(subClass)) {
																		if (!p.equals(s)) {
																			if (!extraTransCorr.equals(subTable)) {
																				if (!extraTransCorr
																						.equals(transitiveSuperClass)) {
																					if (!extraTransCorr.equals(p)) {
																						if (!extraTransCorr
																								.equals(superTable)) {
																							if (!extraTransCorr.equals(
																									transCorr)) {
																								if (!extraTransCorr
																										.equals(transitiveCorr)) {
																									if (!extraTransCorr
																											.equals(subCorr)) {
																										if (!extraTransCorr
																												.equals(supCorr)) {
																											if (!extraTransCorr
																													.equals(superClass)) {
																												if (!extraTransCorr
																														.equals(p2s)) {
																													if (!extraTransCorr
																															.equals(subClass)) {
																														if (!extraTransCorr
																																.equals(s)) {
																															if (!superTable
																																	.equals(transitiveSuperClass)) {
																																if (!superTable
																																		.equals(transCorr)) {
																																	if (!superTable
																																			.equals(transitiveCorr)) {
																																		if (!transCorr
																																				.equals(transitiveSuperClass)) {
																																			if (!transCorr
																																					.equals(transitiveCorr)) {
																																				if (!transitiveCorr
																																						.equals(transitiveSuperClass)) {
																																					if (!subCorr
																																							.equals(subTable)) {
																																						if (!subCorr
																																								.equals(transitiveSuperClass)) {
																																							if (!subCorr
																																									.equals(superTable)) {
																																								if (!subCorr
																																										.equals(transCorr)) {
																																									if (!subCorr
																																											.equals(transitiveCorr)) {
																																										if (!subCorr
																																												.equals(supCorr)) {
																																											if (!subCorr
																																													.equals(superClass)) {
																																												if (!supCorr
																																														.equals(transitiveSuperClass)) {
																																													if (!supCorr
																																															.equals(superTable)) {
																																														if (!supCorr
																																																.equals(transCorr)) {
																																															if (!supCorr
																																																	.equals(transitiveCorr)) {
																																																if (!supCorr
																																																		.equals(superClass)) {
																																																	if (!superClass
																																																			.equals(transitiveSuperClass)) {
																																																		if (!superClass
																																																				.equals(superTable)) {
																																																			if (!superClass
																																																					.equals(transCorr)) {
																																																				if (!superClass
																																																						.equals(transitiveCorr)) {
																																																					if (!p2s.equals(
																																																							subTable)) {
																																																						if (!p2s.equals(
																																																								transitiveSuperClass)) {
																																																							if (!p2s.equals(
																																																									superTable)) {
																																																								if (!p2s.equals(
																																																										transCorr)) {
																																																									if (!p2s.equals(
																																																											transitiveCorr)) {
																																																										if (!p2s.equals(
																																																												subCorr)) {
																																																											if (!p2s.equals(
																																																													supCorr)) {
																																																												if (!p2s.equals(
																																																														superClass)) {
																																																													if (!p2s.equals(
																																																															subClass)) {
																																																														if (!p2s.equals(
																																																																s)) {
																																																															if (!subClass
																																																																	.equals(subTable)) {
																																																																if (!subClass
																																																																		.equals(transitiveSuperClass)) {
																																																																	if (!subClass
																																																																			.equals(superTable)) {
																																																																		if (!subClass
																																																																				.equals(transCorr)) {
																																																																			if (!subClass
																																																																					.equals(transitiveCorr)) {
																																																																				if (!subClass
																																																																						.equals(subCorr)) {
																																																																					if (!subClass
																																																																							.equals(supCorr)) {
																																																																						if (!subClass
																																																																								.equals(superClass)) {
																																																																							if (!s.equals(
																																																																									subTable)) {
																																																																								if (!s.equals(
																																																																										transitiveSuperClass)) {
																																																																									if (!s.equals(
																																																																											superTable)) {
																																																																										if (!s.equals(
																																																																												transCorr)) {
																																																																											if (!s.equals(
																																																																													transitiveCorr)) {
																																																																												if (!s.equals(
																																																																														subCorr)) {
																																																																													if (!s.equals(
																																																																															supCorr)) {
																																																																														if (!s.equals(
																																																																																superClass)) {
																																																																															if (!s.equals(
																																																																																	subClass)) {
																																																																																return new Object[] {
																																																																																		ruleresult,
																																																																																		subTable,
																																																																																		transitiveSuperClass,
																																																																																		p,
																																																																																		extraTransCorr,
																																																																																		superTable,
																																																																																		transCorr,
																																																																																		transitiveCorr,
																																																																																		subCorr,
																																																																																		supCorr,
																																																																																		superClass,
																																																																																		p2s,
																																																																																		subClass,
																																																																																		s };
																																																																															}
																																																																														}
																																																																													}
																																																																												}
																																																																											}
																																																																										}
																																																																									}
																																																																								}
																																																																							}
																																																																						}
																																																																					}
																																																																				}
																																																																			}
																																																																		}
																																																																	}
																																																																}
																																																															}
																																																														}
																																																													}
																																																												}
																																																											}
																																																										}
																																																									}
																																																								}
																																																							}
																																																						}
																																																					}
																																																				}
																																																			}
																																																		}
																																																	}
																																																}
																																															}
																																														}
																																													}
																																												}
																																											}
																																										}
																																									}
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_11_3_bookkeepingforedges_greenBBBBFF(
			PerformRuleResult ruleresult, EObject subTable, EObject transitiveSuperClass, EObject extraTransCorr) {
		EMoflonEdge extraTransCorr__subTable____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge extraTransCorr__transitiveSuperClass____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String ruleresult_ruleName_prime = "TransitiveCorrsAbove";
		String extraTransCorr__subTable____target_name_prime = "target";
		String extraTransCorr__transitiveSuperClass____source_name_prime = "source";
		extraTransCorr__subTable____target.setSrc(extraTransCorr);
		extraTransCorr__subTable____target.setTrg(subTable);
		ruleresult.getCreatedEdges().add(extraTransCorr__subTable____target);
		extraTransCorr__transitiveSuperClass____source.setSrc(extraTransCorr);
		extraTransCorr__transitiveSuperClass____source.setTrg(transitiveSuperClass);
		ruleresult.getCreatedEdges().add(extraTransCorr__transitiveSuperClass____source);
		ruleresult.setRuleName(ruleresult_ruleName_prime);
		extraTransCorr__subTable____target.setName(extraTransCorr__subTable____target_name_prime);
		extraTransCorr__transitiveSuperClass____source
				.setName(extraTransCorr__transitiveSuperClass____source_name_prime);
		return new Object[] { ruleresult, subTable, transitiveSuperClass, extraTransCorr,
				extraTransCorr__subTable____target, extraTransCorr__transitiveSuperClass____source };
	}

	public static final void pattern_TransitiveCorrsAbove_11_5_registerobjects_expressionBBBBBBBBBBBBBBB(
			TransitiveCorrsAbove _this, PerformRuleResult ruleresult, EObject subTable, EObject transitiveSuperClass,
			EObject p, EObject extraTransCorr, EObject superTable, EObject transCorr, EObject transitiveCorr,
			EObject subCorr, EObject supCorr, EObject superClass, EObject p2s, EObject subClass, EObject s) {
		_this.registerObjects_BWD(ruleresult, subTable, transitiveSuperClass, p, extraTransCorr, superTable, transCorr,
				transitiveCorr, subCorr, supCorr, superClass, p2s, subClass, s);

	}

	public static final PerformRuleResult pattern_TransitiveCorrsAbove_11_6_expressionFB(PerformRuleResult ruleresult) {
		PerformRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_12_1_preparereturnvalue_bindingFB(
			TransitiveCorrsAbove _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass eClass = _localVariable_0;
		if (eClass != null) {
			return new Object[] { eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_12_1_preparereturnvalue_blackFBB(EClass eClass,
			TransitiveCorrsAbove _this) {
		for (EOperation performOperation : eClass.getEOperations()) {
			String performOperation_name = performOperation.getName();
			if (performOperation_name.equals("perform_BWD")) {
				return new Object[] { performOperation, eClass, _this };
			}

		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_12_1_preparereturnvalue_bindingAndBlackFFB(
			TransitiveCorrsAbove _this) {
		Object[] result_pattern_TransitiveCorrsAbove_12_1_preparereturnvalue_binding = pattern_TransitiveCorrsAbove_12_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_TransitiveCorrsAbove_12_1_preparereturnvalue_binding != null) {
			EClass eClass = (EClass) result_pattern_TransitiveCorrsAbove_12_1_preparereturnvalue_binding[0];

			Object[] result_pattern_TransitiveCorrsAbove_12_1_preparereturnvalue_black = pattern_TransitiveCorrsAbove_12_1_preparereturnvalue_blackFBB(
					eClass, _this);
			if (result_pattern_TransitiveCorrsAbove_12_1_preparereturnvalue_black != null) {
				EOperation performOperation = (EOperation) result_pattern_TransitiveCorrsAbove_12_1_preparereturnvalue_black[0];

				return new Object[] { performOperation, eClass, _this };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_12_1_preparereturnvalue_greenBF(
			EOperation performOperation) {
		IsApplicableRuleResult ruleresult = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		boolean ruleresult_success_prime = Boolean.valueOf(false);
		String ruleresult_rule_prime = "TransitiveCorrsAbove";
		ruleresult.setPerformOperation(performOperation);
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		ruleresult.setRule(ruleresult_rule_prime);
		return new Object[] { performOperation, ruleresult };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_12_2_corematch_bindingFFFB(Match match) {
		EObject _localVariable_0 = match.getObject("subTable");
		EObject _localVariable_1 = match.getObject("superTable");
		EObject _localVariable_2 = match.getObject("s");
		EObject tmpSubTable = _localVariable_0;
		EObject tmpSuperTable = _localVariable_1;
		EObject tmpS = _localVariable_2;
		if (tmpSubTable instanceof DBTable) {
			DBTable subTable = (DBTable) tmpSubTable;
			if (tmpSuperTable instanceof DBTable) {
				DBTable superTable = (DBTable) tmpSuperTable;
				if (tmpS instanceof DBSchema) {
					DBSchema s = (DBSchema) tmpS;
					return new Object[] { subTable, superTable, s, match };
				}
			}
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_TransitiveCorrsAbove_12_2_corematch_blackBFFBFFFFFFFBB(
			DBTable subTable, DBTable superTable, DBSchema s, Match match) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!subTable.equals(superTable)) {
			for (SuperClassToTable transCorr : org.moflon.core.utilities.eMoflonEMFUtil
					.getOppositeReferenceTyped(superTable, SuperClassToTable.class, "target")) {
				CDClass transitiveSuperClass = transCorr.getSource();
				if (transitiveSuperClass != null) {
					for (SuperClassToTable transitiveCorr : org.moflon.core.utilities.eMoflonEMFUtil
							.getOppositeReferenceTyped(subTable, SuperClassToTable.class, "target")) {
						if (!transCorr.equals(transitiveCorr)) {
							CDClass superClass = transitiveCorr.getSource();
							if (superClass != null) {
								if (!superClass.equals(transitiveSuperClass)) {
									for (ClassToTable subCorr : org.moflon.core.utilities.eMoflonEMFUtil
											.getOppositeReferenceTyped(subTable, ClassToTable.class, "target")) {
										CDClass subClass = subCorr.getSource();
										if (subClass != null) {
											if (!subClass.equals(transitiveSuperClass)) {
												if (!subClass.equals(superClass)) {
													for (ClassToTable supCorr : org.moflon.core.utilities.eMoflonEMFUtil
															.getOppositeReferenceTyped(superTable, ClassToTable.class,
																	"target")) {
														if (!subCorr.equals(supCorr)) {
															if (superClass.equals(supCorr.getSource())) {
																for (PackageToSchema p2s : org.moflon.core.utilities.eMoflonEMFUtil
																		.getOppositeReferenceTyped(s,
																				PackageToSchema.class, "target")) {
																	CDPackage p = p2s.getSource();
																	if (p != null) {
																		_result.add(new Object[] { subTable,
																				transitiveSuperClass, p, superTable,
																				transCorr, transitiveCorr, subCorr,
																				supCorr, superClass, p2s, subClass, s,
																				match });
																	}

																}
															}
														}
													}
												}
											}
										}

									}
								}
							}

						}
					}
				}

			}
		}
		return _result;
	}

	public static final Iterable<Object[]> pattern_TransitiveCorrsAbove_12_3_findcontext_blackBBBBBBBBBBBB(
			DBTable subTable, CDClass transitiveSuperClass, CDPackage p, DBTable superTable,
			SuperClassToTable transCorr, SuperClassToTable transitiveCorr, ClassToTable subCorr, ClassToTable supCorr,
			CDClass superClass, PackageToSchema p2s, CDClass subClass, DBSchema s) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!subTable.equals(superTable)) {
			if (!transCorr.equals(transitiveCorr)) {
				if (!subCorr.equals(supCorr)) {
					if (!superClass.equals(transitiveSuperClass)) {
						if (!subClass.equals(transitiveSuperClass)) {
							if (!subClass.equals(superClass)) {
								if (transitiveSuperClass.equals(transCorr.getSource())) {
									if (p.getClasses().contains(transitiveSuperClass)) {
										if (superTable.equals(transCorr.getTarget())) {
											if (superClass.equals(transitiveCorr.getSource())) {
												if (subTable.equals(transitiveCorr.getTarget())) {
													if (subClass.equals(subCorr.getSource())) {
														if (subTable.equals(subCorr.getTarget())) {
															if (superTable.equals(supCorr.getTarget())) {
																if (superClass.equals(supCorr.getSource())) {
																	if (p.equals(p2s.getSource())) {
																		if (s.equals(p2s.getTarget())) {
																			if (superClass
																					.equals(subClass.getSuperClass())) {
																				if (p.getClasses().contains(subClass)) {
																					if (p.getClasses()
																							.contains(superClass)) {
																						if (s.getTables()
																								.contains(superTable)) {
																							if (s.getTables().contains(
																									subTable)) {
																								_result.add(
																										new Object[] {
																												subTable,
																												transitiveSuperClass,
																												p,
																												superTable,
																												transCorr,
																												transitiveCorr,
																												subCorr,
																												supCorr,
																												superClass,
																												p2s,
																												subClass,
																												s });
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_12_3_findcontext_greenBBBBBBBBBBBBFFFFFFFFFFFFFFFFF(
			DBTable subTable, CDClass transitiveSuperClass, CDPackage p, DBTable superTable,
			SuperClassToTable transCorr, SuperClassToTable transitiveCorr, ClassToTable subCorr, ClassToTable supCorr,
			CDClass superClass, PackageToSchema p2s, CDClass subClass, DBSchema s) {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		EMoflonEdge transCorr__transitiveSuperClass____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p__transitiveSuperClass____classes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge transCorr__superTable____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge transitiveCorr__superClass____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge transitiveCorr__subTable____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge subCorr__subClass____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge subCorr__subTable____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge supCorr__superTable____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge supCorr__superClass____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p2s__p____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p2s__s____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge subClass__superClass____superClass = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p__subClass____classes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p__superClass____classes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s__superTable____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s__subTable____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String transCorr__transitiveSuperClass____source_name_prime = "source";
		String p__transitiveSuperClass____classes_name_prime = "classes";
		String transCorr__superTable____target_name_prime = "target";
		String transitiveCorr__superClass____source_name_prime = "source";
		String transitiveCorr__subTable____target_name_prime = "target";
		String subCorr__subClass____source_name_prime = "source";
		String subCorr__subTable____target_name_prime = "target";
		String supCorr__superTable____target_name_prime = "target";
		String supCorr__superClass____source_name_prime = "source";
		String p2s__p____source_name_prime = "source";
		String p2s__s____target_name_prime = "target";
		String subClass__superClass____superClass_name_prime = "superClass";
		String p__subClass____classes_name_prime = "classes";
		String p__superClass____classes_name_prime = "classes";
		String s__superTable____tables_name_prime = "tables";
		String s__subTable____tables_name_prime = "tables";
		isApplicableMatch.getAllContextElements().add(subTable);
		isApplicableMatch.getAllContextElements().add(transitiveSuperClass);
		isApplicableMatch.getAllContextElements().add(p);
		isApplicableMatch.getAllContextElements().add(superTable);
		isApplicableMatch.getAllContextElements().add(transCorr);
		isApplicableMatch.getAllContextElements().add(transitiveCorr);
		isApplicableMatch.getAllContextElements().add(subCorr);
		isApplicableMatch.getAllContextElements().add(supCorr);
		isApplicableMatch.getAllContextElements().add(superClass);
		isApplicableMatch.getAllContextElements().add(p2s);
		isApplicableMatch.getAllContextElements().add(subClass);
		isApplicableMatch.getAllContextElements().add(s);
		transCorr__transitiveSuperClass____source.setSrc(transCorr);
		transCorr__transitiveSuperClass____source.setTrg(transitiveSuperClass);
		isApplicableMatch.getAllContextElements().add(transCorr__transitiveSuperClass____source);
		p__transitiveSuperClass____classes.setSrc(p);
		p__transitiveSuperClass____classes.setTrg(transitiveSuperClass);
		isApplicableMatch.getAllContextElements().add(p__transitiveSuperClass____classes);
		transCorr__superTable____target.setSrc(transCorr);
		transCorr__superTable____target.setTrg(superTable);
		isApplicableMatch.getAllContextElements().add(transCorr__superTable____target);
		transitiveCorr__superClass____source.setSrc(transitiveCorr);
		transitiveCorr__superClass____source.setTrg(superClass);
		isApplicableMatch.getAllContextElements().add(transitiveCorr__superClass____source);
		transitiveCorr__subTable____target.setSrc(transitiveCorr);
		transitiveCorr__subTable____target.setTrg(subTable);
		isApplicableMatch.getAllContextElements().add(transitiveCorr__subTable____target);
		subCorr__subClass____source.setSrc(subCorr);
		subCorr__subClass____source.setTrg(subClass);
		isApplicableMatch.getAllContextElements().add(subCorr__subClass____source);
		subCorr__subTable____target.setSrc(subCorr);
		subCorr__subTable____target.setTrg(subTable);
		isApplicableMatch.getAllContextElements().add(subCorr__subTable____target);
		supCorr__superTable____target.setSrc(supCorr);
		supCorr__superTable____target.setTrg(superTable);
		isApplicableMatch.getAllContextElements().add(supCorr__superTable____target);
		supCorr__superClass____source.setSrc(supCorr);
		supCorr__superClass____source.setTrg(superClass);
		isApplicableMatch.getAllContextElements().add(supCorr__superClass____source);
		p2s__p____source.setSrc(p2s);
		p2s__p____source.setTrg(p);
		isApplicableMatch.getAllContextElements().add(p2s__p____source);
		p2s__s____target.setSrc(p2s);
		p2s__s____target.setTrg(s);
		isApplicableMatch.getAllContextElements().add(p2s__s____target);
		subClass__superClass____superClass.setSrc(subClass);
		subClass__superClass____superClass.setTrg(superClass);
		isApplicableMatch.getAllContextElements().add(subClass__superClass____superClass);
		p__subClass____classes.setSrc(p);
		p__subClass____classes.setTrg(subClass);
		isApplicableMatch.getAllContextElements().add(p__subClass____classes);
		p__superClass____classes.setSrc(p);
		p__superClass____classes.setTrg(superClass);
		isApplicableMatch.getAllContextElements().add(p__superClass____classes);
		s__superTable____tables.setSrc(s);
		s__superTable____tables.setTrg(superTable);
		isApplicableMatch.getAllContextElements().add(s__superTable____tables);
		s__subTable____tables.setSrc(s);
		s__subTable____tables.setTrg(subTable);
		isApplicableMatch.getAllContextElements().add(s__subTable____tables);
		transCorr__transitiveSuperClass____source.setName(transCorr__transitiveSuperClass____source_name_prime);
		p__transitiveSuperClass____classes.setName(p__transitiveSuperClass____classes_name_prime);
		transCorr__superTable____target.setName(transCorr__superTable____target_name_prime);
		transitiveCorr__superClass____source.setName(transitiveCorr__superClass____source_name_prime);
		transitiveCorr__subTable____target.setName(transitiveCorr__subTable____target_name_prime);
		subCorr__subClass____source.setName(subCorr__subClass____source_name_prime);
		subCorr__subTable____target.setName(subCorr__subTable____target_name_prime);
		supCorr__superTable____target.setName(supCorr__superTable____target_name_prime);
		supCorr__superClass____source.setName(supCorr__superClass____source_name_prime);
		p2s__p____source.setName(p2s__p____source_name_prime);
		p2s__s____target.setName(p2s__s____target_name_prime);
		subClass__superClass____superClass.setName(subClass__superClass____superClass_name_prime);
		p__subClass____classes.setName(p__subClass____classes_name_prime);
		p__superClass____classes.setName(p__superClass____classes_name_prime);
		s__superTable____tables.setName(s__superTable____tables_name_prime);
		s__subTable____tables.setName(s__subTable____tables_name_prime);
		return new Object[] { subTable, transitiveSuperClass, p, superTable, transCorr, transitiveCorr, subCorr,
				supCorr, superClass, p2s, subClass, s, isApplicableMatch, transCorr__transitiveSuperClass____source,
				p__transitiveSuperClass____classes, transCorr__superTable____target,
				transitiveCorr__superClass____source, transitiveCorr__subTable____target, subCorr__subClass____source,
				subCorr__subTable____target, supCorr__superTable____target, supCorr__superClass____source,
				p2s__p____source, p2s__s____target, subClass__superClass____superClass, p__subClass____classes,
				p__superClass____classes, s__superTable____tables, s__subTable____tables };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_12_4_solveCSP_bindingFBBBBBBBBBBBBBB(
			TransitiveCorrsAbove _this, IsApplicableMatch isApplicableMatch, DBTable subTable,
			CDClass transitiveSuperClass, CDPackage p, DBTable superTable, SuperClassToTable transCorr,
			SuperClassToTable transitiveCorr, ClassToTable subCorr, ClassToTable supCorr, CDClass superClass,
			PackageToSchema p2s, CDClass subClass, DBSchema s) {
		CSP _localVariable_0 = _this.isApplicable_solveCsp_BWD(isApplicableMatch, subTable, transitiveSuperClass, p,
				superTable, transCorr, transitiveCorr, subCorr, supCorr, superClass, p2s, subClass, s);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, subTable, transitiveSuperClass, p, superTable,
					transCorr, transitiveCorr, subCorr, supCorr, superClass, p2s, subClass, s };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_12_4_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_12_4_solveCSP_bindingAndBlackFBBBBBBBBBBBBBB(
			TransitiveCorrsAbove _this, IsApplicableMatch isApplicableMatch, DBTable subTable,
			CDClass transitiveSuperClass, CDPackage p, DBTable superTable, SuperClassToTable transCorr,
			SuperClassToTable transitiveCorr, ClassToTable subCorr, ClassToTable supCorr, CDClass superClass,
			PackageToSchema p2s, CDClass subClass, DBSchema s) {
		Object[] result_pattern_TransitiveCorrsAbove_12_4_solveCSP_binding = pattern_TransitiveCorrsAbove_12_4_solveCSP_bindingFBBBBBBBBBBBBBB(
				_this, isApplicableMatch, subTable, transitiveSuperClass, p, superTable, transCorr, transitiveCorr,
				subCorr, supCorr, superClass, p2s, subClass, s);
		if (result_pattern_TransitiveCorrsAbove_12_4_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_TransitiveCorrsAbove_12_4_solveCSP_binding[0];

			Object[] result_pattern_TransitiveCorrsAbove_12_4_solveCSP_black = pattern_TransitiveCorrsAbove_12_4_solveCSP_blackB(
					csp);
			if (result_pattern_TransitiveCorrsAbove_12_4_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, subTable, transitiveSuperClass, p, superTable,
						transCorr, transitiveCorr, subCorr, supCorr, superClass, p2s, subClass, s };
			}
		}
		return null;
	}

	public static final boolean pattern_TransitiveCorrsAbove_12_5_checkCSP_expressionFBB(TransitiveCorrsAbove _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isApplicable_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_12_6_addmatchtoruleresult_blackBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_12_6_addmatchtoruleresult_greenBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		ruleresult.getIsApplicableMatch().add(isApplicableMatch);
		boolean ruleresult_success_prime = Boolean.valueOf(true);
		String isApplicableMatch_ruleName_prime = "TransitiveCorrsAbove";
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		isApplicableMatch.setRuleName(isApplicableMatch_ruleName_prime);
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final IsApplicableRuleResult pattern_TransitiveCorrsAbove_12_7_expressionFB(
			IsApplicableRuleResult ruleresult) {
		IsApplicableRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_20_1_preparereturnvalue_bindingFB(
			TransitiveCorrsAbove _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass __eClass = _localVariable_0;
		if (__eClass != null) {
			return new Object[] { __eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_20_1_preparereturnvalue_blackFBBF(EClass __eClass,
			TransitiveCorrsAbove _this) {
		for (EOperation __performOperation : __eClass.getEOperations()) {
			String __performOperation_name = __performOperation.getName();
			if (__performOperation_name.equals("isApplicable_FWD")) {
				for (EOperation isApplicableCC : __eClass.getEOperations()) {
					if (!__performOperation.equals(isApplicableCC)) {
						String isApplicableCC_name = isApplicableCC.getName();
						if (isApplicableCC_name.equals("isApplicable_CC")) {
							return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
						}

					}
				}
			}

		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_20_1_preparereturnvalue_bindingAndBlackFFBF(
			TransitiveCorrsAbove _this) {
		Object[] result_pattern_TransitiveCorrsAbove_20_1_preparereturnvalue_binding = pattern_TransitiveCorrsAbove_20_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_TransitiveCorrsAbove_20_1_preparereturnvalue_binding != null) {
			EClass __eClass = (EClass) result_pattern_TransitiveCorrsAbove_20_1_preparereturnvalue_binding[0];

			Object[] result_pattern_TransitiveCorrsAbove_20_1_preparereturnvalue_black = pattern_TransitiveCorrsAbove_20_1_preparereturnvalue_blackFBBF(
					__eClass, _this);
			if (result_pattern_TransitiveCorrsAbove_20_1_preparereturnvalue_black != null) {
				EOperation __performOperation = (EOperation) result_pattern_TransitiveCorrsAbove_20_1_preparereturnvalue_black[0];
				EOperation isApplicableCC = (EOperation) result_pattern_TransitiveCorrsAbove_20_1_preparereturnvalue_black[3];

				return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_20_1_preparereturnvalue_greenF() {
		EObjectContainer __result = RuntimeFactory.eINSTANCE.createEObjectContainer();
		return new Object[] { __result };
	}

	public static final Iterable<Object[]> pattern_TransitiveCorrsAbove_20_2_testcorematchandDECs_blackFFFFB(
			EMoflonEdge _edge_classes) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		EObject tmpP = _edge_classes.getSrc();
		if (tmpP instanceof CDPackage) {
			CDPackage p = (CDPackage) tmpP;
			EObject tmpTransitiveSuperClass = _edge_classes.getTrg();
			if (tmpTransitiveSuperClass instanceof CDClass) {
				CDClass transitiveSuperClass = (CDClass) tmpTransitiveSuperClass;
				if (p.getClasses().contains(transitiveSuperClass)) {
					for (CDClass subClass : p.getClasses()) {
						if (!subClass.equals(transitiveSuperClass)) {
							CDClass superClass = subClass.getSuperClass();
							if (superClass != null) {
								if (!superClass.equals(transitiveSuperClass)) {
									if (!subClass.equals(superClass)) {
										if (p.getClasses().contains(superClass)) {
											_result.add(new Object[] { transitiveSuperClass, p, superClass, subClass,
													_edge_classes });
										}
									}
								}
							}

						}
					}
				}
			}

		}

		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_20_2_testcorematchandDECs_greenFB(EClass __eClass) {
		Match match = RuntimeFactory.eINSTANCE.createMatch();
		String __eClass_name = __eClass.getName();
		String match_ruleName_prime = __eClass_name;
		match.setRuleName(match_ruleName_prime);
		return new Object[] { match, __eClass };

	}

	public static final boolean pattern_TransitiveCorrsAbove_20_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBBBB(
			TransitiveCorrsAbove _this, Match match, CDClass transitiveSuperClass, CDPackage p, CDClass superClass,
			CDClass subClass) {
		boolean _localVariable_0 = _this.isAppropriate_FWD(match, transitiveSuperClass, p, superClass, subClass);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final boolean pattern_TransitiveCorrsAbove_20_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
			TransitiveCorrsAbove _this, Match match) {
		boolean _localVariable_0 = _this.checkTypes_FWD(match);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_20_5_Addmatchtoruleresult_blackBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		if (!__performOperation.equals(isApplicableCC)) {
			return new Object[] { match, __performOperation, __result, isApplicableCC };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_20_5_Addmatchtoruleresult_greenBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		__result.getContents().add(match);
		match.setIsApplicableOperation(__performOperation);
		match.setIsApplicableCCOperation(isApplicableCC);
		return new Object[] { match, __performOperation, __result, isApplicableCC };
	}

	public static final EObjectContainer pattern_TransitiveCorrsAbove_20_6_expressionFB(EObjectContainer __result) {
		EObjectContainer _result = __result;
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_21_1_preparereturnvalue_bindingFB(
			TransitiveCorrsAbove _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass __eClass = _localVariable_0;
		if (__eClass != null) {
			return new Object[] { __eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_21_1_preparereturnvalue_blackFBBF(EClass __eClass,
			TransitiveCorrsAbove _this) {
		for (EOperation __performOperation : __eClass.getEOperations()) {
			String __performOperation_name = __performOperation.getName();
			if (__performOperation_name.equals("isApplicable_BWD")) {
				for (EOperation isApplicableCC : __eClass.getEOperations()) {
					if (!__performOperation.equals(isApplicableCC)) {
						String isApplicableCC_name = isApplicableCC.getName();
						if (isApplicableCC_name.equals("isApplicable_CC")) {
							return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
						}

					}
				}
			}

		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_21_1_preparereturnvalue_bindingAndBlackFFBF(
			TransitiveCorrsAbove _this) {
		Object[] result_pattern_TransitiveCorrsAbove_21_1_preparereturnvalue_binding = pattern_TransitiveCorrsAbove_21_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_TransitiveCorrsAbove_21_1_preparereturnvalue_binding != null) {
			EClass __eClass = (EClass) result_pattern_TransitiveCorrsAbove_21_1_preparereturnvalue_binding[0];

			Object[] result_pattern_TransitiveCorrsAbove_21_1_preparereturnvalue_black = pattern_TransitiveCorrsAbove_21_1_preparereturnvalue_blackFBBF(
					__eClass, _this);
			if (result_pattern_TransitiveCorrsAbove_21_1_preparereturnvalue_black != null) {
				EOperation __performOperation = (EOperation) result_pattern_TransitiveCorrsAbove_21_1_preparereturnvalue_black[0];
				EOperation isApplicableCC = (EOperation) result_pattern_TransitiveCorrsAbove_21_1_preparereturnvalue_black[3];

				return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_21_1_preparereturnvalue_greenF() {
		EObjectContainer __result = RuntimeFactory.eINSTANCE.createEObjectContainer();
		return new Object[] { __result };
	}

	public static final Iterable<Object[]> pattern_TransitiveCorrsAbove_21_2_testcorematchandDECs_blackFFFB(
			EMoflonEdge _edge_tables) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		EObject tmpS = _edge_tables.getSrc();
		if (tmpS instanceof DBSchema) {
			DBSchema s = (DBSchema) tmpS;
			EObject tmpSuperTable = _edge_tables.getTrg();
			if (tmpSuperTable instanceof DBTable) {
				DBTable superTable = (DBTable) tmpSuperTable;
				if (s.getTables().contains(superTable)) {
					for (EObject tmpSubTable : s.getTables()) {
						if (tmpSubTable instanceof DBTable) {
							DBTable subTable = (DBTable) tmpSubTable;
							if (!subTable.equals(superTable)) {
								_result.add(new Object[] { subTable, superTable, s, _edge_tables });
							}
						}
					}
				}
			}

		}

		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_21_2_testcorematchandDECs_greenFB(EClass __eClass) {
		Match match = RuntimeFactory.eINSTANCE.createMatch();
		String __eClass_name = __eClass.getName();
		String match_ruleName_prime = __eClass_name;
		match.setRuleName(match_ruleName_prime);
		return new Object[] { match, __eClass };

	}

	public static final boolean pattern_TransitiveCorrsAbove_21_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBBB(
			TransitiveCorrsAbove _this, Match match, DBTable subTable, DBTable superTable, DBSchema s) {
		boolean _localVariable_0 = _this.isAppropriate_BWD(match, subTable, superTable, s);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final boolean pattern_TransitiveCorrsAbove_21_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
			TransitiveCorrsAbove _this, Match match) {
		boolean _localVariable_0 = _this.checkTypes_BWD(match);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_21_5_Addmatchtoruleresult_blackBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		if (!__performOperation.equals(isApplicableCC)) {
			return new Object[] { match, __performOperation, __result, isApplicableCC };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_21_5_Addmatchtoruleresult_greenBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		__result.getContents().add(match);
		match.setIsApplicableOperation(__performOperation);
		match.setIsApplicableCCOperation(isApplicableCC);
		return new Object[] { match, __performOperation, __result, isApplicableCC };
	}

	public static final EObjectContainer pattern_TransitiveCorrsAbove_21_6_expressionFB(EObjectContainer __result) {
		EObjectContainer _result = __result;
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_24_1_prepare_blackB(TransitiveCorrsAbove _this) {
		return new Object[] { _this };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_24_1_prepare_greenF() {
		IsApplicableRuleResult result = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		return new Object[] { result };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_24_2_matchsrctrgcontext_bindingFFFFFFFBB(
			Match targetMatch, Match sourceMatch) {
		EObject _localVariable_0 = targetMatch.getObject("subTable");
		EObject _localVariable_1 = sourceMatch.getObject("transitiveSuperClass");
		EObject _localVariable_2 = sourceMatch.getObject("p");
		EObject _localVariable_3 = targetMatch.getObject("superTable");
		EObject _localVariable_4 = sourceMatch.getObject("superClass");
		EObject _localVariable_5 = sourceMatch.getObject("subClass");
		EObject _localVariable_6 = targetMatch.getObject("s");
		EObject tmpSubTable = _localVariable_0;
		EObject tmpTransitiveSuperClass = _localVariable_1;
		EObject tmpP = _localVariable_2;
		EObject tmpSuperTable = _localVariable_3;
		EObject tmpSuperClass = _localVariable_4;
		EObject tmpSubClass = _localVariable_5;
		EObject tmpS = _localVariable_6;
		if (tmpSubTable instanceof DBTable) {
			DBTable subTable = (DBTable) tmpSubTable;
			if (tmpTransitiveSuperClass instanceof CDClass) {
				CDClass transitiveSuperClass = (CDClass) tmpTransitiveSuperClass;
				if (tmpP instanceof CDPackage) {
					CDPackage p = (CDPackage) tmpP;
					if (tmpSuperTable instanceof DBTable) {
						DBTable superTable = (DBTable) tmpSuperTable;
						if (tmpSuperClass instanceof CDClass) {
							CDClass superClass = (CDClass) tmpSuperClass;
							if (tmpSubClass instanceof CDClass) {
								CDClass subClass = (CDClass) tmpSubClass;
								if (tmpS instanceof DBSchema) {
									DBSchema s = (DBSchema) tmpS;
									return new Object[] { subTable, transitiveSuperClass, p, superTable, superClass,
											subClass, s, targetMatch, sourceMatch };
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_24_2_matchsrctrgcontext_blackBBBBBBBBB(DBTable subTable,
			CDClass transitiveSuperClass, CDPackage p, DBTable superTable, CDClass superClass, CDClass subClass,
			DBSchema s, Match sourceMatch, Match targetMatch) {
		if (!subTable.equals(superTable)) {
			if (!superClass.equals(transitiveSuperClass)) {
				if (!subClass.equals(transitiveSuperClass)) {
					if (!subClass.equals(superClass)) {
						if (!sourceMatch.equals(targetMatch)) {
							return new Object[] { subTable, transitiveSuperClass, p, superTable, superClass, subClass,
									s, sourceMatch, targetMatch };
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_24_2_matchsrctrgcontext_bindingAndBlackFFFFFFFBB(
			Match sourceMatch, Match targetMatch) {
		Object[] result_pattern_TransitiveCorrsAbove_24_2_matchsrctrgcontext_binding = pattern_TransitiveCorrsAbove_24_2_matchsrctrgcontext_bindingFFFFFFFBB(
				targetMatch, sourceMatch);
		if (result_pattern_TransitiveCorrsAbove_24_2_matchsrctrgcontext_binding != null) {
			DBTable subTable = (DBTable) result_pattern_TransitiveCorrsAbove_24_2_matchsrctrgcontext_binding[0];
			CDClass transitiveSuperClass = (CDClass) result_pattern_TransitiveCorrsAbove_24_2_matchsrctrgcontext_binding[1];
			CDPackage p = (CDPackage) result_pattern_TransitiveCorrsAbove_24_2_matchsrctrgcontext_binding[2];
			DBTable superTable = (DBTable) result_pattern_TransitiveCorrsAbove_24_2_matchsrctrgcontext_binding[3];
			CDClass superClass = (CDClass) result_pattern_TransitiveCorrsAbove_24_2_matchsrctrgcontext_binding[4];
			CDClass subClass = (CDClass) result_pattern_TransitiveCorrsAbove_24_2_matchsrctrgcontext_binding[5];
			DBSchema s = (DBSchema) result_pattern_TransitiveCorrsAbove_24_2_matchsrctrgcontext_binding[6];

			Object[] result_pattern_TransitiveCorrsAbove_24_2_matchsrctrgcontext_black = pattern_TransitiveCorrsAbove_24_2_matchsrctrgcontext_blackBBBBBBBBB(
					subTable, transitiveSuperClass, p, superTable, superClass, subClass, s, sourceMatch, targetMatch);
			if (result_pattern_TransitiveCorrsAbove_24_2_matchsrctrgcontext_black != null) {

				return new Object[] { subTable, transitiveSuperClass, p, superTable, superClass, subClass, s,
						sourceMatch, targetMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_24_3_solvecsp_bindingFBBBBBBBBBB(
			TransitiveCorrsAbove _this, DBTable subTable, CDClass transitiveSuperClass, CDPackage p, DBTable superTable,
			CDClass superClass, CDClass subClass, DBSchema s, Match sourceMatch, Match targetMatch) {
		CSP _localVariable_7 = _this.isApplicable_solveCsp_CC(subTable, transitiveSuperClass, p, superTable, superClass,
				subClass, s, sourceMatch, targetMatch);
		CSP csp = _localVariable_7;
		if (csp != null) {
			return new Object[] { csp, _this, subTable, transitiveSuperClass, p, superTable, superClass, subClass, s,
					sourceMatch, targetMatch };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_24_3_solvecsp_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_24_3_solvecsp_bindingAndBlackFBBBBBBBBBB(
			TransitiveCorrsAbove _this, DBTable subTable, CDClass transitiveSuperClass, CDPackage p, DBTable superTable,
			CDClass superClass, CDClass subClass, DBSchema s, Match sourceMatch, Match targetMatch) {
		Object[] result_pattern_TransitiveCorrsAbove_24_3_solvecsp_binding = pattern_TransitiveCorrsAbove_24_3_solvecsp_bindingFBBBBBBBBBB(
				_this, subTable, transitiveSuperClass, p, superTable, superClass, subClass, s, sourceMatch,
				targetMatch);
		if (result_pattern_TransitiveCorrsAbove_24_3_solvecsp_binding != null) {
			CSP csp = (CSP) result_pattern_TransitiveCorrsAbove_24_3_solvecsp_binding[0];

			Object[] result_pattern_TransitiveCorrsAbove_24_3_solvecsp_black = pattern_TransitiveCorrsAbove_24_3_solvecsp_blackB(
					csp);
			if (result_pattern_TransitiveCorrsAbove_24_3_solvecsp_black != null) {

				return new Object[] { csp, _this, subTable, transitiveSuperClass, p, superTable, superClass, subClass,
						s, sourceMatch, targetMatch };
			}
		}
		return null;
	}

	public static final boolean pattern_TransitiveCorrsAbove_24_4_checkCSP_expressionFB(CSP csp) {
		boolean _localVariable_0 = csp.check();
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Iterable<Object[]> pattern_TransitiveCorrsAbove_24_5_matchcorrcontext_blackBBBBFFFFBFBBBB(
			DBTable subTable, CDClass transitiveSuperClass, CDPackage p, DBTable superTable, CDClass superClass,
			CDClass subClass, DBSchema s, Match sourceMatch, Match targetMatch) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!subTable.equals(superTable)) {
			if (!superClass.equals(transitiveSuperClass)) {
				if (!subClass.equals(transitiveSuperClass)) {
					if (!subClass.equals(superClass)) {
						if (!sourceMatch.equals(targetMatch)) {
							for (SuperClassToTable transCorr : org.moflon.core.utilities.eMoflonEMFUtil
									.getOppositeReferenceTyped(transitiveSuperClass, SuperClassToTable.class,
											"source")) {
								if (superTable.equals(transCorr.getTarget())) {
									for (SuperClassToTable transitiveCorr : org.moflon.core.utilities.eMoflonEMFUtil
											.getOppositeReferenceTyped(superClass, SuperClassToTable.class, "source")) {
										if (!transCorr.equals(transitiveCorr)) {
											if (subTable.equals(transitiveCorr.getTarget())) {
												for (ClassToTable subCorr : org.moflon.core.utilities.eMoflonEMFUtil
														.getOppositeReferenceTyped(subClass, ClassToTable.class,
																"source")) {
													if (subTable.equals(subCorr.getTarget())) {
														for (ClassToTable supCorr : org.moflon.core.utilities.eMoflonEMFUtil
																.getOppositeReferenceTyped(superTable,
																		ClassToTable.class, "target")) {
															if (!subCorr.equals(supCorr)) {
																if (superClass.equals(supCorr.getSource())) {
																	for (PackageToSchema p2s : org.moflon.core.utilities.eMoflonEMFUtil
																			.getOppositeReferenceTyped(p,
																					PackageToSchema.class, "source")) {
																		if (s.equals(p2s.getTarget())) {
																			_result.add(new Object[] { subTable,
																					transitiveSuperClass, p, superTable,
																					transCorr, transitiveCorr, subCorr,
																					supCorr, superClass, p2s, subClass,
																					s, sourceMatch, targetMatch });
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_24_5_matchcorrcontext_greenBBBBBBBF(
			SuperClassToTable transCorr, SuperClassToTable transitiveCorr, ClassToTable subCorr, ClassToTable supCorr,
			PackageToSchema p2s, Match sourceMatch, Match targetMatch) {
		CCMatch ccMatch = RuntimeFactory.eINSTANCE.createCCMatch();
		String ccMatch_ruleName_prime = "TransitiveCorrsAbove";
		ccMatch.setSourceMatch(sourceMatch);
		ccMatch.setTargetMatch(targetMatch);
		ccMatch.getAllContextElements().add(transCorr);
		ccMatch.getAllContextElements().add(transitiveCorr);
		ccMatch.getAllContextElements().add(subCorr);
		ccMatch.getAllContextElements().add(supCorr);
		ccMatch.getAllContextElements().add(p2s);
		ccMatch.setRuleName(ccMatch_ruleName_prime);
		return new Object[] { transCorr, transitiveCorr, subCorr, supCorr, p2s, sourceMatch, targetMatch, ccMatch };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_24_6_createcorrespondence_blackBBBBBBBB(DBTable subTable,
			CDClass transitiveSuperClass, CDPackage p, DBTable superTable, CDClass superClass, CDClass subClass,
			DBSchema s, CCMatch ccMatch) {
		if (!subTable.equals(superTable)) {
			if (!superClass.equals(transitiveSuperClass)) {
				if (!subClass.equals(transitiveSuperClass)) {
					if (!subClass.equals(superClass)) {
						return new Object[] { subTable, transitiveSuperClass, p, superTable, superClass, subClass, s,
								ccMatch };
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_24_6_createcorrespondence_greenBBFB(DBTable subTable,
			CDClass transitiveSuperClass, CCMatch ccMatch) {
		SuperClassToTable extraTransCorr = CDToDBFactory.eINSTANCE.createSuperClassToTable();
		extraTransCorr.setTarget(subTable);
		extraTransCorr.setSource(transitiveSuperClass);
		ccMatch.getCreateCorr().add(extraTransCorr);
		return new Object[] { subTable, transitiveSuperClass, extraTransCorr, ccMatch };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_24_7_addtoreturnedresult_blackBB(
			IsApplicableRuleResult result, CCMatch ccMatch) {
		return new Object[] { result, ccMatch };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_24_7_addtoreturnedresult_greenBB(
			IsApplicableRuleResult result, CCMatch ccMatch) {
		result.getIsApplicableMatch().add(ccMatch);
		boolean result_success_prime = Boolean.valueOf(true);
		String ccMatch_ruleName_prime = "TransitiveCorrsAbove";
		result.setSuccess(Boolean.valueOf(result_success_prime));
		ccMatch.setRuleName(ccMatch_ruleName_prime);
		return new Object[] { result, ccMatch };
	}

	public static final IsApplicableRuleResult pattern_TransitiveCorrsAbove_24_8_expressionFB(
			IsApplicableRuleResult result) {
		IsApplicableRuleResult _result = result;
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_27_1_matchtggpattern_blackBBBB(
			CDClass transitiveSuperClass, CDPackage p, CDClass superClass, CDClass subClass) {
		if (!superClass.equals(transitiveSuperClass)) {
			if (!subClass.equals(transitiveSuperClass)) {
				if (!subClass.equals(superClass)) {
					if (p.getClasses().contains(transitiveSuperClass)) {
						if (superClass.equals(subClass.getSuperClass())) {
							if (p.getClasses().contains(subClass)) {
								if (p.getClasses().contains(superClass)) {
									return new Object[] { transitiveSuperClass, p, superClass, subClass };
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final boolean pattern_TransitiveCorrsAbove_27_2_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_TransitiveCorrsAbove_27_3_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_28_1_matchtggpattern_blackBBB(DBTable subTable,
			DBTable superTable, DBSchema s) {
		if (!subTable.equals(superTable)) {
			if (s.getTables().contains(superTable)) {
				if (s.getTables().contains(subTable)) {
					return new Object[] { subTable, superTable, s };
				}
			}
		}
		return null;
	}

	public static final boolean pattern_TransitiveCorrsAbove_28_2_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_TransitiveCorrsAbove_28_3_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_29_1_createresult_blackB(TransitiveCorrsAbove _this) {
		return new Object[] { _this };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_29_1_createresult_greenFF() {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		ModelgeneratorRuleResult ruleResult = RuntimeFactory.eINSTANCE.createModelgeneratorRuleResult();
		boolean ruleResult_success_prime = Boolean.valueOf(false);
		ruleResult.setSuccess(Boolean.valueOf(ruleResult_success_prime));
		return new Object[] { isApplicableMatch, ruleResult };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_0BB(
			ModelgeneratorRuleResult ruleResult, DBTable subTable) {
		if (ruleResult.getTargetObjects().contains(subTable)) {
			return new Object[] { ruleResult, subTable };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_1BB(
			ModelgeneratorRuleResult ruleResult, SuperClassToTable transitiveCorr) {
		if (ruleResult.getCorrObjects().contains(transitiveCorr)) {
			return new Object[] { ruleResult, transitiveCorr };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_2BB(
			ModelgeneratorRuleResult ruleResult, CDClass superClass) {
		if (ruleResult.getSourceObjects().contains(superClass)) {
			return new Object[] { ruleResult, superClass };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_3BB(
			ModelgeneratorRuleResult ruleResult, ClassToTable supCorr) {
		if (ruleResult.getCorrObjects().contains(supCorr)) {
			return new Object[] { ruleResult, supCorr };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_4BB(
			ModelgeneratorRuleResult ruleResult, DBTable superTable) {
		if (ruleResult.getTargetObjects().contains(superTable)) {
			return new Object[] { ruleResult, superTable };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_5BB(
			ModelgeneratorRuleResult ruleResult, SuperClassToTable transCorr) {
		if (ruleResult.getCorrObjects().contains(transCorr)) {
			return new Object[] { ruleResult, transCorr };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_6BB(
			ModelgeneratorRuleResult ruleResult, CDClass transitiveSuperClass) {
		if (ruleResult.getSourceObjects().contains(transitiveSuperClass)) {
			return new Object[] { ruleResult, transitiveSuperClass };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_7BB(
			ModelgeneratorRuleResult ruleResult, CDPackage p) {
		if (ruleResult.getSourceObjects().contains(p)) {
			return new Object[] { ruleResult, p };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_8BB(
			ModelgeneratorRuleResult ruleResult, CDClass subClass) {
		if (ruleResult.getSourceObjects().contains(subClass)) {
			return new Object[] { ruleResult, subClass };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_9BB(
			ModelgeneratorRuleResult ruleResult, ClassToTable subCorr) {
		if (ruleResult.getCorrObjects().contains(subCorr)) {
			return new Object[] { ruleResult, subCorr };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_10BB(
			ModelgeneratorRuleResult ruleResult, PackageToSchema p2s) {
		if (ruleResult.getCorrObjects().contains(p2s)) {
			return new Object[] { ruleResult, p2s };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_11BB(
			ModelgeneratorRuleResult ruleResult, DBSchema s) {
		if (ruleResult.getTargetObjects().contains(s)) {
			return new Object[] { ruleResult, s };
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_TransitiveCorrsAbove_29_2_isapplicablecore_blackFFFFFFFFFFFFFBB(
			RuleEntryContainer ruleEntryContainer, ModelgeneratorRuleResult ruleResult) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		for (RuleEntryList transitiveCorrList : ruleEntryContainer.getRuleEntryList()) {
			for (EObject tmpTransitiveCorr : transitiveCorrList.getEntryObjects()) {
				if (tmpTransitiveCorr instanceof SuperClassToTable) {
					SuperClassToTable transitiveCorr = (SuperClassToTable) tmpTransitiveCorr;
					DBTable subTable = transitiveCorr.getTarget();
					if (subTable != null) {
						CDClass superClass = transitiveCorr.getSource();
						if (superClass != null) {
							if (pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_1BB(ruleResult,
									transitiveCorr) == null) {
								if (pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_0BB(ruleResult,
										subTable) == null) {
									if (pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_2BB(ruleResult,
											superClass) == null) {
										for (ClassToTable subCorr : org.moflon.core.utilities.eMoflonEMFUtil
												.getOppositeReferenceTyped(subTable, ClassToTable.class, "target")) {
											CDClass subClass = subCorr.getSource();
											if (subClass != null) {
												if (!subClass.equals(superClass)) {
													if (superClass.equals(subClass.getSuperClass())) {
														if (pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_9BB(
																ruleResult, subCorr) == null) {
															if (pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_8BB(
																	ruleResult, subClass) == null) {
																for (DBSchema s : org.moflon.core.utilities.eMoflonEMFUtil
																		.getOppositeReferenceTyped(subTable,
																				DBSchema.class, "tables")) {
																	if (pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_11BB(
																			ruleResult, s) == null) {
																		for (EObject tmpSuperTable : s.getTables()) {
																			if (tmpSuperTable instanceof DBTable) {
																				DBTable superTable = (DBTable) tmpSuperTable;
																				if (!subTable.equals(superTable)) {
																					if (pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_4BB(
																							ruleResult,
																							superTable) == null) {
																						for (ClassToTable supCorr : org.moflon.core.utilities.eMoflonEMFUtil
																								.getOppositeReferenceTyped(
																										superClass,
																										ClassToTable.class,
																										"source")) {
																							if (!subCorr
																									.equals(supCorr)) {
																								if (superTable.equals(
																										supCorr.getTarget())) {
																									if (pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_3BB(
																											ruleResult,
																											supCorr) == null) {
																										for (CDPackage p : org.moflon.core.utilities.eMoflonEMFUtil
																												.getOppositeReferenceTyped(
																														superClass,
																														CDPackage.class,
																														"classes")) {
																											if (p.getClasses()
																													.contains(
																															subClass)) {
																												if (pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_7BB(
																														ruleResult,
																														p) == null) {
																													for (CDClass transitiveSuperClass : p
																															.getClasses()) {
																														if (!superClass
																																.equals(transitiveSuperClass)) {
																															if (!subClass
																																	.equals(transitiveSuperClass)) {
																																if (pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_6BB(
																																		ruleResult,
																																		transitiveSuperClass) == null) {
																																	for (PackageToSchema p2s : org.moflon.core.utilities.eMoflonEMFUtil
																																			.getOppositeReferenceTyped(
																																					s,
																																					PackageToSchema.class,
																																					"target")) {
																																		if (p.equals(
																																				p2s.getSource())) {
																																			if (pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_10BB(
																																					ruleResult,
																																					p2s) == null) {
																																				for (SuperClassToTable transCorr : org.moflon.core.utilities.eMoflonEMFUtil
																																						.getOppositeReferenceTyped(
																																								superTable,
																																								SuperClassToTable.class,
																																								"target")) {
																																					if (!transCorr
																																							.equals(transitiveCorr)) {
																																						if (transitiveSuperClass
																																								.equals(transCorr
																																										.getSource())) {
																																							if (pattern_TransitiveCorrsAbove_29_2_isapplicablecore_black_nac_5BB(
																																									ruleResult,
																																									transCorr) == null) {
																																								_result.add(
																																										new Object[] {
																																												transitiveCorrList,
																																												subTable,
																																												transitiveCorr,
																																												superClass,
																																												supCorr,
																																												superTable,
																																												transCorr,
																																												transitiveSuperClass,
																																												p,
																																												subClass,
																																												subCorr,
																																												p2s,
																																												s,
																																												ruleEntryContainer,
																																												ruleResult });
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}

										}
									}
								}
							}
						}

					}

				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_29_3_solveCSP_bindingFBBBBBBBBBBBBBBB(
			TransitiveCorrsAbove _this, IsApplicableMatch isApplicableMatch, DBTable subTable,
			CDClass transitiveSuperClass, CDPackage p, DBTable superTable, SuperClassToTable transCorr,
			SuperClassToTable transitiveCorr, ClassToTable subCorr, ClassToTable supCorr, CDClass superClass,
			PackageToSchema p2s, CDClass subClass, DBSchema s, ModelgeneratorRuleResult ruleResult) {
		CSP _localVariable_0 = _this.generateModel_solveCsp_BWD(isApplicableMatch, subTable, transitiveSuperClass, p,
				superTable, transCorr, transitiveCorr, subCorr, supCorr, superClass, p2s, subClass, s, ruleResult);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, subTable, transitiveSuperClass, p, superTable,
					transCorr, transitiveCorr, subCorr, supCorr, superClass, p2s, subClass, s, ruleResult };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_29_3_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_TransitiveCorrsAbove_29_3_solveCSP_bindingAndBlackFBBBBBBBBBBBBBBB(
			TransitiveCorrsAbove _this, IsApplicableMatch isApplicableMatch, DBTable subTable,
			CDClass transitiveSuperClass, CDPackage p, DBTable superTable, SuperClassToTable transCorr,
			SuperClassToTable transitiveCorr, ClassToTable subCorr, ClassToTable supCorr, CDClass superClass,
			PackageToSchema p2s, CDClass subClass, DBSchema s, ModelgeneratorRuleResult ruleResult) {
		Object[] result_pattern_TransitiveCorrsAbove_29_3_solveCSP_binding = pattern_TransitiveCorrsAbove_29_3_solveCSP_bindingFBBBBBBBBBBBBBBB(
				_this, isApplicableMatch, subTable, transitiveSuperClass, p, superTable, transCorr, transitiveCorr,
				subCorr, supCorr, superClass, p2s, subClass, s, ruleResult);
		if (result_pattern_TransitiveCorrsAbove_29_3_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_TransitiveCorrsAbove_29_3_solveCSP_binding[0];

			Object[] result_pattern_TransitiveCorrsAbove_29_3_solveCSP_black = pattern_TransitiveCorrsAbove_29_3_solveCSP_blackB(
					csp);
			if (result_pattern_TransitiveCorrsAbove_29_3_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, subTable, transitiveSuperClass, p, superTable,
						transCorr, transitiveCorr, subCorr, supCorr, superClass, p2s, subClass, s, ruleResult };
			}
		}
		return null;
	}

	public static final boolean pattern_TransitiveCorrsAbove_29_4_checkCSP_expressionFBB(TransitiveCorrsAbove _this,
			CSP csp) {
		boolean _localVariable_0 = _this.generateModel_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_29_5_checknacs_blackBBBBBBBBBBBB(DBTable subTable,
			CDClass transitiveSuperClass, CDPackage p, DBTable superTable, SuperClassToTable transCorr,
			SuperClassToTable transitiveCorr, ClassToTable subCorr, ClassToTable supCorr, CDClass superClass,
			PackageToSchema p2s, CDClass subClass, DBSchema s) {
		if (!subTable.equals(superTable)) {
			if (!transCorr.equals(transitiveCorr)) {
				if (!subCorr.equals(supCorr)) {
					if (!superClass.equals(transitiveSuperClass)) {
						if (!subClass.equals(transitiveSuperClass)) {
							if (!subClass.equals(superClass)) {
								return new Object[] { subTable, transitiveSuperClass, p, superTable, transCorr,
										transitiveCorr, subCorr, supCorr, superClass, p2s, subClass, s };
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_29_6_perform_blackBBBBBBBBBBBBB(DBTable subTable,
			CDClass transitiveSuperClass, CDPackage p, DBTable superTable, SuperClassToTable transCorr,
			SuperClassToTable transitiveCorr, ClassToTable subCorr, ClassToTable supCorr, CDClass superClass,
			PackageToSchema p2s, CDClass subClass, DBSchema s, ModelgeneratorRuleResult ruleResult) {
		if (!subTable.equals(superTable)) {
			if (!transCorr.equals(transitiveCorr)) {
				if (!subCorr.equals(supCorr)) {
					if (!superClass.equals(transitiveSuperClass)) {
						if (!subClass.equals(transitiveSuperClass)) {
							if (!subClass.equals(superClass)) {
								return new Object[] { subTable, transitiveSuperClass, p, superTable, transCorr,
										transitiveCorr, subCorr, supCorr, superClass, p2s, subClass, s, ruleResult };
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveCorrsAbove_29_6_perform_greenBBFB(DBTable subTable,
			CDClass transitiveSuperClass, ModelgeneratorRuleResult ruleResult) {
		SuperClassToTable extraTransCorr = CDToDBFactory.eINSTANCE.createSuperClassToTable();
		boolean ruleResult_success_prime = Boolean.valueOf(true);
		int _localVariable_0 = ruleResult.getIncrementedPerformCount();
		extraTransCorr.setTarget(subTable);
		extraTransCorr.setSource(transitiveSuperClass);
		ruleResult.getCorrObjects().add(extraTransCorr);
		ruleResult.setSuccess(Boolean.valueOf(ruleResult_success_prime));
		int ruleResult_performCount_prime = Integer.valueOf(_localVariable_0);
		ruleResult.setPerformCount(Integer.valueOf(ruleResult_performCount_prime));
		return new Object[] { subTable, transitiveSuperClass, extraTransCorr, ruleResult };
	}

	public static final ModelgeneratorRuleResult pattern_TransitiveCorrsAbove_29_7_expressionFB(
			ModelgeneratorRuleResult ruleResult) {
		ModelgeneratorRuleResult _result = ruleResult;
		return _result;
	}

	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //TransitiveCorrsAboveImpl
