/**
 */
package CDToDB.Rules;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;

import org.moflon.tgg.runtime.RuntimePackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see CDToDB.Rules.RulesFactory
 * @model kind="package"
 * @generated
 */
public interface RulesPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "Rules";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "platform:/plugin/CDToDB/model/CDToDB.ecore#//Rules";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "Rules";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	RulesPackage eINSTANCE = CDToDB.Rules.impl.RulesPackageImpl.init();

	/**
	 * The meta object id for the '{@link CDToDB.Rules.impl.TransferColsRuleImpl <em>Transfer Cols Rule</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CDToDB.Rules.impl.TransferColsRuleImpl
	 * @see CDToDB.Rules.impl.RulesPackageImpl#getTransferColsRule()
	 * @generated
	 */
	int TRANSFER_COLS_RULE = 0;

	/**
	 * The number of structural features of the '<em>Transfer Cols Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE_FEATURE_COUNT = RuntimePackage.ABSTRACT_RULE_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Is Appropriate FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___IS_APPROPRIATE_FWD__MATCH_CDCLASS_CDCLASS_CDPACKAGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 0;

	/**
	 * The operation id for the '<em>Perform FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___PERFORM_FWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Is Applicable FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___IS_APPLICABLE_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Register Objects To Match FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_CDCLASS_CDCLASS_CDPACKAGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 3;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_CDCLASS_CDCLASS_CDPACKAGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 4;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___IS_APPROPRIATE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 5;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_DBTABLE_DBCOLUMN_DBTABLE_SUPERCLASSTOTABLE_CLASSTOTABLE_CLASSTOTABLE_CDCLASS_PACKAGETOSCHEMA_CDCLASS_CDPACKAGE_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 6;

	/**
	 * The operation id for the '<em>Is Applicable check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___IS_APPLICABLE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 7;

	/**
	 * The operation id for the '<em>Register Objects FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 8;

	/**
	 * The operation id for the '<em>Check Types FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___CHECK_TYPES_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 9;

	/**
	 * The operation id for the '<em>Is Appropriate BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___IS_APPROPRIATE_BWD__MATCH_DBTABLE_DBCOLUMN_DBCOLUMN_DBTABLE_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 10;

	/**
	 * The operation id for the '<em>Perform BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___PERFORM_BWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 11;

	/**
	 * The operation id for the '<em>Is Applicable BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___IS_APPLICABLE_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 12;

	/**
	 * The operation id for the '<em>Register Objects To Match BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_DBTABLE_DBCOLUMN_DBCOLUMN_DBTABLE_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 13;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_DBTABLE_DBCOLUMN_DBCOLUMN_DBTABLE_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 14;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___IS_APPROPRIATE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 15;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_DBTABLE_DBCOLUMN_DBCOLUMN_DBTABLE_SUPERCLASSTOTABLE_CLASSTOTABLE_CLASSTOTABLE_CDCLASS_PACKAGETOSCHEMA_CDCLASS_CDPACKAGE_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 16;

	/**
	 * The operation id for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___IS_APPLICABLE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 17;

	/**
	 * The operation id for the '<em>Register Objects BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 18;

	/**
	 * The operation id for the '<em>Check Types BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___CHECK_TYPES_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 19;

	/**
	 * The operation id for the '<em>Is Appropriate FWD EMoflon Edge 0</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___IS_APPROPRIATE_FWD_EMOFLON_EDGE_0__EMOFLONEDGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 20;

	/**
	 * The operation id for the '<em>Is Appropriate BWD EMoflon Edge 0</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___IS_APPROPRIATE_BWD_EMOFLON_EDGE_0__EMOFLONEDGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 21;

	/**
	 * The operation id for the '<em>Check Attributes FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 22;

	/**
	 * The operation id for the '<em>Check Attributes BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 23;

	/**
	 * The operation id for the '<em>Is Applicable CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___IS_APPLICABLE_CC__MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 24;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___IS_APPLICABLE_SOLVE_CSP_CC__DBTABLE_DBCOLUMN_DBCOLUMN_DBTABLE_CDCLASS_CDCLASS_CDPACKAGE_DBSCHEMA_MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 25;

	/**
	 * The operation id for the '<em>Is Applicable check Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___IS_APPLICABLE_CHECK_CSP_CC__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 26;

	/**
	 * The operation id for the '<em>Check DEC FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___CHECK_DEC_FWD__CDCLASS_CDCLASS_CDPACKAGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 27;

	/**
	 * The operation id for the '<em>Check DEC BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___CHECK_DEC_BWD__DBTABLE_DBCOLUMN_DBCOLUMN_DBTABLE_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 28;

	/**
	 * The operation id for the '<em>Generate Model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___GENERATE_MODEL__RULEENTRYCONTAINER_SUPERCLASSTOTABLE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 29;

	/**
	 * The operation id for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_DBTABLE_DBCOLUMN_DBTABLE_SUPERCLASSTOTABLE_CLASSTOTABLE_CLASSTOTABLE_CDCLASS_PACKAGETOSCHEMA_CDCLASS_CDPACKAGE_DBSCHEMA_MODELGENERATORRULERESULT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 30;

	/**
	 * The operation id for the '<em>Generate Model check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE___GENERATE_MODEL_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 31;

	/**
	 * The number of operations of the '<em>Transfer Cols Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSFER_COLS_RULE_OPERATION_COUNT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 32;

	/**
	 * The meta object id for the '{@link CDToDB.Rules.impl.ClassToTableRuleImpl <em>Class To Table Rule</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CDToDB.Rules.impl.ClassToTableRuleImpl
	 * @see CDToDB.Rules.impl.RulesPackageImpl#getClassToTableRule()
	 * @generated
	 */
	int CLASS_TO_TABLE_RULE = 1;

	/**
	 * The number of structural features of the '<em>Class To Table Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE_FEATURE_COUNT = RuntimePackage.ABSTRACT_RULE_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Is Appropriate FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___IS_APPROPRIATE_FWD__MATCH_CDCLASS_CDPACKAGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 0;

	/**
	 * The operation id for the '<em>Perform FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___PERFORM_FWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Is Applicable FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___IS_APPLICABLE_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Register Objects To Match FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_CDCLASS_CDPACKAGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 3;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_CDCLASS_CDPACKAGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 4;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___IS_APPROPRIATE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 5;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_CDCLASS_PACKAGETOSCHEMA_DBSCHEMA_CDPACKAGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 6;

	/**
	 * The operation id for the '<em>Is Applicable check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___IS_APPLICABLE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 7;

	/**
	 * The operation id for the '<em>Register Objects FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 8;

	/**
	 * The operation id for the '<em>Check Types FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___CHECK_TYPES_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 9;

	/**
	 * The operation id for the '<em>Is Appropriate BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___IS_APPROPRIATE_BWD__MATCH_DBTABLE_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 10;

	/**
	 * The operation id for the '<em>Perform BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___PERFORM_BWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 11;

	/**
	 * The operation id for the '<em>Is Applicable BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___IS_APPLICABLE_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 12;

	/**
	 * The operation id for the '<em>Register Objects To Match BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_DBTABLE_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 13;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_DBTABLE_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 14;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___IS_APPROPRIATE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 15;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_DBTABLE_PACKAGETOSCHEMA_DBSCHEMA_CDPACKAGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 16;

	/**
	 * The operation id for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___IS_APPLICABLE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 17;

	/**
	 * The operation id for the '<em>Register Objects BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 18;

	/**
	 * The operation id for the '<em>Check Types BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___CHECK_TYPES_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 19;

	/**
	 * The operation id for the '<em>Is Appropriate FWD EMoflon Edge 1</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___IS_APPROPRIATE_FWD_EMOFLON_EDGE_1__EMOFLONEDGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 20;

	/**
	 * The operation id for the '<em>Is Appropriate BWD EMoflon Edge 1</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___IS_APPROPRIATE_BWD_EMOFLON_EDGE_1__EMOFLONEDGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 21;

	/**
	 * The operation id for the '<em>Check Attributes FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 22;

	/**
	 * The operation id for the '<em>Check Attributes BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 23;

	/**
	 * The operation id for the '<em>Is Applicable CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___IS_APPLICABLE_CC__MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 24;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___IS_APPLICABLE_SOLVE_CSP_CC__DBTABLE_CDCLASS_DBSCHEMA_CDPACKAGE_MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 25;

	/**
	 * The operation id for the '<em>Is Applicable check Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___IS_APPLICABLE_CHECK_CSP_CC__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 26;

	/**
	 * The operation id for the '<em>Check DEC FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___CHECK_DEC_FWD__CDCLASS_CDPACKAGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 27;

	/**
	 * The operation id for the '<em>Check DEC BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___CHECK_DEC_BWD__DBTABLE_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 28;

	/**
	 * The operation id for the '<em>Generate Model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___GENERATE_MODEL__RULEENTRYCONTAINER_PACKAGETOSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 29;

	/**
	 * The operation id for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_PACKAGETOSCHEMA_DBSCHEMA_CDPACKAGE_MODELGENERATORRULERESULT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 30;

	/**
	 * The operation id for the '<em>Generate Model check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE___GENERATE_MODEL_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 31;

	/**
	 * The number of operations of the '<em>Class To Table Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLASS_TO_TABLE_RULE_OPERATION_COUNT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 32;

	/**
	 * The meta object id for the '{@link CDToDB.Rules.impl.TransitiveCorrsAboveImpl <em>Transitive Corrs Above</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CDToDB.Rules.impl.TransitiveCorrsAboveImpl
	 * @see CDToDB.Rules.impl.RulesPackageImpl#getTransitiveCorrsAbove()
	 * @generated
	 */
	int TRANSITIVE_CORRS_ABOVE = 2;

	/**
	 * The number of structural features of the '<em>Transitive Corrs Above</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE_FEATURE_COUNT = RuntimePackage.ABSTRACT_RULE_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Is Appropriate FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___IS_APPROPRIATE_FWD__MATCH_CDCLASS_CDPACKAGE_CDCLASS_CDCLASS = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 0;

	/**
	 * The operation id for the '<em>Perform FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___PERFORM_FWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Is Applicable FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___IS_APPLICABLE_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Register Objects To Match FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_CDCLASS_CDPACKAGE_CDCLASS_CDCLASS = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 3;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_CDCLASS_CDPACKAGE_CDCLASS_CDCLASS = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 4;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___IS_APPROPRIATE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 5;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_DBTABLE_CDCLASS_CDPACKAGE_DBTABLE_SUPERCLASSTOTABLE_SUPERCLASSTOTABLE_CLASSTOTABLE_CLASSTOTABLE_CDCLASS_PACKAGETOSCHEMA_CDCLASS_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 6;

	/**
	 * The operation id for the '<em>Is Applicable check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___IS_APPLICABLE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 7;

	/**
	 * The operation id for the '<em>Register Objects FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 8;

	/**
	 * The operation id for the '<em>Check Types FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___CHECK_TYPES_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 9;

	/**
	 * The operation id for the '<em>Is Appropriate BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___IS_APPROPRIATE_BWD__MATCH_DBTABLE_DBTABLE_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 10;

	/**
	 * The operation id for the '<em>Perform BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___PERFORM_BWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 11;

	/**
	 * The operation id for the '<em>Is Applicable BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___IS_APPLICABLE_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 12;

	/**
	 * The operation id for the '<em>Register Objects To Match BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_DBTABLE_DBTABLE_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 13;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_DBTABLE_DBTABLE_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 14;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___IS_APPROPRIATE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 15;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_DBTABLE_CDCLASS_CDPACKAGE_DBTABLE_SUPERCLASSTOTABLE_SUPERCLASSTOTABLE_CLASSTOTABLE_CLASSTOTABLE_CDCLASS_PACKAGETOSCHEMA_CDCLASS_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 16;

	/**
	 * The operation id for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___IS_APPLICABLE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 17;

	/**
	 * The operation id for the '<em>Register Objects BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 18;

	/**
	 * The operation id for the '<em>Check Types BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___CHECK_TYPES_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 19;

	/**
	 * The operation id for the '<em>Is Appropriate FWD EMoflon Edge 2</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___IS_APPROPRIATE_FWD_EMOFLON_EDGE_2__EMOFLONEDGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 20;

	/**
	 * The operation id for the '<em>Is Appropriate BWD EMoflon Edge 2</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___IS_APPROPRIATE_BWD_EMOFLON_EDGE_2__EMOFLONEDGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 21;

	/**
	 * The operation id for the '<em>Check Attributes FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 22;

	/**
	 * The operation id for the '<em>Check Attributes BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 23;

	/**
	 * The operation id for the '<em>Is Applicable CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___IS_APPLICABLE_CC__MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 24;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___IS_APPLICABLE_SOLVE_CSP_CC__DBTABLE_CDCLASS_CDPACKAGE_DBTABLE_CDCLASS_CDCLASS_DBSCHEMA_MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 25;

	/**
	 * The operation id for the '<em>Is Applicable check Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___IS_APPLICABLE_CHECK_CSP_CC__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 26;

	/**
	 * The operation id for the '<em>Check DEC FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___CHECK_DEC_FWD__CDCLASS_CDPACKAGE_CDCLASS_CDCLASS = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 27;

	/**
	 * The operation id for the '<em>Check DEC BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___CHECK_DEC_BWD__DBTABLE_DBTABLE_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 28;

	/**
	 * The operation id for the '<em>Generate Model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___GENERATE_MODEL__RULEENTRYCONTAINER_SUPERCLASSTOTABLE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 29;

	/**
	 * The operation id for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_DBTABLE_CDCLASS_CDPACKAGE_DBTABLE_SUPERCLASSTOTABLE_SUPERCLASSTOTABLE_CLASSTOTABLE_CLASSTOTABLE_CDCLASS_PACKAGETOSCHEMA_CDCLASS_DBSCHEMA_MODELGENERATORRULERESULT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 30;

	/**
	 * The operation id for the '<em>Generate Model check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE___GENERATE_MODEL_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 31;

	/**
	 * The number of operations of the '<em>Transitive Corrs Above</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_CORRS_ABOVE_OPERATION_COUNT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 32;

	/**
	 * The meta object id for the '{@link CDToDB.Rules.impl.CreateInheritanceRuleImpl <em>Create Inheritance Rule</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CDToDB.Rules.impl.CreateInheritanceRuleImpl
	 * @see CDToDB.Rules.impl.RulesPackageImpl#getCreateInheritanceRule()
	 * @generated
	 */
	int CREATE_INHERITANCE_RULE = 3;

	/**
	 * The number of structural features of the '<em>Create Inheritance Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE_FEATURE_COUNT = RuntimePackage.ABSTRACT_RULE_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Is Appropriate FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___IS_APPROPRIATE_FWD__MATCH_CDCLASS_CDCLASS_CDPACKAGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 0;

	/**
	 * The operation id for the '<em>Perform FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___PERFORM_FWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Is Applicable FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___IS_APPLICABLE_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Register Objects To Match FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_CDCLASS_CDCLASS_CDPACKAGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 3;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_CDCLASS_CDCLASS_CDPACKAGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 4;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___IS_APPROPRIATE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 5;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_CLASSTOTABLE_DBTABLE_CDCLASS_PACKAGETOSCHEMA_CDCLASS_CDPACKAGE_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 6;

	/**
	 * The operation id for the '<em>Is Applicable check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___IS_APPLICABLE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 7;

	/**
	 * The operation id for the '<em>Register Objects FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 8;

	/**
	 * The operation id for the '<em>Check Types FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___CHECK_TYPES_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 9;

	/**
	 * The operation id for the '<em>Is Appropriate BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___IS_APPROPRIATE_BWD__MATCH_DBTABLE_DBTABLE_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 10;

	/**
	 * The operation id for the '<em>Perform BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___PERFORM_BWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 11;

	/**
	 * The operation id for the '<em>Is Applicable BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___IS_APPLICABLE_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 12;

	/**
	 * The operation id for the '<em>Register Objects To Match BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_DBTABLE_DBTABLE_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 13;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_DBTABLE_DBTABLE_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 14;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___IS_APPROPRIATE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 15;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_CLASSTOTABLE_DBTABLE_CDCLASS_DBTABLE_PACKAGETOSCHEMA_CDPACKAGE_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 16;

	/**
	 * The operation id for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___IS_APPLICABLE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 17;

	/**
	 * The operation id for the '<em>Register Objects BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 18;

	/**
	 * The operation id for the '<em>Check Types BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___CHECK_TYPES_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 19;

	/**
	 * The operation id for the '<em>Is Appropriate FWD EMoflon Edge 3</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___IS_APPROPRIATE_FWD_EMOFLON_EDGE_3__EMOFLONEDGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 20;

	/**
	 * The operation id for the '<em>Is Appropriate BWD EMoflon Edge 3</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___IS_APPROPRIATE_BWD_EMOFLON_EDGE_3__EMOFLONEDGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 21;

	/**
	 * The operation id for the '<em>Check Attributes FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 22;

	/**
	 * The operation id for the '<em>Check Attributes BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 23;

	/**
	 * The operation id for the '<em>Is Applicable CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___IS_APPLICABLE_CC__MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 24;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___IS_APPLICABLE_SOLVE_CSP_CC__DBTABLE_CDCLASS_DBTABLE_CDCLASS_CDPACKAGE_DBSCHEMA_MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 25;

	/**
	 * The operation id for the '<em>Is Applicable check Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___IS_APPLICABLE_CHECK_CSP_CC__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 26;

	/**
	 * The operation id for the '<em>Check DEC FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___CHECK_DEC_FWD__CDCLASS_CDCLASS_CDPACKAGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 27;

	/**
	 * The operation id for the '<em>Check DEC BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___CHECK_DEC_BWD__DBTABLE_DBTABLE_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 28;

	/**
	 * The operation id for the '<em>Generate Model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___GENERATE_MODEL__RULEENTRYCONTAINER_CLASSTOTABLE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 29;

	/**
	 * The operation id for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_CLASSTOTABLE_DBTABLE_CDCLASS_PACKAGETOSCHEMA_CDPACKAGE_DBSCHEMA_MODELGENERATORRULERESULT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 30;

	/**
	 * The operation id for the '<em>Generate Model check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE___GENERATE_MODEL_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 31;

	/**
	 * The number of operations of the '<em>Create Inheritance Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_INHERITANCE_RULE_OPERATION_COUNT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 32;

	/**
	 * The meta object id for the '{@link CDToDB.Rules.impl.PackageToSchemaRuleImpl <em>Package To Schema Rule</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CDToDB.Rules.impl.PackageToSchemaRuleImpl
	 * @see CDToDB.Rules.impl.RulesPackageImpl#getPackageToSchemaRule()
	 * @generated
	 */
	int PACKAGE_TO_SCHEMA_RULE = 4;

	/**
	 * The number of structural features of the '<em>Package To Schema Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE_FEATURE_COUNT = RuntimePackage.ABSTRACT_RULE_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Is Appropriate FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___IS_APPROPRIATE_FWD__MATCH_CDPACKAGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Perform FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___PERFORM_FWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Is Applicable FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___IS_APPLICABLE_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Register Objects To Match FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_CDPACKAGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 3;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_CDPACKAGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 4;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___IS_APPROPRIATE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 5;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_CDPACKAGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 6;

	/**
	 * The operation id for the '<em>Is Applicable check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___IS_APPLICABLE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 7;

	/**
	 * The operation id for the '<em>Register Objects FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 8;

	/**
	 * The operation id for the '<em>Check Types FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___CHECK_TYPES_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 9;

	/**
	 * The operation id for the '<em>Is Appropriate BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___IS_APPROPRIATE_BWD__MATCH_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 10;

	/**
	 * The operation id for the '<em>Perform BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___PERFORM_BWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 11;

	/**
	 * The operation id for the '<em>Is Applicable BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___IS_APPLICABLE_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 12;

	/**
	 * The operation id for the '<em>Register Objects To Match BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 13;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 14;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___IS_APPROPRIATE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 15;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 16;

	/**
	 * The operation id for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___IS_APPLICABLE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 17;

	/**
	 * The operation id for the '<em>Register Objects BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 18;

	/**
	 * The operation id for the '<em>Check Types BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___CHECK_TYPES_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 19;

	/**
	 * The operation id for the '<em>Is Appropriate FWD CD Package 0</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___IS_APPROPRIATE_FWD_CD_PACKAGE_0__CDPACKAGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 20;

	/**
	 * The operation id for the '<em>Is Appropriate BWD DB Schema 0</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___IS_APPROPRIATE_BWD_DB_SCHEMA_0__DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 21;

	/**
	 * The operation id for the '<em>Check Attributes FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 22;

	/**
	 * The operation id for the '<em>Check Attributes BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 23;

	/**
	 * The operation id for the '<em>Is Applicable CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___IS_APPLICABLE_CC__MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 24;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___IS_APPLICABLE_SOLVE_CSP_CC__DBSCHEMA_CDPACKAGE_MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 25;

	/**
	 * The operation id for the '<em>Is Applicable check Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___IS_APPLICABLE_CHECK_CSP_CC__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 26;

	/**
	 * The operation id for the '<em>Check DEC FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___CHECK_DEC_FWD__CDPACKAGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 27;

	/**
	 * The operation id for the '<em>Check DEC BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___CHECK_DEC_BWD__DBSCHEMA = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 28;

	/**
	 * The operation id for the '<em>Generate Model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___GENERATE_MODEL__RULEENTRYCONTAINER = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 29;

	/**
	 * The operation id for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_MODELGENERATORRULERESULT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 30;

	/**
	 * The operation id for the '<em>Generate Model check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE___GENERATE_MODEL_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 31;

	/**
	 * The number of operations of the '<em>Package To Schema Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PACKAGE_TO_SCHEMA_RULE_OPERATION_COUNT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 32;

	/**
	 * The meta object id for the '{@link CDToDB.Rules.impl.TransitiveAttributeRuleImpl <em>Transitive Attribute Rule</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CDToDB.Rules.impl.TransitiveAttributeRuleImpl
	 * @see CDToDB.Rules.impl.RulesPackageImpl#getTransitiveAttributeRule()
	 * @generated
	 */
	int TRANSITIVE_ATTRIBUTE_RULE = 5;

	/**
	 * The number of structural features of the '<em>Transitive Attribute Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE_FEATURE_COUNT = RuntimePackage.ABSTRACT_RULE_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Is Appropriate FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___IS_APPROPRIATE_FWD__MATCH_CDCLASS_CDATTRIBUTE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 0;

	/**
	 * The operation id for the '<em>Perform FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___PERFORM_FWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Is Applicable FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___IS_APPLICABLE_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Register Objects To Match FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_CDCLASS_CDATTRIBUTE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 3;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_CDCLASS_CDATTRIBUTE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 4;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___IS_APPROPRIATE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 5;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_DBSCHEMA_DBTABLE_DBCOLUMN_SUPERCLASSTOTABLE_CDCLASS_DBTABLE_CLASSTOTABLE_CDATTRIBUTE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 6;

	/**
	 * The operation id for the '<em>Is Applicable check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___IS_APPLICABLE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 7;

	/**
	 * The operation id for the '<em>Register Objects FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 8;

	/**
	 * The operation id for the '<em>Check Types FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___CHECK_TYPES_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 9;

	/**
	 * The operation id for the '<em>Is Appropriate BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___IS_APPROPRIATE_BWD__MATCH_DBSCHEMA_DBTABLE_DBCOLUMN_DBCOLUMN_DBTABLE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 10;

	/**
	 * The operation id for the '<em>Perform BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___PERFORM_BWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 11;

	/**
	 * The operation id for the '<em>Is Applicable BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___IS_APPLICABLE_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 12;

	/**
	 * The operation id for the '<em>Register Objects To Match BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_DBSCHEMA_DBTABLE_DBCOLUMN_DBCOLUMN_DBTABLE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 13;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_DBSCHEMA_DBTABLE_DBCOLUMN_DBCOLUMN_DBTABLE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 14;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___IS_APPROPRIATE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 15;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_DBSCHEMA_DBTABLE_DBCOLUMN_SUPERCLASSTOTABLE_CDCLASS_DBCOLUMN_DBTABLE_CLASSTOTABLE_CDATTRIBUTE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 16;

	/**
	 * The operation id for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___IS_APPLICABLE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 17;

	/**
	 * The operation id for the '<em>Register Objects BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 18;

	/**
	 * The operation id for the '<em>Check Types BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___CHECK_TYPES_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 19;

	/**
	 * The operation id for the '<em>Is Appropriate FWD EMoflon Edge 4</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___IS_APPROPRIATE_FWD_EMOFLON_EDGE_4__EMOFLONEDGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 20;

	/**
	 * The operation id for the '<em>Is Appropriate BWD EMoflon Edge 4</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___IS_APPROPRIATE_BWD_EMOFLON_EDGE_4__EMOFLONEDGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 21;

	/**
	 * The operation id for the '<em>Check Attributes FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 22;

	/**
	 * The operation id for the '<em>Check Attributes BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 23;

	/**
	 * The operation id for the '<em>Is Applicable CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___IS_APPLICABLE_CC__MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 24;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___IS_APPLICABLE_SOLVE_CSP_CC__DBSCHEMA_DBTABLE_DBCOLUMN_CDCLASS_DBCOLUMN_DBTABLE_CDATTRIBUTE_MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 25;

	/**
	 * The operation id for the '<em>Is Applicable check Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___IS_APPLICABLE_CHECK_CSP_CC__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 26;

	/**
	 * The operation id for the '<em>Check DEC FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___CHECK_DEC_FWD__CDCLASS_CDATTRIBUTE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 27;

	/**
	 * The operation id for the '<em>Check DEC BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___CHECK_DEC_BWD__DBSCHEMA_DBTABLE_DBCOLUMN_DBCOLUMN_DBTABLE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 28;

	/**
	 * The operation id for the '<em>Generate Model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___GENERATE_MODEL__RULEENTRYCONTAINER_CLASSTOTABLE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 29;

	/**
	 * The operation id for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_DBSCHEMA_DBTABLE_DBCOLUMN_SUPERCLASSTOTABLE_CDCLASS_DBTABLE_CLASSTOTABLE_CDATTRIBUTE_MODELGENERATORRULERESULT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 30;

	/**
	 * The operation id for the '<em>Generate Model check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE___GENERATE_MODEL_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 31;

	/**
	 * The number of operations of the '<em>Transitive Attribute Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSITIVE_ATTRIBUTE_RULE_OPERATION_COUNT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 32;

	/**
	 * The meta object id for the '{@link CDToDB.Rules.impl.CreateAttributeRuleImpl <em>Create Attribute Rule</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see CDToDB.Rules.impl.CreateAttributeRuleImpl
	 * @see CDToDB.Rules.impl.RulesPackageImpl#getCreateAttributeRule()
	 * @generated
	 */
	int CREATE_ATTRIBUTE_RULE = 6;

	/**
	 * The number of structural features of the '<em>Create Attribute Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE_FEATURE_COUNT = RuntimePackage.ABSTRACT_RULE_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Is Appropriate FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___IS_APPROPRIATE_FWD__MATCH_CDATTRIBUTE_CDCLASS = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 0;

	/**
	 * The operation id for the '<em>Perform FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___PERFORM_FWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Is Applicable FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___IS_APPLICABLE_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Register Objects To Match FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_CDATTRIBUTE_CDCLASS = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 3;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_CDATTRIBUTE_CDCLASS = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 4;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___IS_APPROPRIATE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 5;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_CLASSTOTABLE_CDATTRIBUTE_CDCLASS_DBTABLE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 6;

	/**
	 * The operation id for the '<em>Is Applicable check Csp FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___IS_APPLICABLE_CHECK_CSP_FWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 7;

	/**
	 * The operation id for the '<em>Register Objects FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 8;

	/**
	 * The operation id for the '<em>Check Types FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___CHECK_TYPES_FWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 9;

	/**
	 * The operation id for the '<em>Is Appropriate BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___IS_APPROPRIATE_BWD__MATCH_DBTABLE_DBCOLUMN = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 10;

	/**
	 * The operation id for the '<em>Perform BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___PERFORM_BWD__ISAPPLICABLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 11;

	/**
	 * The operation id for the '<em>Is Applicable BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___IS_APPLICABLE_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 12;

	/**
	 * The operation id for the '<em>Register Objects To Match BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_DBTABLE_DBCOLUMN = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 13;

	/**
	 * The operation id for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_DBTABLE_DBCOLUMN = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 14;

	/**
	 * The operation id for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___IS_APPROPRIATE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 15;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_CLASSTOTABLE_CDCLASS_DBTABLE_DBCOLUMN = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 16;

	/**
	 * The operation id for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___IS_APPLICABLE_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 17;

	/**
	 * The operation id for the '<em>Register Objects BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 18;

	/**
	 * The operation id for the '<em>Check Types BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___CHECK_TYPES_BWD__MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 19;

	/**
	 * The operation id for the '<em>Is Appropriate FWD EMoflon Edge 5</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___IS_APPROPRIATE_FWD_EMOFLON_EDGE_5__EMOFLONEDGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 20;

	/**
	 * The operation id for the '<em>Is Appropriate BWD EMoflon Edge 5</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___IS_APPROPRIATE_BWD_EMOFLON_EDGE_5__EMOFLONEDGE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 21;

	/**
	 * The operation id for the '<em>Check Attributes FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 22;

	/**
	 * The operation id for the '<em>Check Attributes BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 23;

	/**
	 * The operation id for the '<em>Is Applicable CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___IS_APPLICABLE_CC__MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 24;

	/**
	 * The operation id for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___IS_APPLICABLE_SOLVE_CSP_CC__CDATTRIBUTE_CDCLASS_DBTABLE_DBCOLUMN_MATCH_MATCH = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 25;

	/**
	 * The operation id for the '<em>Is Applicable check Csp CC</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___IS_APPLICABLE_CHECK_CSP_CC__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 26;

	/**
	 * The operation id for the '<em>Check DEC FWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___CHECK_DEC_FWD__CDATTRIBUTE_CDCLASS = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 27;

	/**
	 * The operation id for the '<em>Check DEC BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___CHECK_DEC_BWD__DBTABLE_DBCOLUMN = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 28;

	/**
	 * The operation id for the '<em>Generate Model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___GENERATE_MODEL__RULEENTRYCONTAINER_CLASSTOTABLE = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 29;

	/**
	 * The operation id for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_CLASSTOTABLE_CDCLASS_DBTABLE_MODELGENERATORRULERESULT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT
			+ 30;

	/**
	 * The operation id for the '<em>Generate Model check Csp BWD</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE___GENERATE_MODEL_CHECK_CSP_BWD__CSP = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 31;

	/**
	 * The number of operations of the '<em>Create Attribute Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREATE_ATTRIBUTE_RULE_OPERATION_COUNT = RuntimePackage.ABSTRACT_RULE_OPERATION_COUNT + 32;

	/**
	 * Returns the meta object for class '{@link CDToDB.Rules.TransferColsRule <em>Transfer Cols Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transfer Cols Rule</em>'.
	 * @see CDToDB.Rules.TransferColsRule
	 * @generated
	 */
	EClass getTransferColsRule();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#isAppropriate_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDClass, ClassDiagrams.CDPackage) <em>Is Appropriate FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#isAppropriate_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDClass, ClassDiagrams.CDPackage)
	 * @generated
	 */
	EOperation getTransferColsRule__IsAppropriate_FWD__Match_CDClass_CDClass_CDPackage();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform FWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getTransferColsRule__Perform_FWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#isApplicable_FWD(org.moflon.tgg.runtime.Match) <em>Is Applicable FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable FWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#isApplicable_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransferColsRule__IsApplicable_FWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDClass, ClassDiagrams.CDPackage) <em>Register Objects To Match FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match FWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDClass, ClassDiagrams.CDPackage)
	 * @generated
	 */
	EOperation getTransferColsRule__RegisterObjectsToMatch_FWD__Match_CDClass_CDClass_CDPackage();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDClass, ClassDiagrams.CDPackage) <em>Is Appropriate solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDClass, ClassDiagrams.CDPackage)
	 * @generated
	 */
	EOperation getTransferColsRule__IsAppropriate_solveCsp_FWD__Match_CDClass_CDClass_CDPackage();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransferColsRule__IsAppropriate_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#isApplicable_solveCsp_FWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable, CDToDB.SuperClassToTable, CDToDB.ClassToTable, CDToDB.ClassToTable, ClassDiagrams.CDClass, CDToDB.PackageToSchema, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, DatabaseSchemata.DBSchema) <em>Is Applicable solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp FWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#isApplicable_solveCsp_FWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable, CDToDB.SuperClassToTable, CDToDB.ClassToTable, CDToDB.ClassToTable, ClassDiagrams.CDClass, CDToDB.PackageToSchema, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getTransferColsRule__IsApplicable_solveCsp_FWD__IsApplicableMatch_DBTable_DBColumn_DBTable_SuperClassToTable_ClassToTable_ClassToTable_CDClass_PackageToSchema_CDClass_CDPackage_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#isApplicable_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp FWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#isApplicable_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransferColsRule__IsApplicable_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#registerObjects_FWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects FWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#registerObjects_FWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getTransferColsRule__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#checkTypes_FWD(org.moflon.tgg.runtime.Match) <em>Check Types FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types FWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#checkTypes_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransferColsRule__CheckTypes_FWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#isAppropriate_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema) <em>Is Appropriate BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#isAppropriate_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getTransferColsRule__IsAppropriate_BWD__Match_DBTable_DBColumn_DBColumn_DBTable_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform BWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getTransferColsRule__Perform_BWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#isApplicable_BWD(org.moflon.tgg.runtime.Match) <em>Is Applicable BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable BWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#isApplicable_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransferColsRule__IsApplicable_BWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema) <em>Register Objects To Match BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match BWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getTransferColsRule__RegisterObjectsToMatch_BWD__Match_DBTable_DBColumn_DBColumn_DBTable_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema) <em>Is Appropriate solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getTransferColsRule__IsAppropriate_solveCsp_BWD__Match_DBTable_DBColumn_DBColumn_DBTable_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransferColsRule__IsAppropriate_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable, CDToDB.SuperClassToTable, CDToDB.ClassToTable, CDToDB.ClassToTable, ClassDiagrams.CDClass, CDToDB.PackageToSchema, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, DatabaseSchemata.DBSchema) <em>Is Applicable solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable, CDToDB.SuperClassToTable, CDToDB.ClassToTable, CDToDB.ClassToTable, ClassDiagrams.CDClass, CDToDB.PackageToSchema, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getTransferColsRule__IsApplicable_solveCsp_BWD__IsApplicableMatch_DBTable_DBColumn_DBColumn_DBTable_SuperClassToTable_ClassToTable_ClassToTable_CDClass_PackageToSchema_CDClass_CDPackage_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransferColsRule__IsApplicable_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects BWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getTransferColsRule__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#checkTypes_BWD(org.moflon.tgg.runtime.Match) <em>Check Types BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types BWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#checkTypes_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransferColsRule__CheckTypes_BWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#isAppropriate_FWD_EMoflonEdge_0(org.moflon.tgg.runtime.EMoflonEdge) <em>Is Appropriate FWD EMoflon Edge 0</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD EMoflon Edge 0</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#isAppropriate_FWD_EMoflonEdge_0(org.moflon.tgg.runtime.EMoflonEdge)
	 * @generated
	 */
	EOperation getTransferColsRule__IsAppropriate_FWD_EMoflonEdge_0__EMoflonEdge();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#isAppropriate_BWD_EMoflonEdge_0(org.moflon.tgg.runtime.EMoflonEdge) <em>Is Appropriate BWD EMoflon Edge 0</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD EMoflon Edge 0</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#isAppropriate_BWD_EMoflonEdge_0(org.moflon.tgg.runtime.EMoflonEdge)
	 * @generated
	 */
	EOperation getTransferColsRule__IsAppropriate_BWD_EMoflonEdge_0__EMoflonEdge();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes FWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getTransferColsRule__CheckAttributes_FWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes BWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getTransferColsRule__CheckAttributes_BWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable CC</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransferColsRule__IsApplicable_CC__Match_Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#isApplicable_solveCsp_CC(DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable, ClassDiagrams.CDClass, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, DatabaseSchemata.DBSchema, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable solve Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#isApplicable_solveCsp_CC(DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable, ClassDiagrams.CDClass, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, DatabaseSchemata.DBSchema, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransferColsRule__IsApplicable_solveCsp_CC__DBTable_DBColumn_DBColumn_DBTable_CDClass_CDClass_CDPackage_DBSchema_Match_Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp CC</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransferColsRule__IsApplicable_checkCsp_CC__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#checkDEC_FWD(ClassDiagrams.CDClass, ClassDiagrams.CDClass, ClassDiagrams.CDPackage) <em>Check DEC FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC FWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#checkDEC_FWD(ClassDiagrams.CDClass, ClassDiagrams.CDClass, ClassDiagrams.CDPackage)
	 * @generated
	 */
	EOperation getTransferColsRule__CheckDEC_FWD__CDClass_CDClass_CDPackage();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#checkDEC_BWD(DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema) <em>Check DEC BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC BWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#checkDEC_BWD(DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getTransferColsRule__CheckDEC_BWD__DBTable_DBColumn_DBColumn_DBTable_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer, CDToDB.SuperClassToTable) <em>Generate Model</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer, CDToDB.SuperClassToTable)
	 * @generated
	 */
	EOperation getTransferColsRule__GenerateModel__RuleEntryContainer_SuperClassToTable();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable, CDToDB.SuperClassToTable, CDToDB.ClassToTable, CDToDB.ClassToTable, ClassDiagrams.CDClass, CDToDB.PackageToSchema, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, DatabaseSchemata.DBSchema, org.moflon.tgg.runtime.ModelgeneratorRuleResult) <em>Generate Model solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable, CDToDB.SuperClassToTable, CDToDB.ClassToTable, CDToDB.ClassToTable, ClassDiagrams.CDClass, CDToDB.PackageToSchema, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, DatabaseSchemata.DBSchema, org.moflon.tgg.runtime.ModelgeneratorRuleResult)
	 * @generated
	 */
	EOperation getTransferColsRule__GenerateModel_solveCsp_BWD__IsApplicableMatch_DBTable_DBColumn_DBTable_SuperClassToTable_ClassToTable_ClassToTable_CDClass_PackageToSchema_CDClass_CDPackage_DBSchema_ModelgeneratorRuleResult();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransferColsRule#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Generate Model check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.TransferColsRule#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransferColsRule__GenerateModel_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for class '{@link CDToDB.Rules.ClassToTableRule <em>Class To Table Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Class To Table Rule</em>'.
	 * @see CDToDB.Rules.ClassToTableRule
	 * @generated
	 */
	EClass getClassToTableRule();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#isAppropriate_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDPackage) <em>Is Appropriate FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#isAppropriate_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDPackage)
	 * @generated
	 */
	EOperation getClassToTableRule__IsAppropriate_FWD__Match_CDClass_CDPackage();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform FWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getClassToTableRule__Perform_FWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#isApplicable_FWD(org.moflon.tgg.runtime.Match) <em>Is Applicable FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable FWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#isApplicable_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getClassToTableRule__IsApplicable_FWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDPackage) <em>Register Objects To Match FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match FWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDPackage)
	 * @generated
	 */
	EOperation getClassToTableRule__RegisterObjectsToMatch_FWD__Match_CDClass_CDPackage();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDPackage) <em>Is Appropriate solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDPackage)
	 * @generated
	 */
	EOperation getClassToTableRule__IsAppropriate_solveCsp_FWD__Match_CDClass_CDPackage();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getClassToTableRule__IsAppropriate_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#isApplicable_solveCsp_FWD(org.moflon.tgg.runtime.IsApplicableMatch, ClassDiagrams.CDClass, CDToDB.PackageToSchema, DatabaseSchemata.DBSchema, ClassDiagrams.CDPackage) <em>Is Applicable solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp FWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#isApplicable_solveCsp_FWD(org.moflon.tgg.runtime.IsApplicableMatch, ClassDiagrams.CDClass, CDToDB.PackageToSchema, DatabaseSchemata.DBSchema, ClassDiagrams.CDPackage)
	 * @generated
	 */
	EOperation getClassToTableRule__IsApplicable_solveCsp_FWD__IsApplicableMatch_CDClass_PackageToSchema_DBSchema_CDPackage();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#isApplicable_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp FWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#isApplicable_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getClassToTableRule__IsApplicable_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#registerObjects_FWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects FWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#registerObjects_FWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getClassToTableRule__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#checkTypes_FWD(org.moflon.tgg.runtime.Match) <em>Check Types FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types FWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#checkTypes_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getClassToTableRule__CheckTypes_FWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#isAppropriate_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema) <em>Is Appropriate BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#isAppropriate_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getClassToTableRule__IsAppropriate_BWD__Match_DBTable_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform BWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getClassToTableRule__Perform_BWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#isApplicable_BWD(org.moflon.tgg.runtime.Match) <em>Is Applicable BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable BWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#isApplicable_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getClassToTableRule__IsApplicable_BWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema) <em>Register Objects To Match BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match BWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getClassToTableRule__RegisterObjectsToMatch_BWD__Match_DBTable_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema) <em>Is Appropriate solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getClassToTableRule__IsAppropriate_solveCsp_BWD__Match_DBTable_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getClassToTableRule__IsAppropriate_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBTable, CDToDB.PackageToSchema, DatabaseSchemata.DBSchema, ClassDiagrams.CDPackage) <em>Is Applicable solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBTable, CDToDB.PackageToSchema, DatabaseSchemata.DBSchema, ClassDiagrams.CDPackage)
	 * @generated
	 */
	EOperation getClassToTableRule__IsApplicable_solveCsp_BWD__IsApplicableMatch_DBTable_PackageToSchema_DBSchema_CDPackage();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getClassToTableRule__IsApplicable_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects BWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getClassToTableRule__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#checkTypes_BWD(org.moflon.tgg.runtime.Match) <em>Check Types BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types BWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#checkTypes_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getClassToTableRule__CheckTypes_BWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#isAppropriate_FWD_EMoflonEdge_1(org.moflon.tgg.runtime.EMoflonEdge) <em>Is Appropriate FWD EMoflon Edge 1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD EMoflon Edge 1</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#isAppropriate_FWD_EMoflonEdge_1(org.moflon.tgg.runtime.EMoflonEdge)
	 * @generated
	 */
	EOperation getClassToTableRule__IsAppropriate_FWD_EMoflonEdge_1__EMoflonEdge();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#isAppropriate_BWD_EMoflonEdge_1(org.moflon.tgg.runtime.EMoflonEdge) <em>Is Appropriate BWD EMoflon Edge 1</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD EMoflon Edge 1</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#isAppropriate_BWD_EMoflonEdge_1(org.moflon.tgg.runtime.EMoflonEdge)
	 * @generated
	 */
	EOperation getClassToTableRule__IsAppropriate_BWD_EMoflonEdge_1__EMoflonEdge();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes FWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getClassToTableRule__CheckAttributes_FWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes BWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getClassToTableRule__CheckAttributes_BWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable CC</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getClassToTableRule__IsApplicable_CC__Match_Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#isApplicable_solveCsp_CC(DatabaseSchemata.DBTable, ClassDiagrams.CDClass, DatabaseSchemata.DBSchema, ClassDiagrams.CDPackage, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable solve Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#isApplicable_solveCsp_CC(DatabaseSchemata.DBTable, ClassDiagrams.CDClass, DatabaseSchemata.DBSchema, ClassDiagrams.CDPackage, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getClassToTableRule__IsApplicable_solveCsp_CC__DBTable_CDClass_DBSchema_CDPackage_Match_Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp CC</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getClassToTableRule__IsApplicable_checkCsp_CC__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#checkDEC_FWD(ClassDiagrams.CDClass, ClassDiagrams.CDPackage) <em>Check DEC FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC FWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#checkDEC_FWD(ClassDiagrams.CDClass, ClassDiagrams.CDPackage)
	 * @generated
	 */
	EOperation getClassToTableRule__CheckDEC_FWD__CDClass_CDPackage();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#checkDEC_BWD(DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema) <em>Check DEC BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC BWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#checkDEC_BWD(DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getClassToTableRule__CheckDEC_BWD__DBTable_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer, CDToDB.PackageToSchema) <em>Generate Model</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer, CDToDB.PackageToSchema)
	 * @generated
	 */
	EOperation getClassToTableRule__GenerateModel__RuleEntryContainer_PackageToSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, CDToDB.PackageToSchema, DatabaseSchemata.DBSchema, ClassDiagrams.CDPackage, org.moflon.tgg.runtime.ModelgeneratorRuleResult) <em>Generate Model solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, CDToDB.PackageToSchema, DatabaseSchemata.DBSchema, ClassDiagrams.CDPackage, org.moflon.tgg.runtime.ModelgeneratorRuleResult)
	 * @generated
	 */
	EOperation getClassToTableRule__GenerateModel_solveCsp_BWD__IsApplicableMatch_PackageToSchema_DBSchema_CDPackage_ModelgeneratorRuleResult();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.ClassToTableRule#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Generate Model check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.ClassToTableRule#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getClassToTableRule__GenerateModel_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for class '{@link CDToDB.Rules.TransitiveCorrsAbove <em>Transitive Corrs Above</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transitive Corrs Above</em>'.
	 * @see CDToDB.Rules.TransitiveCorrsAbove
	 * @generated
	 */
	EClass getTransitiveCorrsAbove();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#isAppropriate_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, ClassDiagrams.CDClass, ClassDiagrams.CDClass) <em>Is Appropriate FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#isAppropriate_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, ClassDiagrams.CDClass, ClassDiagrams.CDClass)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__IsAppropriate_FWD__Match_CDClass_CDPackage_CDClass_CDClass();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__Perform_FWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#isApplicable_FWD(org.moflon.tgg.runtime.Match) <em>Is Applicable FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#isApplicable_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__IsApplicable_FWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, ClassDiagrams.CDClass, ClassDiagrams.CDClass) <em>Register Objects To Match FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, ClassDiagrams.CDClass, ClassDiagrams.CDClass)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__RegisterObjectsToMatch_FWD__Match_CDClass_CDPackage_CDClass_CDClass();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, ClassDiagrams.CDClass, ClassDiagrams.CDClass) <em>Is Appropriate solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, ClassDiagrams.CDClass, ClassDiagrams.CDClass)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__IsAppropriate_solveCsp_FWD__Match_CDClass_CDPackage_CDClass_CDClass();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__IsAppropriate_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#isApplicable_solveCsp_FWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBTable, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, DatabaseSchemata.DBTable, CDToDB.SuperClassToTable, CDToDB.SuperClassToTable, CDToDB.ClassToTable, CDToDB.ClassToTable, ClassDiagrams.CDClass, CDToDB.PackageToSchema, ClassDiagrams.CDClass, DatabaseSchemata.DBSchema) <em>Is Applicable solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#isApplicable_solveCsp_FWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBTable, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, DatabaseSchemata.DBTable, CDToDB.SuperClassToTable, CDToDB.SuperClassToTable, CDToDB.ClassToTable, CDToDB.ClassToTable, ClassDiagrams.CDClass, CDToDB.PackageToSchema, ClassDiagrams.CDClass, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__IsApplicable_solveCsp_FWD__IsApplicableMatch_DBTable_CDClass_CDPackage_DBTable_SuperClassToTable_SuperClassToTable_ClassToTable_ClassToTable_CDClass_PackageToSchema_CDClass_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#isApplicable_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#isApplicable_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__IsApplicable_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#registerObjects_FWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#registerObjects_FWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#checkTypes_FWD(org.moflon.tgg.runtime.Match) <em>Check Types FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#checkTypes_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__CheckTypes_FWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#isAppropriate_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema) <em>Is Appropriate BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#isAppropriate_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__IsAppropriate_BWD__Match_DBTable_DBTable_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__Perform_BWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#isApplicable_BWD(org.moflon.tgg.runtime.Match) <em>Is Applicable BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#isApplicable_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__IsApplicable_BWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema) <em>Register Objects To Match BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__RegisterObjectsToMatch_BWD__Match_DBTable_DBTable_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema) <em>Is Appropriate solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__IsAppropriate_solveCsp_BWD__Match_DBTable_DBTable_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__IsAppropriate_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBTable, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, DatabaseSchemata.DBTable, CDToDB.SuperClassToTable, CDToDB.SuperClassToTable, CDToDB.ClassToTable, CDToDB.ClassToTable, ClassDiagrams.CDClass, CDToDB.PackageToSchema, ClassDiagrams.CDClass, DatabaseSchemata.DBSchema) <em>Is Applicable solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBTable, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, DatabaseSchemata.DBTable, CDToDB.SuperClassToTable, CDToDB.SuperClassToTable, CDToDB.ClassToTable, CDToDB.ClassToTable, ClassDiagrams.CDClass, CDToDB.PackageToSchema, ClassDiagrams.CDClass, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__IsApplicable_solveCsp_BWD__IsApplicableMatch_DBTable_CDClass_CDPackage_DBTable_SuperClassToTable_SuperClassToTable_ClassToTable_ClassToTable_CDClass_PackageToSchema_CDClass_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__IsApplicable_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#checkTypes_BWD(org.moflon.tgg.runtime.Match) <em>Check Types BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#checkTypes_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__CheckTypes_BWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#isAppropriate_FWD_EMoflonEdge_2(org.moflon.tgg.runtime.EMoflonEdge) <em>Is Appropriate FWD EMoflon Edge 2</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD EMoflon Edge 2</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#isAppropriate_FWD_EMoflonEdge_2(org.moflon.tgg.runtime.EMoflonEdge)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__IsAppropriate_FWD_EMoflonEdge_2__EMoflonEdge();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#isAppropriate_BWD_EMoflonEdge_2(org.moflon.tgg.runtime.EMoflonEdge) <em>Is Appropriate BWD EMoflon Edge 2</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD EMoflon Edge 2</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#isAppropriate_BWD_EMoflonEdge_2(org.moflon.tgg.runtime.EMoflonEdge)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__IsAppropriate_BWD_EMoflonEdge_2__EMoflonEdge();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__CheckAttributes_FWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__CheckAttributes_BWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable CC</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__IsApplicable_CC__Match_Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#isApplicable_solveCsp_CC(DatabaseSchemata.DBTable, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, DatabaseSchemata.DBTable, ClassDiagrams.CDClass, ClassDiagrams.CDClass, DatabaseSchemata.DBSchema, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable solve Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#isApplicable_solveCsp_CC(DatabaseSchemata.DBTable, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, DatabaseSchemata.DBTable, ClassDiagrams.CDClass, ClassDiagrams.CDClass, DatabaseSchemata.DBSchema, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__IsApplicable_solveCsp_CC__DBTable_CDClass_CDPackage_DBTable_CDClass_CDClass_DBSchema_Match_Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp CC</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__IsApplicable_checkCsp_CC__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#checkDEC_FWD(ClassDiagrams.CDClass, ClassDiagrams.CDPackage, ClassDiagrams.CDClass, ClassDiagrams.CDClass) <em>Check DEC FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#checkDEC_FWD(ClassDiagrams.CDClass, ClassDiagrams.CDPackage, ClassDiagrams.CDClass, ClassDiagrams.CDClass)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__CheckDEC_FWD__CDClass_CDPackage_CDClass_CDClass();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#checkDEC_BWD(DatabaseSchemata.DBTable, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema) <em>Check DEC BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#checkDEC_BWD(DatabaseSchemata.DBTable, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__CheckDEC_BWD__DBTable_DBTable_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer, CDToDB.SuperClassToTable) <em>Generate Model</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer, CDToDB.SuperClassToTable)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__GenerateModel__RuleEntryContainer_SuperClassToTable();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBTable, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, DatabaseSchemata.DBTable, CDToDB.SuperClassToTable, CDToDB.SuperClassToTable, CDToDB.ClassToTable, CDToDB.ClassToTable, ClassDiagrams.CDClass, CDToDB.PackageToSchema, ClassDiagrams.CDClass, DatabaseSchemata.DBSchema, org.moflon.tgg.runtime.ModelgeneratorRuleResult) <em>Generate Model solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBTable, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, DatabaseSchemata.DBTable, CDToDB.SuperClassToTable, CDToDB.SuperClassToTable, CDToDB.ClassToTable, CDToDB.ClassToTable, ClassDiagrams.CDClass, CDToDB.PackageToSchema, ClassDiagrams.CDClass, DatabaseSchemata.DBSchema, org.moflon.tgg.runtime.ModelgeneratorRuleResult)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__GenerateModel_solveCsp_BWD__IsApplicableMatch_DBTable_CDClass_CDPackage_DBTable_SuperClassToTable_SuperClassToTable_ClassToTable_ClassToTable_CDClass_PackageToSchema_CDClass_DBSchema_ModelgeneratorRuleResult();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveCorrsAbove#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Generate Model check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveCorrsAbove#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransitiveCorrsAbove__GenerateModel_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for class '{@link CDToDB.Rules.CreateInheritanceRule <em>Create Inheritance Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Create Inheritance Rule</em>'.
	 * @see CDToDB.Rules.CreateInheritanceRule
	 * @generated
	 */
	EClass getCreateInheritanceRule();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#isAppropriate_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDClass, ClassDiagrams.CDPackage) <em>Is Appropriate FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#isAppropriate_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDClass, ClassDiagrams.CDPackage)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__IsAppropriate_FWD__Match_CDClass_CDClass_CDPackage();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform FWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__Perform_FWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#isApplicable_FWD(org.moflon.tgg.runtime.Match) <em>Is Applicable FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable FWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#isApplicable_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__IsApplicable_FWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDClass, ClassDiagrams.CDPackage) <em>Register Objects To Match FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match FWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDClass, ClassDiagrams.CDPackage)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__RegisterObjectsToMatch_FWD__Match_CDClass_CDClass_CDPackage();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDClass, ClassDiagrams.CDPackage) <em>Is Appropriate solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDClass, ClassDiagrams.CDPackage)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__IsAppropriate_solveCsp_FWD__Match_CDClass_CDClass_CDPackage();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__IsAppropriate_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#isApplicable_solveCsp_FWD(org.moflon.tgg.runtime.IsApplicableMatch, CDToDB.ClassToTable, DatabaseSchemata.DBTable, ClassDiagrams.CDClass, CDToDB.PackageToSchema, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, DatabaseSchemata.DBSchema) <em>Is Applicable solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp FWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#isApplicable_solveCsp_FWD(org.moflon.tgg.runtime.IsApplicableMatch, CDToDB.ClassToTable, DatabaseSchemata.DBTable, ClassDiagrams.CDClass, CDToDB.PackageToSchema, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__IsApplicable_solveCsp_FWD__IsApplicableMatch_ClassToTable_DBTable_CDClass_PackageToSchema_CDClass_CDPackage_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#isApplicable_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp FWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#isApplicable_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__IsApplicable_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#registerObjects_FWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects FWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#registerObjects_FWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#checkTypes_FWD(org.moflon.tgg.runtime.Match) <em>Check Types FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types FWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#checkTypes_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__CheckTypes_FWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#isAppropriate_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema) <em>Is Appropriate BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#isAppropriate_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__IsAppropriate_BWD__Match_DBTable_DBTable_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform BWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__Perform_BWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#isApplicable_BWD(org.moflon.tgg.runtime.Match) <em>Is Applicable BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable BWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#isApplicable_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__IsApplicable_BWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema) <em>Register Objects To Match BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match BWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__RegisterObjectsToMatch_BWD__Match_DBTable_DBTable_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema) <em>Is Appropriate solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__IsAppropriate_solveCsp_BWD__Match_DBTable_DBTable_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__IsAppropriate_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, CDToDB.ClassToTable, DatabaseSchemata.DBTable, ClassDiagrams.CDClass, DatabaseSchemata.DBTable, CDToDB.PackageToSchema, ClassDiagrams.CDPackage, DatabaseSchemata.DBSchema) <em>Is Applicable solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, CDToDB.ClassToTable, DatabaseSchemata.DBTable, ClassDiagrams.CDClass, DatabaseSchemata.DBTable, CDToDB.PackageToSchema, ClassDiagrams.CDPackage, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__IsApplicable_solveCsp_BWD__IsApplicableMatch_ClassToTable_DBTable_CDClass_DBTable_PackageToSchema_CDPackage_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__IsApplicable_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects BWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#checkTypes_BWD(org.moflon.tgg.runtime.Match) <em>Check Types BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types BWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#checkTypes_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__CheckTypes_BWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#isAppropriate_FWD_EMoflonEdge_3(org.moflon.tgg.runtime.EMoflonEdge) <em>Is Appropriate FWD EMoflon Edge 3</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD EMoflon Edge 3</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#isAppropriate_FWD_EMoflonEdge_3(org.moflon.tgg.runtime.EMoflonEdge)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__IsAppropriate_FWD_EMoflonEdge_3__EMoflonEdge();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#isAppropriate_BWD_EMoflonEdge_3(org.moflon.tgg.runtime.EMoflonEdge) <em>Is Appropriate BWD EMoflon Edge 3</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD EMoflon Edge 3</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#isAppropriate_BWD_EMoflonEdge_3(org.moflon.tgg.runtime.EMoflonEdge)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__IsAppropriate_BWD_EMoflonEdge_3__EMoflonEdge();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes FWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__CheckAttributes_FWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes BWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__CheckAttributes_BWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable CC</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__IsApplicable_CC__Match_Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#isApplicable_solveCsp_CC(DatabaseSchemata.DBTable, ClassDiagrams.CDClass, DatabaseSchemata.DBTable, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, DatabaseSchemata.DBSchema, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable solve Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#isApplicable_solveCsp_CC(DatabaseSchemata.DBTable, ClassDiagrams.CDClass, DatabaseSchemata.DBTable, ClassDiagrams.CDClass, ClassDiagrams.CDPackage, DatabaseSchemata.DBSchema, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__IsApplicable_solveCsp_CC__DBTable_CDClass_DBTable_CDClass_CDPackage_DBSchema_Match_Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp CC</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__IsApplicable_checkCsp_CC__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#checkDEC_FWD(ClassDiagrams.CDClass, ClassDiagrams.CDClass, ClassDiagrams.CDPackage) <em>Check DEC FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC FWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#checkDEC_FWD(ClassDiagrams.CDClass, ClassDiagrams.CDClass, ClassDiagrams.CDPackage)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__CheckDEC_FWD__CDClass_CDClass_CDPackage();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#checkDEC_BWD(DatabaseSchemata.DBTable, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema) <em>Check DEC BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC BWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#checkDEC_BWD(DatabaseSchemata.DBTable, DatabaseSchemata.DBTable, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__CheckDEC_BWD__DBTable_DBTable_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer, CDToDB.ClassToTable) <em>Generate Model</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer, CDToDB.ClassToTable)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__GenerateModel__RuleEntryContainer_ClassToTable();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, CDToDB.ClassToTable, DatabaseSchemata.DBTable, ClassDiagrams.CDClass, CDToDB.PackageToSchema, ClassDiagrams.CDPackage, DatabaseSchemata.DBSchema, org.moflon.tgg.runtime.ModelgeneratorRuleResult) <em>Generate Model solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, CDToDB.ClassToTable, DatabaseSchemata.DBTable, ClassDiagrams.CDClass, CDToDB.PackageToSchema, ClassDiagrams.CDPackage, DatabaseSchemata.DBSchema, org.moflon.tgg.runtime.ModelgeneratorRuleResult)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__GenerateModel_solveCsp_BWD__IsApplicableMatch_ClassToTable_DBTable_CDClass_PackageToSchema_CDPackage_DBSchema_ModelgeneratorRuleResult();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateInheritanceRule#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Generate Model check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.CreateInheritanceRule#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getCreateInheritanceRule__GenerateModel_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for class '{@link CDToDB.Rules.PackageToSchemaRule <em>Package To Schema Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Package To Schema Rule</em>'.
	 * @see CDToDB.Rules.PackageToSchemaRule
	 * @generated
	 */
	EClass getPackageToSchemaRule();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#isAppropriate_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDPackage) <em>Is Appropriate FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#isAppropriate_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDPackage)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__IsAppropriate_FWD__Match_CDPackage();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform FWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__Perform_FWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#isApplicable_FWD(org.moflon.tgg.runtime.Match) <em>Is Applicable FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable FWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#isApplicable_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__IsApplicable_FWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDPackage) <em>Register Objects To Match FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match FWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDPackage)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__RegisterObjectsToMatch_FWD__Match_CDPackage();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDPackage) <em>Is Appropriate solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDPackage)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__IsAppropriate_solveCsp_FWD__Match_CDPackage();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__IsAppropriate_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#isApplicable_solveCsp_FWD(org.moflon.tgg.runtime.IsApplicableMatch, ClassDiagrams.CDPackage) <em>Is Applicable solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp FWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#isApplicable_solveCsp_FWD(org.moflon.tgg.runtime.IsApplicableMatch, ClassDiagrams.CDPackage)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__IsApplicable_solveCsp_FWD__IsApplicableMatch_CDPackage();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#isApplicable_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp FWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#isApplicable_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__IsApplicable_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#registerObjects_FWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects FWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#registerObjects_FWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#checkTypes_FWD(org.moflon.tgg.runtime.Match) <em>Check Types FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types FWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#checkTypes_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__CheckTypes_FWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#isAppropriate_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBSchema) <em>Is Appropriate BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#isAppropriate_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__IsAppropriate_BWD__Match_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform BWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__Perform_BWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#isApplicable_BWD(org.moflon.tgg.runtime.Match) <em>Is Applicable BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable BWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#isApplicable_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__IsApplicable_BWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBSchema) <em>Register Objects To Match BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match BWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__RegisterObjectsToMatch_BWD__Match_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBSchema) <em>Is Appropriate solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__IsAppropriate_solveCsp_BWD__Match_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__IsAppropriate_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBSchema) <em>Is Applicable solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__IsApplicable_solveCsp_BWD__IsApplicableMatch_DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__IsApplicable_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects BWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#checkTypes_BWD(org.moflon.tgg.runtime.Match) <em>Check Types BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types BWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#checkTypes_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__CheckTypes_BWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#isAppropriate_FWD_CDPackage_0(ClassDiagrams.CDPackage) <em>Is Appropriate FWD CD Package 0</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD CD Package 0</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#isAppropriate_FWD_CDPackage_0(ClassDiagrams.CDPackage)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__IsAppropriate_FWD_CDPackage_0__CDPackage();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#isAppropriate_BWD_DBSchema_0(DatabaseSchemata.DBSchema) <em>Is Appropriate BWD DB Schema 0</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD DB Schema 0</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#isAppropriate_BWD_DBSchema_0(DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__IsAppropriate_BWD_DBSchema_0__DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes FWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__CheckAttributes_FWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes BWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__CheckAttributes_BWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable CC</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__IsApplicable_CC__Match_Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#isApplicable_solveCsp_CC(DatabaseSchemata.DBSchema, ClassDiagrams.CDPackage, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable solve Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#isApplicable_solveCsp_CC(DatabaseSchemata.DBSchema, ClassDiagrams.CDPackage, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__IsApplicable_solveCsp_CC__DBSchema_CDPackage_Match_Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp CC</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__IsApplicable_checkCsp_CC__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#checkDEC_FWD(ClassDiagrams.CDPackage) <em>Check DEC FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC FWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#checkDEC_FWD(ClassDiagrams.CDPackage)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__CheckDEC_FWD__CDPackage();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#checkDEC_BWD(DatabaseSchemata.DBSchema) <em>Check DEC BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC BWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#checkDEC_BWD(DatabaseSchemata.DBSchema)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__CheckDEC_BWD__DBSchema();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer) <em>Generate Model</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__GenerateModel__RuleEntryContainer();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, org.moflon.tgg.runtime.ModelgeneratorRuleResult) <em>Generate Model solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, org.moflon.tgg.runtime.ModelgeneratorRuleResult)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__GenerateModel_solveCsp_BWD__IsApplicableMatch_ModelgeneratorRuleResult();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.PackageToSchemaRule#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Generate Model check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.PackageToSchemaRule#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getPackageToSchemaRule__GenerateModel_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for class '{@link CDToDB.Rules.TransitiveAttributeRule <em>Transitive Attribute Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transitive Attribute Rule</em>'.
	 * @see CDToDB.Rules.TransitiveAttributeRule
	 * @generated
	 */
	EClass getTransitiveAttributeRule();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#isAppropriate_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDAttribute) <em>Is Appropriate FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#isAppropriate_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDAttribute)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__IsAppropriate_FWD__Match_CDClass_CDAttribute();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__Perform_FWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#isApplicable_FWD(org.moflon.tgg.runtime.Match) <em>Is Applicable FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#isApplicable_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__IsApplicable_FWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDAttribute) <em>Register Objects To Match FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDAttribute)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__RegisterObjectsToMatch_FWD__Match_CDClass_CDAttribute();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDAttribute) <em>Is Appropriate solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDClass, ClassDiagrams.CDAttribute)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__IsAppropriate_solveCsp_FWD__Match_CDClass_CDAttribute();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__IsAppropriate_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#isApplicable_solveCsp_FWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBSchema, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, CDToDB.SuperClassToTable, ClassDiagrams.CDClass, DatabaseSchemata.DBTable, CDToDB.ClassToTable, ClassDiagrams.CDAttribute) <em>Is Applicable solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#isApplicable_solveCsp_FWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBSchema, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, CDToDB.SuperClassToTable, ClassDiagrams.CDClass, DatabaseSchemata.DBTable, CDToDB.ClassToTable, ClassDiagrams.CDAttribute)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__IsApplicable_solveCsp_FWD__IsApplicableMatch_DBSchema_DBTable_DBColumn_SuperClassToTable_CDClass_DBTable_ClassToTable_CDAttribute();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#isApplicable_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#isApplicable_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__IsApplicable_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#registerObjects_FWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#registerObjects_FWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#checkTypes_FWD(org.moflon.tgg.runtime.Match) <em>Check Types FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#checkTypes_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__CheckTypes_FWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#isAppropriate_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBSchema, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable) <em>Is Appropriate BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#isAppropriate_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBSchema, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__IsAppropriate_BWD__Match_DBSchema_DBTable_DBColumn_DBColumn_DBTable();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__Perform_BWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#isApplicable_BWD(org.moflon.tgg.runtime.Match) <em>Is Applicable BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#isApplicable_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__IsApplicable_BWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBSchema, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable) <em>Register Objects To Match BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBSchema, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__RegisterObjectsToMatch_BWD__Match_DBSchema_DBTable_DBColumn_DBColumn_DBTable();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBSchema, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable) <em>Is Appropriate solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBSchema, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__IsAppropriate_solveCsp_BWD__Match_DBSchema_DBTable_DBColumn_DBColumn_DBTable();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__IsAppropriate_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBSchema, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, CDToDB.SuperClassToTable, ClassDiagrams.CDClass, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable, CDToDB.ClassToTable, ClassDiagrams.CDAttribute) <em>Is Applicable solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBSchema, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, CDToDB.SuperClassToTable, ClassDiagrams.CDClass, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable, CDToDB.ClassToTable, ClassDiagrams.CDAttribute)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__IsApplicable_solveCsp_BWD__IsApplicableMatch_DBSchema_DBTable_DBColumn_SuperClassToTable_CDClass_DBColumn_DBTable_ClassToTable_CDAttribute();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__IsApplicable_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#checkTypes_BWD(org.moflon.tgg.runtime.Match) <em>Check Types BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#checkTypes_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__CheckTypes_BWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#isAppropriate_FWD_EMoflonEdge_4(org.moflon.tgg.runtime.EMoflonEdge) <em>Is Appropriate FWD EMoflon Edge 4</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD EMoflon Edge 4</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#isAppropriate_FWD_EMoflonEdge_4(org.moflon.tgg.runtime.EMoflonEdge)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__IsAppropriate_FWD_EMoflonEdge_4__EMoflonEdge();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#isAppropriate_BWD_EMoflonEdge_4(org.moflon.tgg.runtime.EMoflonEdge) <em>Is Appropriate BWD EMoflon Edge 4</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD EMoflon Edge 4</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#isAppropriate_BWD_EMoflonEdge_4(org.moflon.tgg.runtime.EMoflonEdge)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__IsAppropriate_BWD_EMoflonEdge_4__EMoflonEdge();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__CheckAttributes_FWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__CheckAttributes_BWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable CC</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__IsApplicable_CC__Match_Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#isApplicable_solveCsp_CC(DatabaseSchemata.DBSchema, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, ClassDiagrams.CDClass, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable, ClassDiagrams.CDAttribute, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable solve Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#isApplicable_solveCsp_CC(DatabaseSchemata.DBSchema, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, ClassDiagrams.CDClass, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable, ClassDiagrams.CDAttribute, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__IsApplicable_solveCsp_CC__DBSchema_DBTable_DBColumn_CDClass_DBColumn_DBTable_CDAttribute_Match_Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp CC</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__IsApplicable_checkCsp_CC__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#checkDEC_FWD(ClassDiagrams.CDClass, ClassDiagrams.CDAttribute) <em>Check DEC FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC FWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#checkDEC_FWD(ClassDiagrams.CDClass, ClassDiagrams.CDAttribute)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__CheckDEC_FWD__CDClass_CDAttribute();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#checkDEC_BWD(DatabaseSchemata.DBSchema, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable) <em>Check DEC BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#checkDEC_BWD(DatabaseSchemata.DBSchema, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, DatabaseSchemata.DBColumn, DatabaseSchemata.DBTable)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__CheckDEC_BWD__DBSchema_DBTable_DBColumn_DBColumn_DBTable();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer, CDToDB.ClassToTable) <em>Generate Model</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer, CDToDB.ClassToTable)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__GenerateModel__RuleEntryContainer_ClassToTable();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBSchema, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, CDToDB.SuperClassToTable, ClassDiagrams.CDClass, DatabaseSchemata.DBTable, CDToDB.ClassToTable, ClassDiagrams.CDAttribute, org.moflon.tgg.runtime.ModelgeneratorRuleResult) <em>Generate Model solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, DatabaseSchemata.DBSchema, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, CDToDB.SuperClassToTable, ClassDiagrams.CDClass, DatabaseSchemata.DBTable, CDToDB.ClassToTable, ClassDiagrams.CDAttribute, org.moflon.tgg.runtime.ModelgeneratorRuleResult)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__GenerateModel_solveCsp_BWD__IsApplicableMatch_DBSchema_DBTable_DBColumn_SuperClassToTable_CDClass_DBTable_ClassToTable_CDAttribute_ModelgeneratorRuleResult();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.TransitiveAttributeRule#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Generate Model check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.TransitiveAttributeRule#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getTransitiveAttributeRule__GenerateModel_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for class '{@link CDToDB.Rules.CreateAttributeRule <em>Create Attribute Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Create Attribute Rule</em>'.
	 * @see CDToDB.Rules.CreateAttributeRule
	 * @generated
	 */
	EClass getCreateAttributeRule();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#isAppropriate_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDAttribute, ClassDiagrams.CDClass) <em>Is Appropriate FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#isAppropriate_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDAttribute, ClassDiagrams.CDClass)
	 * @generated
	 */
	EOperation getCreateAttributeRule__IsAppropriate_FWD__Match_CDAttribute_CDClass();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform FWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#perform_FWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getCreateAttributeRule__Perform_FWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#isApplicable_FWD(org.moflon.tgg.runtime.Match) <em>Is Applicable FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable FWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#isApplicable_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getCreateAttributeRule__IsApplicable_FWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDAttribute, ClassDiagrams.CDClass) <em>Register Objects To Match FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match FWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#registerObjectsToMatch_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDAttribute, ClassDiagrams.CDClass)
	 * @generated
	 */
	EOperation getCreateAttributeRule__RegisterObjectsToMatch_FWD__Match_CDAttribute_CDClass();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDAttribute, ClassDiagrams.CDClass) <em>Is Appropriate solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp FWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#isAppropriate_solveCsp_FWD(org.moflon.tgg.runtime.Match, ClassDiagrams.CDAttribute, ClassDiagrams.CDClass)
	 * @generated
	 */
	EOperation getCreateAttributeRule__IsAppropriate_solveCsp_FWD__Match_CDAttribute_CDClass();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp FWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#isAppropriate_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getCreateAttributeRule__IsAppropriate_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#isApplicable_solveCsp_FWD(org.moflon.tgg.runtime.IsApplicableMatch, CDToDB.ClassToTable, ClassDiagrams.CDAttribute, ClassDiagrams.CDClass, DatabaseSchemata.DBTable) <em>Is Applicable solve Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp FWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#isApplicable_solveCsp_FWD(org.moflon.tgg.runtime.IsApplicableMatch, CDToDB.ClassToTable, ClassDiagrams.CDAttribute, ClassDiagrams.CDClass, DatabaseSchemata.DBTable)
	 * @generated
	 */
	EOperation getCreateAttributeRule__IsApplicable_solveCsp_FWD__IsApplicableMatch_ClassToTable_CDAttribute_CDClass_DBTable();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#isApplicable_checkCsp_FWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp FWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#isApplicable_checkCsp_FWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getCreateAttributeRule__IsApplicable_checkCsp_FWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#registerObjects_FWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects FWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#registerObjects_FWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getCreateAttributeRule__RegisterObjects_FWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#checkTypes_FWD(org.moflon.tgg.runtime.Match) <em>Check Types FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types FWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#checkTypes_FWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getCreateAttributeRule__CheckTypes_FWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#isAppropriate_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn) <em>Is Appropriate BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#isAppropriate_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn)
	 * @generated
	 */
	EOperation getCreateAttributeRule__IsAppropriate_BWD__Match_DBTable_DBColumn();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch) <em>Perform BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Perform BWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#perform_BWD(org.moflon.tgg.runtime.IsApplicableMatch)
	 * @generated
	 */
	EOperation getCreateAttributeRule__Perform_BWD__IsApplicableMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#isApplicable_BWD(org.moflon.tgg.runtime.Match) <em>Is Applicable BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable BWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#isApplicable_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getCreateAttributeRule__IsApplicable_BWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn) <em>Register Objects To Match BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects To Match BWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#registerObjectsToMatch_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn)
	 * @generated
	 */
	EOperation getCreateAttributeRule__RegisterObjectsToMatch_BWD__Match_DBTable_DBColumn();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn) <em>Is Appropriate solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#isAppropriate_solveCsp_BWD(org.moflon.tgg.runtime.Match, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn)
	 * @generated
	 */
	EOperation getCreateAttributeRule__IsAppropriate_solveCsp_BWD__Match_DBTable_DBColumn();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Appropriate check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#isAppropriate_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getCreateAttributeRule__IsAppropriate_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, CDToDB.ClassToTable, ClassDiagrams.CDClass, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn) <em>Is Applicable solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#isApplicable_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, CDToDB.ClassToTable, ClassDiagrams.CDClass, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn)
	 * @generated
	 */
	EOperation getCreateAttributeRule__IsApplicable_solveCsp_BWD__IsApplicableMatch_ClassToTable_CDClass_DBTable_DBColumn();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#isApplicable_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getCreateAttributeRule__IsApplicable_checkCsp_BWD__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject) <em>Register Objects BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Register Objects BWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#registerObjects_BWD(org.moflon.tgg.runtime.PerformRuleResult, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject, org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	EOperation getCreateAttributeRule__RegisterObjects_BWD__PerformRuleResult_EObject_EObject_EObject_EObject_EObject();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#checkTypes_BWD(org.moflon.tgg.runtime.Match) <em>Check Types BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Types BWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#checkTypes_BWD(org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getCreateAttributeRule__CheckTypes_BWD__Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#isAppropriate_FWD_EMoflonEdge_5(org.moflon.tgg.runtime.EMoflonEdge) <em>Is Appropriate FWD EMoflon Edge 5</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate FWD EMoflon Edge 5</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#isAppropriate_FWD_EMoflonEdge_5(org.moflon.tgg.runtime.EMoflonEdge)
	 * @generated
	 */
	EOperation getCreateAttributeRule__IsAppropriate_FWD_EMoflonEdge_5__EMoflonEdge();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#isAppropriate_BWD_EMoflonEdge_5(org.moflon.tgg.runtime.EMoflonEdge) <em>Is Appropriate BWD EMoflon Edge 5</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Appropriate BWD EMoflon Edge 5</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#isAppropriate_BWD_EMoflonEdge_5(org.moflon.tgg.runtime.EMoflonEdge)
	 * @generated
	 */
	EOperation getCreateAttributeRule__IsAppropriate_BWD_EMoflonEdge_5__EMoflonEdge();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes FWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#checkAttributes_FWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getCreateAttributeRule__CheckAttributes_FWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch) <em>Check Attributes BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check Attributes BWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#checkAttributes_BWD(org.moflon.tgg.runtime.TripleMatch)
	 * @generated
	 */
	EOperation getCreateAttributeRule__CheckAttributes_BWD__TripleMatch();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable CC</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#isApplicable_CC(org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getCreateAttributeRule__IsApplicable_CC__Match_Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#isApplicable_solveCsp_CC(ClassDiagrams.CDAttribute, ClassDiagrams.CDClass, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match) <em>Is Applicable solve Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable solve Csp CC</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#isApplicable_solveCsp_CC(ClassDiagrams.CDAttribute, ClassDiagrams.CDClass, DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn, org.moflon.tgg.runtime.Match, org.moflon.tgg.runtime.Match)
	 * @generated
	 */
	EOperation getCreateAttributeRule__IsApplicable_solveCsp_CC__CDAttribute_CDClass_DBTable_DBColumn_Match_Match();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP) <em>Is Applicable check Csp CC</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Applicable check Csp CC</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#isApplicable_checkCsp_CC(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getCreateAttributeRule__IsApplicable_checkCsp_CC__CSP();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#checkDEC_FWD(ClassDiagrams.CDAttribute, ClassDiagrams.CDClass) <em>Check DEC FWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC FWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#checkDEC_FWD(ClassDiagrams.CDAttribute, ClassDiagrams.CDClass)
	 * @generated
	 */
	EOperation getCreateAttributeRule__CheckDEC_FWD__CDAttribute_CDClass();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#checkDEC_BWD(DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn) <em>Check DEC BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Check DEC BWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#checkDEC_BWD(DatabaseSchemata.DBTable, DatabaseSchemata.DBColumn)
	 * @generated
	 */
	EOperation getCreateAttributeRule__CheckDEC_BWD__DBTable_DBColumn();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer, CDToDB.ClassToTable) <em>Generate Model</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#generateModel(org.moflon.tgg.language.modelgenerator.RuleEntryContainer, CDToDB.ClassToTable)
	 * @generated
	 */
	EOperation getCreateAttributeRule__GenerateModel__RuleEntryContainer_ClassToTable();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, CDToDB.ClassToTable, ClassDiagrams.CDClass, DatabaseSchemata.DBTable, org.moflon.tgg.runtime.ModelgeneratorRuleResult) <em>Generate Model solve Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model solve Csp BWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#generateModel_solveCsp_BWD(org.moflon.tgg.runtime.IsApplicableMatch, CDToDB.ClassToTable, ClassDiagrams.CDClass, DatabaseSchemata.DBTable, org.moflon.tgg.runtime.ModelgeneratorRuleResult)
	 * @generated
	 */
	EOperation getCreateAttributeRule__GenerateModel_solveCsp_BWD__IsApplicableMatch_ClassToTable_CDClass_DBTable_ModelgeneratorRuleResult();

	/**
	 * Returns the meta object for the '{@link CDToDB.Rules.CreateAttributeRule#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP) <em>Generate Model check Csp BWD</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Generate Model check Csp BWD</em>' operation.
	 * @see CDToDB.Rules.CreateAttributeRule#generateModel_checkCsp_BWD(org.moflon.tgg.language.csp.CSP)
	 * @generated
	 */
	EOperation getCreateAttributeRule__GenerateModel_checkCsp_BWD__CSP();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	RulesFactory getRulesFactory();

} //RulesPackage
