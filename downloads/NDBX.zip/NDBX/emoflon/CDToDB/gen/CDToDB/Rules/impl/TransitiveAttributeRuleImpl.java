/**
 */
package CDToDB.Rules.impl;

import CDToDB.ClassToTable;

import CDToDB.Rules.RulesPackage;
import CDToDB.Rules.TransitiveAttributeRule;

import CDToDB.SuperClassToTable;

import ClassDiagrams.CDAttribute;
import ClassDiagrams.CDClass;

import DatabaseSchemata.DBColumn;
import DatabaseSchemata.DBSchema;
import DatabaseSchemata.DBTable;
import DatabaseSchemata.DatabaseSchemataFactory;

import java.lang.Iterable;

import java.lang.reflect.InvocationTargetException;

import java.util.LinkedList;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EOperation;

import org.moflon.tgg.language.csp.CSP;

import org.moflon.tgg.language.modelgenerator.RuleEntryContainer;
import org.moflon.tgg.language.modelgenerator.RuleEntryList;

import org.moflon.tgg.runtime.AttributeConstraintsRuleResult;
import org.moflon.tgg.runtime.CCMatch;
import org.moflon.tgg.runtime.EMoflonEdge;
import org.moflon.tgg.runtime.EObjectContainer;
import org.moflon.tgg.runtime.IsApplicableMatch;
import org.moflon.tgg.runtime.IsApplicableRuleResult;
import org.moflon.tgg.runtime.Match;
import org.moflon.tgg.runtime.ModelgeneratorRuleResult;
import org.moflon.tgg.runtime.PerformRuleResult;
import org.moflon.tgg.runtime.RuntimeFactory;
import org.moflon.tgg.runtime.TripleMatch;

import org.moflon.tgg.runtime.impl.AbstractRuleImpl;
// <-- [user defined imports]
import org.moflon.tgg.csp.*;
import CDToDB.csp.constraints.*;
import org.moflon.tgg.csp.constraints.*;
import org.moflon.tgg.language.csp.*;
import org.moflon.tgg.runtime.TripleMatchNodeMapping;
import java.util.Optional;
import org.moflon.tgg.algorithm.delta.attribute.CheckAttributeHelper;
import SDMLanguage.expressions.ComparingOperator;
import org.moflon.tgg.runtime.TripleMatchNodeMapping;
import java.util.Optional;
import org.moflon.tgg.algorithm.delta.attribute.CheckAttributeHelper;
import SDMLanguage.expressions.ComparingOperator;
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Transitive Attribute Rule</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class TransitiveAttributeRuleImpl extends AbstractRuleImpl implements TransitiveAttributeRule {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TransitiveAttributeRuleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RulesPackage.eINSTANCE.getTransitiveAttributeRule();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_FWD(Match match, CDClass c, CDAttribute a) {

		Object[] result1_black = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_0_1_initialbindings_blackBBBB(this, match, c, a);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[match] = " + match + ", " + "[c] = " + c + ", " + "[a] = " + a + ".");
		}

		Object[] result2_bindingAndBlack = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_0_2_SolveCSP_bindingAndBlackFBBBB(this, match, c, a);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[match] = " + match + ", " + "[c] = " + c + ", " + "[a] = " + a + ".");
		}
		CSP csp = (CSP) result2_bindingAndBlack[0];
		// 
		if (TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_0_3_CheckCSP_expressionFBB(this, csp)) {

			Object[] result4_black = TransitiveAttributeRuleImpl
					.pattern_TransitiveAttributeRule_0_4_collectelementstobetranslated_blackBBB(match, c, a);
			if (result4_black == null) {
				throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match + ", "
						+ "[c] = " + c + ", " + "[a] = " + a + ".");
			}

			Object[] result5_black = TransitiveAttributeRuleImpl
					.pattern_TransitiveAttributeRule_0_5_collectcontextelements_blackBBB(match, c, a);
			if (result5_black == null) {
				throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match + ", "
						+ "[c] = " + c + ", " + "[a] = " + a + ".");
			}
			TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_0_5_collectcontextelements_greenBBBF(match, c,
					a);
			//nothing EMoflonEdge c__a____attributes = (EMoflonEdge) result5_green[3];

			// 
			TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_0_6_registerobjectstomatch_expressionBBBB(this,
					match, c, a);
			return TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_0_7_expressionF();
		} else {
			return TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_0_8_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformRuleResult perform_FWD(IsApplicableMatch isApplicableMatch) {

		Object[] result1_bindingAndBlack = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_1_1_performtransformation_bindingAndBlackFFFFFFFFFBB(this,
						isApplicableMatch);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[isApplicableMatch] = " + isApplicableMatch + ".");
		}
		DBSchema s = (DBSchema) result1_bindingAndBlack[0];
		DBTable t = (DBTable) result1_bindingAndBlack[1];
		DBColumn col = (DBColumn) result1_bindingAndBlack[2];
		SuperClassToTable superCorr = (SuperClassToTable) result1_bindingAndBlack[3];
		CDClass c = (CDClass) result1_bindingAndBlack[4];
		DBTable subTable = (DBTable) result1_bindingAndBlack[5];
		ClassToTable c2t = (ClassToTable) result1_bindingAndBlack[6];
		CDAttribute a = (CDAttribute) result1_bindingAndBlack[7];
		CSP csp = (CSP) result1_bindingAndBlack[8];
		Object[] result1_green = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_1_1_performtransformation_greenFBB(subTable, csp);
		DBColumn transCol = (DBColumn) result1_green[0];

		Object[] result2_black = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_1_2_collecttranslatedelements_blackB(transCol);
		if (result2_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[transCol] = " + transCol + ".");
		}
		Object[] result2_green = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_1_2_collecttranslatedelements_greenFB(transCol);
		PerformRuleResult ruleresult = (PerformRuleResult) result2_green[0];

		Object[] result3_black = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_1_3_bookkeepingforedges_blackBBBBBBBBBB(ruleresult, s, t, col,
						superCorr, c, transCol, subTable, c2t, a);
		if (result3_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[ruleresult] = " + ruleresult
					+ ", " + "[s] = " + s + ", " + "[t] = " + t + ", " + "[col] = " + col + ", " + "[superCorr] = "
					+ superCorr + ", " + "[c] = " + c + ", " + "[transCol] = " + transCol + ", " + "[subTable] = "
					+ subTable + ", " + "[c2t] = " + c2t + ", " + "[a] = " + a + ".");
		}
		TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_1_3_bookkeepingforedges_greenBBBF(ruleresult,
				transCol, subTable);
		//nothing EMoflonEdge subTable__transCol____cols = (EMoflonEdge) result3_green[3];

		// 
		// 
		TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_1_5_registerobjects_expressionBBBBBBBBBBB(this,
				ruleresult, s, t, col, superCorr, c, transCol, subTable, c2t, a);
		return TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_1_6_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_FWD(Match match) {

		Object[] result1_bindingAndBlack = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_2_1_preparereturnvalue_bindingAndBlackFFB(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		EOperation performOperation = (EOperation) result1_bindingAndBlack[0];
		//nothing EClass eClass = (EClass) result1_bindingAndBlack[1];
		Object[] result1_green = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_2_1_preparereturnvalue_greenBF(performOperation);
		IsApplicableRuleResult ruleresult = (IsApplicableRuleResult) result1_green[1];

		// ForEach 
		Object[] result2_binding = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_2_2_corematch_bindingFFB(match);
		if (result2_binding == null) {
			throw new RuntimeException(
					"Binding in node core match failed." + " Variables: " + "[match] = " + match + ".");
		}
		CDClass c = (CDClass) result2_binding[0];
		CDAttribute a = (CDAttribute) result2_binding[1];
		for (Object[] result2_black : TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_2_2_corematch_blackFFBFFBB(c, a, match)) {
			DBTable t = (DBTable) result2_black[0];
			SuperClassToTable superCorr = (SuperClassToTable) result2_black[1];
			DBTable subTable = (DBTable) result2_black[3];
			ClassToTable c2t = (ClassToTable) result2_black[4];
			// ForEach 
			for (Object[] result3_black : TransitiveAttributeRuleImpl
					.pattern_TransitiveAttributeRule_2_3_findcontext_blackFBFBBBBB(t, superCorr, c, subTable, c2t, a)) {
				DBSchema s = (DBSchema) result3_black[0];
				DBColumn col = (DBColumn) result3_black[2];
				Object[] result3_green = TransitiveAttributeRuleImpl
						.pattern_TransitiveAttributeRule_2_3_findcontext_greenBBBBBBBBFFFFFFFFF(s, t, col, superCorr, c,
								subTable, c2t, a);
				IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result3_green[8];
				//nothing EMoflonEdge s__t____tables = (EMoflonEdge) result3_green[9];
				//nothing EMoflonEdge s__subTable____tables = (EMoflonEdge) result3_green[10];
				//nothing EMoflonEdge superCorr__subTable____target = (EMoflonEdge) result3_green[11];
				//nothing EMoflonEdge superCorr__c____source = (EMoflonEdge) result3_green[12];
				//nothing EMoflonEdge c2t__c____source = (EMoflonEdge) result3_green[13];
				//nothing EMoflonEdge c2t__t____target = (EMoflonEdge) result3_green[14];
				//nothing EMoflonEdge c__a____attributes = (EMoflonEdge) result3_green[15];
				//nothing EMoflonEdge t__col____cols = (EMoflonEdge) result3_green[16];

				Object[] result4_bindingAndBlack = TransitiveAttributeRuleImpl
						.pattern_TransitiveAttributeRule_2_4_solveCSP_bindingAndBlackFBBBBBBBBBB(this,
								isApplicableMatch, s, t, col, superCorr, c, subTable, c2t, a);
				if (result4_bindingAndBlack == null) {
					throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
							+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[s] = " + s + ", " + "[t] = " + t
							+ ", " + "[col] = " + col + ", " + "[superCorr] = " + superCorr + ", " + "[c] = " + c + ", "
							+ "[subTable] = " + subTable + ", " + "[c2t] = " + c2t + ", " + "[a] = " + a + ".");
				}
				CSP csp = (CSP) result4_bindingAndBlack[0];
				// 
				if (TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_2_5_checkCSP_expressionFBB(this, csp)) {

					Object[] result6_black = TransitiveAttributeRuleImpl
							.pattern_TransitiveAttributeRule_2_6_addmatchtoruleresult_blackBB(ruleresult,
									isApplicableMatch);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[ruleresult] = "
								+ ruleresult + ", " + "[isApplicableMatch] = " + isApplicableMatch + ".");
					}
					TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_2_6_addmatchtoruleresult_greenBB(
							ruleresult, isApplicableMatch);

				} else {
				}

			}

		}
		return TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_2_7_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjectsToMatch_FWD(Match match, CDClass c, CDAttribute a) {
		match.registerObject("c", c);
		match.registerObject("a", a);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isAppropriate_solveCsp_FWD(Match match, CDClass c, CDAttribute a) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables

		// Create unbound variables

		// Create constraints

		// Solve CSP
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_checkCsp_FWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_FWD(IsApplicableMatch isApplicableMatch, DBSchema s, DBTable t, DBColumn col,
			SuperClassToTable superCorr, CDClass c, DBTable subTable, ClassToTable c2t, CDAttribute a) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables
		Variable var_col_name = CSPFactoryHelper.eINSTANCE.createVariable("col.name", true, csp);
		var_col_name.setValue(col.getName());
		var_col_name.setType("String");
		Variable var_a_name = CSPFactoryHelper.eINSTANCE.createVariable("a.name", true, csp);
		var_a_name.setValue(a.getName());
		var_a_name.setType("String");

		// Create unbound variables
		Variable var_transCol_name = CSPFactoryHelper.eINSTANCE.createVariable("transCol.name", csp);
		var_transCol_name.setType("String");

		// Create constraints
		Eq eq = new Eq();
		Eq eq_0 = new Eq();

		csp.getConstraints().add(eq);
		csp.getConstraints().add(eq_0);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_a_name, var_col_name);
		eq_0.setRuleName("NoRuleName");
		eq_0.solve(var_col_name, var_transCol_name);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("s", s);
		isApplicableMatch.registerObject("t", t);
		isApplicableMatch.registerObject("col", col);
		isApplicableMatch.registerObject("superCorr", superCorr);
		isApplicableMatch.registerObject("c", c);
		isApplicableMatch.registerObject("subTable", subTable);
		isApplicableMatch.registerObject("c2t", c2t);
		isApplicableMatch.registerObject("a", a);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_FWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjects_FWD(PerformRuleResult ruleresult, EObject s, EObject t, EObject col, EObject superCorr,
			EObject c, EObject transCol, EObject subTable, EObject c2t, EObject a) {
		ruleresult.registerObject("s", s);
		ruleresult.registerObject("t", t);
		ruleresult.registerObject("col", col);
		ruleresult.registerObject("superCorr", superCorr);
		ruleresult.registerObject("c", c);
		ruleresult.registerObject("transCol", transCol);
		ruleresult.registerObject("subTable", subTable);
		ruleresult.registerObject("c2t", c2t);
		ruleresult.registerObject("a", a);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkTypes_FWD(Match match) {
		return true;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_BWD(Match match, DBSchema s, DBTable t, DBColumn col, DBColumn transCol,
			DBTable subTable) {

		Object[] result1_black = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_10_1_initialbindings_blackBBBBBBB(this, match, s, t, col, transCol,
						subTable);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[match] = " + match + ", " + "[s] = " + s + ", " + "[t] = " + t + ", " + "[col] = " + col + ", "
					+ "[transCol] = " + transCol + ", " + "[subTable] = " + subTable + ".");
		}

		Object[] result2_bindingAndBlack = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_10_2_SolveCSP_bindingAndBlackFBBBBBBB(this, match, s, t, col, transCol,
						subTable);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[match] = " + match + ", " + "[s] = " + s + ", " + "[t] = " + t + ", " + "[col] = " + col + ", "
					+ "[transCol] = " + transCol + ", " + "[subTable] = " + subTable + ".");
		}
		CSP csp = (CSP) result2_bindingAndBlack[0];
		// 
		if (TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_10_3_CheckCSP_expressionFBB(this, csp)) {

			Object[] result4_black = TransitiveAttributeRuleImpl
					.pattern_TransitiveAttributeRule_10_4_collectelementstobetranslated_blackBBBBBB(match, s, t, col,
							transCol, subTable);
			if (result4_black == null) {
				throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match + ", "
						+ "[s] = " + s + ", " + "[t] = " + t + ", " + "[col] = " + col + ", " + "[transCol] = "
						+ transCol + ", " + "[subTable] = " + subTable + ".");
			}
			TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_10_4_collectelementstobetranslated_greenBBBF(
					match, transCol, subTable);
			//nothing EMoflonEdge subTable__transCol____cols = (EMoflonEdge) result4_green[3];

			Object[] result5_black = TransitiveAttributeRuleImpl
					.pattern_TransitiveAttributeRule_10_5_collectcontextelements_blackBBBBBB(match, s, t, col, transCol,
							subTable);
			if (result5_black == null) {
				throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match + ", "
						+ "[s] = " + s + ", " + "[t] = " + t + ", " + "[col] = " + col + ", " + "[transCol] = "
						+ transCol + ", " + "[subTable] = " + subTable + ".");
			}
			TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_10_5_collectcontextelements_greenBBBBBFFF(match,
					s, t, col, subTable);
			//nothing EMoflonEdge s__t____tables = (EMoflonEdge) result5_green[5];
			//nothing EMoflonEdge s__subTable____tables = (EMoflonEdge) result5_green[6];
			//nothing EMoflonEdge t__col____cols = (EMoflonEdge) result5_green[7];

			// 
			TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_10_6_registerobjectstomatch_expressionBBBBBBB(
					this, match, s, t, col, transCol, subTable);
			return TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_10_7_expressionF();
		} else {
			return TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_10_8_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformRuleResult perform_BWD(IsApplicableMatch isApplicableMatch) {

		Object[] result1_bindingAndBlack = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_11_1_performtransformation_bindingAndBlackFFFFFFFFFFBB(this,
						isApplicableMatch);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[isApplicableMatch] = " + isApplicableMatch + ".");
		}
		DBSchema s = (DBSchema) result1_bindingAndBlack[0];
		DBTable t = (DBTable) result1_bindingAndBlack[1];
		DBColumn col = (DBColumn) result1_bindingAndBlack[2];
		SuperClassToTable superCorr = (SuperClassToTable) result1_bindingAndBlack[3];
		CDClass c = (CDClass) result1_bindingAndBlack[4];
		DBColumn transCol = (DBColumn) result1_bindingAndBlack[5];
		DBTable subTable = (DBTable) result1_bindingAndBlack[6];
		ClassToTable c2t = (ClassToTable) result1_bindingAndBlack[7];
		CDAttribute a = (CDAttribute) result1_bindingAndBlack[8];
		//nothing CSP csp = (CSP) result1_bindingAndBlack[9];

		Object[] result2_black = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_11_2_collecttranslatedelements_blackB(transCol);
		if (result2_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[transCol] = " + transCol + ".");
		}
		Object[] result2_green = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_11_2_collecttranslatedelements_greenFB(transCol);
		PerformRuleResult ruleresult = (PerformRuleResult) result2_green[0];

		Object[] result3_black = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_11_3_bookkeepingforedges_blackBBBBBBBBBB(ruleresult, s, t, col,
						superCorr, c, transCol, subTable, c2t, a);
		if (result3_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[ruleresult] = " + ruleresult
					+ ", " + "[s] = " + s + ", " + "[t] = " + t + ", " + "[col] = " + col + ", " + "[superCorr] = "
					+ superCorr + ", " + "[c] = " + c + ", " + "[transCol] = " + transCol + ", " + "[subTable] = "
					+ subTable + ", " + "[c2t] = " + c2t + ", " + "[a] = " + a + ".");
		}
		TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_11_3_bookkeepingforedges_greenBBBF(ruleresult,
				transCol, subTable);
		//nothing EMoflonEdge subTable__transCol____cols = (EMoflonEdge) result3_green[3];

		// 
		// 
		TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_11_5_registerobjects_expressionBBBBBBBBBBB(this,
				ruleresult, s, t, col, superCorr, c, transCol, subTable, c2t, a);
		return TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_11_6_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_BWD(Match match) {

		Object[] result1_bindingAndBlack = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_12_1_preparereturnvalue_bindingAndBlackFFB(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		EOperation performOperation = (EOperation) result1_bindingAndBlack[0];
		//nothing EClass eClass = (EClass) result1_bindingAndBlack[1];
		Object[] result1_green = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_12_1_preparereturnvalue_greenBF(performOperation);
		IsApplicableRuleResult ruleresult = (IsApplicableRuleResult) result1_green[1];

		// ForEach 
		Object[] result2_binding = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_12_2_corematch_bindingFFFFFB(match);
		if (result2_binding == null) {
			throw new RuntimeException(
					"Binding in node core match failed." + " Variables: " + "[match] = " + match + ".");
		}
		DBSchema s = (DBSchema) result2_binding[0];
		DBTable t = (DBTable) result2_binding[1];
		DBColumn col = (DBColumn) result2_binding[2];
		DBColumn transCol = (DBColumn) result2_binding[3];
		DBTable subTable = (DBTable) result2_binding[4];
		for (Object[] result2_black : TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_12_2_corematch_blackBBBFFBBFB(s, t, col, transCol, subTable, match)) {
			SuperClassToTable superCorr = (SuperClassToTable) result2_black[3];
			CDClass c = (CDClass) result2_black[4];
			ClassToTable c2t = (ClassToTable) result2_black[7];
			// ForEach 
			for (Object[] result3_black : TransitiveAttributeRuleImpl
					.pattern_TransitiveAttributeRule_12_3_findcontext_blackBBBBBBBBF(s, t, col, superCorr, c, transCol,
							subTable, c2t)) {
				CDAttribute a = (CDAttribute) result3_black[8];
				Object[] result3_green = TransitiveAttributeRuleImpl
						.pattern_TransitiveAttributeRule_12_3_findcontext_greenBBBBBBBBBFFFFFFFFFF(s, t, col, superCorr,
								c, transCol, subTable, c2t, a);
				IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result3_green[9];
				//nothing EMoflonEdge s__t____tables = (EMoflonEdge) result3_green[10];
				//nothing EMoflonEdge s__subTable____tables = (EMoflonEdge) result3_green[11];
				//nothing EMoflonEdge superCorr__subTable____target = (EMoflonEdge) result3_green[12];
				//nothing EMoflonEdge subTable__transCol____cols = (EMoflonEdge) result3_green[13];
				//nothing EMoflonEdge superCorr__c____source = (EMoflonEdge) result3_green[14];
				//nothing EMoflonEdge c2t__c____source = (EMoflonEdge) result3_green[15];
				//nothing EMoflonEdge c2t__t____target = (EMoflonEdge) result3_green[16];
				//nothing EMoflonEdge c__a____attributes = (EMoflonEdge) result3_green[17];
				//nothing EMoflonEdge t__col____cols = (EMoflonEdge) result3_green[18];

				Object[] result4_bindingAndBlack = TransitiveAttributeRuleImpl
						.pattern_TransitiveAttributeRule_12_4_solveCSP_bindingAndBlackFBBBBBBBBBBB(this,
								isApplicableMatch, s, t, col, superCorr, c, transCol, subTable, c2t, a);
				if (result4_bindingAndBlack == null) {
					throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
							+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[s] = " + s + ", " + "[t] = " + t
							+ ", " + "[col] = " + col + ", " + "[superCorr] = " + superCorr + ", " + "[c] = " + c + ", "
							+ "[transCol] = " + transCol + ", " + "[subTable] = " + subTable + ", " + "[c2t] = " + c2t
							+ ", " + "[a] = " + a + ".");
				}
				CSP csp = (CSP) result4_bindingAndBlack[0];
				// 
				if (TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_12_5_checkCSP_expressionFBB(this,
						csp)) {

					Object[] result6_black = TransitiveAttributeRuleImpl
							.pattern_TransitiveAttributeRule_12_6_addmatchtoruleresult_blackBB(ruleresult,
									isApplicableMatch);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[ruleresult] = "
								+ ruleresult + ", " + "[isApplicableMatch] = " + isApplicableMatch + ".");
					}
					TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_12_6_addmatchtoruleresult_greenBB(
							ruleresult, isApplicableMatch);

				} else {
				}

			}

		}
		return TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_12_7_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjectsToMatch_BWD(Match match, DBSchema s, DBTable t, DBColumn col, DBColumn transCol,
			DBTable subTable) {
		match.registerObject("s", s);
		match.registerObject("t", t);
		match.registerObject("col", col);
		match.registerObject("transCol", transCol);
		match.registerObject("subTable", subTable);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isAppropriate_solveCsp_BWD(Match match, DBSchema s, DBTable t, DBColumn col, DBColumn transCol,
			DBTable subTable) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables
		Variable var_col_name = CSPFactoryHelper.eINSTANCE.createVariable("col.name", true, csp);
		var_col_name.setValue(col.getName());
		var_col_name.setType("String");
		Variable var_transCol_name = CSPFactoryHelper.eINSTANCE.createVariable("transCol.name", true, csp);
		var_transCol_name.setValue(transCol.getName());
		var_transCol_name.setType("String");

		// Create unbound variables

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_col_name, var_transCol_name);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_BWD(IsApplicableMatch isApplicableMatch, DBSchema s, DBTable t, DBColumn col,
			SuperClassToTable superCorr, CDClass c, DBColumn transCol, DBTable subTable, ClassToTable c2t,
			CDAttribute a) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables
		Variable var_a_name = CSPFactoryHelper.eINSTANCE.createVariable("a.name", true, csp);
		var_a_name.setValue(a.getName());
		var_a_name.setType("String");
		Variable var_col_name = CSPFactoryHelper.eINSTANCE.createVariable("col.name", true, csp);
		var_col_name.setValue(col.getName());
		var_col_name.setType("String");

		// Create unbound variables

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_a_name, var_col_name);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("s", s);
		isApplicableMatch.registerObject("t", t);
		isApplicableMatch.registerObject("col", col);
		isApplicableMatch.registerObject("superCorr", superCorr);
		isApplicableMatch.registerObject("c", c);
		isApplicableMatch.registerObject("transCol", transCol);
		isApplicableMatch.registerObject("subTable", subTable);
		isApplicableMatch.registerObject("c2t", c2t);
		isApplicableMatch.registerObject("a", a);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjects_BWD(PerformRuleResult ruleresult, EObject s, EObject t, EObject col, EObject superCorr,
			EObject c, EObject transCol, EObject subTable, EObject c2t, EObject a) {
		ruleresult.registerObject("s", s);
		ruleresult.registerObject("t", t);
		ruleresult.registerObject("col", col);
		ruleresult.registerObject("superCorr", superCorr);
		ruleresult.registerObject("c", c);
		ruleresult.registerObject("transCol", transCol);
		ruleresult.registerObject("subTable", subTable);
		ruleresult.registerObject("c2t", c2t);
		ruleresult.registerObject("a", a);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkTypes_BWD(Match match) {
		return true && org.moflon.util.eMoflonSDMUtil.getFQN(match.getObject("transCol").eClass())
				.equals("DatabaseSchemata.DBColumn.");
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObjectContainer isAppropriate_FWD_EMoflonEdge_4(EMoflonEdge _edge_attributes) {

		Object[] result1_bindingAndBlack = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_20_1_preparereturnvalue_bindingAndBlackFFBF(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		EOperation __performOperation = (EOperation) result1_bindingAndBlack[0];
		EClass __eClass = (EClass) result1_bindingAndBlack[1];
		EOperation isApplicableCC = (EOperation) result1_bindingAndBlack[3];
		Object[] result1_green = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_20_1_preparereturnvalue_greenF();
		EObjectContainer __result = (EObjectContainer) result1_green[0];

		// ForEach 
		for (Object[] result2_black : TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_20_2_testcorematchandDECs_blackFFB(_edge_attributes)) {
			CDClass c = (CDClass) result2_black[0];
			CDAttribute a = (CDAttribute) result2_black[1];
			Object[] result2_green = TransitiveAttributeRuleImpl
					.pattern_TransitiveAttributeRule_20_2_testcorematchandDECs_greenFB(__eClass);
			Match match = (Match) result2_green[0];

			// 
			if (TransitiveAttributeRuleImpl
					.pattern_TransitiveAttributeRule_20_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBB(
							this, match, c, a)) {
				// 
				if (TransitiveAttributeRuleImpl
						.pattern_TransitiveAttributeRule_20_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
								this, match)) {

					Object[] result5_black = TransitiveAttributeRuleImpl
							.pattern_TransitiveAttributeRule_20_5_Addmatchtoruleresult_blackBBBB(match,
									__performOperation, __result, isApplicableCC);
					if (result5_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match
								+ ", " + "[__performOperation] = " + __performOperation + ", " + "[__result] = "
								+ __result + ", " + "[isApplicableCC] = " + isApplicableCC + ".");
					}
					TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_20_5_Addmatchtoruleresult_greenBBBB(
							match, __performOperation, __result, isApplicableCC);

				} else {
				}

			} else {
			}

		}
		return TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_20_6_expressionFB(__result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObjectContainer isAppropriate_BWD_EMoflonEdge_4(EMoflonEdge _edge_cols) {

		Object[] result1_bindingAndBlack = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_21_1_preparereturnvalue_bindingAndBlackFFBF(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		EOperation __performOperation = (EOperation) result1_bindingAndBlack[0];
		EClass __eClass = (EClass) result1_bindingAndBlack[1];
		EOperation isApplicableCC = (EOperation) result1_bindingAndBlack[3];
		Object[] result1_green = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_21_1_preparereturnvalue_greenF();
		EObjectContainer __result = (EObjectContainer) result1_green[0];

		// ForEach 
		for (Object[] result2_black : TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_21_2_testcorematchandDECs_blackFFFFFB(_edge_cols)) {
			DBSchema s = (DBSchema) result2_black[0];
			DBTable t = (DBTable) result2_black[1];
			DBColumn col = (DBColumn) result2_black[2];
			DBColumn transCol = (DBColumn) result2_black[3];
			DBTable subTable = (DBTable) result2_black[4];
			Object[] result2_green = TransitiveAttributeRuleImpl
					.pattern_TransitiveAttributeRule_21_2_testcorematchandDECs_greenFB(__eClass);
			Match match = (Match) result2_green[0];

			// 
			if (TransitiveAttributeRuleImpl
					.pattern_TransitiveAttributeRule_21_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBBBBB(
							this, match, s, t, col, transCol, subTable)) {
				// 
				if (TransitiveAttributeRuleImpl
						.pattern_TransitiveAttributeRule_21_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
								this, match)) {

					Object[] result5_black = TransitiveAttributeRuleImpl
							.pattern_TransitiveAttributeRule_21_5_Addmatchtoruleresult_blackBBBB(match,
									__performOperation, __result, isApplicableCC);
					if (result5_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match
								+ ", " + "[__performOperation] = " + __performOperation + ", " + "[__result] = "
								+ __result + ", " + "[isApplicableCC] = " + isApplicableCC + ".");
					}
					TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_21_5_Addmatchtoruleresult_greenBBBB(
							match, __performOperation, __result, isApplicableCC);

				} else {
				}

			} else {
			}

		}
		return TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_21_6_expressionFB(__result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeConstraintsRuleResult checkAttributes_FWD(TripleMatch __tripleMatch) {
		AttributeConstraintsRuleResult ruleResult = org.moflon.tgg.runtime.RuntimeFactory.eINSTANCE
				.createAttributeConstraintsRuleResult();
		ruleResult.setRule("TransitiveAttributeRule");
		ruleResult.setSuccess(true);

		CSP csp = CspFactory.eINSTANCE.createCSP();

		CheckAttributeHelper __helper = new CheckAttributeHelper(__tripleMatch);

		Variable var_transCol_name = CSPFactoryHelper.eINSTANCE.createVariable("transCol", true, csp);
		var_transCol_name.setValue(__helper.getValue("transCol", "name"));
		var_transCol_name.setType("String");

		Variable var_col_name = CSPFactoryHelper.eINSTANCE.createVariable("col", true, csp);
		var_col_name.setValue(__helper.getValue("col", "name"));
		var_col_name.setType("String");

		Variable var_a_name = CSPFactoryHelper.eINSTANCE.createVariable("a", true, csp);
		var_a_name.setValue(__helper.getValue("a", "name"));
		var_a_name.setType("String");

		Eq eq0 = new Eq();
		csp.getConstraints().add(eq0);

		Eq eq1 = new Eq();
		csp.getConstraints().add(eq1);

		eq0.setRuleName("TransitiveAttributeRule");
		eq0.solve(var_a_name, var_col_name);

		eq1.setRuleName("TransitiveAttributeRule");
		eq1.solve(var_col_name, var_transCol_name);

		if (csp.check()) {
			ruleResult.setSuccess(true);
		} else {
			var_transCol_name.setBound(false);
			eq0.solve(var_a_name, var_col_name);
			eq1.solve(var_col_name, var_transCol_name);
			if (csp.check()) {
				ruleResult.setSuccess(true);
				ruleResult.setRequiredChange(true);
				__helper.setValue("transCol", "name", var_transCol_name.getValue());
			} else {
				ruleResult.setSuccess(false);
				return ruleResult;
			}
		}

		return ruleResult;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeConstraintsRuleResult checkAttributes_BWD(TripleMatch __tripleMatch) {
		AttributeConstraintsRuleResult ruleResult = org.moflon.tgg.runtime.RuntimeFactory.eINSTANCE
				.createAttributeConstraintsRuleResult();
		ruleResult.setRule("TransitiveAttributeRule");
		ruleResult.setSuccess(true);

		CSP csp = CspFactory.eINSTANCE.createCSP();

		CheckAttributeHelper __helper = new CheckAttributeHelper(__tripleMatch);

		Variable var_transCol_name = CSPFactoryHelper.eINSTANCE.createVariable("transCol", true, csp);
		var_transCol_name.setValue(__helper.getValue("transCol", "name"));
		var_transCol_name.setType("String");

		Variable var_col_name = CSPFactoryHelper.eINSTANCE.createVariable("col", true, csp);
		var_col_name.setValue(__helper.getValue("col", "name"));
		var_col_name.setType("String");

		Variable var_a_name = CSPFactoryHelper.eINSTANCE.createVariable("a", true, csp);
		var_a_name.setValue(__helper.getValue("a", "name"));
		var_a_name.setType("String");

		Eq eq0 = new Eq();
		csp.getConstraints().add(eq0);

		Eq eq1 = new Eq();
		csp.getConstraints().add(eq1);

		eq0.setRuleName("TransitiveAttributeRule");
		eq0.solve(var_col_name, var_transCol_name);

		eq1.setRuleName("TransitiveAttributeRule");
		eq1.solve(var_a_name, var_col_name);

		if (csp.check()) {
			ruleResult.setSuccess(true);
		} else {
			eq0.solve(var_col_name, var_transCol_name);
			eq1.solve(var_a_name, var_col_name);
			if (csp.check()) {
				ruleResult.setSuccess(true);
				ruleResult.setRequiredChange(true);
			} else {
				ruleResult.setSuccess(false);
				return ruleResult;
			}
		}

		return ruleResult;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_CC(Match sourceMatch, Match targetMatch) {

		Object[] result1_black = TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_24_1_prepare_blackB(this);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		Object[] result1_green = TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_24_1_prepare_greenF();
		IsApplicableRuleResult result = (IsApplicableRuleResult) result1_green[0];

		Object[] result2_bindingAndBlack = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_24_2_matchsrctrgcontext_bindingAndBlackFFFFFFFBB(sourceMatch,
						targetMatch);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[sourceMatch] = " + sourceMatch
					+ ", " + "[targetMatch] = " + targetMatch + ".");
		}
		DBSchema s = (DBSchema) result2_bindingAndBlack[0];
		DBTable t = (DBTable) result2_bindingAndBlack[1];
		DBColumn col = (DBColumn) result2_bindingAndBlack[2];
		CDClass c = (CDClass) result2_bindingAndBlack[3];
		DBColumn transCol = (DBColumn) result2_bindingAndBlack[4];
		DBTable subTable = (DBTable) result2_bindingAndBlack[5];
		CDAttribute a = (CDAttribute) result2_bindingAndBlack[6];

		Object[] result3_bindingAndBlack = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_24_3_solvecsp_bindingAndBlackFBBBBBBBBBB(this, s, t, col, c, transCol,
						subTable, a, sourceMatch, targetMatch);
		if (result3_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[s] = " + s + ", " + "[t] = " + t + ", " + "[col] = " + col + ", " + "[c] = " + c + ", "
					+ "[transCol] = " + transCol + ", " + "[subTable] = " + subTable + ", " + "[a] = " + a + ", "
					+ "[sourceMatch] = " + sourceMatch + ", " + "[targetMatch] = " + targetMatch + ".");
		}
		CSP csp = (CSP) result3_bindingAndBlack[0];
		// 
		if (TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_24_4_checkCSP_expressionFB(csp)) {
			// ForEach 
			for (Object[] result5_black : TransitiveAttributeRuleImpl
					.pattern_TransitiveAttributeRule_24_5_matchcorrcontext_blackBFBBFBB(t, c, subTable, sourceMatch,
							targetMatch)) {
				SuperClassToTable superCorr = (SuperClassToTable) result5_black[1];
				ClassToTable c2t = (ClassToTable) result5_black[4];
				Object[] result5_green = TransitiveAttributeRuleImpl
						.pattern_TransitiveAttributeRule_24_5_matchcorrcontext_greenBBBBF(superCorr, c2t, sourceMatch,
								targetMatch);
				CCMatch ccMatch = (CCMatch) result5_green[4];

				Object[] result6_black = TransitiveAttributeRuleImpl
						.pattern_TransitiveAttributeRule_24_6_createcorrespondence_blackBBBBBBBB(s, t, col, c, transCol,
								subTable, a, ccMatch);
				if (result6_black == null) {
					throw new RuntimeException("Pattern matching failed." + " Variables: " + "[s] = " + s + ", "
							+ "[t] = " + t + ", " + "[col] = " + col + ", " + "[c] = " + c + ", " + "[transCol] = "
							+ transCol + ", " + "[subTable] = " + subTable + ", " + "[a] = " + a + ", " + "[ccMatch] = "
							+ ccMatch + ".");
				}

				Object[] result7_black = TransitiveAttributeRuleImpl
						.pattern_TransitiveAttributeRule_24_7_addtoreturnedresult_blackBB(result, ccMatch);
				if (result7_black == null) {
					throw new RuntimeException("Pattern matching failed." + " Variables: " + "[result] = " + result
							+ ", " + "[ccMatch] = " + ccMatch + ".");
				}
				TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_24_7_addtoreturnedresult_greenBB(result,
						ccMatch);

			}

		} else {
		}
		return TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_24_8_expressionFB(result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_CC(DBSchema s, DBTable t, DBColumn col, CDClass c, DBColumn transCol,
			DBTable subTable, CDAttribute a, Match sourceMatch, Match targetMatch) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables
		Variable var_col_name = CSPFactoryHelper.eINSTANCE.createVariable("col.name", true, csp);
		var_col_name.setValue(col.getName());
		var_col_name.setType("String");
		Variable var_transCol_name = CSPFactoryHelper.eINSTANCE.createVariable("transCol.name", true, csp);
		var_transCol_name.setValue(transCol.getName());
		var_transCol_name.setType("String");
		Variable var_a_name = CSPFactoryHelper.eINSTANCE.createVariable("a.name", true, csp);
		var_a_name.setValue(a.getName());
		var_a_name.setType("String");

		// Create unbound variables

		// Create constraints
		Eq eq = new Eq();
		Eq eq_0 = new Eq();

		csp.getConstraints().add(eq);
		csp.getConstraints().add(eq_0);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_col_name, var_transCol_name);
		eq_0.setRuleName("NoRuleName");
		eq_0.solve(var_a_name, var_col_name);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_CC(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkDEC_FWD(CDClass c, CDAttribute a) {// 
		Object[] result1_black = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_27_1_matchtggpattern_blackBB(c, a);
		if (result1_black != null) {
			return TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_27_2_expressionF();
		} else {
			return TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_27_3_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkDEC_BWD(DBSchema s, DBTable t, DBColumn col, DBColumn transCol, DBTable subTable) {// 
		Object[] result1_black = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_28_1_matchtggpattern_blackBBBBB(s, t, col, transCol, subTable);
		if (result1_black != null) {
			return TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_28_2_expressionF();
		} else {
			return TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_28_3_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ModelgeneratorRuleResult generateModel(RuleEntryContainer ruleEntryContainer, ClassToTable c2tParameter) {

		Object[] result1_black = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_29_1_createresult_blackB(this);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		Object[] result1_green = TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_29_1_createresult_greenFF();
		IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result1_green[0];
		ModelgeneratorRuleResult ruleResult = (ModelgeneratorRuleResult) result1_green[1];

		// ForEach 
		for (Object[] result2_black : TransitiveAttributeRuleImpl
				.pattern_TransitiveAttributeRule_29_2_isapplicablecore_blackFFFFFFFFFBB(ruleEntryContainer,
						ruleResult)) {
			//nothing RuleEntryList c2tList = (RuleEntryList) result2_black[0];
			DBSchema s = (DBSchema) result2_black[1];
			DBTable t = (DBTable) result2_black[2];
			DBColumn col = (DBColumn) result2_black[3];
			ClassToTable c2t = (ClassToTable) result2_black[4];
			CDClass c = (CDClass) result2_black[5];
			CDAttribute a = (CDAttribute) result2_black[6];
			SuperClassToTable superCorr = (SuperClassToTable) result2_black[7];
			DBTable subTable = (DBTable) result2_black[8];

			Object[] result3_bindingAndBlack = TransitiveAttributeRuleImpl
					.pattern_TransitiveAttributeRule_29_3_solveCSP_bindingAndBlackFBBBBBBBBBBB(this, isApplicableMatch,
							s, t, col, superCorr, c, subTable, c2t, a, ruleResult);
			if (result3_bindingAndBlack == null) {
				throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
						+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[s] = " + s + ", " + "[t] = " + t
						+ ", " + "[col] = " + col + ", " + "[superCorr] = " + superCorr + ", " + "[c] = " + c + ", "
						+ "[subTable] = " + subTable + ", " + "[c2t] = " + c2t + ", " + "[a] = " + a + ", "
						+ "[ruleResult] = " + ruleResult + ".");
			}
			CSP csp = (CSP) result3_bindingAndBlack[0];
			// 
			if (TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_29_4_checkCSP_expressionFBB(this, csp)) {
				// 
				Object[] result5_black = TransitiveAttributeRuleImpl
						.pattern_TransitiveAttributeRule_29_5_checknacs_blackBBBBBBBB(s, t, col, superCorr, c, subTable,
								c2t, a);
				if (result5_black != null) {

					Object[] result6_black = TransitiveAttributeRuleImpl
							.pattern_TransitiveAttributeRule_29_6_perform_blackBBBBBBBBB(s, t, col, superCorr, c,
									subTable, c2t, a, ruleResult);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[s] = " + s + ", "
								+ "[t] = " + t + ", " + "[col] = " + col + ", " + "[superCorr] = " + superCorr + ", "
								+ "[c] = " + c + ", " + "[subTable] = " + subTable + ", " + "[c2t] = " + c2t + ", "
								+ "[a] = " + a + ", " + "[ruleResult] = " + ruleResult + ".");
					}
					TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_29_6_perform_greenFBBB(subTable,
							ruleResult, csp);
					//nothing DBColumn transCol = (DBColumn) result6_green[0];

				} else {
				}

			} else {
			}

		}
		return TransitiveAttributeRuleImpl.pattern_TransitiveAttributeRule_29_7_expressionFB(ruleResult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP generateModel_solveCsp_BWD(IsApplicableMatch isApplicableMatch, DBSchema s, DBTable t, DBColumn col,
			SuperClassToTable superCorr, CDClass c, DBTable subTable, ClassToTable c2t, CDAttribute a,
			ModelgeneratorRuleResult ruleResult) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables
		Variable var_col_name = CSPFactoryHelper.eINSTANCE.createVariable("col.name", true, csp);
		var_col_name.setValue(col.getName());
		var_col_name.setType("String");
		Variable var_a_name = CSPFactoryHelper.eINSTANCE.createVariable("a.name", true, csp);
		var_a_name.setValue(a.getName());
		var_a_name.setType("String");

		// Create unbound variables
		Variable var_transCol_name = CSPFactoryHelper.eINSTANCE.createVariable("transCol.name", csp);
		var_transCol_name.setType("String");

		// Create constraints
		Eq eq = new Eq();
		Eq eq_0 = new Eq();

		csp.getConstraints().add(eq);
		csp.getConstraints().add(eq_0);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_a_name, var_col_name);
		eq_0.setRuleName("NoRuleName");
		eq_0.solve(var_col_name, var_transCol_name);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("s", s);
		isApplicableMatch.registerObject("t", t);
		isApplicableMatch.registerObject("col", col);
		isApplicableMatch.registerObject("superCorr", superCorr);
		isApplicableMatch.registerObject("c", c);
		isApplicableMatch.registerObject("subTable", subTable);
		isApplicableMatch.registerObject("c2t", c2t);
		isApplicableMatch.registerObject("a", a);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean generateModel_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___IS_APPROPRIATE_FWD__MATCH_CDCLASS_CDATTRIBUTE:
			return isAppropriate_FWD((Match) arguments.get(0), (CDClass) arguments.get(1),
					(CDAttribute) arguments.get(2));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___PERFORM_FWD__ISAPPLICABLEMATCH:
			return perform_FWD((IsApplicableMatch) arguments.get(0));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___IS_APPLICABLE_FWD__MATCH:
			return isApplicable_FWD((Match) arguments.get(0));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_CDCLASS_CDATTRIBUTE:
			registerObjectsToMatch_FWD((Match) arguments.get(0), (CDClass) arguments.get(1),
					(CDAttribute) arguments.get(2));
			return null;
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_CDCLASS_CDATTRIBUTE:
			return isAppropriate_solveCsp_FWD((Match) arguments.get(0), (CDClass) arguments.get(1),
					(CDAttribute) arguments.get(2));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___IS_APPROPRIATE_CHECK_CSP_FWD__CSP:
			return isAppropriate_checkCsp_FWD((CSP) arguments.get(0));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_DBSCHEMA_DBTABLE_DBCOLUMN_SUPERCLASSTOTABLE_CDCLASS_DBTABLE_CLASSTOTABLE_CDATTRIBUTE:
			return isApplicable_solveCsp_FWD((IsApplicableMatch) arguments.get(0), (DBSchema) arguments.get(1),
					(DBTable) arguments.get(2), (DBColumn) arguments.get(3), (SuperClassToTable) arguments.get(4),
					(CDClass) arguments.get(5), (DBTable) arguments.get(6), (ClassToTable) arguments.get(7),
					(CDAttribute) arguments.get(8));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___IS_APPLICABLE_CHECK_CSP_FWD__CSP:
			return isApplicable_checkCsp_FWD((CSP) arguments.get(0));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT:
			registerObjects_FWD((PerformRuleResult) arguments.get(0), (EObject) arguments.get(1),
					(EObject) arguments.get(2), (EObject) arguments.get(3), (EObject) arguments.get(4),
					(EObject) arguments.get(5), (EObject) arguments.get(6), (EObject) arguments.get(7),
					(EObject) arguments.get(8), (EObject) arguments.get(9));
			return null;
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___CHECK_TYPES_FWD__MATCH:
			return checkTypes_FWD((Match) arguments.get(0));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___IS_APPROPRIATE_BWD__MATCH_DBSCHEMA_DBTABLE_DBCOLUMN_DBCOLUMN_DBTABLE:
			return isAppropriate_BWD((Match) arguments.get(0), (DBSchema) arguments.get(1), (DBTable) arguments.get(2),
					(DBColumn) arguments.get(3), (DBColumn) arguments.get(4), (DBTable) arguments.get(5));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___PERFORM_BWD__ISAPPLICABLEMATCH:
			return perform_BWD((IsApplicableMatch) arguments.get(0));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___IS_APPLICABLE_BWD__MATCH:
			return isApplicable_BWD((Match) arguments.get(0));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_DBSCHEMA_DBTABLE_DBCOLUMN_DBCOLUMN_DBTABLE:
			registerObjectsToMatch_BWD((Match) arguments.get(0), (DBSchema) arguments.get(1),
					(DBTable) arguments.get(2), (DBColumn) arguments.get(3), (DBColumn) arguments.get(4),
					(DBTable) arguments.get(5));
			return null;
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_DBSCHEMA_DBTABLE_DBCOLUMN_DBCOLUMN_DBTABLE:
			return isAppropriate_solveCsp_BWD((Match) arguments.get(0), (DBSchema) arguments.get(1),
					(DBTable) arguments.get(2), (DBColumn) arguments.get(3), (DBColumn) arguments.get(4),
					(DBTable) arguments.get(5));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___IS_APPROPRIATE_CHECK_CSP_BWD__CSP:
			return isAppropriate_checkCsp_BWD((CSP) arguments.get(0));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_DBSCHEMA_DBTABLE_DBCOLUMN_SUPERCLASSTOTABLE_CDCLASS_DBCOLUMN_DBTABLE_CLASSTOTABLE_CDATTRIBUTE:
			return isApplicable_solveCsp_BWD((IsApplicableMatch) arguments.get(0), (DBSchema) arguments.get(1),
					(DBTable) arguments.get(2), (DBColumn) arguments.get(3), (SuperClassToTable) arguments.get(4),
					(CDClass) arguments.get(5), (DBColumn) arguments.get(6), (DBTable) arguments.get(7),
					(ClassToTable) arguments.get(8), (CDAttribute) arguments.get(9));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___IS_APPLICABLE_CHECK_CSP_BWD__CSP:
			return isApplicable_checkCsp_BWD((CSP) arguments.get(0));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT:
			registerObjects_BWD((PerformRuleResult) arguments.get(0), (EObject) arguments.get(1),
					(EObject) arguments.get(2), (EObject) arguments.get(3), (EObject) arguments.get(4),
					(EObject) arguments.get(5), (EObject) arguments.get(6), (EObject) arguments.get(7),
					(EObject) arguments.get(8), (EObject) arguments.get(9));
			return null;
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___CHECK_TYPES_BWD__MATCH:
			return checkTypes_BWD((Match) arguments.get(0));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___IS_APPROPRIATE_FWD_EMOFLON_EDGE_4__EMOFLONEDGE:
			return isAppropriate_FWD_EMoflonEdge_4((EMoflonEdge) arguments.get(0));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___IS_APPROPRIATE_BWD_EMOFLON_EDGE_4__EMOFLONEDGE:
			return isAppropriate_BWD_EMoflonEdge_4((EMoflonEdge) arguments.get(0));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH:
			return checkAttributes_FWD((TripleMatch) arguments.get(0));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH:
			return checkAttributes_BWD((TripleMatch) arguments.get(0));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___IS_APPLICABLE_CC__MATCH_MATCH:
			return isApplicable_CC((Match) arguments.get(0), (Match) arguments.get(1));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___IS_APPLICABLE_SOLVE_CSP_CC__DBSCHEMA_DBTABLE_DBCOLUMN_CDCLASS_DBCOLUMN_DBTABLE_CDATTRIBUTE_MATCH_MATCH:
			return isApplicable_solveCsp_CC((DBSchema) arguments.get(0), (DBTable) arguments.get(1),
					(DBColumn) arguments.get(2), (CDClass) arguments.get(3), (DBColumn) arguments.get(4),
					(DBTable) arguments.get(5), (CDAttribute) arguments.get(6), (Match) arguments.get(7),
					(Match) arguments.get(8));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___IS_APPLICABLE_CHECK_CSP_CC__CSP:
			return isApplicable_checkCsp_CC((CSP) arguments.get(0));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___CHECK_DEC_FWD__CDCLASS_CDATTRIBUTE:
			return checkDEC_FWD((CDClass) arguments.get(0), (CDAttribute) arguments.get(1));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___CHECK_DEC_BWD__DBSCHEMA_DBTABLE_DBCOLUMN_DBCOLUMN_DBTABLE:
			return checkDEC_BWD((DBSchema) arguments.get(0), (DBTable) arguments.get(1), (DBColumn) arguments.get(2),
					(DBColumn) arguments.get(3), (DBTable) arguments.get(4));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___GENERATE_MODEL__RULEENTRYCONTAINER_CLASSTOTABLE:
			return generateModel((RuleEntryContainer) arguments.get(0), (ClassToTable) arguments.get(1));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_DBSCHEMA_DBTABLE_DBCOLUMN_SUPERCLASSTOTABLE_CDCLASS_DBTABLE_CLASSTOTABLE_CDATTRIBUTE_MODELGENERATORRULERESULT:
			return generateModel_solveCsp_BWD((IsApplicableMatch) arguments.get(0), (DBSchema) arguments.get(1),
					(DBTable) arguments.get(2), (DBColumn) arguments.get(3), (SuperClassToTable) arguments.get(4),
					(CDClass) arguments.get(5), (DBTable) arguments.get(6), (ClassToTable) arguments.get(7),
					(CDAttribute) arguments.get(8), (ModelgeneratorRuleResult) arguments.get(9));
		case RulesPackage.TRANSITIVE_ATTRIBUTE_RULE___GENERATE_MODEL_CHECK_CSP_BWD__CSP:
			return generateModel_checkCsp_BWD((CSP) arguments.get(0));
		}
		return super.eInvoke(operationID, arguments);
	}

	public static final Object[] pattern_TransitiveAttributeRule_0_1_initialbindings_blackBBBB(
			TransitiveAttributeRule _this, Match match, CDClass c, CDAttribute a) {
		return new Object[] { _this, match, c, a };
	}

	public static final Object[] pattern_TransitiveAttributeRule_0_2_SolveCSP_bindingFBBBB(
			TransitiveAttributeRule _this, Match match, CDClass c, CDAttribute a) {
		CSP _localVariable_0 = _this.isAppropriate_solveCsp_FWD(match, c, a);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, match, c, a };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_0_2_SolveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_TransitiveAttributeRule_0_2_SolveCSP_bindingAndBlackFBBBB(
			TransitiveAttributeRule _this, Match match, CDClass c, CDAttribute a) {
		Object[] result_pattern_TransitiveAttributeRule_0_2_SolveCSP_binding = pattern_TransitiveAttributeRule_0_2_SolveCSP_bindingFBBBB(
				_this, match, c, a);
		if (result_pattern_TransitiveAttributeRule_0_2_SolveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_TransitiveAttributeRule_0_2_SolveCSP_binding[0];

			Object[] result_pattern_TransitiveAttributeRule_0_2_SolveCSP_black = pattern_TransitiveAttributeRule_0_2_SolveCSP_blackB(
					csp);
			if (result_pattern_TransitiveAttributeRule_0_2_SolveCSP_black != null) {

				return new Object[] { csp, _this, match, c, a };
			}
		}
		return null;
	}

	public static final boolean pattern_TransitiveAttributeRule_0_3_CheckCSP_expressionFBB(
			TransitiveAttributeRule _this, CSP csp) {
		boolean _localVariable_0 = _this.isAppropriate_checkCsp_FWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_0_4_collectelementstobetranslated_blackBBB(Match match,
			CDClass c, CDAttribute a) {
		return new Object[] { match, c, a };
	}

	public static final Object[] pattern_TransitiveAttributeRule_0_5_collectcontextelements_blackBBB(Match match,
			CDClass c, CDAttribute a) {
		return new Object[] { match, c, a };
	}

	public static final Object[] pattern_TransitiveAttributeRule_0_5_collectcontextelements_greenBBBF(Match match,
			CDClass c, CDAttribute a) {
		EMoflonEdge c__a____attributes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getContextNodes().add(c);
		match.getContextNodes().add(a);
		String c__a____attributes_name_prime = "attributes";
		c__a____attributes.setSrc(c);
		c__a____attributes.setTrg(a);
		match.getContextEdges().add(c__a____attributes);
		c__a____attributes.setName(c__a____attributes_name_prime);
		return new Object[] { match, c, a, c__a____attributes };
	}

	public static final void pattern_TransitiveAttributeRule_0_6_registerobjectstomatch_expressionBBBB(
			TransitiveAttributeRule _this, Match match, CDClass c, CDAttribute a) {
		_this.registerObjectsToMatch_FWD(match, c, a);

	}

	public static final boolean pattern_TransitiveAttributeRule_0_7_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_TransitiveAttributeRule_0_8_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_1_1_performtransformation_bindingFFFFFFFFB(
			IsApplicableMatch isApplicableMatch) {
		EObject _localVariable_0 = isApplicableMatch.getObject("s");
		EObject _localVariable_1 = isApplicableMatch.getObject("t");
		EObject _localVariable_2 = isApplicableMatch.getObject("col");
		EObject _localVariable_3 = isApplicableMatch.getObject("superCorr");
		EObject _localVariable_4 = isApplicableMatch.getObject("c");
		EObject _localVariable_5 = isApplicableMatch.getObject("subTable");
		EObject _localVariable_6 = isApplicableMatch.getObject("c2t");
		EObject _localVariable_7 = isApplicableMatch.getObject("a");
		EObject tmpS = _localVariable_0;
		EObject tmpT = _localVariable_1;
		EObject tmpCol = _localVariable_2;
		EObject tmpSuperCorr = _localVariable_3;
		EObject tmpC = _localVariable_4;
		EObject tmpSubTable = _localVariable_5;
		EObject tmpC2t = _localVariable_6;
		EObject tmpA = _localVariable_7;
		if (tmpS instanceof DBSchema) {
			DBSchema s = (DBSchema) tmpS;
			if (tmpT instanceof DBTable) {
				DBTable t = (DBTable) tmpT;
				if (tmpCol instanceof DBColumn) {
					DBColumn col = (DBColumn) tmpCol;
					if (tmpSuperCorr instanceof SuperClassToTable) {
						SuperClassToTable superCorr = (SuperClassToTable) tmpSuperCorr;
						if (tmpC instanceof CDClass) {
							CDClass c = (CDClass) tmpC;
							if (tmpSubTable instanceof DBTable) {
								DBTable subTable = (DBTable) tmpSubTable;
								if (tmpC2t instanceof ClassToTable) {
									ClassToTable c2t = (ClassToTable) tmpC2t;
									if (tmpA instanceof CDAttribute) {
										CDAttribute a = (CDAttribute) tmpA;
										return new Object[] { s, t, col, superCorr, c, subTable, c2t, a,
												isApplicableMatch };
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_1_1_performtransformation_blackBBBBBBBBFBB(DBSchema s,
			DBTable t, DBColumn col, SuperClassToTable superCorr, CDClass c, DBTable subTable, ClassToTable c2t,
			CDAttribute a, TransitiveAttributeRule _this, IsApplicableMatch isApplicableMatch) {
		if (!subTable.equals(t)) {
			for (EObject tmpCsp : isApplicableMatch.getAttributeInfo()) {
				if (tmpCsp instanceof CSP) {
					CSP csp = (CSP) tmpCsp;
					return new Object[] { s, t, col, superCorr, c, subTable, c2t, a, csp, _this, isApplicableMatch };
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_1_1_performtransformation_bindingAndBlackFFFFFFFFFBB(
			TransitiveAttributeRule _this, IsApplicableMatch isApplicableMatch) {
		Object[] result_pattern_TransitiveAttributeRule_1_1_performtransformation_binding = pattern_TransitiveAttributeRule_1_1_performtransformation_bindingFFFFFFFFB(
				isApplicableMatch);
		if (result_pattern_TransitiveAttributeRule_1_1_performtransformation_binding != null) {
			DBSchema s = (DBSchema) result_pattern_TransitiveAttributeRule_1_1_performtransformation_binding[0];
			DBTable t = (DBTable) result_pattern_TransitiveAttributeRule_1_1_performtransformation_binding[1];
			DBColumn col = (DBColumn) result_pattern_TransitiveAttributeRule_1_1_performtransformation_binding[2];
			SuperClassToTable superCorr = (SuperClassToTable) result_pattern_TransitiveAttributeRule_1_1_performtransformation_binding[3];
			CDClass c = (CDClass) result_pattern_TransitiveAttributeRule_1_1_performtransformation_binding[4];
			DBTable subTable = (DBTable) result_pattern_TransitiveAttributeRule_1_1_performtransformation_binding[5];
			ClassToTable c2t = (ClassToTable) result_pattern_TransitiveAttributeRule_1_1_performtransformation_binding[6];
			CDAttribute a = (CDAttribute) result_pattern_TransitiveAttributeRule_1_1_performtransformation_binding[7];

			Object[] result_pattern_TransitiveAttributeRule_1_1_performtransformation_black = pattern_TransitiveAttributeRule_1_1_performtransformation_blackBBBBBBBBFBB(
					s, t, col, superCorr, c, subTable, c2t, a, _this, isApplicableMatch);
			if (result_pattern_TransitiveAttributeRule_1_1_performtransformation_black != null) {
				CSP csp = (CSP) result_pattern_TransitiveAttributeRule_1_1_performtransformation_black[8];

				return new Object[] { s, t, col, superCorr, c, subTable, c2t, a, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_1_1_performtransformation_greenFBB(DBTable subTable,
			CSP csp) {
		DBColumn transCol = DatabaseSchemataFactory.eINSTANCE.createDBColumn();
		Object _localVariable_0 = csp.getValue("transCol", "name");
		subTable.getCols().add(transCol);
		String transCol_name_prime = (String) _localVariable_0;
		transCol.setName(transCol_name_prime);
		return new Object[] { transCol, subTable, csp };
	}

	public static final Object[] pattern_TransitiveAttributeRule_1_2_collecttranslatedelements_blackB(
			DBColumn transCol) {
		return new Object[] { transCol };
	}

	public static final Object[] pattern_TransitiveAttributeRule_1_2_collecttranslatedelements_greenFB(
			DBColumn transCol) {
		PerformRuleResult ruleresult = RuntimeFactory.eINSTANCE.createPerformRuleResult();
		ruleresult.getCreatedElements().add(transCol);
		return new Object[] { ruleresult, transCol };
	}

	public static final Object[] pattern_TransitiveAttributeRule_1_3_bookkeepingforedges_blackBBBBBBBBBB(
			PerformRuleResult ruleresult, EObject s, EObject t, EObject col, EObject superCorr, EObject c,
			EObject transCol, EObject subTable, EObject c2t, EObject a) {
		if (!s.equals(t)) {
			if (!s.equals(superCorr)) {
				if (!s.equals(transCol)) {
					if (!s.equals(subTable)) {
						if (!t.equals(transCol)) {
							if (!col.equals(s)) {
								if (!col.equals(t)) {
									if (!col.equals(superCorr)) {
										if (!col.equals(transCol)) {
											if (!col.equals(subTable)) {
												if (!superCorr.equals(t)) {
													if (!superCorr.equals(transCol)) {
														if (!c.equals(s)) {
															if (!c.equals(t)) {
																if (!c.equals(col)) {
																	if (!c.equals(superCorr)) {
																		if (!c.equals(transCol)) {
																			if (!c.equals(subTable)) {
																				if (!c.equals(c2t)) {
																					if (!subTable.equals(t)) {
																						if (!subTable
																								.equals(superCorr)) {
																							if (!subTable
																									.equals(transCol)) {
																								if (!c2t.equals(s)) {
																									if (!c2t.equals(
																											t)) {
																										if (!c2t.equals(
																												col)) {
																											if (!c2t.equals(
																													superCorr)) {
																												if (!c2t.equals(
																														transCol)) {
																													if (!c2t.equals(
																															subTable)) {
																														if (!a.equals(
																																s)) {
																															if (!a.equals(
																																	t)) {
																																if (!a.equals(
																																		col)) {
																																	if (!a.equals(
																																			superCorr)) {
																																		if (!a.equals(
																																				c)) {
																																			if (!a.equals(
																																					transCol)) {
																																				if (!a.equals(
																																						subTable)) {
																																					if (!a.equals(
																																							c2t)) {
																																						return new Object[] {
																																								ruleresult,
																																								s,
																																								t,
																																								col,
																																								superCorr,
																																								c,
																																								transCol,
																																								subTable,
																																								c2t,
																																								a };
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_1_3_bookkeepingforedges_greenBBBF(
			PerformRuleResult ruleresult, EObject transCol, EObject subTable) {
		EMoflonEdge subTable__transCol____cols = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String ruleresult_ruleName_prime = "TransitiveAttributeRule";
		String subTable__transCol____cols_name_prime = "cols";
		subTable__transCol____cols.setSrc(subTable);
		subTable__transCol____cols.setTrg(transCol);
		ruleresult.getCreatedEdges().add(subTable__transCol____cols);
		ruleresult.setRuleName(ruleresult_ruleName_prime);
		subTable__transCol____cols.setName(subTable__transCol____cols_name_prime);
		return new Object[] { ruleresult, transCol, subTable, subTable__transCol____cols };
	}

	public static final void pattern_TransitiveAttributeRule_1_5_registerobjects_expressionBBBBBBBBBBB(
			TransitiveAttributeRule _this, PerformRuleResult ruleresult, EObject s, EObject t, EObject col,
			EObject superCorr, EObject c, EObject transCol, EObject subTable, EObject c2t, EObject a) {
		_this.registerObjects_FWD(ruleresult, s, t, col, superCorr, c, transCol, subTable, c2t, a);

	}

	public static final PerformRuleResult pattern_TransitiveAttributeRule_1_6_expressionFB(
			PerformRuleResult ruleresult) {
		PerformRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_2_1_preparereturnvalue_bindingFB(
			TransitiveAttributeRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass eClass = _localVariable_0;
		if (eClass != null) {
			return new Object[] { eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_2_1_preparereturnvalue_blackFBB(EClass eClass,
			TransitiveAttributeRule _this) {
		for (EOperation performOperation : eClass.getEOperations()) {
			String performOperation_name = performOperation.getName();
			if (performOperation_name.equals("perform_FWD")) {
				return new Object[] { performOperation, eClass, _this };
			}

		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_2_1_preparereturnvalue_bindingAndBlackFFB(
			TransitiveAttributeRule _this) {
		Object[] result_pattern_TransitiveAttributeRule_2_1_preparereturnvalue_binding = pattern_TransitiveAttributeRule_2_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_TransitiveAttributeRule_2_1_preparereturnvalue_binding != null) {
			EClass eClass = (EClass) result_pattern_TransitiveAttributeRule_2_1_preparereturnvalue_binding[0];

			Object[] result_pattern_TransitiveAttributeRule_2_1_preparereturnvalue_black = pattern_TransitiveAttributeRule_2_1_preparereturnvalue_blackFBB(
					eClass, _this);
			if (result_pattern_TransitiveAttributeRule_2_1_preparereturnvalue_black != null) {
				EOperation performOperation = (EOperation) result_pattern_TransitiveAttributeRule_2_1_preparereturnvalue_black[0];

				return new Object[] { performOperation, eClass, _this };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_2_1_preparereturnvalue_greenBF(
			EOperation performOperation) {
		IsApplicableRuleResult ruleresult = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		boolean ruleresult_success_prime = Boolean.valueOf(false);
		String ruleresult_rule_prime = "TransitiveAttributeRule";
		ruleresult.setPerformOperation(performOperation);
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		ruleresult.setRule(ruleresult_rule_prime);
		return new Object[] { performOperation, ruleresult };
	}

	public static final Object[] pattern_TransitiveAttributeRule_2_2_corematch_bindingFFB(Match match) {
		EObject _localVariable_0 = match.getObject("c");
		EObject _localVariable_1 = match.getObject("a");
		EObject tmpC = _localVariable_0;
		EObject tmpA = _localVariable_1;
		if (tmpC instanceof CDClass) {
			CDClass c = (CDClass) tmpC;
			if (tmpA instanceof CDAttribute) {
				CDAttribute a = (CDAttribute) tmpA;
				return new Object[] { c, a, match };
			}
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_TransitiveAttributeRule_2_2_corematch_blackFFBFFBB(CDClass c,
			CDAttribute a, Match match) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		for (SuperClassToTable superCorr : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(c,
				SuperClassToTable.class, "source")) {
			DBTable subTable = superCorr.getTarget();
			if (subTable != null) {
				for (ClassToTable c2t : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(c,
						ClassToTable.class, "source")) {
					DBTable t = c2t.getTarget();
					if (t != null) {
						if (!subTable.equals(t)) {
							_result.add(new Object[] { t, superCorr, c, subTable, c2t, a, match });
						}
					}

				}
			}

		}
		return _result;
	}

	public static final Iterable<Object[]> pattern_TransitiveAttributeRule_2_3_findcontext_blackFBFBBBBB(DBTable t,
			SuperClassToTable superCorr, CDClass c, DBTable subTable, ClassToTable c2t, CDAttribute a) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!subTable.equals(t)) {
			if (subTable.equals(superCorr.getTarget())) {
				if (c.equals(superCorr.getSource())) {
					if (c.equals(c2t.getSource())) {
						if (t.equals(c2t.getTarget())) {
							if (c.getAttributes().contains(a)) {
								for (DBColumn col : t.getCols()) {
									for (DBSchema s : org.moflon.core.utilities.eMoflonEMFUtil
											.getOppositeReferenceTyped(t, DBSchema.class, "tables")) {
										if (s.getTables().contains(subTable)) {
											_result.add(new Object[] { s, t, col, superCorr, c, subTable, c2t, a });
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_2_3_findcontext_greenBBBBBBBBFFFFFFFFF(DBSchema s,
			DBTable t, DBColumn col, SuperClassToTable superCorr, CDClass c, DBTable subTable, ClassToTable c2t,
			CDAttribute a) {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		EMoflonEdge s__t____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s__subTable____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge superCorr__subTable____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge superCorr__c____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge c2t__c____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge c2t__t____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge c__a____attributes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge t__col____cols = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String s__t____tables_name_prime = "tables";
		String s__subTable____tables_name_prime = "tables";
		String superCorr__subTable____target_name_prime = "target";
		String superCorr__c____source_name_prime = "source";
		String c2t__c____source_name_prime = "source";
		String c2t__t____target_name_prime = "target";
		String c__a____attributes_name_prime = "attributes";
		String t__col____cols_name_prime = "cols";
		isApplicableMatch.getAllContextElements().add(s);
		isApplicableMatch.getAllContextElements().add(t);
		isApplicableMatch.getAllContextElements().add(col);
		isApplicableMatch.getAllContextElements().add(superCorr);
		isApplicableMatch.getAllContextElements().add(c);
		isApplicableMatch.getAllContextElements().add(subTable);
		isApplicableMatch.getAllContextElements().add(c2t);
		isApplicableMatch.getAllContextElements().add(a);
		s__t____tables.setSrc(s);
		s__t____tables.setTrg(t);
		isApplicableMatch.getAllContextElements().add(s__t____tables);
		s__subTable____tables.setSrc(s);
		s__subTable____tables.setTrg(subTable);
		isApplicableMatch.getAllContextElements().add(s__subTable____tables);
		superCorr__subTable____target.setSrc(superCorr);
		superCorr__subTable____target.setTrg(subTable);
		isApplicableMatch.getAllContextElements().add(superCorr__subTable____target);
		superCorr__c____source.setSrc(superCorr);
		superCorr__c____source.setTrg(c);
		isApplicableMatch.getAllContextElements().add(superCorr__c____source);
		c2t__c____source.setSrc(c2t);
		c2t__c____source.setTrg(c);
		isApplicableMatch.getAllContextElements().add(c2t__c____source);
		c2t__t____target.setSrc(c2t);
		c2t__t____target.setTrg(t);
		isApplicableMatch.getAllContextElements().add(c2t__t____target);
		c__a____attributes.setSrc(c);
		c__a____attributes.setTrg(a);
		isApplicableMatch.getAllContextElements().add(c__a____attributes);
		t__col____cols.setSrc(t);
		t__col____cols.setTrg(col);
		isApplicableMatch.getAllContextElements().add(t__col____cols);
		s__t____tables.setName(s__t____tables_name_prime);
		s__subTable____tables.setName(s__subTable____tables_name_prime);
		superCorr__subTable____target.setName(superCorr__subTable____target_name_prime);
		superCorr__c____source.setName(superCorr__c____source_name_prime);
		c2t__c____source.setName(c2t__c____source_name_prime);
		c2t__t____target.setName(c2t__t____target_name_prime);
		c__a____attributes.setName(c__a____attributes_name_prime);
		t__col____cols.setName(t__col____cols_name_prime);
		return new Object[] { s, t, col, superCorr, c, subTable, c2t, a, isApplicableMatch, s__t____tables,
				s__subTable____tables, superCorr__subTable____target, superCorr__c____source, c2t__c____source,
				c2t__t____target, c__a____attributes, t__col____cols };
	}

	public static final Object[] pattern_TransitiveAttributeRule_2_4_solveCSP_bindingFBBBBBBBBBB(
			TransitiveAttributeRule _this, IsApplicableMatch isApplicableMatch, DBSchema s, DBTable t, DBColumn col,
			SuperClassToTable superCorr, CDClass c, DBTable subTable, ClassToTable c2t, CDAttribute a) {
		CSP _localVariable_0 = _this.isApplicable_solveCsp_FWD(isApplicableMatch, s, t, col, superCorr, c, subTable,
				c2t, a);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, s, t, col, superCorr, c, subTable, c2t, a };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_2_4_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_TransitiveAttributeRule_2_4_solveCSP_bindingAndBlackFBBBBBBBBBB(
			TransitiveAttributeRule _this, IsApplicableMatch isApplicableMatch, DBSchema s, DBTable t, DBColumn col,
			SuperClassToTable superCorr, CDClass c, DBTable subTable, ClassToTable c2t, CDAttribute a) {
		Object[] result_pattern_TransitiveAttributeRule_2_4_solveCSP_binding = pattern_TransitiveAttributeRule_2_4_solveCSP_bindingFBBBBBBBBBB(
				_this, isApplicableMatch, s, t, col, superCorr, c, subTable, c2t, a);
		if (result_pattern_TransitiveAttributeRule_2_4_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_TransitiveAttributeRule_2_4_solveCSP_binding[0];

			Object[] result_pattern_TransitiveAttributeRule_2_4_solveCSP_black = pattern_TransitiveAttributeRule_2_4_solveCSP_blackB(
					csp);
			if (result_pattern_TransitiveAttributeRule_2_4_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, s, t, col, superCorr, c, subTable, c2t, a };
			}
		}
		return null;
	}

	public static final boolean pattern_TransitiveAttributeRule_2_5_checkCSP_expressionFBB(
			TransitiveAttributeRule _this, CSP csp) {
		boolean _localVariable_0 = _this.isApplicable_checkCsp_FWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_2_6_addmatchtoruleresult_blackBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final Object[] pattern_TransitiveAttributeRule_2_6_addmatchtoruleresult_greenBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		ruleresult.getIsApplicableMatch().add(isApplicableMatch);
		boolean ruleresult_success_prime = Boolean.valueOf(true);
		String isApplicableMatch_ruleName_prime = "TransitiveAttributeRule";
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		isApplicableMatch.setRuleName(isApplicableMatch_ruleName_prime);
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final IsApplicableRuleResult pattern_TransitiveAttributeRule_2_7_expressionFB(
			IsApplicableRuleResult ruleresult) {
		IsApplicableRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_10_1_initialbindings_blackBBBBBBB(
			TransitiveAttributeRule _this, Match match, DBSchema s, DBTable t, DBColumn col, DBColumn transCol,
			DBTable subTable) {
		if (!col.equals(transCol)) {
			if (!subTable.equals(t)) {
				return new Object[] { _this, match, s, t, col, transCol, subTable };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_10_2_SolveCSP_bindingFBBBBBBB(
			TransitiveAttributeRule _this, Match match, DBSchema s, DBTable t, DBColumn col, DBColumn transCol,
			DBTable subTable) {
		CSP _localVariable_0 = _this.isAppropriate_solveCsp_BWD(match, s, t, col, transCol, subTable);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, match, s, t, col, transCol, subTable };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_10_2_SolveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_TransitiveAttributeRule_10_2_SolveCSP_bindingAndBlackFBBBBBBB(
			TransitiveAttributeRule _this, Match match, DBSchema s, DBTable t, DBColumn col, DBColumn transCol,
			DBTable subTable) {
		Object[] result_pattern_TransitiveAttributeRule_10_2_SolveCSP_binding = pattern_TransitiveAttributeRule_10_2_SolveCSP_bindingFBBBBBBB(
				_this, match, s, t, col, transCol, subTable);
		if (result_pattern_TransitiveAttributeRule_10_2_SolveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_TransitiveAttributeRule_10_2_SolveCSP_binding[0];

			Object[] result_pattern_TransitiveAttributeRule_10_2_SolveCSP_black = pattern_TransitiveAttributeRule_10_2_SolveCSP_blackB(
					csp);
			if (result_pattern_TransitiveAttributeRule_10_2_SolveCSP_black != null) {

				return new Object[] { csp, _this, match, s, t, col, transCol, subTable };
			}
		}
		return null;
	}

	public static final boolean pattern_TransitiveAttributeRule_10_3_CheckCSP_expressionFBB(
			TransitiveAttributeRule _this, CSP csp) {
		boolean _localVariable_0 = _this.isAppropriate_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_10_4_collectelementstobetranslated_blackBBBBBB(
			Match match, DBSchema s, DBTable t, DBColumn col, DBColumn transCol, DBTable subTable) {
		if (!col.equals(transCol)) {
			if (!subTable.equals(t)) {
				return new Object[] { match, s, t, col, transCol, subTable };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_10_4_collectelementstobetranslated_greenBBBF(
			Match match, DBColumn transCol, DBTable subTable) {
		EMoflonEdge subTable__transCol____cols = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getToBeTranslatedNodes().add(transCol);
		String subTable__transCol____cols_name_prime = "cols";
		subTable__transCol____cols.setSrc(subTable);
		subTable__transCol____cols.setTrg(transCol);
		match.getToBeTranslatedEdges().add(subTable__transCol____cols);
		subTable__transCol____cols.setName(subTable__transCol____cols_name_prime);
		return new Object[] { match, transCol, subTable, subTable__transCol____cols };
	}

	public static final Object[] pattern_TransitiveAttributeRule_10_5_collectcontextelements_blackBBBBBB(Match match,
			DBSchema s, DBTable t, DBColumn col, DBColumn transCol, DBTable subTable) {
		if (!col.equals(transCol)) {
			if (!subTable.equals(t)) {
				return new Object[] { match, s, t, col, transCol, subTable };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_10_5_collectcontextelements_greenBBBBBFFF(Match match,
			DBSchema s, DBTable t, DBColumn col, DBTable subTable) {
		EMoflonEdge s__t____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s__subTable____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge t__col____cols = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getContextNodes().add(s);
		match.getContextNodes().add(t);
		match.getContextNodes().add(col);
		match.getContextNodes().add(subTable);
		String s__t____tables_name_prime = "tables";
		String s__subTable____tables_name_prime = "tables";
		String t__col____cols_name_prime = "cols";
		s__t____tables.setSrc(s);
		s__t____tables.setTrg(t);
		match.getContextEdges().add(s__t____tables);
		s__subTable____tables.setSrc(s);
		s__subTable____tables.setTrg(subTable);
		match.getContextEdges().add(s__subTable____tables);
		t__col____cols.setSrc(t);
		t__col____cols.setTrg(col);
		match.getContextEdges().add(t__col____cols);
		s__t____tables.setName(s__t____tables_name_prime);
		s__subTable____tables.setName(s__subTable____tables_name_prime);
		t__col____cols.setName(t__col____cols_name_prime);
		return new Object[] { match, s, t, col, subTable, s__t____tables, s__subTable____tables, t__col____cols };
	}

	public static final void pattern_TransitiveAttributeRule_10_6_registerobjectstomatch_expressionBBBBBBB(
			TransitiveAttributeRule _this, Match match, DBSchema s, DBTable t, DBColumn col, DBColumn transCol,
			DBTable subTable) {
		_this.registerObjectsToMatch_BWD(match, s, t, col, transCol, subTable);

	}

	public static final boolean pattern_TransitiveAttributeRule_10_7_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_TransitiveAttributeRule_10_8_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_11_1_performtransformation_bindingFFFFFFFFFB(
			IsApplicableMatch isApplicableMatch) {
		EObject _localVariable_0 = isApplicableMatch.getObject("s");
		EObject _localVariable_1 = isApplicableMatch.getObject("t");
		EObject _localVariable_2 = isApplicableMatch.getObject("col");
		EObject _localVariable_3 = isApplicableMatch.getObject("superCorr");
		EObject _localVariable_4 = isApplicableMatch.getObject("c");
		EObject _localVariable_5 = isApplicableMatch.getObject("transCol");
		EObject _localVariable_6 = isApplicableMatch.getObject("subTable");
		EObject _localVariable_7 = isApplicableMatch.getObject("c2t");
		EObject _localVariable_8 = isApplicableMatch.getObject("a");
		EObject tmpS = _localVariable_0;
		EObject tmpT = _localVariable_1;
		EObject tmpCol = _localVariable_2;
		EObject tmpSuperCorr = _localVariable_3;
		EObject tmpC = _localVariable_4;
		EObject tmpTransCol = _localVariable_5;
		EObject tmpSubTable = _localVariable_6;
		EObject tmpC2t = _localVariable_7;
		EObject tmpA = _localVariable_8;
		if (tmpS instanceof DBSchema) {
			DBSchema s = (DBSchema) tmpS;
			if (tmpT instanceof DBTable) {
				DBTable t = (DBTable) tmpT;
				if (tmpCol instanceof DBColumn) {
					DBColumn col = (DBColumn) tmpCol;
					if (tmpSuperCorr instanceof SuperClassToTable) {
						SuperClassToTable superCorr = (SuperClassToTable) tmpSuperCorr;
						if (tmpC instanceof CDClass) {
							CDClass c = (CDClass) tmpC;
							if (tmpTransCol instanceof DBColumn) {
								DBColumn transCol = (DBColumn) tmpTransCol;
								if (tmpSubTable instanceof DBTable) {
									DBTable subTable = (DBTable) tmpSubTable;
									if (tmpC2t instanceof ClassToTable) {
										ClassToTable c2t = (ClassToTable) tmpC2t;
										if (tmpA instanceof CDAttribute) {
											CDAttribute a = (CDAttribute) tmpA;
											return new Object[] { s, t, col, superCorr, c, transCol, subTable, c2t, a,
													isApplicableMatch };
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_11_1_performtransformation_blackBBBBBBBBBFBB(
			DBSchema s, DBTable t, DBColumn col, SuperClassToTable superCorr, CDClass c, DBColumn transCol,
			DBTable subTable, ClassToTable c2t, CDAttribute a, TransitiveAttributeRule _this,
			IsApplicableMatch isApplicableMatch) {
		if (!col.equals(transCol)) {
			if (!subTable.equals(t)) {
				for (EObject tmpCsp : isApplicableMatch.getAttributeInfo()) {
					if (tmpCsp instanceof CSP) {
						CSP csp = (CSP) tmpCsp;
						return new Object[] { s, t, col, superCorr, c, transCol, subTable, c2t, a, csp, _this,
								isApplicableMatch };
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_11_1_performtransformation_bindingAndBlackFFFFFFFFFFBB(
			TransitiveAttributeRule _this, IsApplicableMatch isApplicableMatch) {
		Object[] result_pattern_TransitiveAttributeRule_11_1_performtransformation_binding = pattern_TransitiveAttributeRule_11_1_performtransformation_bindingFFFFFFFFFB(
				isApplicableMatch);
		if (result_pattern_TransitiveAttributeRule_11_1_performtransformation_binding != null) {
			DBSchema s = (DBSchema) result_pattern_TransitiveAttributeRule_11_1_performtransformation_binding[0];
			DBTable t = (DBTable) result_pattern_TransitiveAttributeRule_11_1_performtransformation_binding[1];
			DBColumn col = (DBColumn) result_pattern_TransitiveAttributeRule_11_1_performtransformation_binding[2];
			SuperClassToTable superCorr = (SuperClassToTable) result_pattern_TransitiveAttributeRule_11_1_performtransformation_binding[3];
			CDClass c = (CDClass) result_pattern_TransitiveAttributeRule_11_1_performtransformation_binding[4];
			DBColumn transCol = (DBColumn) result_pattern_TransitiveAttributeRule_11_1_performtransformation_binding[5];
			DBTable subTable = (DBTable) result_pattern_TransitiveAttributeRule_11_1_performtransformation_binding[6];
			ClassToTable c2t = (ClassToTable) result_pattern_TransitiveAttributeRule_11_1_performtransformation_binding[7];
			CDAttribute a = (CDAttribute) result_pattern_TransitiveAttributeRule_11_1_performtransformation_binding[8];

			Object[] result_pattern_TransitiveAttributeRule_11_1_performtransformation_black = pattern_TransitiveAttributeRule_11_1_performtransformation_blackBBBBBBBBBFBB(
					s, t, col, superCorr, c, transCol, subTable, c2t, a, _this, isApplicableMatch);
			if (result_pattern_TransitiveAttributeRule_11_1_performtransformation_black != null) {
				CSP csp = (CSP) result_pattern_TransitiveAttributeRule_11_1_performtransformation_black[9];

				return new Object[] { s, t, col, superCorr, c, transCol, subTable, c2t, a, csp, _this,
						isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_11_2_collecttranslatedelements_blackB(
			DBColumn transCol) {
		return new Object[] { transCol };
	}

	public static final Object[] pattern_TransitiveAttributeRule_11_2_collecttranslatedelements_greenFB(
			DBColumn transCol) {
		PerformRuleResult ruleresult = RuntimeFactory.eINSTANCE.createPerformRuleResult();
		ruleresult.getTranslatedElements().add(transCol);
		return new Object[] { ruleresult, transCol };
	}

	public static final Object[] pattern_TransitiveAttributeRule_11_3_bookkeepingforedges_blackBBBBBBBBBB(
			PerformRuleResult ruleresult, EObject s, EObject t, EObject col, EObject superCorr, EObject c,
			EObject transCol, EObject subTable, EObject c2t, EObject a) {
		if (!s.equals(t)) {
			if (!s.equals(superCorr)) {
				if (!s.equals(transCol)) {
					if (!s.equals(subTable)) {
						if (!t.equals(transCol)) {
							if (!col.equals(s)) {
								if (!col.equals(t)) {
									if (!col.equals(superCorr)) {
										if (!col.equals(transCol)) {
											if (!col.equals(subTable)) {
												if (!superCorr.equals(t)) {
													if (!superCorr.equals(transCol)) {
														if (!c.equals(s)) {
															if (!c.equals(t)) {
																if (!c.equals(col)) {
																	if (!c.equals(superCorr)) {
																		if (!c.equals(transCol)) {
																			if (!c.equals(subTable)) {
																				if (!c.equals(c2t)) {
																					if (!subTable.equals(t)) {
																						if (!subTable
																								.equals(superCorr)) {
																							if (!subTable
																									.equals(transCol)) {
																								if (!c2t.equals(s)) {
																									if (!c2t.equals(
																											t)) {
																										if (!c2t.equals(
																												col)) {
																											if (!c2t.equals(
																													superCorr)) {
																												if (!c2t.equals(
																														transCol)) {
																													if (!c2t.equals(
																															subTable)) {
																														if (!a.equals(
																																s)) {
																															if (!a.equals(
																																	t)) {
																																if (!a.equals(
																																		col)) {
																																	if (!a.equals(
																																			superCorr)) {
																																		if (!a.equals(
																																				c)) {
																																			if (!a.equals(
																																					transCol)) {
																																				if (!a.equals(
																																						subTable)) {
																																					if (!a.equals(
																																							c2t)) {
																																						return new Object[] {
																																								ruleresult,
																																								s,
																																								t,
																																								col,
																																								superCorr,
																																								c,
																																								transCol,
																																								subTable,
																																								c2t,
																																								a };
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_11_3_bookkeepingforedges_greenBBBF(
			PerformRuleResult ruleresult, EObject transCol, EObject subTable) {
		EMoflonEdge subTable__transCol____cols = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String ruleresult_ruleName_prime = "TransitiveAttributeRule";
		String subTable__transCol____cols_name_prime = "cols";
		subTable__transCol____cols.setSrc(subTable);
		subTable__transCol____cols.setTrg(transCol);
		ruleresult.getTranslatedEdges().add(subTable__transCol____cols);
		ruleresult.setRuleName(ruleresult_ruleName_prime);
		subTable__transCol____cols.setName(subTable__transCol____cols_name_prime);
		return new Object[] { ruleresult, transCol, subTable, subTable__transCol____cols };
	}

	public static final void pattern_TransitiveAttributeRule_11_5_registerobjects_expressionBBBBBBBBBBB(
			TransitiveAttributeRule _this, PerformRuleResult ruleresult, EObject s, EObject t, EObject col,
			EObject superCorr, EObject c, EObject transCol, EObject subTable, EObject c2t, EObject a) {
		_this.registerObjects_BWD(ruleresult, s, t, col, superCorr, c, transCol, subTable, c2t, a);

	}

	public static final PerformRuleResult pattern_TransitiveAttributeRule_11_6_expressionFB(
			PerformRuleResult ruleresult) {
		PerformRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_12_1_preparereturnvalue_bindingFB(
			TransitiveAttributeRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass eClass = _localVariable_0;
		if (eClass != null) {
			return new Object[] { eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_12_1_preparereturnvalue_blackFBB(EClass eClass,
			TransitiveAttributeRule _this) {
		for (EOperation performOperation : eClass.getEOperations()) {
			String performOperation_name = performOperation.getName();
			if (performOperation_name.equals("perform_BWD")) {
				return new Object[] { performOperation, eClass, _this };
			}

		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_12_1_preparereturnvalue_bindingAndBlackFFB(
			TransitiveAttributeRule _this) {
		Object[] result_pattern_TransitiveAttributeRule_12_1_preparereturnvalue_binding = pattern_TransitiveAttributeRule_12_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_TransitiveAttributeRule_12_1_preparereturnvalue_binding != null) {
			EClass eClass = (EClass) result_pattern_TransitiveAttributeRule_12_1_preparereturnvalue_binding[0];

			Object[] result_pattern_TransitiveAttributeRule_12_1_preparereturnvalue_black = pattern_TransitiveAttributeRule_12_1_preparereturnvalue_blackFBB(
					eClass, _this);
			if (result_pattern_TransitiveAttributeRule_12_1_preparereturnvalue_black != null) {
				EOperation performOperation = (EOperation) result_pattern_TransitiveAttributeRule_12_1_preparereturnvalue_black[0];

				return new Object[] { performOperation, eClass, _this };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_12_1_preparereturnvalue_greenBF(
			EOperation performOperation) {
		IsApplicableRuleResult ruleresult = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		boolean ruleresult_success_prime = Boolean.valueOf(false);
		String ruleresult_rule_prime = "TransitiveAttributeRule";
		ruleresult.setPerformOperation(performOperation);
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		ruleresult.setRule(ruleresult_rule_prime);
		return new Object[] { performOperation, ruleresult };
	}

	public static final Object[] pattern_TransitiveAttributeRule_12_2_corematch_bindingFFFFFB(Match match) {
		EObject _localVariable_0 = match.getObject("s");
		EObject _localVariable_1 = match.getObject("t");
		EObject _localVariable_2 = match.getObject("col");
		EObject _localVariable_3 = match.getObject("transCol");
		EObject _localVariable_4 = match.getObject("subTable");
		EObject tmpS = _localVariable_0;
		EObject tmpT = _localVariable_1;
		EObject tmpCol = _localVariable_2;
		EObject tmpTransCol = _localVariable_3;
		EObject tmpSubTable = _localVariable_4;
		if (tmpS instanceof DBSchema) {
			DBSchema s = (DBSchema) tmpS;
			if (tmpT instanceof DBTable) {
				DBTable t = (DBTable) tmpT;
				if (tmpCol instanceof DBColumn) {
					DBColumn col = (DBColumn) tmpCol;
					if (tmpTransCol instanceof DBColumn) {
						DBColumn transCol = (DBColumn) tmpTransCol;
						if (tmpSubTable instanceof DBTable) {
							DBTable subTable = (DBTable) tmpSubTable;
							return new Object[] { s, t, col, transCol, subTable, match };
						}
					}
				}
			}
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_TransitiveAttributeRule_12_2_corematch_blackBBBFFBBFB(DBSchema s,
			DBTable t, DBColumn col, DBColumn transCol, DBTable subTable, Match match) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!col.equals(transCol)) {
			if (!subTable.equals(t)) {
				for (SuperClassToTable superCorr : org.moflon.core.utilities.eMoflonEMFUtil
						.getOppositeReferenceTyped(subTable, SuperClassToTable.class, "target")) {
					CDClass c = superCorr.getSource();
					if (c != null) {
						for (ClassToTable c2t : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(t,
								ClassToTable.class, "target")) {
							if (c.equals(c2t.getSource())) {
								_result.add(new Object[] { s, t, col, superCorr, c, transCol, subTable, c2t, match });
							}
						}
					}

				}
			}
		}
		return _result;
	}

	public static final Iterable<Object[]> pattern_TransitiveAttributeRule_12_3_findcontext_blackBBBBBBBBF(DBSchema s,
			DBTable t, DBColumn col, SuperClassToTable superCorr, CDClass c, DBColumn transCol, DBTable subTable,
			ClassToTable c2t) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!col.equals(transCol)) {
			if (!subTable.equals(t)) {
				if (s.getTables().contains(t)) {
					if (s.getTables().contains(subTable)) {
						if (subTable.equals(superCorr.getTarget())) {
							if (subTable.getCols().contains(transCol)) {
								if (c.equals(superCorr.getSource())) {
									if (c.equals(c2t.getSource())) {
										if (t.equals(c2t.getTarget())) {
											if (t.getCols().contains(col)) {
												for (CDAttribute a : c.getAttributes()) {
													_result.add(new Object[] { s, t, col, superCorr, c, transCol,
															subTable, c2t, a });
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_12_3_findcontext_greenBBBBBBBBBFFFFFFFFFF(DBSchema s,
			DBTable t, DBColumn col, SuperClassToTable superCorr, CDClass c, DBColumn transCol, DBTable subTable,
			ClassToTable c2t, CDAttribute a) {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		EMoflonEdge s__t____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s__subTable____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge superCorr__subTable____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge subTable__transCol____cols = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge superCorr__c____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge c2t__c____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge c2t__t____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge c__a____attributes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge t__col____cols = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String s__t____tables_name_prime = "tables";
		String s__subTable____tables_name_prime = "tables";
		String superCorr__subTable____target_name_prime = "target";
		String subTable__transCol____cols_name_prime = "cols";
		String superCorr__c____source_name_prime = "source";
		String c2t__c____source_name_prime = "source";
		String c2t__t____target_name_prime = "target";
		String c__a____attributes_name_prime = "attributes";
		String t__col____cols_name_prime = "cols";
		isApplicableMatch.getAllContextElements().add(s);
		isApplicableMatch.getAllContextElements().add(t);
		isApplicableMatch.getAllContextElements().add(col);
		isApplicableMatch.getAllContextElements().add(superCorr);
		isApplicableMatch.getAllContextElements().add(c);
		isApplicableMatch.getAllContextElements().add(transCol);
		isApplicableMatch.getAllContextElements().add(subTable);
		isApplicableMatch.getAllContextElements().add(c2t);
		isApplicableMatch.getAllContextElements().add(a);
		s__t____tables.setSrc(s);
		s__t____tables.setTrg(t);
		isApplicableMatch.getAllContextElements().add(s__t____tables);
		s__subTable____tables.setSrc(s);
		s__subTable____tables.setTrg(subTable);
		isApplicableMatch.getAllContextElements().add(s__subTable____tables);
		superCorr__subTable____target.setSrc(superCorr);
		superCorr__subTable____target.setTrg(subTable);
		isApplicableMatch.getAllContextElements().add(superCorr__subTable____target);
		subTable__transCol____cols.setSrc(subTable);
		subTable__transCol____cols.setTrg(transCol);
		isApplicableMatch.getAllContextElements().add(subTable__transCol____cols);
		superCorr__c____source.setSrc(superCorr);
		superCorr__c____source.setTrg(c);
		isApplicableMatch.getAllContextElements().add(superCorr__c____source);
		c2t__c____source.setSrc(c2t);
		c2t__c____source.setTrg(c);
		isApplicableMatch.getAllContextElements().add(c2t__c____source);
		c2t__t____target.setSrc(c2t);
		c2t__t____target.setTrg(t);
		isApplicableMatch.getAllContextElements().add(c2t__t____target);
		c__a____attributes.setSrc(c);
		c__a____attributes.setTrg(a);
		isApplicableMatch.getAllContextElements().add(c__a____attributes);
		t__col____cols.setSrc(t);
		t__col____cols.setTrg(col);
		isApplicableMatch.getAllContextElements().add(t__col____cols);
		s__t____tables.setName(s__t____tables_name_prime);
		s__subTable____tables.setName(s__subTable____tables_name_prime);
		superCorr__subTable____target.setName(superCorr__subTable____target_name_prime);
		subTable__transCol____cols.setName(subTable__transCol____cols_name_prime);
		superCorr__c____source.setName(superCorr__c____source_name_prime);
		c2t__c____source.setName(c2t__c____source_name_prime);
		c2t__t____target.setName(c2t__t____target_name_prime);
		c__a____attributes.setName(c__a____attributes_name_prime);
		t__col____cols.setName(t__col____cols_name_prime);
		return new Object[] { s, t, col, superCorr, c, transCol, subTable, c2t, a, isApplicableMatch, s__t____tables,
				s__subTable____tables, superCorr__subTable____target, subTable__transCol____cols,
				superCorr__c____source, c2t__c____source, c2t__t____target, c__a____attributes, t__col____cols };
	}

	public static final Object[] pattern_TransitiveAttributeRule_12_4_solveCSP_bindingFBBBBBBBBBBB(
			TransitiveAttributeRule _this, IsApplicableMatch isApplicableMatch, DBSchema s, DBTable t, DBColumn col,
			SuperClassToTable superCorr, CDClass c, DBColumn transCol, DBTable subTable, ClassToTable c2t,
			CDAttribute a) {
		CSP _localVariable_0 = _this.isApplicable_solveCsp_BWD(isApplicableMatch, s, t, col, superCorr, c, transCol,
				subTable, c2t, a);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, s, t, col, superCorr, c, transCol, subTable, c2t, a };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_12_4_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_TransitiveAttributeRule_12_4_solveCSP_bindingAndBlackFBBBBBBBBBBB(
			TransitiveAttributeRule _this, IsApplicableMatch isApplicableMatch, DBSchema s, DBTable t, DBColumn col,
			SuperClassToTable superCorr, CDClass c, DBColumn transCol, DBTable subTable, ClassToTable c2t,
			CDAttribute a) {
		Object[] result_pattern_TransitiveAttributeRule_12_4_solveCSP_binding = pattern_TransitiveAttributeRule_12_4_solveCSP_bindingFBBBBBBBBBBB(
				_this, isApplicableMatch, s, t, col, superCorr, c, transCol, subTable, c2t, a);
		if (result_pattern_TransitiveAttributeRule_12_4_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_TransitiveAttributeRule_12_4_solveCSP_binding[0];

			Object[] result_pattern_TransitiveAttributeRule_12_4_solveCSP_black = pattern_TransitiveAttributeRule_12_4_solveCSP_blackB(
					csp);
			if (result_pattern_TransitiveAttributeRule_12_4_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, s, t, col, superCorr, c, transCol, subTable, c2t,
						a };
			}
		}
		return null;
	}

	public static final boolean pattern_TransitiveAttributeRule_12_5_checkCSP_expressionFBB(
			TransitiveAttributeRule _this, CSP csp) {
		boolean _localVariable_0 = _this.isApplicable_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_12_6_addmatchtoruleresult_blackBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final Object[] pattern_TransitiveAttributeRule_12_6_addmatchtoruleresult_greenBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		ruleresult.getIsApplicableMatch().add(isApplicableMatch);
		boolean ruleresult_success_prime = Boolean.valueOf(true);
		String isApplicableMatch_ruleName_prime = "TransitiveAttributeRule";
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		isApplicableMatch.setRuleName(isApplicableMatch_ruleName_prime);
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final IsApplicableRuleResult pattern_TransitiveAttributeRule_12_7_expressionFB(
			IsApplicableRuleResult ruleresult) {
		IsApplicableRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_20_1_preparereturnvalue_bindingFB(
			TransitiveAttributeRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass __eClass = _localVariable_0;
		if (__eClass != null) {
			return new Object[] { __eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_20_1_preparereturnvalue_blackFBBF(EClass __eClass,
			TransitiveAttributeRule _this) {
		for (EOperation __performOperation : __eClass.getEOperations()) {
			String __performOperation_name = __performOperation.getName();
			if (__performOperation_name.equals("isApplicable_FWD")) {
				for (EOperation isApplicableCC : __eClass.getEOperations()) {
					if (!__performOperation.equals(isApplicableCC)) {
						String isApplicableCC_name = isApplicableCC.getName();
						if (isApplicableCC_name.equals("isApplicable_CC")) {
							return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
						}

					}
				}
			}

		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_20_1_preparereturnvalue_bindingAndBlackFFBF(
			TransitiveAttributeRule _this) {
		Object[] result_pattern_TransitiveAttributeRule_20_1_preparereturnvalue_binding = pattern_TransitiveAttributeRule_20_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_TransitiveAttributeRule_20_1_preparereturnvalue_binding != null) {
			EClass __eClass = (EClass) result_pattern_TransitiveAttributeRule_20_1_preparereturnvalue_binding[0];

			Object[] result_pattern_TransitiveAttributeRule_20_1_preparereturnvalue_black = pattern_TransitiveAttributeRule_20_1_preparereturnvalue_blackFBBF(
					__eClass, _this);
			if (result_pattern_TransitiveAttributeRule_20_1_preparereturnvalue_black != null) {
				EOperation __performOperation = (EOperation) result_pattern_TransitiveAttributeRule_20_1_preparereturnvalue_black[0];
				EOperation isApplicableCC = (EOperation) result_pattern_TransitiveAttributeRule_20_1_preparereturnvalue_black[3];

				return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_20_1_preparereturnvalue_greenF() {
		EObjectContainer __result = RuntimeFactory.eINSTANCE.createEObjectContainer();
		return new Object[] { __result };
	}

	public static final Iterable<Object[]> pattern_TransitiveAttributeRule_20_2_testcorematchandDECs_blackFFB(
			EMoflonEdge _edge_attributes) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		EObject tmpC = _edge_attributes.getSrc();
		if (tmpC instanceof CDClass) {
			CDClass c = (CDClass) tmpC;
			EObject tmpA = _edge_attributes.getTrg();
			if (tmpA instanceof CDAttribute) {
				CDAttribute a = (CDAttribute) tmpA;
				if (c.getAttributes().contains(a)) {
					_result.add(new Object[] { c, a, _edge_attributes });
				}
			}

		}

		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_20_2_testcorematchandDECs_greenFB(EClass __eClass) {
		Match match = RuntimeFactory.eINSTANCE.createMatch();
		String __eClass_name = __eClass.getName();
		String match_ruleName_prime = __eClass_name;
		match.setRuleName(match_ruleName_prime);
		return new Object[] { match, __eClass };

	}

	public static final boolean pattern_TransitiveAttributeRule_20_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBB(
			TransitiveAttributeRule _this, Match match, CDClass c, CDAttribute a) {
		boolean _localVariable_0 = _this.isAppropriate_FWD(match, c, a);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final boolean pattern_TransitiveAttributeRule_20_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
			TransitiveAttributeRule _this, Match match) {
		boolean _localVariable_0 = _this.checkTypes_FWD(match);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_20_5_Addmatchtoruleresult_blackBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		if (!__performOperation.equals(isApplicableCC)) {
			return new Object[] { match, __performOperation, __result, isApplicableCC };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_20_5_Addmatchtoruleresult_greenBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		__result.getContents().add(match);
		match.setIsApplicableOperation(__performOperation);
		match.setIsApplicableCCOperation(isApplicableCC);
		return new Object[] { match, __performOperation, __result, isApplicableCC };
	}

	public static final EObjectContainer pattern_TransitiveAttributeRule_20_6_expressionFB(EObjectContainer __result) {
		EObjectContainer _result = __result;
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_21_1_preparereturnvalue_bindingFB(
			TransitiveAttributeRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass __eClass = _localVariable_0;
		if (__eClass != null) {
			return new Object[] { __eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_21_1_preparereturnvalue_blackFBBF(EClass __eClass,
			TransitiveAttributeRule _this) {
		for (EOperation __performOperation : __eClass.getEOperations()) {
			String __performOperation_name = __performOperation.getName();
			if (__performOperation_name.equals("isApplicable_BWD")) {
				for (EOperation isApplicableCC : __eClass.getEOperations()) {
					if (!__performOperation.equals(isApplicableCC)) {
						String isApplicableCC_name = isApplicableCC.getName();
						if (isApplicableCC_name.equals("isApplicable_CC")) {
							return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
						}

					}
				}
			}

		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_21_1_preparereturnvalue_bindingAndBlackFFBF(
			TransitiveAttributeRule _this) {
		Object[] result_pattern_TransitiveAttributeRule_21_1_preparereturnvalue_binding = pattern_TransitiveAttributeRule_21_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_TransitiveAttributeRule_21_1_preparereturnvalue_binding != null) {
			EClass __eClass = (EClass) result_pattern_TransitiveAttributeRule_21_1_preparereturnvalue_binding[0];

			Object[] result_pattern_TransitiveAttributeRule_21_1_preparereturnvalue_black = pattern_TransitiveAttributeRule_21_1_preparereturnvalue_blackFBBF(
					__eClass, _this);
			if (result_pattern_TransitiveAttributeRule_21_1_preparereturnvalue_black != null) {
				EOperation __performOperation = (EOperation) result_pattern_TransitiveAttributeRule_21_1_preparereturnvalue_black[0];
				EOperation isApplicableCC = (EOperation) result_pattern_TransitiveAttributeRule_21_1_preparereturnvalue_black[3];

				return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_21_1_preparereturnvalue_greenF() {
		EObjectContainer __result = RuntimeFactory.eINSTANCE.createEObjectContainer();
		return new Object[] { __result };
	}

	public static final Iterable<Object[]> pattern_TransitiveAttributeRule_21_2_testcorematchandDECs_blackFFFFFB(
			EMoflonEdge _edge_cols) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		EObject tmpSubTable = _edge_cols.getSrc();
		if (tmpSubTable instanceof DBTable) {
			DBTable subTable = (DBTable) tmpSubTable;
			EObject tmpTransCol = _edge_cols.getTrg();
			if (tmpTransCol instanceof DBColumn) {
				DBColumn transCol = (DBColumn) tmpTransCol;
				if (subTable.getCols().contains(transCol)) {
					for (DBSchema s : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(subTable,
							DBSchema.class, "tables")) {
						for (EObject tmpT : s.getTables()) {
							if (tmpT instanceof DBTable) {
								DBTable t = (DBTable) tmpT;
								if (!subTable.equals(t)) {
									for (DBColumn col : t.getCols()) {
										if (!col.equals(transCol)) {
											_result.add(new Object[] { s, t, col, transCol, subTable, _edge_cols });
										}
									}
								}
							}
						}
					}
				}
			}

		}

		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_21_2_testcorematchandDECs_greenFB(EClass __eClass) {
		Match match = RuntimeFactory.eINSTANCE.createMatch();
		String __eClass_name = __eClass.getName();
		String match_ruleName_prime = __eClass_name;
		match.setRuleName(match_ruleName_prime);
		return new Object[] { match, __eClass };

	}

	public static final boolean pattern_TransitiveAttributeRule_21_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBBBBB(
			TransitiveAttributeRule _this, Match match, DBSchema s, DBTable t, DBColumn col, DBColumn transCol,
			DBTable subTable) {
		boolean _localVariable_0 = _this.isAppropriate_BWD(match, s, t, col, transCol, subTable);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final boolean pattern_TransitiveAttributeRule_21_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
			TransitiveAttributeRule _this, Match match) {
		boolean _localVariable_0 = _this.checkTypes_BWD(match);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_21_5_Addmatchtoruleresult_blackBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		if (!__performOperation.equals(isApplicableCC)) {
			return new Object[] { match, __performOperation, __result, isApplicableCC };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_21_5_Addmatchtoruleresult_greenBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		__result.getContents().add(match);
		match.setIsApplicableOperation(__performOperation);
		match.setIsApplicableCCOperation(isApplicableCC);
		return new Object[] { match, __performOperation, __result, isApplicableCC };
	}

	public static final EObjectContainer pattern_TransitiveAttributeRule_21_6_expressionFB(EObjectContainer __result) {
		EObjectContainer _result = __result;
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_24_1_prepare_blackB(TransitiveAttributeRule _this) {
		return new Object[] { _this };
	}

	public static final Object[] pattern_TransitiveAttributeRule_24_1_prepare_greenF() {
		IsApplicableRuleResult result = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		return new Object[] { result };
	}

	public static final Object[] pattern_TransitiveAttributeRule_24_2_matchsrctrgcontext_bindingFFFFFFFBB(
			Match targetMatch, Match sourceMatch) {
		EObject _localVariable_0 = targetMatch.getObject("s");
		EObject _localVariable_1 = targetMatch.getObject("t");
		EObject _localVariable_2 = targetMatch.getObject("col");
		EObject _localVariable_3 = sourceMatch.getObject("c");
		EObject _localVariable_4 = targetMatch.getObject("transCol");
		EObject _localVariable_5 = targetMatch.getObject("subTable");
		EObject _localVariable_6 = sourceMatch.getObject("a");
		EObject tmpS = _localVariable_0;
		EObject tmpT = _localVariable_1;
		EObject tmpCol = _localVariable_2;
		EObject tmpC = _localVariable_3;
		EObject tmpTransCol = _localVariable_4;
		EObject tmpSubTable = _localVariable_5;
		EObject tmpA = _localVariable_6;
		if (tmpS instanceof DBSchema) {
			DBSchema s = (DBSchema) tmpS;
			if (tmpT instanceof DBTable) {
				DBTable t = (DBTable) tmpT;
				if (tmpCol instanceof DBColumn) {
					DBColumn col = (DBColumn) tmpCol;
					if (tmpC instanceof CDClass) {
						CDClass c = (CDClass) tmpC;
						if (tmpTransCol instanceof DBColumn) {
							DBColumn transCol = (DBColumn) tmpTransCol;
							if (tmpSubTable instanceof DBTable) {
								DBTable subTable = (DBTable) tmpSubTable;
								if (tmpA instanceof CDAttribute) {
									CDAttribute a = (CDAttribute) tmpA;
									return new Object[] { s, t, col, c, transCol, subTable, a, targetMatch,
											sourceMatch };
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_24_2_matchsrctrgcontext_blackBBBBBBBBB(DBSchema s,
			DBTable t, DBColumn col, CDClass c, DBColumn transCol, DBTable subTable, CDAttribute a, Match sourceMatch,
			Match targetMatch) {
		if (!col.equals(transCol)) {
			if (!subTable.equals(t)) {
				if (!sourceMatch.equals(targetMatch)) {
					return new Object[] { s, t, col, c, transCol, subTable, a, sourceMatch, targetMatch };
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_24_2_matchsrctrgcontext_bindingAndBlackFFFFFFFBB(
			Match sourceMatch, Match targetMatch) {
		Object[] result_pattern_TransitiveAttributeRule_24_2_matchsrctrgcontext_binding = pattern_TransitiveAttributeRule_24_2_matchsrctrgcontext_bindingFFFFFFFBB(
				targetMatch, sourceMatch);
		if (result_pattern_TransitiveAttributeRule_24_2_matchsrctrgcontext_binding != null) {
			DBSchema s = (DBSchema) result_pattern_TransitiveAttributeRule_24_2_matchsrctrgcontext_binding[0];
			DBTable t = (DBTable) result_pattern_TransitiveAttributeRule_24_2_matchsrctrgcontext_binding[1];
			DBColumn col = (DBColumn) result_pattern_TransitiveAttributeRule_24_2_matchsrctrgcontext_binding[2];
			CDClass c = (CDClass) result_pattern_TransitiveAttributeRule_24_2_matchsrctrgcontext_binding[3];
			DBColumn transCol = (DBColumn) result_pattern_TransitiveAttributeRule_24_2_matchsrctrgcontext_binding[4];
			DBTable subTable = (DBTable) result_pattern_TransitiveAttributeRule_24_2_matchsrctrgcontext_binding[5];
			CDAttribute a = (CDAttribute) result_pattern_TransitiveAttributeRule_24_2_matchsrctrgcontext_binding[6];

			Object[] result_pattern_TransitiveAttributeRule_24_2_matchsrctrgcontext_black = pattern_TransitiveAttributeRule_24_2_matchsrctrgcontext_blackBBBBBBBBB(
					s, t, col, c, transCol, subTable, a, sourceMatch, targetMatch);
			if (result_pattern_TransitiveAttributeRule_24_2_matchsrctrgcontext_black != null) {

				return new Object[] { s, t, col, c, transCol, subTable, a, sourceMatch, targetMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_24_3_solvecsp_bindingFBBBBBBBBBB(
			TransitiveAttributeRule _this, DBSchema s, DBTable t, DBColumn col, CDClass c, DBColumn transCol,
			DBTable subTable, CDAttribute a, Match sourceMatch, Match targetMatch) {
		CSP _localVariable_7 = _this.isApplicable_solveCsp_CC(s, t, col, c, transCol, subTable, a, sourceMatch,
				targetMatch);
		CSP csp = _localVariable_7;
		if (csp != null) {
			return new Object[] { csp, _this, s, t, col, c, transCol, subTable, a, sourceMatch, targetMatch };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_24_3_solvecsp_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_TransitiveAttributeRule_24_3_solvecsp_bindingAndBlackFBBBBBBBBBB(
			TransitiveAttributeRule _this, DBSchema s, DBTable t, DBColumn col, CDClass c, DBColumn transCol,
			DBTable subTable, CDAttribute a, Match sourceMatch, Match targetMatch) {
		Object[] result_pattern_TransitiveAttributeRule_24_3_solvecsp_binding = pattern_TransitiveAttributeRule_24_3_solvecsp_bindingFBBBBBBBBBB(
				_this, s, t, col, c, transCol, subTable, a, sourceMatch, targetMatch);
		if (result_pattern_TransitiveAttributeRule_24_3_solvecsp_binding != null) {
			CSP csp = (CSP) result_pattern_TransitiveAttributeRule_24_3_solvecsp_binding[0];

			Object[] result_pattern_TransitiveAttributeRule_24_3_solvecsp_black = pattern_TransitiveAttributeRule_24_3_solvecsp_blackB(
					csp);
			if (result_pattern_TransitiveAttributeRule_24_3_solvecsp_black != null) {

				return new Object[] { csp, _this, s, t, col, c, transCol, subTable, a, sourceMatch, targetMatch };
			}
		}
		return null;
	}

	public static final boolean pattern_TransitiveAttributeRule_24_4_checkCSP_expressionFB(CSP csp) {
		boolean _localVariable_0 = csp.check();
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Iterable<Object[]> pattern_TransitiveAttributeRule_24_5_matchcorrcontext_blackBFBBFBB(DBTable t,
			CDClass c, DBTable subTable, Match sourceMatch, Match targetMatch) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!subTable.equals(t)) {
			if (!sourceMatch.equals(targetMatch)) {
				for (SuperClassToTable superCorr : org.moflon.core.utilities.eMoflonEMFUtil
						.getOppositeReferenceTyped(subTable, SuperClassToTable.class, "target")) {
					if (c.equals(superCorr.getSource())) {
						for (ClassToTable c2t : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(c,
								ClassToTable.class, "source")) {
							if (t.equals(c2t.getTarget())) {
								_result.add(new Object[] { t, superCorr, c, subTable, c2t, sourceMatch, targetMatch });
							}
						}
					}
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_24_5_matchcorrcontext_greenBBBBF(
			SuperClassToTable superCorr, ClassToTable c2t, Match sourceMatch, Match targetMatch) {
		CCMatch ccMatch = RuntimeFactory.eINSTANCE.createCCMatch();
		String ccMatch_ruleName_prime = "TransitiveAttributeRule";
		ccMatch.setSourceMatch(sourceMatch);
		ccMatch.setTargetMatch(targetMatch);
		ccMatch.getAllContextElements().add(superCorr);
		ccMatch.getAllContextElements().add(c2t);
		ccMatch.setRuleName(ccMatch_ruleName_prime);
		return new Object[] { superCorr, c2t, sourceMatch, targetMatch, ccMatch };
	}

	public static final Object[] pattern_TransitiveAttributeRule_24_6_createcorrespondence_blackBBBBBBBB(DBSchema s,
			DBTable t, DBColumn col, CDClass c, DBColumn transCol, DBTable subTable, CDAttribute a, CCMatch ccMatch) {
		if (!col.equals(transCol)) {
			if (!subTable.equals(t)) {
				return new Object[] { s, t, col, c, transCol, subTable, a, ccMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_24_7_addtoreturnedresult_blackBB(
			IsApplicableRuleResult result, CCMatch ccMatch) {
		return new Object[] { result, ccMatch };
	}

	public static final Object[] pattern_TransitiveAttributeRule_24_7_addtoreturnedresult_greenBB(
			IsApplicableRuleResult result, CCMatch ccMatch) {
		result.getIsApplicableMatch().add(ccMatch);
		boolean result_success_prime = Boolean.valueOf(true);
		String ccMatch_ruleName_prime = "TransitiveAttributeRule";
		result.setSuccess(Boolean.valueOf(result_success_prime));
		ccMatch.setRuleName(ccMatch_ruleName_prime);
		return new Object[] { result, ccMatch };
	}

	public static final IsApplicableRuleResult pattern_TransitiveAttributeRule_24_8_expressionFB(
			IsApplicableRuleResult result) {
		IsApplicableRuleResult _result = result;
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_27_1_matchtggpattern_blackBB(CDClass c,
			CDAttribute a) {
		if (c.getAttributes().contains(a)) {
			return new Object[] { c, a };
		}
		return null;
	}

	public static final boolean pattern_TransitiveAttributeRule_27_2_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_TransitiveAttributeRule_27_3_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_28_1_matchtggpattern_blackBBBBB(DBSchema s, DBTable t,
			DBColumn col, DBColumn transCol, DBTable subTable) {
		if (!col.equals(transCol)) {
			if (!subTable.equals(t)) {
				if (s.getTables().contains(t)) {
					if (s.getTables().contains(subTable)) {
						if (subTable.getCols().contains(transCol)) {
							if (t.getCols().contains(col)) {
								return new Object[] { s, t, col, transCol, subTable };
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final boolean pattern_TransitiveAttributeRule_28_2_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_TransitiveAttributeRule_28_3_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_29_1_createresult_blackB(
			TransitiveAttributeRule _this) {
		return new Object[] { _this };
	}

	public static final Object[] pattern_TransitiveAttributeRule_29_1_createresult_greenFF() {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		ModelgeneratorRuleResult ruleResult = RuntimeFactory.eINSTANCE.createModelgeneratorRuleResult();
		boolean ruleResult_success_prime = Boolean.valueOf(false);
		ruleResult.setSuccess(Boolean.valueOf(ruleResult_success_prime));
		return new Object[] { isApplicableMatch, ruleResult };
	}

	public static final Object[] pattern_TransitiveAttributeRule_29_2_isapplicablecore_black_nac_0BB(
			ModelgeneratorRuleResult ruleResult, DBSchema s) {
		if (ruleResult.getTargetObjects().contains(s)) {
			return new Object[] { ruleResult, s };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_29_2_isapplicablecore_black_nac_1BB(
			ModelgeneratorRuleResult ruleResult, DBTable t) {
		if (ruleResult.getTargetObjects().contains(t)) {
			return new Object[] { ruleResult, t };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_29_2_isapplicablecore_black_nac_2BB(
			ModelgeneratorRuleResult ruleResult, DBColumn col) {
		if (ruleResult.getTargetObjects().contains(col)) {
			return new Object[] { ruleResult, col };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_29_2_isapplicablecore_black_nac_3BB(
			ModelgeneratorRuleResult ruleResult, ClassToTable c2t) {
		if (ruleResult.getCorrObjects().contains(c2t)) {
			return new Object[] { ruleResult, c2t };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_29_2_isapplicablecore_black_nac_4BB(
			ModelgeneratorRuleResult ruleResult, CDClass c) {
		if (ruleResult.getSourceObjects().contains(c)) {
			return new Object[] { ruleResult, c };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_29_2_isapplicablecore_black_nac_5BB(
			ModelgeneratorRuleResult ruleResult, CDAttribute a) {
		if (ruleResult.getSourceObjects().contains(a)) {
			return new Object[] { ruleResult, a };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_29_2_isapplicablecore_black_nac_6BB(
			ModelgeneratorRuleResult ruleResult, SuperClassToTable superCorr) {
		if (ruleResult.getCorrObjects().contains(superCorr)) {
			return new Object[] { ruleResult, superCorr };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_29_2_isapplicablecore_black_nac_7BB(
			ModelgeneratorRuleResult ruleResult, DBTable subTable) {
		if (ruleResult.getTargetObjects().contains(subTable)) {
			return new Object[] { ruleResult, subTable };
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_TransitiveAttributeRule_29_2_isapplicablecore_blackFFFFFFFFFBB(
			RuleEntryContainer ruleEntryContainer, ModelgeneratorRuleResult ruleResult) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		for (RuleEntryList c2tList : ruleEntryContainer.getRuleEntryList()) {
			for (EObject tmpC2t : c2tList.getEntryObjects()) {
				if (tmpC2t instanceof ClassToTable) {
					ClassToTable c2t = (ClassToTable) tmpC2t;
					DBTable t = c2t.getTarget();
					if (t != null) {
						CDClass c = c2t.getSource();
						if (c != null) {
							if (pattern_TransitiveAttributeRule_29_2_isapplicablecore_black_nac_3BB(ruleResult,
									c2t) == null) {
								if (pattern_TransitiveAttributeRule_29_2_isapplicablecore_black_nac_1BB(ruleResult,
										t) == null) {
									if (pattern_TransitiveAttributeRule_29_2_isapplicablecore_black_nac_4BB(ruleResult,
											c) == null) {
										for (DBColumn col : t.getCols()) {
											if (pattern_TransitiveAttributeRule_29_2_isapplicablecore_black_nac_2BB(
													ruleResult, col) == null) {
												for (CDAttribute a : c.getAttributes()) {
													if (pattern_TransitiveAttributeRule_29_2_isapplicablecore_black_nac_5BB(
															ruleResult, a) == null) {
														for (DBSchema s : org.moflon.core.utilities.eMoflonEMFUtil
																.getOppositeReferenceTyped(t, DBSchema.class,
																		"tables")) {
															if (pattern_TransitiveAttributeRule_29_2_isapplicablecore_black_nac_0BB(
																	ruleResult, s) == null) {
																for (EObject tmpSubTable : s.getTables()) {
																	if (tmpSubTable instanceof DBTable) {
																		DBTable subTable = (DBTable) tmpSubTable;
																		if (!subTable.equals(t)) {
																			if (pattern_TransitiveAttributeRule_29_2_isapplicablecore_black_nac_7BB(
																					ruleResult, subTable) == null) {
																				for (SuperClassToTable superCorr : org.moflon.core.utilities.eMoflonEMFUtil
																						.getOppositeReferenceTyped(c,
																								SuperClassToTable.class,
																								"source")) {
																					if (subTable.equals(
																							superCorr.getTarget())) {
																						if (pattern_TransitiveAttributeRule_29_2_isapplicablecore_black_nac_6BB(
																								ruleResult,
																								superCorr) == null) {
																							_result.add(new Object[] {
																									c2tList, s, t, col,
																									c2t, c, a,
																									superCorr, subTable,
																									ruleEntryContainer,
																									ruleResult });
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}

					}

				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_29_3_solveCSP_bindingFBBBBBBBBBBB(
			TransitiveAttributeRule _this, IsApplicableMatch isApplicableMatch, DBSchema s, DBTable t, DBColumn col,
			SuperClassToTable superCorr, CDClass c, DBTable subTable, ClassToTable c2t, CDAttribute a,
			ModelgeneratorRuleResult ruleResult) {
		CSP _localVariable_0 = _this.generateModel_solveCsp_BWD(isApplicableMatch, s, t, col, superCorr, c, subTable,
				c2t, a, ruleResult);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, s, t, col, superCorr, c, subTable, c2t, a,
					ruleResult };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_29_3_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_TransitiveAttributeRule_29_3_solveCSP_bindingAndBlackFBBBBBBBBBBB(
			TransitiveAttributeRule _this, IsApplicableMatch isApplicableMatch, DBSchema s, DBTable t, DBColumn col,
			SuperClassToTable superCorr, CDClass c, DBTable subTable, ClassToTable c2t, CDAttribute a,
			ModelgeneratorRuleResult ruleResult) {
		Object[] result_pattern_TransitiveAttributeRule_29_3_solveCSP_binding = pattern_TransitiveAttributeRule_29_3_solveCSP_bindingFBBBBBBBBBBB(
				_this, isApplicableMatch, s, t, col, superCorr, c, subTable, c2t, a, ruleResult);
		if (result_pattern_TransitiveAttributeRule_29_3_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_TransitiveAttributeRule_29_3_solveCSP_binding[0];

			Object[] result_pattern_TransitiveAttributeRule_29_3_solveCSP_black = pattern_TransitiveAttributeRule_29_3_solveCSP_blackB(
					csp);
			if (result_pattern_TransitiveAttributeRule_29_3_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, s, t, col, superCorr, c, subTable, c2t, a,
						ruleResult };
			}
		}
		return null;
	}

	public static final boolean pattern_TransitiveAttributeRule_29_4_checkCSP_expressionFBB(
			TransitiveAttributeRule _this, CSP csp) {
		boolean _localVariable_0 = _this.generateModel_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_TransitiveAttributeRule_29_5_checknacs_blackBBBBBBBB(DBSchema s, DBTable t,
			DBColumn col, SuperClassToTable superCorr, CDClass c, DBTable subTable, ClassToTable c2t, CDAttribute a) {
		if (!subTable.equals(t)) {
			return new Object[] { s, t, col, superCorr, c, subTable, c2t, a };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_29_6_perform_blackBBBBBBBBB(DBSchema s, DBTable t,
			DBColumn col, SuperClassToTable superCorr, CDClass c, DBTable subTable, ClassToTable c2t, CDAttribute a,
			ModelgeneratorRuleResult ruleResult) {
		if (!subTable.equals(t)) {
			return new Object[] { s, t, col, superCorr, c, subTable, c2t, a, ruleResult };
		}
		return null;
	}

	public static final Object[] pattern_TransitiveAttributeRule_29_6_perform_greenFBBB(DBTable subTable,
			ModelgeneratorRuleResult ruleResult, CSP csp) {
		DBColumn transCol = DatabaseSchemataFactory.eINSTANCE.createDBColumn();
		Object _localVariable_0 = csp.getValue("transCol", "name");
		boolean ruleResult_success_prime = Boolean.valueOf(true);
		int _localVariable_1 = ruleResult.getIncrementedPerformCount();
		subTable.getCols().add(transCol);
		ruleResult.getTargetObjects().add(transCol);
		String transCol_name_prime = (String) _localVariable_0;
		ruleResult.setSuccess(Boolean.valueOf(ruleResult_success_prime));
		int ruleResult_performCount_prime = Integer.valueOf(_localVariable_1);
		transCol.setName(transCol_name_prime);
		ruleResult.setPerformCount(Integer.valueOf(ruleResult_performCount_prime));
		return new Object[] { transCol, subTable, ruleResult, csp };
	}

	public static final ModelgeneratorRuleResult pattern_TransitiveAttributeRule_29_7_expressionFB(
			ModelgeneratorRuleResult ruleResult) {
		ModelgeneratorRuleResult _result = ruleResult;
		return _result;
	}

	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //TransitiveAttributeRuleImpl
