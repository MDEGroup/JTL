/**
 */
package CDToDB.Rules.impl;

import CDToDB.ClassToTable;

import CDToDB.Rules.CreateAttributeRule;
import CDToDB.Rules.RulesPackage;

import ClassDiagrams.CDAttribute;
import ClassDiagrams.CDClass;
import ClassDiagrams.ClassDiagramsFactory;

import DatabaseSchemata.DBColumn;
import DatabaseSchemata.DBTable;
import DatabaseSchemata.DatabaseSchemataFactory;

import java.lang.Iterable;

import java.lang.reflect.InvocationTargetException;

import java.util.LinkedList;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EOperation;

import org.moflon.tgg.language.csp.CSP;

import org.moflon.tgg.language.modelgenerator.RuleEntryContainer;
import org.moflon.tgg.language.modelgenerator.RuleEntryList;

import org.moflon.tgg.runtime.AttributeConstraintsRuleResult;
import org.moflon.tgg.runtime.CCMatch;
import org.moflon.tgg.runtime.EMoflonEdge;
import org.moflon.tgg.runtime.EObjectContainer;
import org.moflon.tgg.runtime.IsApplicableMatch;
import org.moflon.tgg.runtime.IsApplicableRuleResult;
import org.moflon.tgg.runtime.Match;
import org.moflon.tgg.runtime.ModelgeneratorRuleResult;
import org.moflon.tgg.runtime.PerformRuleResult;
import org.moflon.tgg.runtime.RuntimeFactory;
import org.moflon.tgg.runtime.TripleMatch;

import org.moflon.tgg.runtime.impl.AbstractRuleImpl;
// <-- [user defined imports]
import org.moflon.tgg.csp.*;
import CDToDB.csp.constraints.*;
import org.moflon.tgg.csp.constraints.*;
import org.moflon.tgg.language.csp.*;
import org.moflon.tgg.runtime.TripleMatchNodeMapping;
import java.util.Optional;
import org.moflon.tgg.algorithm.delta.attribute.CheckAttributeHelper;
import SDMLanguage.expressions.ComparingOperator;
import org.moflon.tgg.runtime.TripleMatchNodeMapping;
import java.util.Optional;
import org.moflon.tgg.algorithm.delta.attribute.CheckAttributeHelper;
import SDMLanguage.expressions.ComparingOperator;
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Create Attribute Rule</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class CreateAttributeRuleImpl extends AbstractRuleImpl implements CreateAttributeRule {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CreateAttributeRuleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RulesPackage.eINSTANCE.getCreateAttributeRule();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_FWD(Match match, CDAttribute a, CDClass c) {

		Object[] result1_black = CreateAttributeRuleImpl.pattern_CreateAttributeRule_0_1_initialbindings_blackBBBB(this,
				match, a, c);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[match] = " + match + ", " + "[a] = " + a + ", " + "[c] = " + c + ".");
		}

		Object[] result2_bindingAndBlack = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_0_2_SolveCSP_bindingAndBlackFBBBB(this, match, a, c);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[match] = " + match + ", " + "[a] = " + a + ", " + "[c] = " + c + ".");
		}
		CSP csp = (CSP) result2_bindingAndBlack[0];
		// 
		if (CreateAttributeRuleImpl.pattern_CreateAttributeRule_0_3_CheckCSP_expressionFBB(this, csp)) {

			Object[] result4_black = CreateAttributeRuleImpl
					.pattern_CreateAttributeRule_0_4_collectelementstobetranslated_blackBBB(match, a, c);
			if (result4_black == null) {
				throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match + ", "
						+ "[a] = " + a + ", " + "[c] = " + c + ".");
			}
			CreateAttributeRuleImpl.pattern_CreateAttributeRule_0_4_collectelementstobetranslated_greenBBBF(match, a,
					c);
			//nothing EMoflonEdge c__a____attributes = (EMoflonEdge) result4_green[3];

			Object[] result5_black = CreateAttributeRuleImpl
					.pattern_CreateAttributeRule_0_5_collectcontextelements_blackBBB(match, a, c);
			if (result5_black == null) {
				throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match + ", "
						+ "[a] = " + a + ", " + "[c] = " + c + ".");
			}
			CreateAttributeRuleImpl.pattern_CreateAttributeRule_0_5_collectcontextelements_greenBB(match, c);

			// 
			CreateAttributeRuleImpl.pattern_CreateAttributeRule_0_6_registerobjectstomatch_expressionBBBB(this, match,
					a, c);
			return CreateAttributeRuleImpl.pattern_CreateAttributeRule_0_7_expressionF();
		} else {
			return CreateAttributeRuleImpl.pattern_CreateAttributeRule_0_8_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformRuleResult perform_FWD(IsApplicableMatch isApplicableMatch) {

		Object[] result1_bindingAndBlack = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_1_1_performtransformation_bindingAndBlackFFFFFBB(this, isApplicableMatch);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[isApplicableMatch] = " + isApplicableMatch + ".");
		}
		ClassToTable c2t = (ClassToTable) result1_bindingAndBlack[0];
		CDAttribute a = (CDAttribute) result1_bindingAndBlack[1];
		CDClass c = (CDClass) result1_bindingAndBlack[2];
		DBTable t = (DBTable) result1_bindingAndBlack[3];
		CSP csp = (CSP) result1_bindingAndBlack[4];
		Object[] result1_green = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_1_1_performtransformation_greenBFB(t, csp);
		DBColumn col = (DBColumn) result1_green[1];

		Object[] result2_black = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_1_2_collecttranslatedelements_blackBB(a, col);
		if (result2_black == null) {
			throw new RuntimeException(
					"Pattern matching failed." + " Variables: " + "[a] = " + a + ", " + "[col] = " + col + ".");
		}
		Object[] result2_green = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_1_2_collecttranslatedelements_greenFBB(a, col);
		PerformRuleResult ruleresult = (PerformRuleResult) result2_green[0];

		Object[] result3_black = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_1_3_bookkeepingforedges_blackBBBBBB(ruleresult, c2t, a, c, t, col);
		if (result3_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[ruleresult] = " + ruleresult
					+ ", " + "[c2t] = " + c2t + ", " + "[a] = " + a + ", " + "[c] = " + c + ", " + "[t] = " + t + ", "
					+ "[col] = " + col + ".");
		}
		CreateAttributeRuleImpl.pattern_CreateAttributeRule_1_3_bookkeepingforedges_greenBBBBBFF(ruleresult, a, c, t,
				col);
		//nothing EMoflonEdge t__col____cols = (EMoflonEdge) result3_green[5];
		//nothing EMoflonEdge c__a____attributes = (EMoflonEdge) result3_green[6];

		// 
		// 
		CreateAttributeRuleImpl.pattern_CreateAttributeRule_1_5_registerobjects_expressionBBBBBBB(this, ruleresult, c2t,
				a, c, t, col);
		return CreateAttributeRuleImpl.pattern_CreateAttributeRule_1_6_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_FWD(Match match) {

		Object[] result1_bindingAndBlack = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_2_1_preparereturnvalue_bindingAndBlackFFB(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		EOperation performOperation = (EOperation) result1_bindingAndBlack[0];
		//nothing EClass eClass = (EClass) result1_bindingAndBlack[1];
		Object[] result1_green = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_2_1_preparereturnvalue_greenBF(performOperation);
		IsApplicableRuleResult ruleresult = (IsApplicableRuleResult) result1_green[1];

		// ForEach 
		Object[] result2_binding = CreateAttributeRuleImpl.pattern_CreateAttributeRule_2_2_corematch_bindingFFB(match);
		if (result2_binding == null) {
			throw new RuntimeException(
					"Binding in node core match failed." + " Variables: " + "[match] = " + match + ".");
		}
		CDAttribute a = (CDAttribute) result2_binding[0];
		CDClass c = (CDClass) result2_binding[1];
		for (Object[] result2_black : CreateAttributeRuleImpl.pattern_CreateAttributeRule_2_2_corematch_blackFBBFB(a, c,
				match)) {
			ClassToTable c2t = (ClassToTable) result2_black[0];
			DBTable t = (DBTable) result2_black[3];
			// ForEach 
			for (Object[] result3_black : CreateAttributeRuleImpl
					.pattern_CreateAttributeRule_2_3_findcontext_blackBBBB(c2t, a, c, t)) {
				Object[] result3_green = CreateAttributeRuleImpl
						.pattern_CreateAttributeRule_2_3_findcontext_greenBBBBFFFF(c2t, a, c, t);
				IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result3_green[4];
				//nothing EMoflonEdge c2t__c____source = (EMoflonEdge) result3_green[5];
				//nothing EMoflonEdge c2t__t____target = (EMoflonEdge) result3_green[6];
				//nothing EMoflonEdge c__a____attributes = (EMoflonEdge) result3_green[7];

				Object[] result4_bindingAndBlack = CreateAttributeRuleImpl
						.pattern_CreateAttributeRule_2_4_solveCSP_bindingAndBlackFBBBBBB(this, isApplicableMatch, c2t,
								a, c, t);
				if (result4_bindingAndBlack == null) {
					throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
							+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[c2t] = " + c2t + ", " + "[a] = "
							+ a + ", " + "[c] = " + c + ", " + "[t] = " + t + ".");
				}
				CSP csp = (CSP) result4_bindingAndBlack[0];
				// 
				if (CreateAttributeRuleImpl.pattern_CreateAttributeRule_2_5_checkCSP_expressionFBB(this, csp)) {

					Object[] result6_black = CreateAttributeRuleImpl
							.pattern_CreateAttributeRule_2_6_addmatchtoruleresult_blackBB(ruleresult,
									isApplicableMatch);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[ruleresult] = "
								+ ruleresult + ", " + "[isApplicableMatch] = " + isApplicableMatch + ".");
					}
					CreateAttributeRuleImpl.pattern_CreateAttributeRule_2_6_addmatchtoruleresult_greenBB(ruleresult,
							isApplicableMatch);

				} else {
				}

			}

		}
		return CreateAttributeRuleImpl.pattern_CreateAttributeRule_2_7_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjectsToMatch_FWD(Match match, CDAttribute a, CDClass c) {
		match.registerObject("a", a);
		match.registerObject("c", c);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isAppropriate_solveCsp_FWD(Match match, CDAttribute a, CDClass c) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables

		// Create unbound variables

		// Create constraints

		// Solve CSP
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_checkCsp_FWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_FWD(IsApplicableMatch isApplicableMatch, ClassToTable c2t, CDAttribute a,
			CDClass c, DBTable t) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables
		Variable var_a_name = CSPFactoryHelper.eINSTANCE.createVariable("a.name", true, csp);
		var_a_name.setValue(a.getName());
		var_a_name.setType("String");

		// Create unbound variables
		Variable var_col_name = CSPFactoryHelper.eINSTANCE.createVariable("col.name", csp);
		var_col_name.setType("String");

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_a_name, var_col_name);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("c2t", c2t);
		isApplicableMatch.registerObject("a", a);
		isApplicableMatch.registerObject("c", c);
		isApplicableMatch.registerObject("t", t);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_FWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjects_FWD(PerformRuleResult ruleresult, EObject c2t, EObject a, EObject c, EObject t,
			EObject col) {
		ruleresult.registerObject("c2t", c2t);
		ruleresult.registerObject("a", a);
		ruleresult.registerObject("c", c);
		ruleresult.registerObject("t", t);
		ruleresult.registerObject("col", col);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkTypes_FWD(Match match) {
		return true && org.moflon.util.eMoflonSDMUtil.getFQN(match.getObject("a").eClass())
				.equals("ClassDiagrams.CDAttribute.");
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_BWD(Match match, DBTable t, DBColumn col) {

		Object[] result1_black = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_10_1_initialbindings_blackBBBB(this, match, t, col);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[match] = " + match + ", " + "[t] = " + t + ", " + "[col] = " + col + ".");
		}

		Object[] result2_bindingAndBlack = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_10_2_SolveCSP_bindingAndBlackFBBBB(this, match, t, col);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[match] = " + match + ", " + "[t] = " + t + ", " + "[col] = " + col + ".");
		}
		CSP csp = (CSP) result2_bindingAndBlack[0];
		// 
		if (CreateAttributeRuleImpl.pattern_CreateAttributeRule_10_3_CheckCSP_expressionFBB(this, csp)) {

			Object[] result4_black = CreateAttributeRuleImpl
					.pattern_CreateAttributeRule_10_4_collectelementstobetranslated_blackBBB(match, t, col);
			if (result4_black == null) {
				throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match + ", "
						+ "[t] = " + t + ", " + "[col] = " + col + ".");
			}
			CreateAttributeRuleImpl.pattern_CreateAttributeRule_10_4_collectelementstobetranslated_greenBBBF(match, t,
					col);
			//nothing EMoflonEdge t__col____cols = (EMoflonEdge) result4_green[3];

			Object[] result5_black = CreateAttributeRuleImpl
					.pattern_CreateAttributeRule_10_5_collectcontextelements_blackBBB(match, t, col);
			if (result5_black == null) {
				throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match + ", "
						+ "[t] = " + t + ", " + "[col] = " + col + ".");
			}
			CreateAttributeRuleImpl.pattern_CreateAttributeRule_10_5_collectcontextelements_greenBB(match, t);

			// 
			CreateAttributeRuleImpl.pattern_CreateAttributeRule_10_6_registerobjectstomatch_expressionBBBB(this, match,
					t, col);
			return CreateAttributeRuleImpl.pattern_CreateAttributeRule_10_7_expressionF();
		} else {
			return CreateAttributeRuleImpl.pattern_CreateAttributeRule_10_8_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformRuleResult perform_BWD(IsApplicableMatch isApplicableMatch) {

		Object[] result1_bindingAndBlack = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_11_1_performtransformation_bindingAndBlackFFFFFBB(this, isApplicableMatch);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[isApplicableMatch] = " + isApplicableMatch + ".");
		}
		ClassToTable c2t = (ClassToTable) result1_bindingAndBlack[0];
		CDClass c = (CDClass) result1_bindingAndBlack[1];
		DBTable t = (DBTable) result1_bindingAndBlack[2];
		DBColumn col = (DBColumn) result1_bindingAndBlack[3];
		CSP csp = (CSP) result1_bindingAndBlack[4];
		Object[] result1_green = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_11_1_performtransformation_greenFBB(c, csp);
		CDAttribute a = (CDAttribute) result1_green[0];

		Object[] result2_black = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_11_2_collecttranslatedelements_blackBB(a, col);
		if (result2_black == null) {
			throw new RuntimeException(
					"Pattern matching failed." + " Variables: " + "[a] = " + a + ", " + "[col] = " + col + ".");
		}
		Object[] result2_green = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_11_2_collecttranslatedelements_greenFBB(a, col);
		PerformRuleResult ruleresult = (PerformRuleResult) result2_green[0];

		Object[] result3_black = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_11_3_bookkeepingforedges_blackBBBBBB(ruleresult, c2t, a, c, t, col);
		if (result3_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[ruleresult] = " + ruleresult
					+ ", " + "[c2t] = " + c2t + ", " + "[a] = " + a + ", " + "[c] = " + c + ", " + "[t] = " + t + ", "
					+ "[col] = " + col + ".");
		}
		CreateAttributeRuleImpl.pattern_CreateAttributeRule_11_3_bookkeepingforedges_greenBBBBBFF(ruleresult, a, c, t,
				col);
		//nothing EMoflonEdge t__col____cols = (EMoflonEdge) result3_green[5];
		//nothing EMoflonEdge c__a____attributes = (EMoflonEdge) result3_green[6];

		// 
		// 
		CreateAttributeRuleImpl.pattern_CreateAttributeRule_11_5_registerobjects_expressionBBBBBBB(this, ruleresult,
				c2t, a, c, t, col);
		return CreateAttributeRuleImpl.pattern_CreateAttributeRule_11_6_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_BWD(Match match) {

		Object[] result1_bindingAndBlack = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_12_1_preparereturnvalue_bindingAndBlackFFB(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		EOperation performOperation = (EOperation) result1_bindingAndBlack[0];
		//nothing EClass eClass = (EClass) result1_bindingAndBlack[1];
		Object[] result1_green = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_12_1_preparereturnvalue_greenBF(performOperation);
		IsApplicableRuleResult ruleresult = (IsApplicableRuleResult) result1_green[1];

		// ForEach 
		Object[] result2_binding = CreateAttributeRuleImpl.pattern_CreateAttributeRule_12_2_corematch_bindingFFB(match);
		if (result2_binding == null) {
			throw new RuntimeException(
					"Binding in node core match failed." + " Variables: " + "[match] = " + match + ".");
		}
		DBTable t = (DBTable) result2_binding[0];
		DBColumn col = (DBColumn) result2_binding[1];
		for (Object[] result2_black : CreateAttributeRuleImpl.pattern_CreateAttributeRule_12_2_corematch_blackFFBBB(t,
				col, match)) {
			ClassToTable c2t = (ClassToTable) result2_black[0];
			CDClass c = (CDClass) result2_black[1];
			// ForEach 
			for (Object[] result3_black : CreateAttributeRuleImpl
					.pattern_CreateAttributeRule_12_3_findcontext_blackBBBB(c2t, c, t, col)) {
				Object[] result3_green = CreateAttributeRuleImpl
						.pattern_CreateAttributeRule_12_3_findcontext_greenBBBBFFFF(c2t, c, t, col);
				IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result3_green[4];
				//nothing EMoflonEdge c2t__c____source = (EMoflonEdge) result3_green[5];
				//nothing EMoflonEdge t__col____cols = (EMoflonEdge) result3_green[6];
				//nothing EMoflonEdge c2t__t____target = (EMoflonEdge) result3_green[7];

				Object[] result4_bindingAndBlack = CreateAttributeRuleImpl
						.pattern_CreateAttributeRule_12_4_solveCSP_bindingAndBlackFBBBBBB(this, isApplicableMatch, c2t,
								c, t, col);
				if (result4_bindingAndBlack == null) {
					throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
							+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[c2t] = " + c2t + ", " + "[c] = "
							+ c + ", " + "[t] = " + t + ", " + "[col] = " + col + ".");
				}
				CSP csp = (CSP) result4_bindingAndBlack[0];
				// 
				if (CreateAttributeRuleImpl.pattern_CreateAttributeRule_12_5_checkCSP_expressionFBB(this, csp)) {

					Object[] result6_black = CreateAttributeRuleImpl
							.pattern_CreateAttributeRule_12_6_addmatchtoruleresult_blackBB(ruleresult,
									isApplicableMatch);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[ruleresult] = "
								+ ruleresult + ", " + "[isApplicableMatch] = " + isApplicableMatch + ".");
					}
					CreateAttributeRuleImpl.pattern_CreateAttributeRule_12_6_addmatchtoruleresult_greenBB(ruleresult,
							isApplicableMatch);

				} else {
				}

			}

		}
		return CreateAttributeRuleImpl.pattern_CreateAttributeRule_12_7_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjectsToMatch_BWD(Match match, DBTable t, DBColumn col) {
		match.registerObject("t", t);
		match.registerObject("col", col);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isAppropriate_solveCsp_BWD(Match match, DBTable t, DBColumn col) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables

		// Create unbound variables

		// Create constraints

		// Solve CSP
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_BWD(IsApplicableMatch isApplicableMatch, ClassToTable c2t, CDClass c, DBTable t,
			DBColumn col) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables
		Variable var_col_name = CSPFactoryHelper.eINSTANCE.createVariable("col.name", true, csp);
		var_col_name.setValue(col.getName());
		var_col_name.setType("String");

		// Create unbound variables
		Variable var_a_name = CSPFactoryHelper.eINSTANCE.createVariable("a.name", csp);
		var_a_name.setType("String");

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_a_name, var_col_name);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("c2t", c2t);
		isApplicableMatch.registerObject("c", c);
		isApplicableMatch.registerObject("t", t);
		isApplicableMatch.registerObject("col", col);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjects_BWD(PerformRuleResult ruleresult, EObject c2t, EObject a, EObject c, EObject t,
			EObject col) {
		ruleresult.registerObject("c2t", c2t);
		ruleresult.registerObject("a", a);
		ruleresult.registerObject("c", c);
		ruleresult.registerObject("t", t);
		ruleresult.registerObject("col", col);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkTypes_BWD(Match match) {
		return true && org.moflon.util.eMoflonSDMUtil.getFQN(match.getObject("col").eClass())
				.equals("DatabaseSchemata.DBColumn.");
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObjectContainer isAppropriate_FWD_EMoflonEdge_5(EMoflonEdge _edge_attributes) {

		Object[] result1_bindingAndBlack = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_20_1_preparereturnvalue_bindingAndBlackFFBF(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		EOperation __performOperation = (EOperation) result1_bindingAndBlack[0];
		EClass __eClass = (EClass) result1_bindingAndBlack[1];
		EOperation isApplicableCC = (EOperation) result1_bindingAndBlack[3];
		Object[] result1_green = CreateAttributeRuleImpl.pattern_CreateAttributeRule_20_1_preparereturnvalue_greenF();
		EObjectContainer __result = (EObjectContainer) result1_green[0];

		// ForEach 
		for (Object[] result2_black : CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_20_2_testcorematchandDECs_blackFFB(_edge_attributes)) {
			CDAttribute a = (CDAttribute) result2_black[0];
			CDClass c = (CDClass) result2_black[1];
			Object[] result2_green = CreateAttributeRuleImpl
					.pattern_CreateAttributeRule_20_2_testcorematchandDECs_greenFB(__eClass);
			Match match = (Match) result2_green[0];

			// 
			if (CreateAttributeRuleImpl
					.pattern_CreateAttributeRule_20_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBB(this,
							match, a, c)) {
				// 
				if (CreateAttributeRuleImpl
						.pattern_CreateAttributeRule_20_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
								this, match)) {

					Object[] result5_black = CreateAttributeRuleImpl
							.pattern_CreateAttributeRule_20_5_Addmatchtoruleresult_blackBBBB(match, __performOperation,
									__result, isApplicableCC);
					if (result5_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match
								+ ", " + "[__performOperation] = " + __performOperation + ", " + "[__result] = "
								+ __result + ", " + "[isApplicableCC] = " + isApplicableCC + ".");
					}
					CreateAttributeRuleImpl.pattern_CreateAttributeRule_20_5_Addmatchtoruleresult_greenBBBB(match,
							__performOperation, __result, isApplicableCC);

				} else {
				}

			} else {
			}

		}
		return CreateAttributeRuleImpl.pattern_CreateAttributeRule_20_6_expressionFB(__result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObjectContainer isAppropriate_BWD_EMoflonEdge_5(EMoflonEdge _edge_cols) {

		Object[] result1_bindingAndBlack = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_21_1_preparereturnvalue_bindingAndBlackFFBF(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		EOperation __performOperation = (EOperation) result1_bindingAndBlack[0];
		EClass __eClass = (EClass) result1_bindingAndBlack[1];
		EOperation isApplicableCC = (EOperation) result1_bindingAndBlack[3];
		Object[] result1_green = CreateAttributeRuleImpl.pattern_CreateAttributeRule_21_1_preparereturnvalue_greenF();
		EObjectContainer __result = (EObjectContainer) result1_green[0];

		// ForEach 
		for (Object[] result2_black : CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_21_2_testcorematchandDECs_blackFFB(_edge_cols)) {
			DBTable t = (DBTable) result2_black[0];
			DBColumn col = (DBColumn) result2_black[1];
			Object[] result2_green = CreateAttributeRuleImpl
					.pattern_CreateAttributeRule_21_2_testcorematchandDECs_greenFB(__eClass);
			Match match = (Match) result2_green[0];

			// 
			if (CreateAttributeRuleImpl
					.pattern_CreateAttributeRule_21_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBB(this,
							match, t, col)) {
				// 
				if (CreateAttributeRuleImpl
						.pattern_CreateAttributeRule_21_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
								this, match)) {

					Object[] result5_black = CreateAttributeRuleImpl
							.pattern_CreateAttributeRule_21_5_Addmatchtoruleresult_blackBBBB(match, __performOperation,
									__result, isApplicableCC);
					if (result5_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match
								+ ", " + "[__performOperation] = " + __performOperation + ", " + "[__result] = "
								+ __result + ", " + "[isApplicableCC] = " + isApplicableCC + ".");
					}
					CreateAttributeRuleImpl.pattern_CreateAttributeRule_21_5_Addmatchtoruleresult_greenBBBB(match,
							__performOperation, __result, isApplicableCC);

				} else {
				}

			} else {
			}

		}
		return CreateAttributeRuleImpl.pattern_CreateAttributeRule_21_6_expressionFB(__result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeConstraintsRuleResult checkAttributes_FWD(TripleMatch __tripleMatch) {
		AttributeConstraintsRuleResult ruleResult = org.moflon.tgg.runtime.RuntimeFactory.eINSTANCE
				.createAttributeConstraintsRuleResult();
		ruleResult.setRule("CreateAttributeRule");
		ruleResult.setSuccess(true);

		CSP csp = CspFactory.eINSTANCE.createCSP();

		CheckAttributeHelper __helper = new CheckAttributeHelper(__tripleMatch);

		Variable var_a_name = CSPFactoryHelper.eINSTANCE.createVariable("a", true, csp);
		var_a_name.setValue(__helper.getValue("a", "name"));
		var_a_name.setType("String");

		Variable var_col_name = CSPFactoryHelper.eINSTANCE.createVariable("col", true, csp);
		var_col_name.setValue(__helper.getValue("col", "name"));
		var_col_name.setType("String");

		Eq eq0 = new Eq();
		csp.getConstraints().add(eq0);

		eq0.setRuleName("CreateAttributeRule");
		eq0.solve(var_a_name, var_col_name);

		if (csp.check()) {
			ruleResult.setSuccess(true);
		} else {
			var_col_name.setBound(false);
			eq0.solve(var_a_name, var_col_name);
			if (csp.check()) {
				ruleResult.setSuccess(true);
				ruleResult.setRequiredChange(true);
				__helper.setValue("col", "name", var_col_name.getValue());
			} else {
				ruleResult.setSuccess(false);
				return ruleResult;
			}
		}

		return ruleResult;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeConstraintsRuleResult checkAttributes_BWD(TripleMatch __tripleMatch) {
		AttributeConstraintsRuleResult ruleResult = org.moflon.tgg.runtime.RuntimeFactory.eINSTANCE
				.createAttributeConstraintsRuleResult();
		ruleResult.setRule("CreateAttributeRule");
		ruleResult.setSuccess(true);

		CSP csp = CspFactory.eINSTANCE.createCSP();

		CheckAttributeHelper __helper = new CheckAttributeHelper(__tripleMatch);

		Variable var_a_name = CSPFactoryHelper.eINSTANCE.createVariable("a", true, csp);
		var_a_name.setValue(__helper.getValue("a", "name"));
		var_a_name.setType("String");

		Variable var_col_name = CSPFactoryHelper.eINSTANCE.createVariable("col", true, csp);
		var_col_name.setValue(__helper.getValue("col", "name"));
		var_col_name.setType("String");

		Eq eq0 = new Eq();
		csp.getConstraints().add(eq0);

		eq0.setRuleName("CreateAttributeRule");
		eq0.solve(var_a_name, var_col_name);

		if (csp.check()) {
			ruleResult.setSuccess(true);
		} else {
			var_a_name.setBound(false);
			eq0.solve(var_a_name, var_col_name);
			if (csp.check()) {
				ruleResult.setSuccess(true);
				ruleResult.setRequiredChange(true);
				__helper.setValue("a", "name", var_a_name.getValue());
			} else {
				ruleResult.setSuccess(false);
				return ruleResult;
			}
		}

		return ruleResult;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_CC(Match sourceMatch, Match targetMatch) {

		Object[] result1_black = CreateAttributeRuleImpl.pattern_CreateAttributeRule_24_1_prepare_blackB(this);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		Object[] result1_green = CreateAttributeRuleImpl.pattern_CreateAttributeRule_24_1_prepare_greenF();
		IsApplicableRuleResult result = (IsApplicableRuleResult) result1_green[0];

		Object[] result2_bindingAndBlack = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_24_2_matchsrctrgcontext_bindingAndBlackFFFFBB(sourceMatch, targetMatch);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[sourceMatch] = " + sourceMatch
					+ ", " + "[targetMatch] = " + targetMatch + ".");
		}
		CDAttribute a = (CDAttribute) result2_bindingAndBlack[0];
		CDClass c = (CDClass) result2_bindingAndBlack[1];
		DBTable t = (DBTable) result2_bindingAndBlack[2];
		DBColumn col = (DBColumn) result2_bindingAndBlack[3];

		Object[] result3_bindingAndBlack = CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_24_3_solvecsp_bindingAndBlackFBBBBBBB(this, a, c, t, col, sourceMatch,
						targetMatch);
		if (result3_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[a] = " + a + ", " + "[c] = " + c + ", " + "[t] = " + t + ", " + "[col] = " + col + ", "
					+ "[sourceMatch] = " + sourceMatch + ", " + "[targetMatch] = " + targetMatch + ".");
		}
		CSP csp = (CSP) result3_bindingAndBlack[0];
		// 
		if (CreateAttributeRuleImpl.pattern_CreateAttributeRule_24_4_checkCSP_expressionFB(csp)) {
			// ForEach 
			for (Object[] result5_black : CreateAttributeRuleImpl
					.pattern_CreateAttributeRule_24_5_matchcorrcontext_blackFBBBB(c, t, sourceMatch, targetMatch)) {
				ClassToTable c2t = (ClassToTable) result5_black[0];
				Object[] result5_green = CreateAttributeRuleImpl
						.pattern_CreateAttributeRule_24_5_matchcorrcontext_greenBBBF(c2t, sourceMatch, targetMatch);
				CCMatch ccMatch = (CCMatch) result5_green[3];

				Object[] result6_black = CreateAttributeRuleImpl
						.pattern_CreateAttributeRule_24_6_createcorrespondence_blackBBBBB(a, c, t, col, ccMatch);
				if (result6_black == null) {
					throw new RuntimeException(
							"Pattern matching failed." + " Variables: " + "[a] = " + a + ", " + "[c] = " + c + ", "
									+ "[t] = " + t + ", " + "[col] = " + col + ", " + "[ccMatch] = " + ccMatch + ".");
				}

				Object[] result7_black = CreateAttributeRuleImpl
						.pattern_CreateAttributeRule_24_7_addtoreturnedresult_blackBB(result, ccMatch);
				if (result7_black == null) {
					throw new RuntimeException("Pattern matching failed." + " Variables: " + "[result] = " + result
							+ ", " + "[ccMatch] = " + ccMatch + ".");
				}
				CreateAttributeRuleImpl.pattern_CreateAttributeRule_24_7_addtoreturnedresult_greenBB(result, ccMatch);

			}

		} else {
		}
		return CreateAttributeRuleImpl.pattern_CreateAttributeRule_24_8_expressionFB(result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_CC(CDAttribute a, CDClass c, DBTable t, DBColumn col, Match sourceMatch,
			Match targetMatch) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables
		Variable var_a_name = CSPFactoryHelper.eINSTANCE.createVariable("a.name", true, csp);
		var_a_name.setValue(a.getName());
		var_a_name.setType("String");
		Variable var_col_name = CSPFactoryHelper.eINSTANCE.createVariable("col.name", true, csp);
		var_col_name.setValue(col.getName());
		var_col_name.setType("String");

		// Create unbound variables

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_a_name, var_col_name);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_CC(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkDEC_FWD(CDAttribute a, CDClass c) {// 
		Object[] result1_black = CreateAttributeRuleImpl.pattern_CreateAttributeRule_27_1_matchtggpattern_blackBB(a, c);
		if (result1_black != null) {
			return CreateAttributeRuleImpl.pattern_CreateAttributeRule_27_2_expressionF();
		} else {
			return CreateAttributeRuleImpl.pattern_CreateAttributeRule_27_3_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkDEC_BWD(DBTable t, DBColumn col) {// 
		Object[] result1_black = CreateAttributeRuleImpl.pattern_CreateAttributeRule_28_1_matchtggpattern_blackBB(t,
				col);
		if (result1_black != null) {
			return CreateAttributeRuleImpl.pattern_CreateAttributeRule_28_2_expressionF();
		} else {
			return CreateAttributeRuleImpl.pattern_CreateAttributeRule_28_3_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ModelgeneratorRuleResult generateModel(RuleEntryContainer ruleEntryContainer, ClassToTable c2tParameter) {

		Object[] result1_black = CreateAttributeRuleImpl.pattern_CreateAttributeRule_29_1_createresult_blackB(this);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		Object[] result1_green = CreateAttributeRuleImpl.pattern_CreateAttributeRule_29_1_createresult_greenFF();
		IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result1_green[0];
		ModelgeneratorRuleResult ruleResult = (ModelgeneratorRuleResult) result1_green[1];

		// ForEach 
		for (Object[] result2_black : CreateAttributeRuleImpl
				.pattern_CreateAttributeRule_29_2_isapplicablecore_blackFFFFBB(ruleEntryContainer, ruleResult)) {
			//nothing RuleEntryList c2tList = (RuleEntryList) result2_black[0];
			ClassToTable c2t = (ClassToTable) result2_black[1];
			CDClass c = (CDClass) result2_black[2];
			DBTable t = (DBTable) result2_black[3];

			Object[] result3_bindingAndBlack = CreateAttributeRuleImpl
					.pattern_CreateAttributeRule_29_3_solveCSP_bindingAndBlackFBBBBBB(this, isApplicableMatch, c2t, c,
							t, ruleResult);
			if (result3_bindingAndBlack == null) {
				throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
						+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[c2t] = " + c2t + ", " + "[c] = " + c
						+ ", " + "[t] = " + t + ", " + "[ruleResult] = " + ruleResult + ".");
			}
			CSP csp = (CSP) result3_bindingAndBlack[0];
			// 
			if (CreateAttributeRuleImpl.pattern_CreateAttributeRule_29_4_checkCSP_expressionFBB(this, csp)) {
				// 
				Object[] result5_black = CreateAttributeRuleImpl
						.pattern_CreateAttributeRule_29_5_checknacs_blackBBB(c2t, c, t);
				if (result5_black != null) {

					Object[] result6_black = CreateAttributeRuleImpl
							.pattern_CreateAttributeRule_29_6_perform_blackBBBB(c2t, c, t, ruleResult);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[c2t] = " + c2t + ", "
								+ "[c] = " + c + ", " + "[t] = " + t + ", " + "[ruleResult] = " + ruleResult + ".");
					}
					CreateAttributeRuleImpl.pattern_CreateAttributeRule_29_6_perform_greenFBBFBB(c, t, ruleResult, csp);
					//nothing CDAttribute a = (CDAttribute) result6_green[0];
					//nothing DBColumn col = (DBColumn) result6_green[3];

				} else {
				}

			} else {
			}

		}
		return CreateAttributeRuleImpl.pattern_CreateAttributeRule_29_7_expressionFB(ruleResult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP generateModel_solveCsp_BWD(IsApplicableMatch isApplicableMatch, ClassToTable c2t, CDClass c, DBTable t,
			ModelgeneratorRuleResult ruleResult) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables

		// Create unbound variables
		Variable var_a_name = CSPFactoryHelper.eINSTANCE.createVariable("a.name", csp);
		var_a_name.setType("String");
		Variable var_col_name = CSPFactoryHelper.eINSTANCE.createVariable("col.name", csp);
		var_col_name.setType("String");

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_a_name, var_col_name);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("c2t", c2t);
		isApplicableMatch.registerObject("c", c);
		isApplicableMatch.registerObject("t", t);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean generateModel_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case RulesPackage.CREATE_ATTRIBUTE_RULE___IS_APPROPRIATE_FWD__MATCH_CDATTRIBUTE_CDCLASS:
			return isAppropriate_FWD((Match) arguments.get(0), (CDAttribute) arguments.get(1),
					(CDClass) arguments.get(2));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___PERFORM_FWD__ISAPPLICABLEMATCH:
			return perform_FWD((IsApplicableMatch) arguments.get(0));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___IS_APPLICABLE_FWD__MATCH:
			return isApplicable_FWD((Match) arguments.get(0));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_CDATTRIBUTE_CDCLASS:
			registerObjectsToMatch_FWD((Match) arguments.get(0), (CDAttribute) arguments.get(1),
					(CDClass) arguments.get(2));
			return null;
		case RulesPackage.CREATE_ATTRIBUTE_RULE___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_CDATTRIBUTE_CDCLASS:
			return isAppropriate_solveCsp_FWD((Match) arguments.get(0), (CDAttribute) arguments.get(1),
					(CDClass) arguments.get(2));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___IS_APPROPRIATE_CHECK_CSP_FWD__CSP:
			return isAppropriate_checkCsp_FWD((CSP) arguments.get(0));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_CLASSTOTABLE_CDATTRIBUTE_CDCLASS_DBTABLE:
			return isApplicable_solveCsp_FWD((IsApplicableMatch) arguments.get(0), (ClassToTable) arguments.get(1),
					(CDAttribute) arguments.get(2), (CDClass) arguments.get(3), (DBTable) arguments.get(4));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___IS_APPLICABLE_CHECK_CSP_FWD__CSP:
			return isApplicable_checkCsp_FWD((CSP) arguments.get(0));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT:
			registerObjects_FWD((PerformRuleResult) arguments.get(0), (EObject) arguments.get(1),
					(EObject) arguments.get(2), (EObject) arguments.get(3), (EObject) arguments.get(4),
					(EObject) arguments.get(5));
			return null;
		case RulesPackage.CREATE_ATTRIBUTE_RULE___CHECK_TYPES_FWD__MATCH:
			return checkTypes_FWD((Match) arguments.get(0));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___IS_APPROPRIATE_BWD__MATCH_DBTABLE_DBCOLUMN:
			return isAppropriate_BWD((Match) arguments.get(0), (DBTable) arguments.get(1), (DBColumn) arguments.get(2));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___PERFORM_BWD__ISAPPLICABLEMATCH:
			return perform_BWD((IsApplicableMatch) arguments.get(0));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___IS_APPLICABLE_BWD__MATCH:
			return isApplicable_BWD((Match) arguments.get(0));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_DBTABLE_DBCOLUMN:
			registerObjectsToMatch_BWD((Match) arguments.get(0), (DBTable) arguments.get(1),
					(DBColumn) arguments.get(2));
			return null;
		case RulesPackage.CREATE_ATTRIBUTE_RULE___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_DBTABLE_DBCOLUMN:
			return isAppropriate_solveCsp_BWD((Match) arguments.get(0), (DBTable) arguments.get(1),
					(DBColumn) arguments.get(2));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___IS_APPROPRIATE_CHECK_CSP_BWD__CSP:
			return isAppropriate_checkCsp_BWD((CSP) arguments.get(0));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_CLASSTOTABLE_CDCLASS_DBTABLE_DBCOLUMN:
			return isApplicable_solveCsp_BWD((IsApplicableMatch) arguments.get(0), (ClassToTable) arguments.get(1),
					(CDClass) arguments.get(2), (DBTable) arguments.get(3), (DBColumn) arguments.get(4));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___IS_APPLICABLE_CHECK_CSP_BWD__CSP:
			return isApplicable_checkCsp_BWD((CSP) arguments.get(0));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT:
			registerObjects_BWD((PerformRuleResult) arguments.get(0), (EObject) arguments.get(1),
					(EObject) arguments.get(2), (EObject) arguments.get(3), (EObject) arguments.get(4),
					(EObject) arguments.get(5));
			return null;
		case RulesPackage.CREATE_ATTRIBUTE_RULE___CHECK_TYPES_BWD__MATCH:
			return checkTypes_BWD((Match) arguments.get(0));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___IS_APPROPRIATE_FWD_EMOFLON_EDGE_5__EMOFLONEDGE:
			return isAppropriate_FWD_EMoflonEdge_5((EMoflonEdge) arguments.get(0));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___IS_APPROPRIATE_BWD_EMOFLON_EDGE_5__EMOFLONEDGE:
			return isAppropriate_BWD_EMoflonEdge_5((EMoflonEdge) arguments.get(0));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH:
			return checkAttributes_FWD((TripleMatch) arguments.get(0));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH:
			return checkAttributes_BWD((TripleMatch) arguments.get(0));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___IS_APPLICABLE_CC__MATCH_MATCH:
			return isApplicable_CC((Match) arguments.get(0), (Match) arguments.get(1));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___IS_APPLICABLE_SOLVE_CSP_CC__CDATTRIBUTE_CDCLASS_DBTABLE_DBCOLUMN_MATCH_MATCH:
			return isApplicable_solveCsp_CC((CDAttribute) arguments.get(0), (CDClass) arguments.get(1),
					(DBTable) arguments.get(2), (DBColumn) arguments.get(3), (Match) arguments.get(4),
					(Match) arguments.get(5));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___IS_APPLICABLE_CHECK_CSP_CC__CSP:
			return isApplicable_checkCsp_CC((CSP) arguments.get(0));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___CHECK_DEC_FWD__CDATTRIBUTE_CDCLASS:
			return checkDEC_FWD((CDAttribute) arguments.get(0), (CDClass) arguments.get(1));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___CHECK_DEC_BWD__DBTABLE_DBCOLUMN:
			return checkDEC_BWD((DBTable) arguments.get(0), (DBColumn) arguments.get(1));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___GENERATE_MODEL__RULEENTRYCONTAINER_CLASSTOTABLE:
			return generateModel((RuleEntryContainer) arguments.get(0), (ClassToTable) arguments.get(1));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_CLASSTOTABLE_CDCLASS_DBTABLE_MODELGENERATORRULERESULT:
			return generateModel_solveCsp_BWD((IsApplicableMatch) arguments.get(0), (ClassToTable) arguments.get(1),
					(CDClass) arguments.get(2), (DBTable) arguments.get(3),
					(ModelgeneratorRuleResult) arguments.get(4));
		case RulesPackage.CREATE_ATTRIBUTE_RULE___GENERATE_MODEL_CHECK_CSP_BWD__CSP:
			return generateModel_checkCsp_BWD((CSP) arguments.get(0));
		}
		return super.eInvoke(operationID, arguments);
	}

	public static final Object[] pattern_CreateAttributeRule_0_1_initialbindings_blackBBBB(CreateAttributeRule _this,
			Match match, CDAttribute a, CDClass c) {
		return new Object[] { _this, match, a, c };
	}

	public static final Object[] pattern_CreateAttributeRule_0_2_SolveCSP_bindingFBBBB(CreateAttributeRule _this,
			Match match, CDAttribute a, CDClass c) {
		CSP _localVariable_0 = _this.isAppropriate_solveCsp_FWD(match, a, c);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, match, a, c };
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_0_2_SolveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_CreateAttributeRule_0_2_SolveCSP_bindingAndBlackFBBBB(
			CreateAttributeRule _this, Match match, CDAttribute a, CDClass c) {
		Object[] result_pattern_CreateAttributeRule_0_2_SolveCSP_binding = pattern_CreateAttributeRule_0_2_SolveCSP_bindingFBBBB(
				_this, match, a, c);
		if (result_pattern_CreateAttributeRule_0_2_SolveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_CreateAttributeRule_0_2_SolveCSP_binding[0];

			Object[] result_pattern_CreateAttributeRule_0_2_SolveCSP_black = pattern_CreateAttributeRule_0_2_SolveCSP_blackB(
					csp);
			if (result_pattern_CreateAttributeRule_0_2_SolveCSP_black != null) {

				return new Object[] { csp, _this, match, a, c };
			}
		}
		return null;
	}

	public static final boolean pattern_CreateAttributeRule_0_3_CheckCSP_expressionFBB(CreateAttributeRule _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isAppropriate_checkCsp_FWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_0_4_collectelementstobetranslated_blackBBB(Match match,
			CDAttribute a, CDClass c) {
		return new Object[] { match, a, c };
	}

	public static final Object[] pattern_CreateAttributeRule_0_4_collectelementstobetranslated_greenBBBF(Match match,
			CDAttribute a, CDClass c) {
		EMoflonEdge c__a____attributes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getToBeTranslatedNodes().add(a);
		String c__a____attributes_name_prime = "attributes";
		c__a____attributes.setSrc(c);
		c__a____attributes.setTrg(a);
		match.getToBeTranslatedEdges().add(c__a____attributes);
		c__a____attributes.setName(c__a____attributes_name_prime);
		return new Object[] { match, a, c, c__a____attributes };
	}

	public static final Object[] pattern_CreateAttributeRule_0_5_collectcontextelements_blackBBB(Match match,
			CDAttribute a, CDClass c) {
		return new Object[] { match, a, c };
	}

	public static final Object[] pattern_CreateAttributeRule_0_5_collectcontextelements_greenBB(Match match,
			CDClass c) {
		match.getContextNodes().add(c);
		return new Object[] { match, c };
	}

	public static final void pattern_CreateAttributeRule_0_6_registerobjectstomatch_expressionBBBB(
			CreateAttributeRule _this, Match match, CDAttribute a, CDClass c) {
		_this.registerObjectsToMatch_FWD(match, a, c);

	}

	public static final boolean pattern_CreateAttributeRule_0_7_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_CreateAttributeRule_0_8_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_1_1_performtransformation_bindingFFFFB(
			IsApplicableMatch isApplicableMatch) {
		EObject _localVariable_0 = isApplicableMatch.getObject("c2t");
		EObject _localVariable_1 = isApplicableMatch.getObject("a");
		EObject _localVariable_2 = isApplicableMatch.getObject("c");
		EObject _localVariable_3 = isApplicableMatch.getObject("t");
		EObject tmpC2t = _localVariable_0;
		EObject tmpA = _localVariable_1;
		EObject tmpC = _localVariable_2;
		EObject tmpT = _localVariable_3;
		if (tmpC2t instanceof ClassToTable) {
			ClassToTable c2t = (ClassToTable) tmpC2t;
			if (tmpA instanceof CDAttribute) {
				CDAttribute a = (CDAttribute) tmpA;
				if (tmpC instanceof CDClass) {
					CDClass c = (CDClass) tmpC;
					if (tmpT instanceof DBTable) {
						DBTable t = (DBTable) tmpT;
						return new Object[] { c2t, a, c, t, isApplicableMatch };
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_1_1_performtransformation_blackBBBBFBB(ClassToTable c2t,
			CDAttribute a, CDClass c, DBTable t, CreateAttributeRule _this, IsApplicableMatch isApplicableMatch) {
		for (EObject tmpCsp : isApplicableMatch.getAttributeInfo()) {
			if (tmpCsp instanceof CSP) {
				CSP csp = (CSP) tmpCsp;
				return new Object[] { c2t, a, c, t, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_1_1_performtransformation_bindingAndBlackFFFFFBB(
			CreateAttributeRule _this, IsApplicableMatch isApplicableMatch) {
		Object[] result_pattern_CreateAttributeRule_1_1_performtransformation_binding = pattern_CreateAttributeRule_1_1_performtransformation_bindingFFFFB(
				isApplicableMatch);
		if (result_pattern_CreateAttributeRule_1_1_performtransformation_binding != null) {
			ClassToTable c2t = (ClassToTable) result_pattern_CreateAttributeRule_1_1_performtransformation_binding[0];
			CDAttribute a = (CDAttribute) result_pattern_CreateAttributeRule_1_1_performtransformation_binding[1];
			CDClass c = (CDClass) result_pattern_CreateAttributeRule_1_1_performtransformation_binding[2];
			DBTable t = (DBTable) result_pattern_CreateAttributeRule_1_1_performtransformation_binding[3];

			Object[] result_pattern_CreateAttributeRule_1_1_performtransformation_black = pattern_CreateAttributeRule_1_1_performtransformation_blackBBBBFBB(
					c2t, a, c, t, _this, isApplicableMatch);
			if (result_pattern_CreateAttributeRule_1_1_performtransformation_black != null) {
				CSP csp = (CSP) result_pattern_CreateAttributeRule_1_1_performtransformation_black[4];

				return new Object[] { c2t, a, c, t, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_1_1_performtransformation_greenBFB(DBTable t, CSP csp) {
		DBColumn col = DatabaseSchemataFactory.eINSTANCE.createDBColumn();
		Object _localVariable_0 = csp.getValue("col", "name");
		t.getCols().add(col);
		String col_name_prime = (String) _localVariable_0;
		col.setName(col_name_prime);
		return new Object[] { t, col, csp };
	}

	public static final Object[] pattern_CreateAttributeRule_1_2_collecttranslatedelements_blackBB(CDAttribute a,
			DBColumn col) {
		return new Object[] { a, col };
	}

	public static final Object[] pattern_CreateAttributeRule_1_2_collecttranslatedelements_greenFBB(CDAttribute a,
			DBColumn col) {
		PerformRuleResult ruleresult = RuntimeFactory.eINSTANCE.createPerformRuleResult();
		ruleresult.getTranslatedElements().add(a);
		ruleresult.getCreatedElements().add(col);
		return new Object[] { ruleresult, a, col };
	}

	public static final Object[] pattern_CreateAttributeRule_1_3_bookkeepingforedges_blackBBBBBB(
			PerformRuleResult ruleresult, EObject c2t, EObject a, EObject c, EObject t, EObject col) {
		if (!c2t.equals(t)) {
			if (!c2t.equals(col)) {
				if (!a.equals(c2t)) {
					if (!a.equals(c)) {
						if (!a.equals(t)) {
							if (!a.equals(col)) {
								if (!c.equals(c2t)) {
									if (!c.equals(t)) {
										if (!c.equals(col)) {
											if (!col.equals(t)) {
												return new Object[] { ruleresult, c2t, a, c, t, col };
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_1_3_bookkeepingforedges_greenBBBBBFF(
			PerformRuleResult ruleresult, EObject a, EObject c, EObject t, EObject col) {
		EMoflonEdge t__col____cols = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge c__a____attributes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String ruleresult_ruleName_prime = "CreateAttributeRule";
		String t__col____cols_name_prime = "cols";
		String c__a____attributes_name_prime = "attributes";
		t__col____cols.setSrc(t);
		t__col____cols.setTrg(col);
		ruleresult.getCreatedEdges().add(t__col____cols);
		c__a____attributes.setSrc(c);
		c__a____attributes.setTrg(a);
		ruleresult.getTranslatedEdges().add(c__a____attributes);
		ruleresult.setRuleName(ruleresult_ruleName_prime);
		t__col____cols.setName(t__col____cols_name_prime);
		c__a____attributes.setName(c__a____attributes_name_prime);
		return new Object[] { ruleresult, a, c, t, col, t__col____cols, c__a____attributes };
	}

	public static final void pattern_CreateAttributeRule_1_5_registerobjects_expressionBBBBBBB(
			CreateAttributeRule _this, PerformRuleResult ruleresult, EObject c2t, EObject a, EObject c, EObject t,
			EObject col) {
		_this.registerObjects_FWD(ruleresult, c2t, a, c, t, col);

	}

	public static final PerformRuleResult pattern_CreateAttributeRule_1_6_expressionFB(PerformRuleResult ruleresult) {
		PerformRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_2_1_preparereturnvalue_bindingFB(
			CreateAttributeRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass eClass = _localVariable_0;
		if (eClass != null) {
			return new Object[] { eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_2_1_preparereturnvalue_blackFBB(EClass eClass,
			CreateAttributeRule _this) {
		for (EOperation performOperation : eClass.getEOperations()) {
			String performOperation_name = performOperation.getName();
			if (performOperation_name.equals("perform_FWD")) {
				return new Object[] { performOperation, eClass, _this };
			}

		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_2_1_preparereturnvalue_bindingAndBlackFFB(
			CreateAttributeRule _this) {
		Object[] result_pattern_CreateAttributeRule_2_1_preparereturnvalue_binding = pattern_CreateAttributeRule_2_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_CreateAttributeRule_2_1_preparereturnvalue_binding != null) {
			EClass eClass = (EClass) result_pattern_CreateAttributeRule_2_1_preparereturnvalue_binding[0];

			Object[] result_pattern_CreateAttributeRule_2_1_preparereturnvalue_black = pattern_CreateAttributeRule_2_1_preparereturnvalue_blackFBB(
					eClass, _this);
			if (result_pattern_CreateAttributeRule_2_1_preparereturnvalue_black != null) {
				EOperation performOperation = (EOperation) result_pattern_CreateAttributeRule_2_1_preparereturnvalue_black[0];

				return new Object[] { performOperation, eClass, _this };
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_2_1_preparereturnvalue_greenBF(
			EOperation performOperation) {
		IsApplicableRuleResult ruleresult = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		boolean ruleresult_success_prime = Boolean.valueOf(false);
		String ruleresult_rule_prime = "CreateAttributeRule";
		ruleresult.setPerformOperation(performOperation);
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		ruleresult.setRule(ruleresult_rule_prime);
		return new Object[] { performOperation, ruleresult };
	}

	public static final Object[] pattern_CreateAttributeRule_2_2_corematch_bindingFFB(Match match) {
		EObject _localVariable_0 = match.getObject("a");
		EObject _localVariable_1 = match.getObject("c");
		EObject tmpA = _localVariable_0;
		EObject tmpC = _localVariable_1;
		if (tmpA instanceof CDAttribute) {
			CDAttribute a = (CDAttribute) tmpA;
			if (tmpC instanceof CDClass) {
				CDClass c = (CDClass) tmpC;
				return new Object[] { a, c, match };
			}
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_CreateAttributeRule_2_2_corematch_blackFBBFB(CDAttribute a,
			CDClass c, Match match) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		for (ClassToTable c2t : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(c,
				ClassToTable.class, "source")) {
			DBTable t = c2t.getTarget();
			if (t != null) {
				_result.add(new Object[] { c2t, a, c, t, match });
			}

		}
		return _result;
	}

	public static final Iterable<Object[]> pattern_CreateAttributeRule_2_3_findcontext_blackBBBB(ClassToTable c2t,
			CDAttribute a, CDClass c, DBTable t) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (c.equals(c2t.getSource())) {
			if (t.equals(c2t.getTarget())) {
				if (c.getAttributes().contains(a)) {
					_result.add(new Object[] { c2t, a, c, t });
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_2_3_findcontext_greenBBBBFFFF(ClassToTable c2t,
			CDAttribute a, CDClass c, DBTable t) {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		EMoflonEdge c2t__c____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge c2t__t____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge c__a____attributes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String c2t__c____source_name_prime = "source";
		String c2t__t____target_name_prime = "target";
		String c__a____attributes_name_prime = "attributes";
		isApplicableMatch.getAllContextElements().add(c2t);
		isApplicableMatch.getAllContextElements().add(a);
		isApplicableMatch.getAllContextElements().add(c);
		isApplicableMatch.getAllContextElements().add(t);
		c2t__c____source.setSrc(c2t);
		c2t__c____source.setTrg(c);
		isApplicableMatch.getAllContextElements().add(c2t__c____source);
		c2t__t____target.setSrc(c2t);
		c2t__t____target.setTrg(t);
		isApplicableMatch.getAllContextElements().add(c2t__t____target);
		c__a____attributes.setSrc(c);
		c__a____attributes.setTrg(a);
		isApplicableMatch.getAllContextElements().add(c__a____attributes);
		c2t__c____source.setName(c2t__c____source_name_prime);
		c2t__t____target.setName(c2t__t____target_name_prime);
		c__a____attributes.setName(c__a____attributes_name_prime);
		return new Object[] { c2t, a, c, t, isApplicableMatch, c2t__c____source, c2t__t____target, c__a____attributes };
	}

	public static final Object[] pattern_CreateAttributeRule_2_4_solveCSP_bindingFBBBBBB(CreateAttributeRule _this,
			IsApplicableMatch isApplicableMatch, ClassToTable c2t, CDAttribute a, CDClass c, DBTable t) {
		CSP _localVariable_0 = _this.isApplicable_solveCsp_FWD(isApplicableMatch, c2t, a, c, t);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, c2t, a, c, t };
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_2_4_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_CreateAttributeRule_2_4_solveCSP_bindingAndBlackFBBBBBB(
			CreateAttributeRule _this, IsApplicableMatch isApplicableMatch, ClassToTable c2t, CDAttribute a, CDClass c,
			DBTable t) {
		Object[] result_pattern_CreateAttributeRule_2_4_solveCSP_binding = pattern_CreateAttributeRule_2_4_solveCSP_bindingFBBBBBB(
				_this, isApplicableMatch, c2t, a, c, t);
		if (result_pattern_CreateAttributeRule_2_4_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_CreateAttributeRule_2_4_solveCSP_binding[0];

			Object[] result_pattern_CreateAttributeRule_2_4_solveCSP_black = pattern_CreateAttributeRule_2_4_solveCSP_blackB(
					csp);
			if (result_pattern_CreateAttributeRule_2_4_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, c2t, a, c, t };
			}
		}
		return null;
	}

	public static final boolean pattern_CreateAttributeRule_2_5_checkCSP_expressionFBB(CreateAttributeRule _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isApplicable_checkCsp_FWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_2_6_addmatchtoruleresult_blackBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final Object[] pattern_CreateAttributeRule_2_6_addmatchtoruleresult_greenBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		ruleresult.getIsApplicableMatch().add(isApplicableMatch);
		boolean ruleresult_success_prime = Boolean.valueOf(true);
		String isApplicableMatch_ruleName_prime = "CreateAttributeRule";
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		isApplicableMatch.setRuleName(isApplicableMatch_ruleName_prime);
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final IsApplicableRuleResult pattern_CreateAttributeRule_2_7_expressionFB(
			IsApplicableRuleResult ruleresult) {
		IsApplicableRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_10_1_initialbindings_blackBBBB(CreateAttributeRule _this,
			Match match, DBTable t, DBColumn col) {
		return new Object[] { _this, match, t, col };
	}

	public static final Object[] pattern_CreateAttributeRule_10_2_SolveCSP_bindingFBBBB(CreateAttributeRule _this,
			Match match, DBTable t, DBColumn col) {
		CSP _localVariable_0 = _this.isAppropriate_solveCsp_BWD(match, t, col);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, match, t, col };
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_10_2_SolveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_CreateAttributeRule_10_2_SolveCSP_bindingAndBlackFBBBB(
			CreateAttributeRule _this, Match match, DBTable t, DBColumn col) {
		Object[] result_pattern_CreateAttributeRule_10_2_SolveCSP_binding = pattern_CreateAttributeRule_10_2_SolveCSP_bindingFBBBB(
				_this, match, t, col);
		if (result_pattern_CreateAttributeRule_10_2_SolveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_CreateAttributeRule_10_2_SolveCSP_binding[0];

			Object[] result_pattern_CreateAttributeRule_10_2_SolveCSP_black = pattern_CreateAttributeRule_10_2_SolveCSP_blackB(
					csp);
			if (result_pattern_CreateAttributeRule_10_2_SolveCSP_black != null) {

				return new Object[] { csp, _this, match, t, col };
			}
		}
		return null;
	}

	public static final boolean pattern_CreateAttributeRule_10_3_CheckCSP_expressionFBB(CreateAttributeRule _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isAppropriate_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_10_4_collectelementstobetranslated_blackBBB(Match match,
			DBTable t, DBColumn col) {
		return new Object[] { match, t, col };
	}

	public static final Object[] pattern_CreateAttributeRule_10_4_collectelementstobetranslated_greenBBBF(Match match,
			DBTable t, DBColumn col) {
		EMoflonEdge t__col____cols = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getToBeTranslatedNodes().add(col);
		String t__col____cols_name_prime = "cols";
		t__col____cols.setSrc(t);
		t__col____cols.setTrg(col);
		match.getToBeTranslatedEdges().add(t__col____cols);
		t__col____cols.setName(t__col____cols_name_prime);
		return new Object[] { match, t, col, t__col____cols };
	}

	public static final Object[] pattern_CreateAttributeRule_10_5_collectcontextelements_blackBBB(Match match,
			DBTable t, DBColumn col) {
		return new Object[] { match, t, col };
	}

	public static final Object[] pattern_CreateAttributeRule_10_5_collectcontextelements_greenBB(Match match,
			DBTable t) {
		match.getContextNodes().add(t);
		return new Object[] { match, t };
	}

	public static final void pattern_CreateAttributeRule_10_6_registerobjectstomatch_expressionBBBB(
			CreateAttributeRule _this, Match match, DBTable t, DBColumn col) {
		_this.registerObjectsToMatch_BWD(match, t, col);

	}

	public static final boolean pattern_CreateAttributeRule_10_7_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_CreateAttributeRule_10_8_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_11_1_performtransformation_bindingFFFFB(
			IsApplicableMatch isApplicableMatch) {
		EObject _localVariable_0 = isApplicableMatch.getObject("c2t");
		EObject _localVariable_1 = isApplicableMatch.getObject("c");
		EObject _localVariable_2 = isApplicableMatch.getObject("t");
		EObject _localVariable_3 = isApplicableMatch.getObject("col");
		EObject tmpC2t = _localVariable_0;
		EObject tmpC = _localVariable_1;
		EObject tmpT = _localVariable_2;
		EObject tmpCol = _localVariable_3;
		if (tmpC2t instanceof ClassToTable) {
			ClassToTable c2t = (ClassToTable) tmpC2t;
			if (tmpC instanceof CDClass) {
				CDClass c = (CDClass) tmpC;
				if (tmpT instanceof DBTable) {
					DBTable t = (DBTable) tmpT;
					if (tmpCol instanceof DBColumn) {
						DBColumn col = (DBColumn) tmpCol;
						return new Object[] { c2t, c, t, col, isApplicableMatch };
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_11_1_performtransformation_blackBBBBFBB(ClassToTable c2t,
			CDClass c, DBTable t, DBColumn col, CreateAttributeRule _this, IsApplicableMatch isApplicableMatch) {
		for (EObject tmpCsp : isApplicableMatch.getAttributeInfo()) {
			if (tmpCsp instanceof CSP) {
				CSP csp = (CSP) tmpCsp;
				return new Object[] { c2t, c, t, col, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_11_1_performtransformation_bindingAndBlackFFFFFBB(
			CreateAttributeRule _this, IsApplicableMatch isApplicableMatch) {
		Object[] result_pattern_CreateAttributeRule_11_1_performtransformation_binding = pattern_CreateAttributeRule_11_1_performtransformation_bindingFFFFB(
				isApplicableMatch);
		if (result_pattern_CreateAttributeRule_11_1_performtransformation_binding != null) {
			ClassToTable c2t = (ClassToTable) result_pattern_CreateAttributeRule_11_1_performtransformation_binding[0];
			CDClass c = (CDClass) result_pattern_CreateAttributeRule_11_1_performtransformation_binding[1];
			DBTable t = (DBTable) result_pattern_CreateAttributeRule_11_1_performtransformation_binding[2];
			DBColumn col = (DBColumn) result_pattern_CreateAttributeRule_11_1_performtransformation_binding[3];

			Object[] result_pattern_CreateAttributeRule_11_1_performtransformation_black = pattern_CreateAttributeRule_11_1_performtransformation_blackBBBBFBB(
					c2t, c, t, col, _this, isApplicableMatch);
			if (result_pattern_CreateAttributeRule_11_1_performtransformation_black != null) {
				CSP csp = (CSP) result_pattern_CreateAttributeRule_11_1_performtransformation_black[4];

				return new Object[] { c2t, c, t, col, csp, _this, isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_11_1_performtransformation_greenFBB(CDClass c, CSP csp) {
		CDAttribute a = ClassDiagramsFactory.eINSTANCE.createCDAttribute();
		Object _localVariable_0 = csp.getValue("a", "name");
		c.getAttributes().add(a);
		String a_name_prime = (String) _localVariable_0;
		a.setName(a_name_prime);
		return new Object[] { a, c, csp };
	}

	public static final Object[] pattern_CreateAttributeRule_11_2_collecttranslatedelements_blackBB(CDAttribute a,
			DBColumn col) {
		return new Object[] { a, col };
	}

	public static final Object[] pattern_CreateAttributeRule_11_2_collecttranslatedelements_greenFBB(CDAttribute a,
			DBColumn col) {
		PerformRuleResult ruleresult = RuntimeFactory.eINSTANCE.createPerformRuleResult();
		ruleresult.getCreatedElements().add(a);
		ruleresult.getTranslatedElements().add(col);
		return new Object[] { ruleresult, a, col };
	}

	public static final Object[] pattern_CreateAttributeRule_11_3_bookkeepingforedges_blackBBBBBB(
			PerformRuleResult ruleresult, EObject c2t, EObject a, EObject c, EObject t, EObject col) {
		if (!c2t.equals(t)) {
			if (!c2t.equals(col)) {
				if (!a.equals(c2t)) {
					if (!a.equals(c)) {
						if (!a.equals(t)) {
							if (!a.equals(col)) {
								if (!c.equals(c2t)) {
									if (!c.equals(t)) {
										if (!c.equals(col)) {
											if (!col.equals(t)) {
												return new Object[] { ruleresult, c2t, a, c, t, col };
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_11_3_bookkeepingforedges_greenBBBBBFF(
			PerformRuleResult ruleresult, EObject a, EObject c, EObject t, EObject col) {
		EMoflonEdge t__col____cols = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge c__a____attributes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String ruleresult_ruleName_prime = "CreateAttributeRule";
		String t__col____cols_name_prime = "cols";
		String c__a____attributes_name_prime = "attributes";
		t__col____cols.setSrc(t);
		t__col____cols.setTrg(col);
		ruleresult.getTranslatedEdges().add(t__col____cols);
		c__a____attributes.setSrc(c);
		c__a____attributes.setTrg(a);
		ruleresult.getCreatedEdges().add(c__a____attributes);
		ruleresult.setRuleName(ruleresult_ruleName_prime);
		t__col____cols.setName(t__col____cols_name_prime);
		c__a____attributes.setName(c__a____attributes_name_prime);
		return new Object[] { ruleresult, a, c, t, col, t__col____cols, c__a____attributes };
	}

	public static final void pattern_CreateAttributeRule_11_5_registerobjects_expressionBBBBBBB(
			CreateAttributeRule _this, PerformRuleResult ruleresult, EObject c2t, EObject a, EObject c, EObject t,
			EObject col) {
		_this.registerObjects_BWD(ruleresult, c2t, a, c, t, col);

	}

	public static final PerformRuleResult pattern_CreateAttributeRule_11_6_expressionFB(PerformRuleResult ruleresult) {
		PerformRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_12_1_preparereturnvalue_bindingFB(
			CreateAttributeRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass eClass = _localVariable_0;
		if (eClass != null) {
			return new Object[] { eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_12_1_preparereturnvalue_blackFBB(EClass eClass,
			CreateAttributeRule _this) {
		for (EOperation performOperation : eClass.getEOperations()) {
			String performOperation_name = performOperation.getName();
			if (performOperation_name.equals("perform_BWD")) {
				return new Object[] { performOperation, eClass, _this };
			}

		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_12_1_preparereturnvalue_bindingAndBlackFFB(
			CreateAttributeRule _this) {
		Object[] result_pattern_CreateAttributeRule_12_1_preparereturnvalue_binding = pattern_CreateAttributeRule_12_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_CreateAttributeRule_12_1_preparereturnvalue_binding != null) {
			EClass eClass = (EClass) result_pattern_CreateAttributeRule_12_1_preparereturnvalue_binding[0];

			Object[] result_pattern_CreateAttributeRule_12_1_preparereturnvalue_black = pattern_CreateAttributeRule_12_1_preparereturnvalue_blackFBB(
					eClass, _this);
			if (result_pattern_CreateAttributeRule_12_1_preparereturnvalue_black != null) {
				EOperation performOperation = (EOperation) result_pattern_CreateAttributeRule_12_1_preparereturnvalue_black[0];

				return new Object[] { performOperation, eClass, _this };
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_12_1_preparereturnvalue_greenBF(
			EOperation performOperation) {
		IsApplicableRuleResult ruleresult = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		boolean ruleresult_success_prime = Boolean.valueOf(false);
		String ruleresult_rule_prime = "CreateAttributeRule";
		ruleresult.setPerformOperation(performOperation);
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		ruleresult.setRule(ruleresult_rule_prime);
		return new Object[] { performOperation, ruleresult };
	}

	public static final Object[] pattern_CreateAttributeRule_12_2_corematch_bindingFFB(Match match) {
		EObject _localVariable_0 = match.getObject("t");
		EObject _localVariable_1 = match.getObject("col");
		EObject tmpT = _localVariable_0;
		EObject tmpCol = _localVariable_1;
		if (tmpT instanceof DBTable) {
			DBTable t = (DBTable) tmpT;
			if (tmpCol instanceof DBColumn) {
				DBColumn col = (DBColumn) tmpCol;
				return new Object[] { t, col, match };
			}
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_CreateAttributeRule_12_2_corematch_blackFFBBB(DBTable t,
			DBColumn col, Match match) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		for (ClassToTable c2t : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(t,
				ClassToTable.class, "target")) {
			CDClass c = c2t.getSource();
			if (c != null) {
				_result.add(new Object[] { c2t, c, t, col, match });
			}

		}
		return _result;
	}

	public static final Iterable<Object[]> pattern_CreateAttributeRule_12_3_findcontext_blackBBBB(ClassToTable c2t,
			CDClass c, DBTable t, DBColumn col) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (c.equals(c2t.getSource())) {
			if (t.getCols().contains(col)) {
				if (t.equals(c2t.getTarget())) {
					_result.add(new Object[] { c2t, c, t, col });
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_12_3_findcontext_greenBBBBFFFF(ClassToTable c2t, CDClass c,
			DBTable t, DBColumn col) {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		EMoflonEdge c2t__c____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge t__col____cols = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge c2t__t____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String c2t__c____source_name_prime = "source";
		String t__col____cols_name_prime = "cols";
		String c2t__t____target_name_prime = "target";
		isApplicableMatch.getAllContextElements().add(c2t);
		isApplicableMatch.getAllContextElements().add(c);
		isApplicableMatch.getAllContextElements().add(t);
		isApplicableMatch.getAllContextElements().add(col);
		c2t__c____source.setSrc(c2t);
		c2t__c____source.setTrg(c);
		isApplicableMatch.getAllContextElements().add(c2t__c____source);
		t__col____cols.setSrc(t);
		t__col____cols.setTrg(col);
		isApplicableMatch.getAllContextElements().add(t__col____cols);
		c2t__t____target.setSrc(c2t);
		c2t__t____target.setTrg(t);
		isApplicableMatch.getAllContextElements().add(c2t__t____target);
		c2t__c____source.setName(c2t__c____source_name_prime);
		t__col____cols.setName(t__col____cols_name_prime);
		c2t__t____target.setName(c2t__t____target_name_prime);
		return new Object[] { c2t, c, t, col, isApplicableMatch, c2t__c____source, t__col____cols, c2t__t____target };
	}

	public static final Object[] pattern_CreateAttributeRule_12_4_solveCSP_bindingFBBBBBB(CreateAttributeRule _this,
			IsApplicableMatch isApplicableMatch, ClassToTable c2t, CDClass c, DBTable t, DBColumn col) {
		CSP _localVariable_0 = _this.isApplicable_solveCsp_BWD(isApplicableMatch, c2t, c, t, col);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, c2t, c, t, col };
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_12_4_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_CreateAttributeRule_12_4_solveCSP_bindingAndBlackFBBBBBB(
			CreateAttributeRule _this, IsApplicableMatch isApplicableMatch, ClassToTable c2t, CDClass c, DBTable t,
			DBColumn col) {
		Object[] result_pattern_CreateAttributeRule_12_4_solveCSP_binding = pattern_CreateAttributeRule_12_4_solveCSP_bindingFBBBBBB(
				_this, isApplicableMatch, c2t, c, t, col);
		if (result_pattern_CreateAttributeRule_12_4_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_CreateAttributeRule_12_4_solveCSP_binding[0];

			Object[] result_pattern_CreateAttributeRule_12_4_solveCSP_black = pattern_CreateAttributeRule_12_4_solveCSP_blackB(
					csp);
			if (result_pattern_CreateAttributeRule_12_4_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, c2t, c, t, col };
			}
		}
		return null;
	}

	public static final boolean pattern_CreateAttributeRule_12_5_checkCSP_expressionFBB(CreateAttributeRule _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isApplicable_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_12_6_addmatchtoruleresult_blackBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final Object[] pattern_CreateAttributeRule_12_6_addmatchtoruleresult_greenBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		ruleresult.getIsApplicableMatch().add(isApplicableMatch);
		boolean ruleresult_success_prime = Boolean.valueOf(true);
		String isApplicableMatch_ruleName_prime = "CreateAttributeRule";
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		isApplicableMatch.setRuleName(isApplicableMatch_ruleName_prime);
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final IsApplicableRuleResult pattern_CreateAttributeRule_12_7_expressionFB(
			IsApplicableRuleResult ruleresult) {
		IsApplicableRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_20_1_preparereturnvalue_bindingFB(
			CreateAttributeRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass __eClass = _localVariable_0;
		if (__eClass != null) {
			return new Object[] { __eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_20_1_preparereturnvalue_blackFBBF(EClass __eClass,
			CreateAttributeRule _this) {
		for (EOperation __performOperation : __eClass.getEOperations()) {
			String __performOperation_name = __performOperation.getName();
			if (__performOperation_name.equals("isApplicable_FWD")) {
				for (EOperation isApplicableCC : __eClass.getEOperations()) {
					if (!__performOperation.equals(isApplicableCC)) {
						String isApplicableCC_name = isApplicableCC.getName();
						if (isApplicableCC_name.equals("isApplicable_CC")) {
							return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
						}

					}
				}
			}

		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_20_1_preparereturnvalue_bindingAndBlackFFBF(
			CreateAttributeRule _this) {
		Object[] result_pattern_CreateAttributeRule_20_1_preparereturnvalue_binding = pattern_CreateAttributeRule_20_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_CreateAttributeRule_20_1_preparereturnvalue_binding != null) {
			EClass __eClass = (EClass) result_pattern_CreateAttributeRule_20_1_preparereturnvalue_binding[0];

			Object[] result_pattern_CreateAttributeRule_20_1_preparereturnvalue_black = pattern_CreateAttributeRule_20_1_preparereturnvalue_blackFBBF(
					__eClass, _this);
			if (result_pattern_CreateAttributeRule_20_1_preparereturnvalue_black != null) {
				EOperation __performOperation = (EOperation) result_pattern_CreateAttributeRule_20_1_preparereturnvalue_black[0];
				EOperation isApplicableCC = (EOperation) result_pattern_CreateAttributeRule_20_1_preparereturnvalue_black[3];

				return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_20_1_preparereturnvalue_greenF() {
		EObjectContainer __result = RuntimeFactory.eINSTANCE.createEObjectContainer();
		return new Object[] { __result };
	}

	public static final Iterable<Object[]> pattern_CreateAttributeRule_20_2_testcorematchandDECs_blackFFB(
			EMoflonEdge _edge_attributes) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		EObject tmpC = _edge_attributes.getSrc();
		if (tmpC instanceof CDClass) {
			CDClass c = (CDClass) tmpC;
			EObject tmpA = _edge_attributes.getTrg();
			if (tmpA instanceof CDAttribute) {
				CDAttribute a = (CDAttribute) tmpA;
				if (c.getAttributes().contains(a)) {
					_result.add(new Object[] { a, c, _edge_attributes });
				}
			}

		}

		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_20_2_testcorematchandDECs_greenFB(EClass __eClass) {
		Match match = RuntimeFactory.eINSTANCE.createMatch();
		String __eClass_name = __eClass.getName();
		String match_ruleName_prime = __eClass_name;
		match.setRuleName(match_ruleName_prime);
		return new Object[] { match, __eClass };

	}

	public static final boolean pattern_CreateAttributeRule_20_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBB(
			CreateAttributeRule _this, Match match, CDAttribute a, CDClass c) {
		boolean _localVariable_0 = _this.isAppropriate_FWD(match, a, c);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final boolean pattern_CreateAttributeRule_20_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
			CreateAttributeRule _this, Match match) {
		boolean _localVariable_0 = _this.checkTypes_FWD(match);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_20_5_Addmatchtoruleresult_blackBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		if (!__performOperation.equals(isApplicableCC)) {
			return new Object[] { match, __performOperation, __result, isApplicableCC };
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_20_5_Addmatchtoruleresult_greenBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		__result.getContents().add(match);
		match.setIsApplicableOperation(__performOperation);
		match.setIsApplicableCCOperation(isApplicableCC);
		return new Object[] { match, __performOperation, __result, isApplicableCC };
	}

	public static final EObjectContainer pattern_CreateAttributeRule_20_6_expressionFB(EObjectContainer __result) {
		EObjectContainer _result = __result;
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_21_1_preparereturnvalue_bindingFB(
			CreateAttributeRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass __eClass = _localVariable_0;
		if (__eClass != null) {
			return new Object[] { __eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_21_1_preparereturnvalue_blackFBBF(EClass __eClass,
			CreateAttributeRule _this) {
		for (EOperation __performOperation : __eClass.getEOperations()) {
			String __performOperation_name = __performOperation.getName();
			if (__performOperation_name.equals("isApplicable_BWD")) {
				for (EOperation isApplicableCC : __eClass.getEOperations()) {
					if (!__performOperation.equals(isApplicableCC)) {
						String isApplicableCC_name = isApplicableCC.getName();
						if (isApplicableCC_name.equals("isApplicable_CC")) {
							return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
						}

					}
				}
			}

		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_21_1_preparereturnvalue_bindingAndBlackFFBF(
			CreateAttributeRule _this) {
		Object[] result_pattern_CreateAttributeRule_21_1_preparereturnvalue_binding = pattern_CreateAttributeRule_21_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_CreateAttributeRule_21_1_preparereturnvalue_binding != null) {
			EClass __eClass = (EClass) result_pattern_CreateAttributeRule_21_1_preparereturnvalue_binding[0];

			Object[] result_pattern_CreateAttributeRule_21_1_preparereturnvalue_black = pattern_CreateAttributeRule_21_1_preparereturnvalue_blackFBBF(
					__eClass, _this);
			if (result_pattern_CreateAttributeRule_21_1_preparereturnvalue_black != null) {
				EOperation __performOperation = (EOperation) result_pattern_CreateAttributeRule_21_1_preparereturnvalue_black[0];
				EOperation isApplicableCC = (EOperation) result_pattern_CreateAttributeRule_21_1_preparereturnvalue_black[3];

				return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_21_1_preparereturnvalue_greenF() {
		EObjectContainer __result = RuntimeFactory.eINSTANCE.createEObjectContainer();
		return new Object[] { __result };
	}

	public static final Iterable<Object[]> pattern_CreateAttributeRule_21_2_testcorematchandDECs_blackFFB(
			EMoflonEdge _edge_cols) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		EObject tmpT = _edge_cols.getSrc();
		if (tmpT instanceof DBTable) {
			DBTable t = (DBTable) tmpT;
			EObject tmpCol = _edge_cols.getTrg();
			if (tmpCol instanceof DBColumn) {
				DBColumn col = (DBColumn) tmpCol;
				if (t.getCols().contains(col)) {
					_result.add(new Object[] { t, col, _edge_cols });
				}
			}

		}

		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_21_2_testcorematchandDECs_greenFB(EClass __eClass) {
		Match match = RuntimeFactory.eINSTANCE.createMatch();
		String __eClass_name = __eClass.getName();
		String match_ruleName_prime = __eClass_name;
		match.setRuleName(match_ruleName_prime);
		return new Object[] { match, __eClass };

	}

	public static final boolean pattern_CreateAttributeRule_21_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBB(
			CreateAttributeRule _this, Match match, DBTable t, DBColumn col) {
		boolean _localVariable_0 = _this.isAppropriate_BWD(match, t, col);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final boolean pattern_CreateAttributeRule_21_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
			CreateAttributeRule _this, Match match) {
		boolean _localVariable_0 = _this.checkTypes_BWD(match);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_21_5_Addmatchtoruleresult_blackBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		if (!__performOperation.equals(isApplicableCC)) {
			return new Object[] { match, __performOperation, __result, isApplicableCC };
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_21_5_Addmatchtoruleresult_greenBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		__result.getContents().add(match);
		match.setIsApplicableOperation(__performOperation);
		match.setIsApplicableCCOperation(isApplicableCC);
		return new Object[] { match, __performOperation, __result, isApplicableCC };
	}

	public static final EObjectContainer pattern_CreateAttributeRule_21_6_expressionFB(EObjectContainer __result) {
		EObjectContainer _result = __result;
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_24_1_prepare_blackB(CreateAttributeRule _this) {
		return new Object[] { _this };
	}

	public static final Object[] pattern_CreateAttributeRule_24_1_prepare_greenF() {
		IsApplicableRuleResult result = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		return new Object[] { result };
	}

	public static final Object[] pattern_CreateAttributeRule_24_2_matchsrctrgcontext_bindingFFFFBB(Match sourceMatch,
			Match targetMatch) {
		EObject _localVariable_0 = sourceMatch.getObject("a");
		EObject _localVariable_1 = sourceMatch.getObject("c");
		EObject _localVariable_2 = targetMatch.getObject("t");
		EObject _localVariable_3 = targetMatch.getObject("col");
		EObject tmpA = _localVariable_0;
		EObject tmpC = _localVariable_1;
		EObject tmpT = _localVariable_2;
		EObject tmpCol = _localVariable_3;
		if (tmpA instanceof CDAttribute) {
			CDAttribute a = (CDAttribute) tmpA;
			if (tmpC instanceof CDClass) {
				CDClass c = (CDClass) tmpC;
				if (tmpT instanceof DBTable) {
					DBTable t = (DBTable) tmpT;
					if (tmpCol instanceof DBColumn) {
						DBColumn col = (DBColumn) tmpCol;
						return new Object[] { a, c, t, col, sourceMatch, targetMatch };
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_24_2_matchsrctrgcontext_blackBBBBBB(CDAttribute a,
			CDClass c, DBTable t, DBColumn col, Match sourceMatch, Match targetMatch) {
		if (!sourceMatch.equals(targetMatch)) {
			return new Object[] { a, c, t, col, sourceMatch, targetMatch };
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_24_2_matchsrctrgcontext_bindingAndBlackFFFFBB(
			Match sourceMatch, Match targetMatch) {
		Object[] result_pattern_CreateAttributeRule_24_2_matchsrctrgcontext_binding = pattern_CreateAttributeRule_24_2_matchsrctrgcontext_bindingFFFFBB(
				sourceMatch, targetMatch);
		if (result_pattern_CreateAttributeRule_24_2_matchsrctrgcontext_binding != null) {
			CDAttribute a = (CDAttribute) result_pattern_CreateAttributeRule_24_2_matchsrctrgcontext_binding[0];
			CDClass c = (CDClass) result_pattern_CreateAttributeRule_24_2_matchsrctrgcontext_binding[1];
			DBTable t = (DBTable) result_pattern_CreateAttributeRule_24_2_matchsrctrgcontext_binding[2];
			DBColumn col = (DBColumn) result_pattern_CreateAttributeRule_24_2_matchsrctrgcontext_binding[3];

			Object[] result_pattern_CreateAttributeRule_24_2_matchsrctrgcontext_black = pattern_CreateAttributeRule_24_2_matchsrctrgcontext_blackBBBBBB(
					a, c, t, col, sourceMatch, targetMatch);
			if (result_pattern_CreateAttributeRule_24_2_matchsrctrgcontext_black != null) {

				return new Object[] { a, c, t, col, sourceMatch, targetMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_24_3_solvecsp_bindingFBBBBBBB(CreateAttributeRule _this,
			CDAttribute a, CDClass c, DBTable t, DBColumn col, Match sourceMatch, Match targetMatch) {
		CSP _localVariable_4 = _this.isApplicable_solveCsp_CC(a, c, t, col, sourceMatch, targetMatch);
		CSP csp = _localVariable_4;
		if (csp != null) {
			return new Object[] { csp, _this, a, c, t, col, sourceMatch, targetMatch };
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_24_3_solvecsp_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_CreateAttributeRule_24_3_solvecsp_bindingAndBlackFBBBBBBB(
			CreateAttributeRule _this, CDAttribute a, CDClass c, DBTable t, DBColumn col, Match sourceMatch,
			Match targetMatch) {
		Object[] result_pattern_CreateAttributeRule_24_3_solvecsp_binding = pattern_CreateAttributeRule_24_3_solvecsp_bindingFBBBBBBB(
				_this, a, c, t, col, sourceMatch, targetMatch);
		if (result_pattern_CreateAttributeRule_24_3_solvecsp_binding != null) {
			CSP csp = (CSP) result_pattern_CreateAttributeRule_24_3_solvecsp_binding[0];

			Object[] result_pattern_CreateAttributeRule_24_3_solvecsp_black = pattern_CreateAttributeRule_24_3_solvecsp_blackB(
					csp);
			if (result_pattern_CreateAttributeRule_24_3_solvecsp_black != null) {

				return new Object[] { csp, _this, a, c, t, col, sourceMatch, targetMatch };
			}
		}
		return null;
	}

	public static final boolean pattern_CreateAttributeRule_24_4_checkCSP_expressionFB(CSP csp) {
		boolean _localVariable_0 = csp.check();
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Iterable<Object[]> pattern_CreateAttributeRule_24_5_matchcorrcontext_blackFBBBB(CDClass c,
			DBTable t, Match sourceMatch, Match targetMatch) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!sourceMatch.equals(targetMatch)) {
			for (ClassToTable c2t : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(c,
					ClassToTable.class, "source")) {
				if (t.equals(c2t.getTarget())) {
					_result.add(new Object[] { c2t, c, t, sourceMatch, targetMatch });
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_24_5_matchcorrcontext_greenBBBF(ClassToTable c2t,
			Match sourceMatch, Match targetMatch) {
		CCMatch ccMatch = RuntimeFactory.eINSTANCE.createCCMatch();
		String ccMatch_ruleName_prime = "CreateAttributeRule";
		ccMatch.setSourceMatch(sourceMatch);
		ccMatch.setTargetMatch(targetMatch);
		ccMatch.getAllContextElements().add(c2t);
		ccMatch.setRuleName(ccMatch_ruleName_prime);
		return new Object[] { c2t, sourceMatch, targetMatch, ccMatch };
	}

	public static final Object[] pattern_CreateAttributeRule_24_6_createcorrespondence_blackBBBBB(CDAttribute a,
			CDClass c, DBTable t, DBColumn col, CCMatch ccMatch) {
		return new Object[] { a, c, t, col, ccMatch };
	}

	public static final Object[] pattern_CreateAttributeRule_24_7_addtoreturnedresult_blackBB(
			IsApplicableRuleResult result, CCMatch ccMatch) {
		return new Object[] { result, ccMatch };
	}

	public static final Object[] pattern_CreateAttributeRule_24_7_addtoreturnedresult_greenBB(
			IsApplicableRuleResult result, CCMatch ccMatch) {
		result.getIsApplicableMatch().add(ccMatch);
		boolean result_success_prime = Boolean.valueOf(true);
		String ccMatch_ruleName_prime = "CreateAttributeRule";
		result.setSuccess(Boolean.valueOf(result_success_prime));
		ccMatch.setRuleName(ccMatch_ruleName_prime);
		return new Object[] { result, ccMatch };
	}

	public static final IsApplicableRuleResult pattern_CreateAttributeRule_24_8_expressionFB(
			IsApplicableRuleResult result) {
		IsApplicableRuleResult _result = result;
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_27_1_matchtggpattern_blackBB(CDAttribute a, CDClass c) {
		if (c.getAttributes().contains(a)) {
			return new Object[] { a, c };
		}
		return null;
	}

	public static final boolean pattern_CreateAttributeRule_27_2_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_CreateAttributeRule_27_3_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_28_1_matchtggpattern_blackBB(DBTable t, DBColumn col) {
		if (t.getCols().contains(col)) {
			return new Object[] { t, col };
		}
		return null;
	}

	public static final boolean pattern_CreateAttributeRule_28_2_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_CreateAttributeRule_28_3_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_29_1_createresult_blackB(CreateAttributeRule _this) {
		return new Object[] { _this };
	}

	public static final Object[] pattern_CreateAttributeRule_29_1_createresult_greenFF() {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		ModelgeneratorRuleResult ruleResult = RuntimeFactory.eINSTANCE.createModelgeneratorRuleResult();
		boolean ruleResult_success_prime = Boolean.valueOf(false);
		ruleResult.setSuccess(Boolean.valueOf(ruleResult_success_prime));
		return new Object[] { isApplicableMatch, ruleResult };
	}

	public static final Object[] pattern_CreateAttributeRule_29_2_isapplicablecore_black_nac_0BB(
			ModelgeneratorRuleResult ruleResult, ClassToTable c2t) {
		if (ruleResult.getCorrObjects().contains(c2t)) {
			return new Object[] { ruleResult, c2t };
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_29_2_isapplicablecore_black_nac_1BB(
			ModelgeneratorRuleResult ruleResult, CDClass c) {
		if (ruleResult.getSourceObjects().contains(c)) {
			return new Object[] { ruleResult, c };
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_29_2_isapplicablecore_black_nac_2BB(
			ModelgeneratorRuleResult ruleResult, DBTable t) {
		if (ruleResult.getTargetObjects().contains(t)) {
			return new Object[] { ruleResult, t };
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_CreateAttributeRule_29_2_isapplicablecore_blackFFFFBB(
			RuleEntryContainer ruleEntryContainer, ModelgeneratorRuleResult ruleResult) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		for (RuleEntryList c2tList : ruleEntryContainer.getRuleEntryList()) {
			for (EObject tmpC2t : c2tList.getEntryObjects()) {
				if (tmpC2t instanceof ClassToTable) {
					ClassToTable c2t = (ClassToTable) tmpC2t;
					CDClass c = c2t.getSource();
					if (c != null) {
						DBTable t = c2t.getTarget();
						if (t != null) {
							if (pattern_CreateAttributeRule_29_2_isapplicablecore_black_nac_0BB(ruleResult,
									c2t) == null) {
								if (pattern_CreateAttributeRule_29_2_isapplicablecore_black_nac_1BB(ruleResult,
										c) == null) {
									if (pattern_CreateAttributeRule_29_2_isapplicablecore_black_nac_2BB(ruleResult,
											t) == null) {
										_result.add(
												new Object[] { c2tList, c2t, c, t, ruleEntryContainer, ruleResult });
									}
								}
							}
						}

					}

				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_29_3_solveCSP_bindingFBBBBBB(CreateAttributeRule _this,
			IsApplicableMatch isApplicableMatch, ClassToTable c2t, CDClass c, DBTable t,
			ModelgeneratorRuleResult ruleResult) {
		CSP _localVariable_0 = _this.generateModel_solveCsp_BWD(isApplicableMatch, c2t, c, t, ruleResult);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, c2t, c, t, ruleResult };
		}
		return null;
	}

	public static final Object[] pattern_CreateAttributeRule_29_3_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_CreateAttributeRule_29_3_solveCSP_bindingAndBlackFBBBBBB(
			CreateAttributeRule _this, IsApplicableMatch isApplicableMatch, ClassToTable c2t, CDClass c, DBTable t,
			ModelgeneratorRuleResult ruleResult) {
		Object[] result_pattern_CreateAttributeRule_29_3_solveCSP_binding = pattern_CreateAttributeRule_29_3_solveCSP_bindingFBBBBBB(
				_this, isApplicableMatch, c2t, c, t, ruleResult);
		if (result_pattern_CreateAttributeRule_29_3_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_CreateAttributeRule_29_3_solveCSP_binding[0];

			Object[] result_pattern_CreateAttributeRule_29_3_solveCSP_black = pattern_CreateAttributeRule_29_3_solveCSP_blackB(
					csp);
			if (result_pattern_CreateAttributeRule_29_3_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, c2t, c, t, ruleResult };
			}
		}
		return null;
	}

	public static final boolean pattern_CreateAttributeRule_29_4_checkCSP_expressionFBB(CreateAttributeRule _this,
			CSP csp) {
		boolean _localVariable_0 = _this.generateModel_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_CreateAttributeRule_29_5_checknacs_blackBBB(ClassToTable c2t, CDClass c,
			DBTable t) {
		return new Object[] { c2t, c, t };
	}

	public static final Object[] pattern_CreateAttributeRule_29_6_perform_blackBBBB(ClassToTable c2t, CDClass c,
			DBTable t, ModelgeneratorRuleResult ruleResult) {
		return new Object[] { c2t, c, t, ruleResult };
	}

	public static final Object[] pattern_CreateAttributeRule_29_6_perform_greenFBBFBB(CDClass c, DBTable t,
			ModelgeneratorRuleResult ruleResult, CSP csp) {
		CDAttribute a = ClassDiagramsFactory.eINSTANCE.createCDAttribute();
		DBColumn col = DatabaseSchemataFactory.eINSTANCE.createDBColumn();
		Object _localVariable_0 = csp.getValue("a", "name");
		Object _localVariable_1 = csp.getValue("col", "name");
		boolean ruleResult_success_prime = Boolean.valueOf(true);
		int _localVariable_2 = ruleResult.getIncrementedPerformCount();
		c.getAttributes().add(a);
		ruleResult.getSourceObjects().add(a);
		t.getCols().add(col);
		ruleResult.getTargetObjects().add(col);
		String a_name_prime = (String) _localVariable_0;
		String col_name_prime = (String) _localVariable_1;
		ruleResult.setSuccess(Boolean.valueOf(ruleResult_success_prime));
		int ruleResult_performCount_prime = Integer.valueOf(_localVariable_2);
		a.setName(a_name_prime);
		col.setName(col_name_prime);
		ruleResult.setPerformCount(Integer.valueOf(ruleResult_performCount_prime));
		return new Object[] { a, c, t, col, ruleResult, csp };
	}

	public static final ModelgeneratorRuleResult pattern_CreateAttributeRule_29_7_expressionFB(
			ModelgeneratorRuleResult ruleResult) {
		ModelgeneratorRuleResult _result = ruleResult;
		return _result;
	}

	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //CreateAttributeRuleImpl
