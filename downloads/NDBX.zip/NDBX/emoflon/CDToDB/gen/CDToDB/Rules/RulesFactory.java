/**
 */
package CDToDB.Rules;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see CDToDB.Rules.RulesPackage
 * @generated
 */
public interface RulesFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	RulesFactory eINSTANCE = CDToDB.Rules.impl.RulesFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Transfer Cols Rule</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Transfer Cols Rule</em>'.
	 * @generated
	 */
	TransferColsRule createTransferColsRule();

	/**
	 * Returns a new object of class '<em>Class To Table Rule</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Class To Table Rule</em>'.
	 * @generated
	 */
	ClassToTableRule createClassToTableRule();

	/**
	 * Returns a new object of class '<em>Transitive Corrs Above</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Transitive Corrs Above</em>'.
	 * @generated
	 */
	TransitiveCorrsAbove createTransitiveCorrsAbove();

	/**
	 * Returns a new object of class '<em>Create Inheritance Rule</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Create Inheritance Rule</em>'.
	 * @generated
	 */
	CreateInheritanceRule createCreateInheritanceRule();

	/**
	 * Returns a new object of class '<em>Package To Schema Rule</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Package To Schema Rule</em>'.
	 * @generated
	 */
	PackageToSchemaRule createPackageToSchemaRule();

	/**
	 * Returns a new object of class '<em>Transitive Attribute Rule</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Transitive Attribute Rule</em>'.
	 * @generated
	 */
	TransitiveAttributeRule createTransitiveAttributeRule();

	/**
	 * Returns a new object of class '<em>Create Attribute Rule</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Create Attribute Rule</em>'.
	 * @generated
	 */
	CreateAttributeRule createCreateAttributeRule();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	RulesPackage getRulesPackage();

} //RulesFactory
