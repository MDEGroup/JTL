/**
 */
package CDToDB.Rules.impl;

import CDToDB.CDToDBFactory;
import CDToDB.ClassToTable;
import CDToDB.PackageToSchema;

import CDToDB.Rules.CreateInheritanceRule;
import CDToDB.Rules.RulesPackage;

import CDToDB.SuperClassToTable;

import ClassDiagrams.CDClass;
import ClassDiagrams.CDPackage;
import ClassDiagrams.ClassDiagramsFactory;

import DatabaseSchemata.DBSchema;
import DatabaseSchemata.DBTable;
import DatabaseSchemata.DatabaseSchemataFactory;

import java.lang.Iterable;

import java.lang.reflect.InvocationTargetException;

import java.util.LinkedList;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EOperation;

import org.moflon.tgg.language.csp.CSP;

import org.moflon.tgg.language.modelgenerator.RuleEntryContainer;
import org.moflon.tgg.language.modelgenerator.RuleEntryList;

import org.moflon.tgg.runtime.AttributeConstraintsRuleResult;
import org.moflon.tgg.runtime.CCMatch;
import org.moflon.tgg.runtime.EMoflonEdge;
import org.moflon.tgg.runtime.EObjectContainer;
import org.moflon.tgg.runtime.IsApplicableMatch;
import org.moflon.tgg.runtime.IsApplicableRuleResult;
import org.moflon.tgg.runtime.Match;
import org.moflon.tgg.runtime.ModelgeneratorRuleResult;
import org.moflon.tgg.runtime.PerformRuleResult;
import org.moflon.tgg.runtime.RuntimeFactory;
import org.moflon.tgg.runtime.TripleMatch;

import org.moflon.tgg.runtime.impl.AbstractRuleImpl;
// <-- [user defined imports]
import org.moflon.tgg.csp.*;
import CDToDB.csp.constraints.*;
import org.moflon.tgg.csp.constraints.*;
import org.moflon.tgg.language.csp.*;
import org.moflon.tgg.runtime.TripleMatchNodeMapping;
import java.util.Optional;
import org.moflon.tgg.algorithm.delta.attribute.CheckAttributeHelper;
import SDMLanguage.expressions.ComparingOperator;
import org.moflon.tgg.runtime.TripleMatchNodeMapping;
import java.util.Optional;
import org.moflon.tgg.algorithm.delta.attribute.CheckAttributeHelper;
import SDMLanguage.expressions.ComparingOperator;
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Create Inheritance Rule</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class CreateInheritanceRuleImpl extends AbstractRuleImpl implements CreateInheritanceRule {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CreateInheritanceRuleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RulesPackage.eINSTANCE.getCreateInheritanceRule();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_FWD(Match match, CDClass superClass, CDClass subClass, CDPackage p) {

		Object[] result1_black = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_0_1_initialbindings_blackBBBBB(this, match, superClass, subClass, p);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[match] = " + match + ", " + "[superClass] = " + superClass + ", " + "[subClass] = " + subClass
					+ ", " + "[p] = " + p + ".");
		}

		Object[] result2_bindingAndBlack = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_0_2_SolveCSP_bindingAndBlackFBBBBB(this, match, superClass, subClass, p);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[match] = " + match + ", " + "[superClass] = " + superClass + ", " + "[subClass] = " + subClass
					+ ", " + "[p] = " + p + ".");
		}
		CSP csp = (CSP) result2_bindingAndBlack[0];
		// 
		if (CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_0_3_CheckCSP_expressionFBB(this, csp)) {

			Object[] result4_black = CreateInheritanceRuleImpl
					.pattern_CreateInheritanceRule_0_4_collectelementstobetranslated_blackBBBB(match, superClass,
							subClass, p);
			if (result4_black == null) {
				throw new RuntimeException(
						"Pattern matching failed." + " Variables: " + "[match] = " + match + ", " + "[superClass] = "
								+ superClass + ", " + "[subClass] = " + subClass + ", " + "[p] = " + p + ".");
			}
			CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_0_4_collectelementstobetranslated_greenBBBBFF(match,
					superClass, subClass, p);
			//nothing EMoflonEdge p__subClass____classes = (EMoflonEdge) result4_green[4];
			//nothing EMoflonEdge subClass__superClass____superClass = (EMoflonEdge) result4_green[5];

			Object[] result5_black = CreateInheritanceRuleImpl
					.pattern_CreateInheritanceRule_0_5_collectcontextelements_blackBBBB(match, superClass, subClass, p);
			if (result5_black == null) {
				throw new RuntimeException(
						"Pattern matching failed." + " Variables: " + "[match] = " + match + ", " + "[superClass] = "
								+ superClass + ", " + "[subClass] = " + subClass + ", " + "[p] = " + p + ".");
			}
			CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_0_5_collectcontextelements_greenBBBF(match,
					superClass, p);
			//nothing EMoflonEdge p__superClass____classes = (EMoflonEdge) result5_green[3];

			// 
			CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_0_6_registerobjectstomatch_expressionBBBBB(this,
					match, superClass, subClass, p);
			return CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_0_7_expressionF();
		} else {
			return CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_0_8_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformRuleResult perform_FWD(IsApplicableMatch isApplicableMatch) {

		Object[] result1_bindingAndBlack = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_1_1_performtransformation_bindingAndBlackFFFFFFFFBB(this,
						isApplicableMatch);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[isApplicableMatch] = " + isApplicableMatch + ".");
		}
		ClassToTable supCorr = (ClassToTable) result1_bindingAndBlack[0];
		DBTable superTable = (DBTable) result1_bindingAndBlack[1];
		CDClass superClass = (CDClass) result1_bindingAndBlack[2];
		PackageToSchema p2s = (PackageToSchema) result1_bindingAndBlack[3];
		CDClass subClass = (CDClass) result1_bindingAndBlack[4];
		CDPackage p = (CDPackage) result1_bindingAndBlack[5];
		DBSchema s = (DBSchema) result1_bindingAndBlack[6];
		CSP csp = (CSP) result1_bindingAndBlack[7];
		Object[] result1_green = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_1_1_performtransformation_greenFFBFBBB(superClass, subClass, s, csp);
		SuperClassToTable transitiveCorr = (SuperClassToTable) result1_green[0];
		ClassToTable subCorr = (ClassToTable) result1_green[1];
		DBTable subTable = (DBTable) result1_green[3];

		Object[] result2_black = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_1_2_collecttranslatedelements_blackBBBB(transitiveCorr, subCorr,
						subTable, subClass);
		if (result2_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[transitiveCorr] = "
					+ transitiveCorr + ", " + "[subCorr] = " + subCorr + ", " + "[subTable] = " + subTable + ", "
					+ "[subClass] = " + subClass + ".");
		}
		Object[] result2_green = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_1_2_collecttranslatedelements_greenFBBBB(transitiveCorr, subCorr,
						subTable, subClass);
		PerformRuleResult ruleresult = (PerformRuleResult) result2_green[0];

		Object[] result3_black = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_1_3_bookkeepingforedges_blackBBBBBBBBBBB(ruleresult, transitiveCorr,
						subCorr, supCorr, superTable, superClass, subTable, p2s, subClass, p, s);
		if (result3_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[ruleresult] = " + ruleresult
					+ ", " + "[transitiveCorr] = " + transitiveCorr + ", " + "[subCorr] = " + subCorr + ", "
					+ "[supCorr] = " + supCorr + ", " + "[superTable] = " + superTable + ", " + "[superClass] = "
					+ superClass + ", " + "[subTable] = " + subTable + ", " + "[p2s] = " + p2s + ", " + "[subClass] = "
					+ subClass + ", " + "[p] = " + p + ", " + "[s] = " + s + ".");
		}
		CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_1_3_bookkeepingforedges_greenBBBBBBBBFFFFFFF(ruleresult,
				transitiveCorr, subCorr, superClass, subTable, subClass, p, s);
		//nothing EMoflonEdge transitiveCorr__superClass____source = (EMoflonEdge) result3_green[8];
		//nothing EMoflonEdge transitiveCorr__subTable____target = (EMoflonEdge) result3_green[9];
		//nothing EMoflonEdge subCorr__subClass____source = (EMoflonEdge) result3_green[10];
		//nothing EMoflonEdge subCorr__subTable____target = (EMoflonEdge) result3_green[11];
		//nothing EMoflonEdge p__subClass____classes = (EMoflonEdge) result3_green[12];
		//nothing EMoflonEdge subClass__superClass____superClass = (EMoflonEdge) result3_green[13];
		//nothing EMoflonEdge s__subTable____tables = (EMoflonEdge) result3_green[14];

		// 
		// 
		CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_1_5_registerobjects_expressionBBBBBBBBBBBB(this,
				ruleresult, transitiveCorr, subCorr, supCorr, superTable, superClass, subTable, p2s, subClass, p, s);
		return CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_1_6_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_FWD(Match match) {

		Object[] result1_bindingAndBlack = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_2_1_preparereturnvalue_bindingAndBlackFFB(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		EOperation performOperation = (EOperation) result1_bindingAndBlack[0];
		//nothing EClass eClass = (EClass) result1_bindingAndBlack[1];
		Object[] result1_green = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_2_1_preparereturnvalue_greenBF(performOperation);
		IsApplicableRuleResult ruleresult = (IsApplicableRuleResult) result1_green[1];

		// ForEach 
		Object[] result2_binding = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_2_2_corematch_bindingFFFB(match);
		if (result2_binding == null) {
			throw new RuntimeException(
					"Binding in node core match failed." + " Variables: " + "[match] = " + match + ".");
		}
		CDClass superClass = (CDClass) result2_binding[0];
		CDClass subClass = (CDClass) result2_binding[1];
		CDPackage p = (CDPackage) result2_binding[2];
		for (Object[] result2_black : CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_2_2_corematch_blackFFBFBBFB(superClass, subClass, p, match)) {
			ClassToTable supCorr = (ClassToTable) result2_black[0];
			DBTable superTable = (DBTable) result2_black[1];
			PackageToSchema p2s = (PackageToSchema) result2_black[3];
			DBSchema s = (DBSchema) result2_black[6];
			// ForEach 
			for (Object[] result3_black : CreateInheritanceRuleImpl
					.pattern_CreateInheritanceRule_2_3_findcontext_blackBBBBBBB(supCorr, superTable, superClass, p2s,
							subClass, p, s)) {
				Object[] result3_green = CreateInheritanceRuleImpl
						.pattern_CreateInheritanceRule_2_3_findcontext_greenBBBBBBBFFFFFFFFF(supCorr, superTable,
								superClass, p2s, subClass, p, s);
				IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result3_green[7];
				//nothing EMoflonEdge supCorr__superTable____target = (EMoflonEdge) result3_green[8];
				//nothing EMoflonEdge p__subClass____classes = (EMoflonEdge) result3_green[9];
				//nothing EMoflonEdge p2s__p____source = (EMoflonEdge) result3_green[10];
				//nothing EMoflonEdge s__superTable____tables = (EMoflonEdge) result3_green[11];
				//nothing EMoflonEdge subClass__superClass____superClass = (EMoflonEdge) result3_green[12];
				//nothing EMoflonEdge supCorr__superClass____source = (EMoflonEdge) result3_green[13];
				//nothing EMoflonEdge p2s__s____target = (EMoflonEdge) result3_green[14];
				//nothing EMoflonEdge p__superClass____classes = (EMoflonEdge) result3_green[15];

				Object[] result4_bindingAndBlack = CreateInheritanceRuleImpl
						.pattern_CreateInheritanceRule_2_4_solveCSP_bindingAndBlackFBBBBBBBBB(this, isApplicableMatch,
								supCorr, superTable, superClass, p2s, subClass, p, s);
				if (result4_bindingAndBlack == null) {
					throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
							+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[supCorr] = " + supCorr + ", "
							+ "[superTable] = " + superTable + ", " + "[superClass] = " + superClass + ", " + "[p2s] = "
							+ p2s + ", " + "[subClass] = " + subClass + ", " + "[p] = " + p + ", " + "[s] = " + s
							+ ".");
				}
				CSP csp = (CSP) result4_bindingAndBlack[0];
				// 
				if (CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_2_5_checkCSP_expressionFBB(this, csp)) {

					Object[] result6_black = CreateInheritanceRuleImpl
							.pattern_CreateInheritanceRule_2_6_addmatchtoruleresult_blackBB(ruleresult,
									isApplicableMatch);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[ruleresult] = "
								+ ruleresult + ", " + "[isApplicableMatch] = " + isApplicableMatch + ".");
					}
					CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_2_6_addmatchtoruleresult_greenBB(ruleresult,
							isApplicableMatch);

				} else {
				}

			}

		}
		return CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_2_7_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjectsToMatch_FWD(Match match, CDClass superClass, CDClass subClass, CDPackage p) {
		match.registerObject("superClass", superClass);
		match.registerObject("subClass", subClass);
		match.registerObject("p", p);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isAppropriate_solveCsp_FWD(Match match, CDClass superClass, CDClass subClass, CDPackage p) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables

		// Create unbound variables

		// Create constraints

		// Solve CSP
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_checkCsp_FWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_FWD(IsApplicableMatch isApplicableMatch, ClassToTable supCorr, DBTable superTable,
			CDClass superClass, PackageToSchema p2s, CDClass subClass, CDPackage p, DBSchema s) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables
		Variable var_subClass_name = CSPFactoryHelper.eINSTANCE.createVariable("subClass.name", true, csp);
		var_subClass_name.setValue(subClass.getName());
		var_subClass_name.setType("String");

		// Create unbound variables
		Variable var_subTable_name = CSPFactoryHelper.eINSTANCE.createVariable("subTable.name", csp);
		var_subTable_name.setType("String");

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_subClass_name, var_subTable_name);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("supCorr", supCorr);
		isApplicableMatch.registerObject("superTable", superTable);
		isApplicableMatch.registerObject("superClass", superClass);
		isApplicableMatch.registerObject("p2s", p2s);
		isApplicableMatch.registerObject("subClass", subClass);
		isApplicableMatch.registerObject("p", p);
		isApplicableMatch.registerObject("s", s);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_FWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjects_FWD(PerformRuleResult ruleresult, EObject transitiveCorr, EObject subCorr,
			EObject supCorr, EObject superTable, EObject superClass, EObject subTable, EObject p2s, EObject subClass,
			EObject p, EObject s) {
		ruleresult.registerObject("transitiveCorr", transitiveCorr);
		ruleresult.registerObject("subCorr", subCorr);
		ruleresult.registerObject("supCorr", supCorr);
		ruleresult.registerObject("superTable", superTable);
		ruleresult.registerObject("superClass", superClass);
		ruleresult.registerObject("subTable", subTable);
		ruleresult.registerObject("p2s", p2s);
		ruleresult.registerObject("subClass", subClass);
		ruleresult.registerObject("p", p);
		ruleresult.registerObject("s", s);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkTypes_FWD(Match match) {
		return true && org.moflon.util.eMoflonSDMUtil.getFQN(match.getObject("subClass").eClass())
				.equals("ClassDiagrams.CDClass.");
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_BWD(Match match, DBTable superTable, DBTable subTable, DBSchema s) {

		Object[] result1_black = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_10_1_initialbindings_blackBBBBB(this, match, superTable, subTable, s);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[match] = " + match + ", " + "[superTable] = " + superTable + ", " + "[subTable] = " + subTable
					+ ", " + "[s] = " + s + ".");
		}

		Object[] result2_bindingAndBlack = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_10_2_SolveCSP_bindingAndBlackFBBBBB(this, match, superTable, subTable,
						s);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[match] = " + match + ", " + "[superTable] = " + superTable + ", " + "[subTable] = " + subTable
					+ ", " + "[s] = " + s + ".");
		}
		CSP csp = (CSP) result2_bindingAndBlack[0];
		// 
		if (CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_10_3_CheckCSP_expressionFBB(this, csp)) {

			Object[] result4_black = CreateInheritanceRuleImpl
					.pattern_CreateInheritanceRule_10_4_collectelementstobetranslated_blackBBBB(match, superTable,
							subTable, s);
			if (result4_black == null) {
				throw new RuntimeException(
						"Pattern matching failed." + " Variables: " + "[match] = " + match + ", " + "[superTable] = "
								+ superTable + ", " + "[subTable] = " + subTable + ", " + "[s] = " + s + ".");
			}
			CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_10_4_collectelementstobetranslated_greenBBBF(match,
					subTable, s);
			//nothing EMoflonEdge s__subTable____tables = (EMoflonEdge) result4_green[3];

			Object[] result5_black = CreateInheritanceRuleImpl
					.pattern_CreateInheritanceRule_10_5_collectcontextelements_blackBBBB(match, superTable, subTable,
							s);
			if (result5_black == null) {
				throw new RuntimeException(
						"Pattern matching failed." + " Variables: " + "[match] = " + match + ", " + "[superTable] = "
								+ superTable + ", " + "[subTable] = " + subTable + ", " + "[s] = " + s + ".");
			}
			CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_10_5_collectcontextelements_greenBBBF(match,
					superTable, s);
			//nothing EMoflonEdge s__superTable____tables = (EMoflonEdge) result5_green[3];

			// 
			CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_10_6_registerobjectstomatch_expressionBBBBB(this,
					match, superTable, subTable, s);
			return CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_10_7_expressionF();
		} else {
			return CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_10_8_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PerformRuleResult perform_BWD(IsApplicableMatch isApplicableMatch) {

		Object[] result1_bindingAndBlack = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_11_1_performtransformation_bindingAndBlackFFFFFFFFBB(this,
						isApplicableMatch);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[isApplicableMatch] = " + isApplicableMatch + ".");
		}
		ClassToTable supCorr = (ClassToTable) result1_bindingAndBlack[0];
		DBTable superTable = (DBTable) result1_bindingAndBlack[1];
		CDClass superClass = (CDClass) result1_bindingAndBlack[2];
		DBTable subTable = (DBTable) result1_bindingAndBlack[3];
		PackageToSchema p2s = (PackageToSchema) result1_bindingAndBlack[4];
		CDPackage p = (CDPackage) result1_bindingAndBlack[5];
		DBSchema s = (DBSchema) result1_bindingAndBlack[6];
		CSP csp = (CSP) result1_bindingAndBlack[7];
		Object[] result1_green = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_11_1_performtransformation_greenFFBBFBB(superClass, subTable, p, csp);
		SuperClassToTable transitiveCorr = (SuperClassToTable) result1_green[0];
		ClassToTable subCorr = (ClassToTable) result1_green[1];
		CDClass subClass = (CDClass) result1_green[4];

		Object[] result2_black = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_11_2_collecttranslatedelements_blackBBBB(transitiveCorr, subCorr,
						subTable, subClass);
		if (result2_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[transitiveCorr] = "
					+ transitiveCorr + ", " + "[subCorr] = " + subCorr + ", " + "[subTable] = " + subTable + ", "
					+ "[subClass] = " + subClass + ".");
		}
		Object[] result2_green = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_11_2_collecttranslatedelements_greenFBBBB(transitiveCorr, subCorr,
						subTable, subClass);
		PerformRuleResult ruleresult = (PerformRuleResult) result2_green[0];

		Object[] result3_black = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_11_3_bookkeepingforedges_blackBBBBBBBBBBB(ruleresult, transitiveCorr,
						subCorr, supCorr, superTable, superClass, subTable, p2s, subClass, p, s);
		if (result3_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[ruleresult] = " + ruleresult
					+ ", " + "[transitiveCorr] = " + transitiveCorr + ", " + "[subCorr] = " + subCorr + ", "
					+ "[supCorr] = " + supCorr + ", " + "[superTable] = " + superTable + ", " + "[superClass] = "
					+ superClass + ", " + "[subTable] = " + subTable + ", " + "[p2s] = " + p2s + ", " + "[subClass] = "
					+ subClass + ", " + "[p] = " + p + ", " + "[s] = " + s + ".");
		}
		CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_11_3_bookkeepingforedges_greenBBBBBBBBFFFFFFF(
				ruleresult, transitiveCorr, subCorr, superClass, subTable, subClass, p, s);
		//nothing EMoflonEdge transitiveCorr__superClass____source = (EMoflonEdge) result3_green[8];
		//nothing EMoflonEdge transitiveCorr__subTable____target = (EMoflonEdge) result3_green[9];
		//nothing EMoflonEdge subCorr__subClass____source = (EMoflonEdge) result3_green[10];
		//nothing EMoflonEdge subCorr__subTable____target = (EMoflonEdge) result3_green[11];
		//nothing EMoflonEdge p__subClass____classes = (EMoflonEdge) result3_green[12];
		//nothing EMoflonEdge subClass__superClass____superClass = (EMoflonEdge) result3_green[13];
		//nothing EMoflonEdge s__subTable____tables = (EMoflonEdge) result3_green[14];

		// 
		// 
		CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_11_5_registerobjects_expressionBBBBBBBBBBBB(this,
				ruleresult, transitiveCorr, subCorr, supCorr, superTable, superClass, subTable, p2s, subClass, p, s);
		return CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_11_6_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_BWD(Match match) {

		Object[] result1_bindingAndBlack = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_12_1_preparereturnvalue_bindingAndBlackFFB(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		EOperation performOperation = (EOperation) result1_bindingAndBlack[0];
		//nothing EClass eClass = (EClass) result1_bindingAndBlack[1];
		Object[] result1_green = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_12_1_preparereturnvalue_greenBF(performOperation);
		IsApplicableRuleResult ruleresult = (IsApplicableRuleResult) result1_green[1];

		// ForEach 
		Object[] result2_binding = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_12_2_corematch_bindingFFFB(match);
		if (result2_binding == null) {
			throw new RuntimeException(
					"Binding in node core match failed." + " Variables: " + "[match] = " + match + ".");
		}
		DBTable superTable = (DBTable) result2_binding[0];
		DBTable subTable = (DBTable) result2_binding[1];
		DBSchema s = (DBSchema) result2_binding[2];
		for (Object[] result2_black : CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_12_2_corematch_blackFBFBFFBB(superTable, subTable, s, match)) {
			ClassToTable supCorr = (ClassToTable) result2_black[0];
			CDClass superClass = (CDClass) result2_black[2];
			PackageToSchema p2s = (PackageToSchema) result2_black[4];
			CDPackage p = (CDPackage) result2_black[5];
			// ForEach 
			for (Object[] result3_black : CreateInheritanceRuleImpl
					.pattern_CreateInheritanceRule_12_3_findcontext_blackBBBBBBB(supCorr, superTable, superClass,
							subTable, p2s, p, s)) {
				Object[] result3_green = CreateInheritanceRuleImpl
						.pattern_CreateInheritanceRule_12_3_findcontext_greenBBBBBBBFFFFFFFF(supCorr, superTable,
								superClass, subTable, p2s, p, s);
				IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result3_green[7];
				//nothing EMoflonEdge supCorr__superTable____target = (EMoflonEdge) result3_green[8];
				//nothing EMoflonEdge p2s__p____source = (EMoflonEdge) result3_green[9];
				//nothing EMoflonEdge s__superTable____tables = (EMoflonEdge) result3_green[10];
				//nothing EMoflonEdge supCorr__superClass____source = (EMoflonEdge) result3_green[11];
				//nothing EMoflonEdge s__subTable____tables = (EMoflonEdge) result3_green[12];
				//nothing EMoflonEdge p2s__s____target = (EMoflonEdge) result3_green[13];
				//nothing EMoflonEdge p__superClass____classes = (EMoflonEdge) result3_green[14];

				Object[] result4_bindingAndBlack = CreateInheritanceRuleImpl
						.pattern_CreateInheritanceRule_12_4_solveCSP_bindingAndBlackFBBBBBBBBB(this, isApplicableMatch,
								supCorr, superTable, superClass, subTable, p2s, p, s);
				if (result4_bindingAndBlack == null) {
					throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
							+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[supCorr] = " + supCorr + ", "
							+ "[superTable] = " + superTable + ", " + "[superClass] = " + superClass + ", "
							+ "[subTable] = " + subTable + ", " + "[p2s] = " + p2s + ", " + "[p] = " + p + ", "
							+ "[s] = " + s + ".");
				}
				CSP csp = (CSP) result4_bindingAndBlack[0];
				// 
				if (CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_12_5_checkCSP_expressionFBB(this, csp)) {

					Object[] result6_black = CreateInheritanceRuleImpl
							.pattern_CreateInheritanceRule_12_6_addmatchtoruleresult_blackBB(ruleresult,
									isApplicableMatch);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[ruleresult] = "
								+ ruleresult + ", " + "[isApplicableMatch] = " + isApplicableMatch + ".");
					}
					CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_12_6_addmatchtoruleresult_greenBB(
							ruleresult, isApplicableMatch);

				} else {
				}

			}

		}
		return CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_12_7_expressionFB(ruleresult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjectsToMatch_BWD(Match match, DBTable superTable, DBTable subTable, DBSchema s) {
		match.registerObject("superTable", superTable);
		match.registerObject("subTable", subTable);
		match.registerObject("s", s);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isAppropriate_solveCsp_BWD(Match match, DBTable superTable, DBTable subTable, DBSchema s) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables

		// Create unbound variables

		// Create constraints

		// Solve CSP
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isAppropriate_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_BWD(IsApplicableMatch isApplicableMatch, ClassToTable supCorr, DBTable superTable,
			CDClass superClass, DBTable subTable, PackageToSchema p2s, CDPackage p, DBSchema s) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables
		Variable var_subTable_name = CSPFactoryHelper.eINSTANCE.createVariable("subTable.name", true, csp);
		var_subTable_name.setValue(subTable.getName());
		var_subTable_name.setType("String");

		// Create unbound variables
		Variable var_subClass_name = CSPFactoryHelper.eINSTANCE.createVariable("subClass.name", csp);
		var_subClass_name.setType("String");

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_subClass_name, var_subTable_name);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("supCorr", supCorr);
		isApplicableMatch.registerObject("superTable", superTable);
		isApplicableMatch.registerObject("superClass", superClass);
		isApplicableMatch.registerObject("subTable", subTable);
		isApplicableMatch.registerObject("p2s", p2s);
		isApplicableMatch.registerObject("p", p);
		isApplicableMatch.registerObject("s", s);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void registerObjects_BWD(PerformRuleResult ruleresult, EObject transitiveCorr, EObject subCorr,
			EObject supCorr, EObject superTable, EObject superClass, EObject subTable, EObject p2s, EObject subClass,
			EObject p, EObject s) {
		ruleresult.registerObject("transitiveCorr", transitiveCorr);
		ruleresult.registerObject("subCorr", subCorr);
		ruleresult.registerObject("supCorr", supCorr);
		ruleresult.registerObject("superTable", superTable);
		ruleresult.registerObject("superClass", superClass);
		ruleresult.registerObject("subTable", subTable);
		ruleresult.registerObject("p2s", p2s);
		ruleresult.registerObject("subClass", subClass);
		ruleresult.registerObject("p", p);
		ruleresult.registerObject("s", s);

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkTypes_BWD(Match match) {
		return true && org.moflon.util.eMoflonSDMUtil.getFQN(match.getObject("subTable").eClass())
				.equals("DatabaseSchemata.DBTable.");
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObjectContainer isAppropriate_FWD_EMoflonEdge_3(EMoflonEdge _edge_classes) {

		Object[] result1_bindingAndBlack = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_20_1_preparereturnvalue_bindingAndBlackFFBF(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		EOperation __performOperation = (EOperation) result1_bindingAndBlack[0];
		EClass __eClass = (EClass) result1_bindingAndBlack[1];
		EOperation isApplicableCC = (EOperation) result1_bindingAndBlack[3];
		Object[] result1_green = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_20_1_preparereturnvalue_greenF();
		EObjectContainer __result = (EObjectContainer) result1_green[0];

		// ForEach 
		for (Object[] result2_black : CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_20_2_testcorematchandDECs_blackFFFB(_edge_classes)) {
			CDClass superClass = (CDClass) result2_black[0];
			CDClass subClass = (CDClass) result2_black[1];
			CDPackage p = (CDPackage) result2_black[2];
			Object[] result2_green = CreateInheritanceRuleImpl
					.pattern_CreateInheritanceRule_20_2_testcorematchandDECs_greenFB(__eClass);
			Match match = (Match) result2_green[0];

			// 
			if (CreateInheritanceRuleImpl
					.pattern_CreateInheritanceRule_20_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBBB(this,
							match, superClass, subClass, p)) {
				// 
				if (CreateInheritanceRuleImpl
						.pattern_CreateInheritanceRule_20_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
								this, match)) {

					Object[] result5_black = CreateInheritanceRuleImpl
							.pattern_CreateInheritanceRule_20_5_Addmatchtoruleresult_blackBBBB(match,
									__performOperation, __result, isApplicableCC);
					if (result5_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match
								+ ", " + "[__performOperation] = " + __performOperation + ", " + "[__result] = "
								+ __result + ", " + "[isApplicableCC] = " + isApplicableCC + ".");
					}
					CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_20_5_Addmatchtoruleresult_greenBBBB(match,
							__performOperation, __result, isApplicableCC);

				} else {
				}

			} else {
			}

		}
		return CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_20_6_expressionFB(__result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObjectContainer isAppropriate_BWD_EMoflonEdge_3(EMoflonEdge _edge_tables) {

		Object[] result1_bindingAndBlack = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_21_1_preparereturnvalue_bindingAndBlackFFBF(this);
		if (result1_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		EOperation __performOperation = (EOperation) result1_bindingAndBlack[0];
		EClass __eClass = (EClass) result1_bindingAndBlack[1];
		EOperation isApplicableCC = (EOperation) result1_bindingAndBlack[3];
		Object[] result1_green = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_21_1_preparereturnvalue_greenF();
		EObjectContainer __result = (EObjectContainer) result1_green[0];

		// ForEach 
		for (Object[] result2_black : CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_21_2_testcorematchandDECs_blackFFFB(_edge_tables)) {
			DBTable superTable = (DBTable) result2_black[0];
			DBTable subTable = (DBTable) result2_black[1];
			DBSchema s = (DBSchema) result2_black[2];
			Object[] result2_green = CreateInheritanceRuleImpl
					.pattern_CreateInheritanceRule_21_2_testcorematchandDECs_greenFB(__eClass);
			Match match = (Match) result2_green[0];

			// 
			if (CreateInheritanceRuleImpl
					.pattern_CreateInheritanceRule_21_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBBB(this,
							match, superTable, subTable, s)) {
				// 
				if (CreateInheritanceRuleImpl
						.pattern_CreateInheritanceRule_21_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
								this, match)) {

					Object[] result5_black = CreateInheritanceRuleImpl
							.pattern_CreateInheritanceRule_21_5_Addmatchtoruleresult_blackBBBB(match,
									__performOperation, __result, isApplicableCC);
					if (result5_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[match] = " + match
								+ ", " + "[__performOperation] = " + __performOperation + ", " + "[__result] = "
								+ __result + ", " + "[isApplicableCC] = " + isApplicableCC + ".");
					}
					CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_21_5_Addmatchtoruleresult_greenBBBB(match,
							__performOperation, __result, isApplicableCC);

				} else {
				}

			} else {
			}

		}
		return CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_21_6_expressionFB(__result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeConstraintsRuleResult checkAttributes_FWD(TripleMatch __tripleMatch) {
		AttributeConstraintsRuleResult ruleResult = org.moflon.tgg.runtime.RuntimeFactory.eINSTANCE
				.createAttributeConstraintsRuleResult();
		ruleResult.setRule("CreateInheritanceRule");
		ruleResult.setSuccess(true);

		CSP csp = CspFactory.eINSTANCE.createCSP();

		CheckAttributeHelper __helper = new CheckAttributeHelper(__tripleMatch);

		Variable var_subTable_name = CSPFactoryHelper.eINSTANCE.createVariable("subTable", true, csp);
		var_subTable_name.setValue(__helper.getValue("subTable", "name"));
		var_subTable_name.setType("String");

		Variable var_subClass_name = CSPFactoryHelper.eINSTANCE.createVariable("subClass", true, csp);
		var_subClass_name.setValue(__helper.getValue("subClass", "name"));
		var_subClass_name.setType("String");

		Eq eq0 = new Eq();
		csp.getConstraints().add(eq0);

		eq0.setRuleName("CreateInheritanceRule");
		eq0.solve(var_subClass_name, var_subTable_name);

		if (csp.check()) {
			ruleResult.setSuccess(true);
		} else {
			var_subTable_name.setBound(false);
			eq0.solve(var_subClass_name, var_subTable_name);
			if (csp.check()) {
				ruleResult.setSuccess(true);
				ruleResult.setRequiredChange(true);
				__helper.setValue("subTable", "name", var_subTable_name.getValue());
			} else {
				ruleResult.setSuccess(false);
				return ruleResult;
			}
		}

		return ruleResult;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AttributeConstraintsRuleResult checkAttributes_BWD(TripleMatch __tripleMatch) {
		AttributeConstraintsRuleResult ruleResult = org.moflon.tgg.runtime.RuntimeFactory.eINSTANCE
				.createAttributeConstraintsRuleResult();
		ruleResult.setRule("CreateInheritanceRule");
		ruleResult.setSuccess(true);

		CSP csp = CspFactory.eINSTANCE.createCSP();

		CheckAttributeHelper __helper = new CheckAttributeHelper(__tripleMatch);

		Variable var_subTable_name = CSPFactoryHelper.eINSTANCE.createVariable("subTable", true, csp);
		var_subTable_name.setValue(__helper.getValue("subTable", "name"));
		var_subTable_name.setType("String");

		Variable var_subClass_name = CSPFactoryHelper.eINSTANCE.createVariable("subClass", true, csp);
		var_subClass_name.setValue(__helper.getValue("subClass", "name"));
		var_subClass_name.setType("String");

		Eq eq0 = new Eq();
		csp.getConstraints().add(eq0);

		eq0.setRuleName("CreateInheritanceRule");
		eq0.solve(var_subClass_name, var_subTable_name);

		if (csp.check()) {
			ruleResult.setSuccess(true);
		} else {
			var_subClass_name.setBound(false);
			eq0.solve(var_subClass_name, var_subTable_name);
			if (csp.check()) {
				ruleResult.setSuccess(true);
				ruleResult.setRequiredChange(true);
				__helper.setValue("subClass", "name", var_subClass_name.getValue());
			} else {
				ruleResult.setSuccess(false);
				return ruleResult;
			}
		}

		return ruleResult;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IsApplicableRuleResult isApplicable_CC(Match sourceMatch, Match targetMatch) {

		Object[] result1_black = CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_24_1_prepare_blackB(this);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		Object[] result1_green = CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_24_1_prepare_greenF();
		IsApplicableRuleResult result = (IsApplicableRuleResult) result1_green[0];

		Object[] result2_bindingAndBlack = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_24_2_matchsrctrgcontext_bindingAndBlackFFFFFFBB(sourceMatch,
						targetMatch);
		if (result2_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[sourceMatch] = " + sourceMatch
					+ ", " + "[targetMatch] = " + targetMatch + ".");
		}
		DBTable superTable = (DBTable) result2_bindingAndBlack[0];
		CDClass superClass = (CDClass) result2_bindingAndBlack[1];
		DBTable subTable = (DBTable) result2_bindingAndBlack[2];
		CDClass subClass = (CDClass) result2_bindingAndBlack[3];
		CDPackage p = (CDPackage) result2_bindingAndBlack[4];
		DBSchema s = (DBSchema) result2_bindingAndBlack[5];

		Object[] result3_bindingAndBlack = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_24_3_solvecsp_bindingAndBlackFBBBBBBBBB(this, superTable, superClass,
						subTable, subClass, p, s, sourceMatch, targetMatch);
		if (result3_bindingAndBlack == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
					+ "[superTable] = " + superTable + ", " + "[superClass] = " + superClass + ", " + "[subTable] = "
					+ subTable + ", " + "[subClass] = " + subClass + ", " + "[p] = " + p + ", " + "[s] = " + s + ", "
					+ "[sourceMatch] = " + sourceMatch + ", " + "[targetMatch] = " + targetMatch + ".");
		}
		CSP csp = (CSP) result3_bindingAndBlack[0];
		// 
		if (CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_24_4_checkCSP_expressionFB(csp)) {
			// ForEach 
			for (Object[] result5_black : CreateInheritanceRuleImpl
					.pattern_CreateInheritanceRule_24_5_matchcorrcontext_blackFBBFBBBB(superTable, superClass, p, s,
							sourceMatch, targetMatch)) {
				ClassToTable supCorr = (ClassToTable) result5_black[0];
				PackageToSchema p2s = (PackageToSchema) result5_black[3];
				Object[] result5_green = CreateInheritanceRuleImpl
						.pattern_CreateInheritanceRule_24_5_matchcorrcontext_greenBBBBF(supCorr, p2s, sourceMatch,
								targetMatch);
				CCMatch ccMatch = (CCMatch) result5_green[4];

				Object[] result6_black = CreateInheritanceRuleImpl
						.pattern_CreateInheritanceRule_24_6_createcorrespondence_blackBBBBBBB(superTable, superClass,
								subTable, subClass, p, s, ccMatch);
				if (result6_black == null) {
					throw new RuntimeException("Pattern matching failed." + " Variables: " + "[superTable] = "
							+ superTable + ", " + "[superClass] = " + superClass + ", " + "[subTable] = " + subTable
							+ ", " + "[subClass] = " + subClass + ", " + "[p] = " + p + ", " + "[s] = " + s + ", "
							+ "[ccMatch] = " + ccMatch + ".");
				}
				CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_24_6_createcorrespondence_greenFFBBBB(
						superClass, subTable, subClass, ccMatch);
				//nothing SuperClassToTable transitiveCorr = (SuperClassToTable) result6_green[0];
				//nothing ClassToTable subCorr = (ClassToTable) result6_green[1];

				Object[] result7_black = CreateInheritanceRuleImpl
						.pattern_CreateInheritanceRule_24_7_addtoreturnedresult_blackBB(result, ccMatch);
				if (result7_black == null) {
					throw new RuntimeException("Pattern matching failed." + " Variables: " + "[result] = " + result
							+ ", " + "[ccMatch] = " + ccMatch + ".");
				}
				CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_24_7_addtoreturnedresult_greenBB(result,
						ccMatch);

			}

		} else {
		}
		return CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_24_8_expressionFB(result);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP isApplicable_solveCsp_CC(DBTable superTable, CDClass superClass, DBTable subTable, CDClass subClass,
			CDPackage p, DBSchema s, Match sourceMatch, Match targetMatch) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();

		// Create literals

		// Create attribute variables
		Variable var_subClass_name = CSPFactoryHelper.eINSTANCE.createVariable("subClass.name", true, csp);
		var_subClass_name.setValue(subClass.getName());
		var_subClass_name.setType("String");
		Variable var_subTable_name = CSPFactoryHelper.eINSTANCE.createVariable("subTable.name", true, csp);
		var_subTable_name.setValue(subTable.getName());
		var_subTable_name.setType("String");

		// Create unbound variables

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_subClass_name, var_subTable_name);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplicable_checkCsp_CC(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkDEC_FWD(CDClass superClass, CDClass subClass, CDPackage p) {// 
		Object[] result1_black = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_27_1_matchtggpattern_blackBBB(superClass, subClass, p);
		if (result1_black != null) {
			return CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_27_2_expressionF();
		} else {
			return CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_27_3_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean checkDEC_BWD(DBTable superTable, DBTable subTable, DBSchema s) {// 
		Object[] result1_black = CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_28_1_matchtggpattern_blackBBB(superTable, subTable, s);
		if (result1_black != null) {
			return CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_28_2_expressionF();
		} else {
			return CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_28_3_expressionF();
		}

	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ModelgeneratorRuleResult generateModel(RuleEntryContainer ruleEntryContainer,
			ClassToTable supCorrParameter) {

		Object[] result1_black = CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_29_1_createresult_blackB(this);
		if (result1_black == null) {
			throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ".");
		}
		Object[] result1_green = CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_29_1_createresult_greenFF();
		IsApplicableMatch isApplicableMatch = (IsApplicableMatch) result1_green[0];
		ModelgeneratorRuleResult ruleResult = (ModelgeneratorRuleResult) result1_green[1];

		// ForEach 
		for (Object[] result2_black : CreateInheritanceRuleImpl
				.pattern_CreateInheritanceRule_29_2_isapplicablecore_blackFFFFFFFBB(ruleEntryContainer, ruleResult)) {
			//nothing RuleEntryList supCorrList = (RuleEntryList) result2_black[0];
			ClassToTable supCorr = (ClassToTable) result2_black[1];
			DBTable superTable = (DBTable) result2_black[2];
			DBSchema s = (DBSchema) result2_black[3];
			PackageToSchema p2s = (PackageToSchema) result2_black[4];
			CDPackage p = (CDPackage) result2_black[5];
			CDClass superClass = (CDClass) result2_black[6];

			Object[] result3_bindingAndBlack = CreateInheritanceRuleImpl
					.pattern_CreateInheritanceRule_29_3_solveCSP_bindingAndBlackFBBBBBBBBB(this, isApplicableMatch,
							supCorr, superTable, superClass, p2s, p, s, ruleResult);
			if (result3_bindingAndBlack == null) {
				throw new RuntimeException("Pattern matching failed." + " Variables: " + "[this] = " + this + ", "
						+ "[isApplicableMatch] = " + isApplicableMatch + ", " + "[supCorr] = " + supCorr + ", "
						+ "[superTable] = " + superTable + ", " + "[superClass] = " + superClass + ", " + "[p2s] = "
						+ p2s + ", " + "[p] = " + p + ", " + "[s] = " + s + ", " + "[ruleResult] = " + ruleResult
						+ ".");
			}
			CSP csp = (CSP) result3_bindingAndBlack[0];
			// 
			if (CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_29_4_checkCSP_expressionFBB(this, csp)) {
				// 
				Object[] result5_black = CreateInheritanceRuleImpl
						.pattern_CreateInheritanceRule_29_5_checknacs_blackBBBBBB(supCorr, superTable, superClass, p2s,
								p, s);
				if (result5_black != null) {

					Object[] result6_black = CreateInheritanceRuleImpl
							.pattern_CreateInheritanceRule_29_6_perform_blackBBBBBBB(supCorr, superTable, superClass,
									p2s, p, s, ruleResult);
					if (result6_black == null) {
						throw new RuntimeException("Pattern matching failed." + " Variables: " + "[supCorr] = "
								+ supCorr + ", " + "[superTable] = " + superTable + ", " + "[superClass] = "
								+ superClass + ", " + "[p2s] = " + p2s + ", " + "[p] = " + p + ", " + "[s] = " + s
								+ ", " + "[ruleResult] = " + ruleResult + ".");
					}
					CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_29_6_perform_greenFFBFFBBBB(superClass, p,
							s, ruleResult, csp);
					//nothing SuperClassToTable transitiveCorr = (SuperClassToTable) result6_green[0];
					//nothing ClassToTable subCorr = (ClassToTable) result6_green[1];
					//nothing DBTable subTable = (DBTable) result6_green[3];
					//nothing CDClass subClass = (CDClass) result6_green[4];

				} else {
				}

			} else {
			}

		}
		return CreateInheritanceRuleImpl.pattern_CreateInheritanceRule_29_7_expressionFB(ruleResult);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CSP generateModel_solveCsp_BWD(IsApplicableMatch isApplicableMatch, ClassToTable supCorr, DBTable superTable,
			CDClass superClass, PackageToSchema p2s, CDPackage p, DBSchema s, ModelgeneratorRuleResult ruleResult) {// Create CSP
		CSP csp = CspFactory.eINSTANCE.createCSP();
		isApplicableMatch.getAttributeInfo().add(csp);

		// Create literals

		// Create attribute variables

		// Create unbound variables
		Variable var_subClass_name = CSPFactoryHelper.eINSTANCE.createVariable("subClass.name", csp);
		var_subClass_name.setType("String");
		Variable var_subTable_name = CSPFactoryHelper.eINSTANCE.createVariable("subTable.name", csp);
		var_subTable_name.setType("String");

		// Create constraints
		Eq eq = new Eq();

		csp.getConstraints().add(eq);

		// Solve CSP
		eq.setRuleName("NoRuleName");
		eq.solve(var_subClass_name, var_subTable_name);

		// Snapshot pattern match on which CSP is solved
		isApplicableMatch.registerObject("supCorr", supCorr);
		isApplicableMatch.registerObject("superTable", superTable);
		isApplicableMatch.registerObject("superClass", superClass);
		isApplicableMatch.registerObject("p2s", p2s);
		isApplicableMatch.registerObject("p", p);
		isApplicableMatch.registerObject("s", s);
		return csp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean generateModel_checkCsp_BWD(CSP csp) {
		return csp.check();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case RulesPackage.CREATE_INHERITANCE_RULE___IS_APPROPRIATE_FWD__MATCH_CDCLASS_CDCLASS_CDPACKAGE:
			return isAppropriate_FWD((Match) arguments.get(0), (CDClass) arguments.get(1), (CDClass) arguments.get(2),
					(CDPackage) arguments.get(3));
		case RulesPackage.CREATE_INHERITANCE_RULE___PERFORM_FWD__ISAPPLICABLEMATCH:
			return perform_FWD((IsApplicableMatch) arguments.get(0));
		case RulesPackage.CREATE_INHERITANCE_RULE___IS_APPLICABLE_FWD__MATCH:
			return isApplicable_FWD((Match) arguments.get(0));
		case RulesPackage.CREATE_INHERITANCE_RULE___REGISTER_OBJECTS_TO_MATCH_FWD__MATCH_CDCLASS_CDCLASS_CDPACKAGE:
			registerObjectsToMatch_FWD((Match) arguments.get(0), (CDClass) arguments.get(1), (CDClass) arguments.get(2),
					(CDPackage) arguments.get(3));
			return null;
		case RulesPackage.CREATE_INHERITANCE_RULE___IS_APPROPRIATE_SOLVE_CSP_FWD__MATCH_CDCLASS_CDCLASS_CDPACKAGE:
			return isAppropriate_solveCsp_FWD((Match) arguments.get(0), (CDClass) arguments.get(1),
					(CDClass) arguments.get(2), (CDPackage) arguments.get(3));
		case RulesPackage.CREATE_INHERITANCE_RULE___IS_APPROPRIATE_CHECK_CSP_FWD__CSP:
			return isAppropriate_checkCsp_FWD((CSP) arguments.get(0));
		case RulesPackage.CREATE_INHERITANCE_RULE___IS_APPLICABLE_SOLVE_CSP_FWD__ISAPPLICABLEMATCH_CLASSTOTABLE_DBTABLE_CDCLASS_PACKAGETOSCHEMA_CDCLASS_CDPACKAGE_DBSCHEMA:
			return isApplicable_solveCsp_FWD((IsApplicableMatch) arguments.get(0), (ClassToTable) arguments.get(1),
					(DBTable) arguments.get(2), (CDClass) arguments.get(3), (PackageToSchema) arguments.get(4),
					(CDClass) arguments.get(5), (CDPackage) arguments.get(6), (DBSchema) arguments.get(7));
		case RulesPackage.CREATE_INHERITANCE_RULE___IS_APPLICABLE_CHECK_CSP_FWD__CSP:
			return isApplicable_checkCsp_FWD((CSP) arguments.get(0));
		case RulesPackage.CREATE_INHERITANCE_RULE___REGISTER_OBJECTS_FWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT:
			registerObjects_FWD((PerformRuleResult) arguments.get(0), (EObject) arguments.get(1),
					(EObject) arguments.get(2), (EObject) arguments.get(3), (EObject) arguments.get(4),
					(EObject) arguments.get(5), (EObject) arguments.get(6), (EObject) arguments.get(7),
					(EObject) arguments.get(8), (EObject) arguments.get(9), (EObject) arguments.get(10));
			return null;
		case RulesPackage.CREATE_INHERITANCE_RULE___CHECK_TYPES_FWD__MATCH:
			return checkTypes_FWD((Match) arguments.get(0));
		case RulesPackage.CREATE_INHERITANCE_RULE___IS_APPROPRIATE_BWD__MATCH_DBTABLE_DBTABLE_DBSCHEMA:
			return isAppropriate_BWD((Match) arguments.get(0), (DBTable) arguments.get(1), (DBTable) arguments.get(2),
					(DBSchema) arguments.get(3));
		case RulesPackage.CREATE_INHERITANCE_RULE___PERFORM_BWD__ISAPPLICABLEMATCH:
			return perform_BWD((IsApplicableMatch) arguments.get(0));
		case RulesPackage.CREATE_INHERITANCE_RULE___IS_APPLICABLE_BWD__MATCH:
			return isApplicable_BWD((Match) arguments.get(0));
		case RulesPackage.CREATE_INHERITANCE_RULE___REGISTER_OBJECTS_TO_MATCH_BWD__MATCH_DBTABLE_DBTABLE_DBSCHEMA:
			registerObjectsToMatch_BWD((Match) arguments.get(0), (DBTable) arguments.get(1), (DBTable) arguments.get(2),
					(DBSchema) arguments.get(3));
			return null;
		case RulesPackage.CREATE_INHERITANCE_RULE___IS_APPROPRIATE_SOLVE_CSP_BWD__MATCH_DBTABLE_DBTABLE_DBSCHEMA:
			return isAppropriate_solveCsp_BWD((Match) arguments.get(0), (DBTable) arguments.get(1),
					(DBTable) arguments.get(2), (DBSchema) arguments.get(3));
		case RulesPackage.CREATE_INHERITANCE_RULE___IS_APPROPRIATE_CHECK_CSP_BWD__CSP:
			return isAppropriate_checkCsp_BWD((CSP) arguments.get(0));
		case RulesPackage.CREATE_INHERITANCE_RULE___IS_APPLICABLE_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_CLASSTOTABLE_DBTABLE_CDCLASS_DBTABLE_PACKAGETOSCHEMA_CDPACKAGE_DBSCHEMA:
			return isApplicable_solveCsp_BWD((IsApplicableMatch) arguments.get(0), (ClassToTable) arguments.get(1),
					(DBTable) arguments.get(2), (CDClass) arguments.get(3), (DBTable) arguments.get(4),
					(PackageToSchema) arguments.get(5), (CDPackage) arguments.get(6), (DBSchema) arguments.get(7));
		case RulesPackage.CREATE_INHERITANCE_RULE___IS_APPLICABLE_CHECK_CSP_BWD__CSP:
			return isApplicable_checkCsp_BWD((CSP) arguments.get(0));
		case RulesPackage.CREATE_INHERITANCE_RULE___REGISTER_OBJECTS_BWD__PERFORMRULERESULT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT_EOBJECT:
			registerObjects_BWD((PerformRuleResult) arguments.get(0), (EObject) arguments.get(1),
					(EObject) arguments.get(2), (EObject) arguments.get(3), (EObject) arguments.get(4),
					(EObject) arguments.get(5), (EObject) arguments.get(6), (EObject) arguments.get(7),
					(EObject) arguments.get(8), (EObject) arguments.get(9), (EObject) arguments.get(10));
			return null;
		case RulesPackage.CREATE_INHERITANCE_RULE___CHECK_TYPES_BWD__MATCH:
			return checkTypes_BWD((Match) arguments.get(0));
		case RulesPackage.CREATE_INHERITANCE_RULE___IS_APPROPRIATE_FWD_EMOFLON_EDGE_3__EMOFLONEDGE:
			return isAppropriate_FWD_EMoflonEdge_3((EMoflonEdge) arguments.get(0));
		case RulesPackage.CREATE_INHERITANCE_RULE___IS_APPROPRIATE_BWD_EMOFLON_EDGE_3__EMOFLONEDGE:
			return isAppropriate_BWD_EMoflonEdge_3((EMoflonEdge) arguments.get(0));
		case RulesPackage.CREATE_INHERITANCE_RULE___CHECK_ATTRIBUTES_FWD__TRIPLEMATCH:
			return checkAttributes_FWD((TripleMatch) arguments.get(0));
		case RulesPackage.CREATE_INHERITANCE_RULE___CHECK_ATTRIBUTES_BWD__TRIPLEMATCH:
			return checkAttributes_BWD((TripleMatch) arguments.get(0));
		case RulesPackage.CREATE_INHERITANCE_RULE___IS_APPLICABLE_CC__MATCH_MATCH:
			return isApplicable_CC((Match) arguments.get(0), (Match) arguments.get(1));
		case RulesPackage.CREATE_INHERITANCE_RULE___IS_APPLICABLE_SOLVE_CSP_CC__DBTABLE_CDCLASS_DBTABLE_CDCLASS_CDPACKAGE_DBSCHEMA_MATCH_MATCH:
			return isApplicable_solveCsp_CC((DBTable) arguments.get(0), (CDClass) arguments.get(1),
					(DBTable) arguments.get(2), (CDClass) arguments.get(3), (CDPackage) arguments.get(4),
					(DBSchema) arguments.get(5), (Match) arguments.get(6), (Match) arguments.get(7));
		case RulesPackage.CREATE_INHERITANCE_RULE___IS_APPLICABLE_CHECK_CSP_CC__CSP:
			return isApplicable_checkCsp_CC((CSP) arguments.get(0));
		case RulesPackage.CREATE_INHERITANCE_RULE___CHECK_DEC_FWD__CDCLASS_CDCLASS_CDPACKAGE:
			return checkDEC_FWD((CDClass) arguments.get(0), (CDClass) arguments.get(1), (CDPackage) arguments.get(2));
		case RulesPackage.CREATE_INHERITANCE_RULE___CHECK_DEC_BWD__DBTABLE_DBTABLE_DBSCHEMA:
			return checkDEC_BWD((DBTable) arguments.get(0), (DBTable) arguments.get(1), (DBSchema) arguments.get(2));
		case RulesPackage.CREATE_INHERITANCE_RULE___GENERATE_MODEL__RULEENTRYCONTAINER_CLASSTOTABLE:
			return generateModel((RuleEntryContainer) arguments.get(0), (ClassToTable) arguments.get(1));
		case RulesPackage.CREATE_INHERITANCE_RULE___GENERATE_MODEL_SOLVE_CSP_BWD__ISAPPLICABLEMATCH_CLASSTOTABLE_DBTABLE_CDCLASS_PACKAGETOSCHEMA_CDPACKAGE_DBSCHEMA_MODELGENERATORRULERESULT:
			return generateModel_solveCsp_BWD((IsApplicableMatch) arguments.get(0), (ClassToTable) arguments.get(1),
					(DBTable) arguments.get(2), (CDClass) arguments.get(3), (PackageToSchema) arguments.get(4),
					(CDPackage) arguments.get(5), (DBSchema) arguments.get(6),
					(ModelgeneratorRuleResult) arguments.get(7));
		case RulesPackage.CREATE_INHERITANCE_RULE___GENERATE_MODEL_CHECK_CSP_BWD__CSP:
			return generateModel_checkCsp_BWD((CSP) arguments.get(0));
		}
		return super.eInvoke(operationID, arguments);
	}

	public static final Object[] pattern_CreateInheritanceRule_0_1_initialbindings_blackBBBBB(
			CreateInheritanceRule _this, Match match, CDClass superClass, CDClass subClass, CDPackage p) {
		if (!subClass.equals(superClass)) {
			return new Object[] { _this, match, superClass, subClass, p };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_0_2_SolveCSP_bindingFBBBBB(CreateInheritanceRule _this,
			Match match, CDClass superClass, CDClass subClass, CDPackage p) {
		CSP _localVariable_0 = _this.isAppropriate_solveCsp_FWD(match, superClass, subClass, p);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, match, superClass, subClass, p };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_0_2_SolveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_CreateInheritanceRule_0_2_SolveCSP_bindingAndBlackFBBBBB(
			CreateInheritanceRule _this, Match match, CDClass superClass, CDClass subClass, CDPackage p) {
		Object[] result_pattern_CreateInheritanceRule_0_2_SolveCSP_binding = pattern_CreateInheritanceRule_0_2_SolveCSP_bindingFBBBBB(
				_this, match, superClass, subClass, p);
		if (result_pattern_CreateInheritanceRule_0_2_SolveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_CreateInheritanceRule_0_2_SolveCSP_binding[0];

			Object[] result_pattern_CreateInheritanceRule_0_2_SolveCSP_black = pattern_CreateInheritanceRule_0_2_SolveCSP_blackB(
					csp);
			if (result_pattern_CreateInheritanceRule_0_2_SolveCSP_black != null) {

				return new Object[] { csp, _this, match, superClass, subClass, p };
			}
		}
		return null;
	}

	public static final boolean pattern_CreateInheritanceRule_0_3_CheckCSP_expressionFBB(CreateInheritanceRule _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isAppropriate_checkCsp_FWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_0_4_collectelementstobetranslated_blackBBBB(Match match,
			CDClass superClass, CDClass subClass, CDPackage p) {
		if (!subClass.equals(superClass)) {
			return new Object[] { match, superClass, subClass, p };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_0_4_collectelementstobetranslated_greenBBBBFF(
			Match match, CDClass superClass, CDClass subClass, CDPackage p) {
		EMoflonEdge p__subClass____classes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge subClass__superClass____superClass = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getToBeTranslatedNodes().add(subClass);
		String p__subClass____classes_name_prime = "classes";
		String subClass__superClass____superClass_name_prime = "superClass";
		p__subClass____classes.setSrc(p);
		p__subClass____classes.setTrg(subClass);
		match.getToBeTranslatedEdges().add(p__subClass____classes);
		subClass__superClass____superClass.setSrc(subClass);
		subClass__superClass____superClass.setTrg(superClass);
		match.getToBeTranslatedEdges().add(subClass__superClass____superClass);
		p__subClass____classes.setName(p__subClass____classes_name_prime);
		subClass__superClass____superClass.setName(subClass__superClass____superClass_name_prime);
		return new Object[] { match, superClass, subClass, p, p__subClass____classes,
				subClass__superClass____superClass };
	}

	public static final Object[] pattern_CreateInheritanceRule_0_5_collectcontextelements_blackBBBB(Match match,
			CDClass superClass, CDClass subClass, CDPackage p) {
		if (!subClass.equals(superClass)) {
			return new Object[] { match, superClass, subClass, p };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_0_5_collectcontextelements_greenBBBF(Match match,
			CDClass superClass, CDPackage p) {
		EMoflonEdge p__superClass____classes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getContextNodes().add(superClass);
		match.getContextNodes().add(p);
		String p__superClass____classes_name_prime = "classes";
		p__superClass____classes.setSrc(p);
		p__superClass____classes.setTrg(superClass);
		match.getContextEdges().add(p__superClass____classes);
		p__superClass____classes.setName(p__superClass____classes_name_prime);
		return new Object[] { match, superClass, p, p__superClass____classes };
	}

	public static final void pattern_CreateInheritanceRule_0_6_registerobjectstomatch_expressionBBBBB(
			CreateInheritanceRule _this, Match match, CDClass superClass, CDClass subClass, CDPackage p) {
		_this.registerObjectsToMatch_FWD(match, superClass, subClass, p);

	}

	public static final boolean pattern_CreateInheritanceRule_0_7_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_CreateInheritanceRule_0_8_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_1_1_performtransformation_bindingFFFFFFFB(
			IsApplicableMatch isApplicableMatch) {
		EObject _localVariable_0 = isApplicableMatch.getObject("supCorr");
		EObject _localVariable_1 = isApplicableMatch.getObject("superTable");
		EObject _localVariable_2 = isApplicableMatch.getObject("superClass");
		EObject _localVariable_3 = isApplicableMatch.getObject("p2s");
		EObject _localVariable_4 = isApplicableMatch.getObject("subClass");
		EObject _localVariable_5 = isApplicableMatch.getObject("p");
		EObject _localVariable_6 = isApplicableMatch.getObject("s");
		EObject tmpSupCorr = _localVariable_0;
		EObject tmpSuperTable = _localVariable_1;
		EObject tmpSuperClass = _localVariable_2;
		EObject tmpP2s = _localVariable_3;
		EObject tmpSubClass = _localVariable_4;
		EObject tmpP = _localVariable_5;
		EObject tmpS = _localVariable_6;
		if (tmpSupCorr instanceof ClassToTable) {
			ClassToTable supCorr = (ClassToTable) tmpSupCorr;
			if (tmpSuperTable instanceof DBTable) {
				DBTable superTable = (DBTable) tmpSuperTable;
				if (tmpSuperClass instanceof CDClass) {
					CDClass superClass = (CDClass) tmpSuperClass;
					if (tmpP2s instanceof PackageToSchema) {
						PackageToSchema p2s = (PackageToSchema) tmpP2s;
						if (tmpSubClass instanceof CDClass) {
							CDClass subClass = (CDClass) tmpSubClass;
							if (tmpP instanceof CDPackage) {
								CDPackage p = (CDPackage) tmpP;
								if (tmpS instanceof DBSchema) {
									DBSchema s = (DBSchema) tmpS;
									return new Object[] { supCorr, superTable, superClass, p2s, subClass, p, s,
											isApplicableMatch };
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_1_1_performtransformation_blackBBBBBBBFBB(
			ClassToTable supCorr, DBTable superTable, CDClass superClass, PackageToSchema p2s, CDClass subClass,
			CDPackage p, DBSchema s, CreateInheritanceRule _this, IsApplicableMatch isApplicableMatch) {
		if (!subClass.equals(superClass)) {
			for (EObject tmpCsp : isApplicableMatch.getAttributeInfo()) {
				if (tmpCsp instanceof CSP) {
					CSP csp = (CSP) tmpCsp;
					return new Object[] { supCorr, superTable, superClass, p2s, subClass, p, s, csp, _this,
							isApplicableMatch };
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_1_1_performtransformation_bindingAndBlackFFFFFFFFBB(
			CreateInheritanceRule _this, IsApplicableMatch isApplicableMatch) {
		Object[] result_pattern_CreateInheritanceRule_1_1_performtransformation_binding = pattern_CreateInheritanceRule_1_1_performtransformation_bindingFFFFFFFB(
				isApplicableMatch);
		if (result_pattern_CreateInheritanceRule_1_1_performtransformation_binding != null) {
			ClassToTable supCorr = (ClassToTable) result_pattern_CreateInheritanceRule_1_1_performtransformation_binding[0];
			DBTable superTable = (DBTable) result_pattern_CreateInheritanceRule_1_1_performtransformation_binding[1];
			CDClass superClass = (CDClass) result_pattern_CreateInheritanceRule_1_1_performtransformation_binding[2];
			PackageToSchema p2s = (PackageToSchema) result_pattern_CreateInheritanceRule_1_1_performtransformation_binding[3];
			CDClass subClass = (CDClass) result_pattern_CreateInheritanceRule_1_1_performtransformation_binding[4];
			CDPackage p = (CDPackage) result_pattern_CreateInheritanceRule_1_1_performtransformation_binding[5];
			DBSchema s = (DBSchema) result_pattern_CreateInheritanceRule_1_1_performtransformation_binding[6];

			Object[] result_pattern_CreateInheritanceRule_1_1_performtransformation_black = pattern_CreateInheritanceRule_1_1_performtransformation_blackBBBBBBBFBB(
					supCorr, superTable, superClass, p2s, subClass, p, s, _this, isApplicableMatch);
			if (result_pattern_CreateInheritanceRule_1_1_performtransformation_black != null) {
				CSP csp = (CSP) result_pattern_CreateInheritanceRule_1_1_performtransformation_black[7];

				return new Object[] { supCorr, superTable, superClass, p2s, subClass, p, s, csp, _this,
						isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_1_1_performtransformation_greenFFBFBBB(
			CDClass superClass, CDClass subClass, DBSchema s, CSP csp) {
		SuperClassToTable transitiveCorr = CDToDBFactory.eINSTANCE.createSuperClassToTable();
		ClassToTable subCorr = CDToDBFactory.eINSTANCE.createClassToTable();
		DBTable subTable = DatabaseSchemataFactory.eINSTANCE.createDBTable();
		Object _localVariable_0 = csp.getValue("subTable", "name");
		transitiveCorr.setSource(superClass);
		subCorr.setSource(subClass);
		transitiveCorr.setTarget(subTable);
		subCorr.setTarget(subTable);
		s.getTables().add(subTable);
		String subTable_name_prime = (String) _localVariable_0;
		subTable.setName(subTable_name_prime);
		return new Object[] { transitiveCorr, subCorr, superClass, subTable, subClass, s, csp };
	}

	public static final Object[] pattern_CreateInheritanceRule_1_2_collecttranslatedelements_blackBBBB(
			SuperClassToTable transitiveCorr, ClassToTable subCorr, DBTable subTable, CDClass subClass) {
		return new Object[] { transitiveCorr, subCorr, subTable, subClass };
	}

	public static final Object[] pattern_CreateInheritanceRule_1_2_collecttranslatedelements_greenFBBBB(
			SuperClassToTable transitiveCorr, ClassToTable subCorr, DBTable subTable, CDClass subClass) {
		PerformRuleResult ruleresult = RuntimeFactory.eINSTANCE.createPerformRuleResult();
		ruleresult.getCreatedLinkElements().add(transitiveCorr);
		ruleresult.getCreatedLinkElements().add(subCorr);
		ruleresult.getCreatedElements().add(subTable);
		ruleresult.getTranslatedElements().add(subClass);
		return new Object[] { ruleresult, transitiveCorr, subCorr, subTable, subClass };
	}

	public static final Object[] pattern_CreateInheritanceRule_1_3_bookkeepingforedges_blackBBBBBBBBBBB(
			PerformRuleResult ruleresult, EObject transitiveCorr, EObject subCorr, EObject supCorr, EObject superTable,
			EObject superClass, EObject subTable, EObject p2s, EObject subClass, EObject p, EObject s) {
		if (!subCorr.equals(transitiveCorr)) {
			if (!subCorr.equals(supCorr)) {
				if (!subCorr.equals(superTable)) {
					if (!subCorr.equals(superClass)) {
						if (!subCorr.equals(subTable)) {
							if (!supCorr.equals(transitiveCorr)) {
								if (!supCorr.equals(superTable)) {
									if (!supCorr.equals(superClass)) {
										if (!superTable.equals(transitiveCorr)) {
											if (!superClass.equals(transitiveCorr)) {
												if (!superClass.equals(superTable)) {
													if (!subTable.equals(transitiveCorr)) {
														if (!subTable.equals(supCorr)) {
															if (!subTable.equals(superTable)) {
																if (!subTable.equals(superClass)) {
																	if (!p2s.equals(transitiveCorr)) {
																		if (!p2s.equals(subCorr)) {
																			if (!p2s.equals(supCorr)) {
																				if (!p2s.equals(superTable)) {
																					if (!p2s.equals(superClass)) {
																						if (!p2s.equals(subTable)) {
																							if (!p2s.equals(subClass)) {
																								if (!p2s.equals(s)) {
																									if (!subClass
																											.equals(transitiveCorr)) {
																										if (!subClass
																												.equals(subCorr)) {
																											if (!subClass
																													.equals(supCorr)) {
																												if (!subClass
																														.equals(superTable)) {
																													if (!subClass
																															.equals(superClass)) {
																														if (!subClass
																																.equals(subTable)) {
																															if (!p.equals(
																																	transitiveCorr)) {
																																if (!p.equals(
																																		subCorr)) {
																																	if (!p.equals(
																																			supCorr)) {
																																		if (!p.equals(
																																				superTable)) {
																																			if (!p.equals(
																																					superClass)) {
																																				if (!p.equals(
																																						subTable)) {
																																					if (!p.equals(
																																							p2s)) {
																																						if (!p.equals(
																																								subClass)) {
																																							if (!p.equals(
																																									s)) {
																																								if (!s.equals(
																																										transitiveCorr)) {
																																									if (!s.equals(
																																											subCorr)) {
																																										if (!s.equals(
																																												supCorr)) {
																																											if (!s.equals(
																																													superTable)) {
																																												if (!s.equals(
																																														superClass)) {
																																													if (!s.equals(
																																															subTable)) {
																																														if (!s.equals(
																																																subClass)) {
																																															return new Object[] {
																																																	ruleresult,
																																																	transitiveCorr,
																																																	subCorr,
																																																	supCorr,
																																																	superTable,
																																																	superClass,
																																																	subTable,
																																																	p2s,
																																																	subClass,
																																																	p,
																																																	s };
																																														}
																																													}
																																												}
																																											}
																																										}
																																									}
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_1_3_bookkeepingforedges_greenBBBBBBBBFFFFFFF(
			PerformRuleResult ruleresult, EObject transitiveCorr, EObject subCorr, EObject superClass, EObject subTable,
			EObject subClass, EObject p, EObject s) {
		EMoflonEdge transitiveCorr__superClass____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge transitiveCorr__subTable____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge subCorr__subClass____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge subCorr__subTable____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p__subClass____classes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge subClass__superClass____superClass = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s__subTable____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String ruleresult_ruleName_prime = "CreateInheritanceRule";
		String transitiveCorr__superClass____source_name_prime = "source";
		String transitiveCorr__subTable____target_name_prime = "target";
		String subCorr__subClass____source_name_prime = "source";
		String subCorr__subTable____target_name_prime = "target";
		String p__subClass____classes_name_prime = "classes";
		String subClass__superClass____superClass_name_prime = "superClass";
		String s__subTable____tables_name_prime = "tables";
		transitiveCorr__superClass____source.setSrc(transitiveCorr);
		transitiveCorr__superClass____source.setTrg(superClass);
		ruleresult.getCreatedEdges().add(transitiveCorr__superClass____source);
		transitiveCorr__subTable____target.setSrc(transitiveCorr);
		transitiveCorr__subTable____target.setTrg(subTable);
		ruleresult.getCreatedEdges().add(transitiveCorr__subTable____target);
		subCorr__subClass____source.setSrc(subCorr);
		subCorr__subClass____source.setTrg(subClass);
		ruleresult.getCreatedEdges().add(subCorr__subClass____source);
		subCorr__subTable____target.setSrc(subCorr);
		subCorr__subTable____target.setTrg(subTable);
		ruleresult.getCreatedEdges().add(subCorr__subTable____target);
		p__subClass____classes.setSrc(p);
		p__subClass____classes.setTrg(subClass);
		ruleresult.getTranslatedEdges().add(p__subClass____classes);
		subClass__superClass____superClass.setSrc(subClass);
		subClass__superClass____superClass.setTrg(superClass);
		ruleresult.getTranslatedEdges().add(subClass__superClass____superClass);
		s__subTable____tables.setSrc(s);
		s__subTable____tables.setTrg(subTable);
		ruleresult.getCreatedEdges().add(s__subTable____tables);
		ruleresult.setRuleName(ruleresult_ruleName_prime);
		transitiveCorr__superClass____source.setName(transitiveCorr__superClass____source_name_prime);
		transitiveCorr__subTable____target.setName(transitiveCorr__subTable____target_name_prime);
		subCorr__subClass____source.setName(subCorr__subClass____source_name_prime);
		subCorr__subTable____target.setName(subCorr__subTable____target_name_prime);
		p__subClass____classes.setName(p__subClass____classes_name_prime);
		subClass__superClass____superClass.setName(subClass__superClass____superClass_name_prime);
		s__subTable____tables.setName(s__subTable____tables_name_prime);
		return new Object[] { ruleresult, transitiveCorr, subCorr, superClass, subTable, subClass, p, s,
				transitiveCorr__superClass____source, transitiveCorr__subTable____target, subCorr__subClass____source,
				subCorr__subTable____target, p__subClass____classes, subClass__superClass____superClass,
				s__subTable____tables };
	}

	public static final void pattern_CreateInheritanceRule_1_5_registerobjects_expressionBBBBBBBBBBBB(
			CreateInheritanceRule _this, PerformRuleResult ruleresult, EObject transitiveCorr, EObject subCorr,
			EObject supCorr, EObject superTable, EObject superClass, EObject subTable, EObject p2s, EObject subClass,
			EObject p, EObject s) {
		_this.registerObjects_FWD(ruleresult, transitiveCorr, subCorr, supCorr, superTable, superClass, subTable, p2s,
				subClass, p, s);

	}

	public static final PerformRuleResult pattern_CreateInheritanceRule_1_6_expressionFB(PerformRuleResult ruleresult) {
		PerformRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_2_1_preparereturnvalue_bindingFB(
			CreateInheritanceRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass eClass = _localVariable_0;
		if (eClass != null) {
			return new Object[] { eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_2_1_preparereturnvalue_blackFBB(EClass eClass,
			CreateInheritanceRule _this) {
		for (EOperation performOperation : eClass.getEOperations()) {
			String performOperation_name = performOperation.getName();
			if (performOperation_name.equals("perform_FWD")) {
				return new Object[] { performOperation, eClass, _this };
			}

		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_2_1_preparereturnvalue_bindingAndBlackFFB(
			CreateInheritanceRule _this) {
		Object[] result_pattern_CreateInheritanceRule_2_1_preparereturnvalue_binding = pattern_CreateInheritanceRule_2_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_CreateInheritanceRule_2_1_preparereturnvalue_binding != null) {
			EClass eClass = (EClass) result_pattern_CreateInheritanceRule_2_1_preparereturnvalue_binding[0];

			Object[] result_pattern_CreateInheritanceRule_2_1_preparereturnvalue_black = pattern_CreateInheritanceRule_2_1_preparereturnvalue_blackFBB(
					eClass, _this);
			if (result_pattern_CreateInheritanceRule_2_1_preparereturnvalue_black != null) {
				EOperation performOperation = (EOperation) result_pattern_CreateInheritanceRule_2_1_preparereturnvalue_black[0];

				return new Object[] { performOperation, eClass, _this };
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_2_1_preparereturnvalue_greenBF(
			EOperation performOperation) {
		IsApplicableRuleResult ruleresult = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		boolean ruleresult_success_prime = Boolean.valueOf(false);
		String ruleresult_rule_prime = "CreateInheritanceRule";
		ruleresult.setPerformOperation(performOperation);
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		ruleresult.setRule(ruleresult_rule_prime);
		return new Object[] { performOperation, ruleresult };
	}

	public static final Object[] pattern_CreateInheritanceRule_2_2_corematch_bindingFFFB(Match match) {
		EObject _localVariable_0 = match.getObject("superClass");
		EObject _localVariable_1 = match.getObject("subClass");
		EObject _localVariable_2 = match.getObject("p");
		EObject tmpSuperClass = _localVariable_0;
		EObject tmpSubClass = _localVariable_1;
		EObject tmpP = _localVariable_2;
		if (tmpSuperClass instanceof CDClass) {
			CDClass superClass = (CDClass) tmpSuperClass;
			if (tmpSubClass instanceof CDClass) {
				CDClass subClass = (CDClass) tmpSubClass;
				if (tmpP instanceof CDPackage) {
					CDPackage p = (CDPackage) tmpP;
					return new Object[] { superClass, subClass, p, match };
				}
			}
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_CreateInheritanceRule_2_2_corematch_blackFFBFBBFB(CDClass superClass,
			CDClass subClass, CDPackage p, Match match) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!subClass.equals(superClass)) {
			for (PackageToSchema p2s : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(p,
					PackageToSchema.class, "source")) {
				DBSchema s = p2s.getTarget();
				if (s != null) {
					for (ClassToTable supCorr : org.moflon.core.utilities.eMoflonEMFUtil
							.getOppositeReferenceTyped(superClass, ClassToTable.class, "source")) {
						DBTable superTable = supCorr.getTarget();
						if (superTable != null) {
							_result.add(new Object[] { supCorr, superTable, superClass, p2s, subClass, p, s, match });
						}

					}
				}

			}
		}
		return _result;
	}

	public static final Iterable<Object[]> pattern_CreateInheritanceRule_2_3_findcontext_blackBBBBBBB(
			ClassToTable supCorr, DBTable superTable, CDClass superClass, PackageToSchema p2s, CDClass subClass,
			CDPackage p, DBSchema s) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!subClass.equals(superClass)) {
			if (superTable.equals(supCorr.getTarget())) {
				if (p.getClasses().contains(subClass)) {
					if (p.equals(p2s.getSource())) {
						if (s.getTables().contains(superTable)) {
							if (superClass.equals(subClass.getSuperClass())) {
								if (superClass.equals(supCorr.getSource())) {
									if (s.equals(p2s.getTarget())) {
										if (p.getClasses().contains(superClass)) {
											_result.add(new Object[] { supCorr, superTable, superClass, p2s, subClass,
													p, s });
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_2_3_findcontext_greenBBBBBBBFFFFFFFFF(
			ClassToTable supCorr, DBTable superTable, CDClass superClass, PackageToSchema p2s, CDClass subClass,
			CDPackage p, DBSchema s) {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		EMoflonEdge supCorr__superTable____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p__subClass____classes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p2s__p____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s__superTable____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge subClass__superClass____superClass = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge supCorr__superClass____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p2s__s____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p__superClass____classes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String supCorr__superTable____target_name_prime = "target";
		String p__subClass____classes_name_prime = "classes";
		String p2s__p____source_name_prime = "source";
		String s__superTable____tables_name_prime = "tables";
		String subClass__superClass____superClass_name_prime = "superClass";
		String supCorr__superClass____source_name_prime = "source";
		String p2s__s____target_name_prime = "target";
		String p__superClass____classes_name_prime = "classes";
		isApplicableMatch.getAllContextElements().add(supCorr);
		isApplicableMatch.getAllContextElements().add(superTable);
		isApplicableMatch.getAllContextElements().add(superClass);
		isApplicableMatch.getAllContextElements().add(p2s);
		isApplicableMatch.getAllContextElements().add(subClass);
		isApplicableMatch.getAllContextElements().add(p);
		isApplicableMatch.getAllContextElements().add(s);
		supCorr__superTable____target.setSrc(supCorr);
		supCorr__superTable____target.setTrg(superTable);
		isApplicableMatch.getAllContextElements().add(supCorr__superTable____target);
		p__subClass____classes.setSrc(p);
		p__subClass____classes.setTrg(subClass);
		isApplicableMatch.getAllContextElements().add(p__subClass____classes);
		p2s__p____source.setSrc(p2s);
		p2s__p____source.setTrg(p);
		isApplicableMatch.getAllContextElements().add(p2s__p____source);
		s__superTable____tables.setSrc(s);
		s__superTable____tables.setTrg(superTable);
		isApplicableMatch.getAllContextElements().add(s__superTable____tables);
		subClass__superClass____superClass.setSrc(subClass);
		subClass__superClass____superClass.setTrg(superClass);
		isApplicableMatch.getAllContextElements().add(subClass__superClass____superClass);
		supCorr__superClass____source.setSrc(supCorr);
		supCorr__superClass____source.setTrg(superClass);
		isApplicableMatch.getAllContextElements().add(supCorr__superClass____source);
		p2s__s____target.setSrc(p2s);
		p2s__s____target.setTrg(s);
		isApplicableMatch.getAllContextElements().add(p2s__s____target);
		p__superClass____classes.setSrc(p);
		p__superClass____classes.setTrg(superClass);
		isApplicableMatch.getAllContextElements().add(p__superClass____classes);
		supCorr__superTable____target.setName(supCorr__superTable____target_name_prime);
		p__subClass____classes.setName(p__subClass____classes_name_prime);
		p2s__p____source.setName(p2s__p____source_name_prime);
		s__superTable____tables.setName(s__superTable____tables_name_prime);
		subClass__superClass____superClass.setName(subClass__superClass____superClass_name_prime);
		supCorr__superClass____source.setName(supCorr__superClass____source_name_prime);
		p2s__s____target.setName(p2s__s____target_name_prime);
		p__superClass____classes.setName(p__superClass____classes_name_prime);
		return new Object[] { supCorr, superTable, superClass, p2s, subClass, p, s, isApplicableMatch,
				supCorr__superTable____target, p__subClass____classes, p2s__p____source, s__superTable____tables,
				subClass__superClass____superClass, supCorr__superClass____source, p2s__s____target,
				p__superClass____classes };
	}

	public static final Object[] pattern_CreateInheritanceRule_2_4_solveCSP_bindingFBBBBBBBBB(
			CreateInheritanceRule _this, IsApplicableMatch isApplicableMatch, ClassToTable supCorr, DBTable superTable,
			CDClass superClass, PackageToSchema p2s, CDClass subClass, CDPackage p, DBSchema s) {
		CSP _localVariable_0 = _this.isApplicable_solveCsp_FWD(isApplicableMatch, supCorr, superTable, superClass, p2s,
				subClass, p, s);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, supCorr, superTable, superClass, p2s, subClass, p, s };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_2_4_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_CreateInheritanceRule_2_4_solveCSP_bindingAndBlackFBBBBBBBBB(
			CreateInheritanceRule _this, IsApplicableMatch isApplicableMatch, ClassToTable supCorr, DBTable superTable,
			CDClass superClass, PackageToSchema p2s, CDClass subClass, CDPackage p, DBSchema s) {
		Object[] result_pattern_CreateInheritanceRule_2_4_solveCSP_binding = pattern_CreateInheritanceRule_2_4_solveCSP_bindingFBBBBBBBBB(
				_this, isApplicableMatch, supCorr, superTable, superClass, p2s, subClass, p, s);
		if (result_pattern_CreateInheritanceRule_2_4_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_CreateInheritanceRule_2_4_solveCSP_binding[0];

			Object[] result_pattern_CreateInheritanceRule_2_4_solveCSP_black = pattern_CreateInheritanceRule_2_4_solveCSP_blackB(
					csp);
			if (result_pattern_CreateInheritanceRule_2_4_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, supCorr, superTable, superClass, p2s, subClass, p,
						s };
			}
		}
		return null;
	}

	public static final boolean pattern_CreateInheritanceRule_2_5_checkCSP_expressionFBB(CreateInheritanceRule _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isApplicable_checkCsp_FWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_2_6_addmatchtoruleresult_blackBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final Object[] pattern_CreateInheritanceRule_2_6_addmatchtoruleresult_greenBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		ruleresult.getIsApplicableMatch().add(isApplicableMatch);
		boolean ruleresult_success_prime = Boolean.valueOf(true);
		String isApplicableMatch_ruleName_prime = "CreateInheritanceRule";
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		isApplicableMatch.setRuleName(isApplicableMatch_ruleName_prime);
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final IsApplicableRuleResult pattern_CreateInheritanceRule_2_7_expressionFB(
			IsApplicableRuleResult ruleresult) {
		IsApplicableRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_10_1_initialbindings_blackBBBBB(
			CreateInheritanceRule _this, Match match, DBTable superTable, DBTable subTable, DBSchema s) {
		if (!subTable.equals(superTable)) {
			return new Object[] { _this, match, superTable, subTable, s };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_10_2_SolveCSP_bindingFBBBBB(CreateInheritanceRule _this,
			Match match, DBTable superTable, DBTable subTable, DBSchema s) {
		CSP _localVariable_0 = _this.isAppropriate_solveCsp_BWD(match, superTable, subTable, s);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, match, superTable, subTable, s };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_10_2_SolveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_CreateInheritanceRule_10_2_SolveCSP_bindingAndBlackFBBBBB(
			CreateInheritanceRule _this, Match match, DBTable superTable, DBTable subTable, DBSchema s) {
		Object[] result_pattern_CreateInheritanceRule_10_2_SolveCSP_binding = pattern_CreateInheritanceRule_10_2_SolveCSP_bindingFBBBBB(
				_this, match, superTable, subTable, s);
		if (result_pattern_CreateInheritanceRule_10_2_SolveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_CreateInheritanceRule_10_2_SolveCSP_binding[0];

			Object[] result_pattern_CreateInheritanceRule_10_2_SolveCSP_black = pattern_CreateInheritanceRule_10_2_SolveCSP_blackB(
					csp);
			if (result_pattern_CreateInheritanceRule_10_2_SolveCSP_black != null) {

				return new Object[] { csp, _this, match, superTable, subTable, s };
			}
		}
		return null;
	}

	public static final boolean pattern_CreateInheritanceRule_10_3_CheckCSP_expressionFBB(CreateInheritanceRule _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isAppropriate_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_10_4_collectelementstobetranslated_blackBBBB(Match match,
			DBTable superTable, DBTable subTable, DBSchema s) {
		if (!subTable.equals(superTable)) {
			return new Object[] { match, superTable, subTable, s };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_10_4_collectelementstobetranslated_greenBBBF(Match match,
			DBTable subTable, DBSchema s) {
		EMoflonEdge s__subTable____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getToBeTranslatedNodes().add(subTable);
		String s__subTable____tables_name_prime = "tables";
		s__subTable____tables.setSrc(s);
		s__subTable____tables.setTrg(subTable);
		match.getToBeTranslatedEdges().add(s__subTable____tables);
		s__subTable____tables.setName(s__subTable____tables_name_prime);
		return new Object[] { match, subTable, s, s__subTable____tables };
	}

	public static final Object[] pattern_CreateInheritanceRule_10_5_collectcontextelements_blackBBBB(Match match,
			DBTable superTable, DBTable subTable, DBSchema s) {
		if (!subTable.equals(superTable)) {
			return new Object[] { match, superTable, subTable, s };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_10_5_collectcontextelements_greenBBBF(Match match,
			DBTable superTable, DBSchema s) {
		EMoflonEdge s__superTable____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		match.getContextNodes().add(superTable);
		match.getContextNodes().add(s);
		String s__superTable____tables_name_prime = "tables";
		s__superTable____tables.setSrc(s);
		s__superTable____tables.setTrg(superTable);
		match.getContextEdges().add(s__superTable____tables);
		s__superTable____tables.setName(s__superTable____tables_name_prime);
		return new Object[] { match, superTable, s, s__superTable____tables };
	}

	public static final void pattern_CreateInheritanceRule_10_6_registerobjectstomatch_expressionBBBBB(
			CreateInheritanceRule _this, Match match, DBTable superTable, DBTable subTable, DBSchema s) {
		_this.registerObjectsToMatch_BWD(match, superTable, subTable, s);

	}

	public static final boolean pattern_CreateInheritanceRule_10_7_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_CreateInheritanceRule_10_8_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_11_1_performtransformation_bindingFFFFFFFB(
			IsApplicableMatch isApplicableMatch) {
		EObject _localVariable_0 = isApplicableMatch.getObject("supCorr");
		EObject _localVariable_1 = isApplicableMatch.getObject("superTable");
		EObject _localVariable_2 = isApplicableMatch.getObject("superClass");
		EObject _localVariable_3 = isApplicableMatch.getObject("subTable");
		EObject _localVariable_4 = isApplicableMatch.getObject("p2s");
		EObject _localVariable_5 = isApplicableMatch.getObject("p");
		EObject _localVariable_6 = isApplicableMatch.getObject("s");
		EObject tmpSupCorr = _localVariable_0;
		EObject tmpSuperTable = _localVariable_1;
		EObject tmpSuperClass = _localVariable_2;
		EObject tmpSubTable = _localVariable_3;
		EObject tmpP2s = _localVariable_4;
		EObject tmpP = _localVariable_5;
		EObject tmpS = _localVariable_6;
		if (tmpSupCorr instanceof ClassToTable) {
			ClassToTable supCorr = (ClassToTable) tmpSupCorr;
			if (tmpSuperTable instanceof DBTable) {
				DBTable superTable = (DBTable) tmpSuperTable;
				if (tmpSuperClass instanceof CDClass) {
					CDClass superClass = (CDClass) tmpSuperClass;
					if (tmpSubTable instanceof DBTable) {
						DBTable subTable = (DBTable) tmpSubTable;
						if (tmpP2s instanceof PackageToSchema) {
							PackageToSchema p2s = (PackageToSchema) tmpP2s;
							if (tmpP instanceof CDPackage) {
								CDPackage p = (CDPackage) tmpP;
								if (tmpS instanceof DBSchema) {
									DBSchema s = (DBSchema) tmpS;
									return new Object[] { supCorr, superTable, superClass, subTable, p2s, p, s,
											isApplicableMatch };
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_11_1_performtransformation_blackBBBBBBBFBB(
			ClassToTable supCorr, DBTable superTable, CDClass superClass, DBTable subTable, PackageToSchema p2s,
			CDPackage p, DBSchema s, CreateInheritanceRule _this, IsApplicableMatch isApplicableMatch) {
		if (!subTable.equals(superTable)) {
			for (EObject tmpCsp : isApplicableMatch.getAttributeInfo()) {
				if (tmpCsp instanceof CSP) {
					CSP csp = (CSP) tmpCsp;
					return new Object[] { supCorr, superTable, superClass, subTable, p2s, p, s, csp, _this,
							isApplicableMatch };
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_11_1_performtransformation_bindingAndBlackFFFFFFFFBB(
			CreateInheritanceRule _this, IsApplicableMatch isApplicableMatch) {
		Object[] result_pattern_CreateInheritanceRule_11_1_performtransformation_binding = pattern_CreateInheritanceRule_11_1_performtransformation_bindingFFFFFFFB(
				isApplicableMatch);
		if (result_pattern_CreateInheritanceRule_11_1_performtransformation_binding != null) {
			ClassToTable supCorr = (ClassToTable) result_pattern_CreateInheritanceRule_11_1_performtransformation_binding[0];
			DBTable superTable = (DBTable) result_pattern_CreateInheritanceRule_11_1_performtransformation_binding[1];
			CDClass superClass = (CDClass) result_pattern_CreateInheritanceRule_11_1_performtransformation_binding[2];
			DBTable subTable = (DBTable) result_pattern_CreateInheritanceRule_11_1_performtransformation_binding[3];
			PackageToSchema p2s = (PackageToSchema) result_pattern_CreateInheritanceRule_11_1_performtransformation_binding[4];
			CDPackage p = (CDPackage) result_pattern_CreateInheritanceRule_11_1_performtransformation_binding[5];
			DBSchema s = (DBSchema) result_pattern_CreateInheritanceRule_11_1_performtransformation_binding[6];

			Object[] result_pattern_CreateInheritanceRule_11_1_performtransformation_black = pattern_CreateInheritanceRule_11_1_performtransformation_blackBBBBBBBFBB(
					supCorr, superTable, superClass, subTable, p2s, p, s, _this, isApplicableMatch);
			if (result_pattern_CreateInheritanceRule_11_1_performtransformation_black != null) {
				CSP csp = (CSP) result_pattern_CreateInheritanceRule_11_1_performtransformation_black[7];

				return new Object[] { supCorr, superTable, superClass, subTable, p2s, p, s, csp, _this,
						isApplicableMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_11_1_performtransformation_greenFFBBFBB(
			CDClass superClass, DBTable subTable, CDPackage p, CSP csp) {
		SuperClassToTable transitiveCorr = CDToDBFactory.eINSTANCE.createSuperClassToTable();
		ClassToTable subCorr = CDToDBFactory.eINSTANCE.createClassToTable();
		CDClass subClass = ClassDiagramsFactory.eINSTANCE.createCDClass();
		Object _localVariable_0 = csp.getValue("subClass", "name");
		transitiveCorr.setSource(superClass);
		transitiveCorr.setTarget(subTable);
		subCorr.setTarget(subTable);
		subCorr.setSource(subClass);
		p.getClasses().add(subClass);
		subClass.setSuperClass(superClass);
		String subClass_name_prime = (String) _localVariable_0;
		subClass.setName(subClass_name_prime);
		return new Object[] { transitiveCorr, subCorr, superClass, subTable, subClass, p, csp };
	}

	public static final Object[] pattern_CreateInheritanceRule_11_2_collecttranslatedelements_blackBBBB(
			SuperClassToTable transitiveCorr, ClassToTable subCorr, DBTable subTable, CDClass subClass) {
		return new Object[] { transitiveCorr, subCorr, subTable, subClass };
	}

	public static final Object[] pattern_CreateInheritanceRule_11_2_collecttranslatedelements_greenFBBBB(
			SuperClassToTable transitiveCorr, ClassToTable subCorr, DBTable subTable, CDClass subClass) {
		PerformRuleResult ruleresult = RuntimeFactory.eINSTANCE.createPerformRuleResult();
		ruleresult.getCreatedLinkElements().add(transitiveCorr);
		ruleresult.getCreatedLinkElements().add(subCorr);
		ruleresult.getTranslatedElements().add(subTable);
		ruleresult.getCreatedElements().add(subClass);
		return new Object[] { ruleresult, transitiveCorr, subCorr, subTable, subClass };
	}

	public static final Object[] pattern_CreateInheritanceRule_11_3_bookkeepingforedges_blackBBBBBBBBBBB(
			PerformRuleResult ruleresult, EObject transitiveCorr, EObject subCorr, EObject supCorr, EObject superTable,
			EObject superClass, EObject subTable, EObject p2s, EObject subClass, EObject p, EObject s) {
		if (!subCorr.equals(transitiveCorr)) {
			if (!subCorr.equals(supCorr)) {
				if (!subCorr.equals(superTable)) {
					if (!subCorr.equals(superClass)) {
						if (!subCorr.equals(subTable)) {
							if (!supCorr.equals(transitiveCorr)) {
								if (!supCorr.equals(superTable)) {
									if (!supCorr.equals(superClass)) {
										if (!superTable.equals(transitiveCorr)) {
											if (!superClass.equals(transitiveCorr)) {
												if (!superClass.equals(superTable)) {
													if (!subTable.equals(transitiveCorr)) {
														if (!subTable.equals(supCorr)) {
															if (!subTable.equals(superTable)) {
																if (!subTable.equals(superClass)) {
																	if (!p2s.equals(transitiveCorr)) {
																		if (!p2s.equals(subCorr)) {
																			if (!p2s.equals(supCorr)) {
																				if (!p2s.equals(superTable)) {
																					if (!p2s.equals(superClass)) {
																						if (!p2s.equals(subTable)) {
																							if (!p2s.equals(subClass)) {
																								if (!p2s.equals(s)) {
																									if (!subClass
																											.equals(transitiveCorr)) {
																										if (!subClass
																												.equals(subCorr)) {
																											if (!subClass
																													.equals(supCorr)) {
																												if (!subClass
																														.equals(superTable)) {
																													if (!subClass
																															.equals(superClass)) {
																														if (!subClass
																																.equals(subTable)) {
																															if (!p.equals(
																																	transitiveCorr)) {
																																if (!p.equals(
																																		subCorr)) {
																																	if (!p.equals(
																																			supCorr)) {
																																		if (!p.equals(
																																				superTable)) {
																																			if (!p.equals(
																																					superClass)) {
																																				if (!p.equals(
																																						subTable)) {
																																					if (!p.equals(
																																							p2s)) {
																																						if (!p.equals(
																																								subClass)) {
																																							if (!p.equals(
																																									s)) {
																																								if (!s.equals(
																																										transitiveCorr)) {
																																									if (!s.equals(
																																											subCorr)) {
																																										if (!s.equals(
																																												supCorr)) {
																																											if (!s.equals(
																																													superTable)) {
																																												if (!s.equals(
																																														superClass)) {
																																													if (!s.equals(
																																															subTable)) {
																																														if (!s.equals(
																																																subClass)) {
																																															return new Object[] {
																																																	ruleresult,
																																																	transitiveCorr,
																																																	subCorr,
																																																	supCorr,
																																																	superTable,
																																																	superClass,
																																																	subTable,
																																																	p2s,
																																																	subClass,
																																																	p,
																																																	s };
																																														}
																																													}
																																												}
																																											}
																																										}
																																									}
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_11_3_bookkeepingforedges_greenBBBBBBBBFFFFFFF(
			PerformRuleResult ruleresult, EObject transitiveCorr, EObject subCorr, EObject superClass, EObject subTable,
			EObject subClass, EObject p, EObject s) {
		EMoflonEdge transitiveCorr__superClass____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge transitiveCorr__subTable____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge subCorr__subClass____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge subCorr__subTable____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p__subClass____classes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge subClass__superClass____superClass = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s__subTable____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String ruleresult_ruleName_prime = "CreateInheritanceRule";
		String transitiveCorr__superClass____source_name_prime = "source";
		String transitiveCorr__subTable____target_name_prime = "target";
		String subCorr__subClass____source_name_prime = "source";
		String subCorr__subTable____target_name_prime = "target";
		String p__subClass____classes_name_prime = "classes";
		String subClass__superClass____superClass_name_prime = "superClass";
		String s__subTable____tables_name_prime = "tables";
		transitiveCorr__superClass____source.setSrc(transitiveCorr);
		transitiveCorr__superClass____source.setTrg(superClass);
		ruleresult.getCreatedEdges().add(transitiveCorr__superClass____source);
		transitiveCorr__subTable____target.setSrc(transitiveCorr);
		transitiveCorr__subTable____target.setTrg(subTable);
		ruleresult.getCreatedEdges().add(transitiveCorr__subTable____target);
		subCorr__subClass____source.setSrc(subCorr);
		subCorr__subClass____source.setTrg(subClass);
		ruleresult.getCreatedEdges().add(subCorr__subClass____source);
		subCorr__subTable____target.setSrc(subCorr);
		subCorr__subTable____target.setTrg(subTable);
		ruleresult.getCreatedEdges().add(subCorr__subTable____target);
		p__subClass____classes.setSrc(p);
		p__subClass____classes.setTrg(subClass);
		ruleresult.getCreatedEdges().add(p__subClass____classes);
		subClass__superClass____superClass.setSrc(subClass);
		subClass__superClass____superClass.setTrg(superClass);
		ruleresult.getCreatedEdges().add(subClass__superClass____superClass);
		s__subTable____tables.setSrc(s);
		s__subTable____tables.setTrg(subTable);
		ruleresult.getTranslatedEdges().add(s__subTable____tables);
		ruleresult.setRuleName(ruleresult_ruleName_prime);
		transitiveCorr__superClass____source.setName(transitiveCorr__superClass____source_name_prime);
		transitiveCorr__subTable____target.setName(transitiveCorr__subTable____target_name_prime);
		subCorr__subClass____source.setName(subCorr__subClass____source_name_prime);
		subCorr__subTable____target.setName(subCorr__subTable____target_name_prime);
		p__subClass____classes.setName(p__subClass____classes_name_prime);
		subClass__superClass____superClass.setName(subClass__superClass____superClass_name_prime);
		s__subTable____tables.setName(s__subTable____tables_name_prime);
		return new Object[] { ruleresult, transitiveCorr, subCorr, superClass, subTable, subClass, p, s,
				transitiveCorr__superClass____source, transitiveCorr__subTable____target, subCorr__subClass____source,
				subCorr__subTable____target, p__subClass____classes, subClass__superClass____superClass,
				s__subTable____tables };
	}

	public static final void pattern_CreateInheritanceRule_11_5_registerobjects_expressionBBBBBBBBBBBB(
			CreateInheritanceRule _this, PerformRuleResult ruleresult, EObject transitiveCorr, EObject subCorr,
			EObject supCorr, EObject superTable, EObject superClass, EObject subTable, EObject p2s, EObject subClass,
			EObject p, EObject s) {
		_this.registerObjects_BWD(ruleresult, transitiveCorr, subCorr, supCorr, superTable, superClass, subTable, p2s,
				subClass, p, s);

	}

	public static final PerformRuleResult pattern_CreateInheritanceRule_11_6_expressionFB(
			PerformRuleResult ruleresult) {
		PerformRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_12_1_preparereturnvalue_bindingFB(
			CreateInheritanceRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass eClass = _localVariable_0;
		if (eClass != null) {
			return new Object[] { eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_12_1_preparereturnvalue_blackFBB(EClass eClass,
			CreateInheritanceRule _this) {
		for (EOperation performOperation : eClass.getEOperations()) {
			String performOperation_name = performOperation.getName();
			if (performOperation_name.equals("perform_BWD")) {
				return new Object[] { performOperation, eClass, _this };
			}

		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_12_1_preparereturnvalue_bindingAndBlackFFB(
			CreateInheritanceRule _this) {
		Object[] result_pattern_CreateInheritanceRule_12_1_preparereturnvalue_binding = pattern_CreateInheritanceRule_12_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_CreateInheritanceRule_12_1_preparereturnvalue_binding != null) {
			EClass eClass = (EClass) result_pattern_CreateInheritanceRule_12_1_preparereturnvalue_binding[0];

			Object[] result_pattern_CreateInheritanceRule_12_1_preparereturnvalue_black = pattern_CreateInheritanceRule_12_1_preparereturnvalue_blackFBB(
					eClass, _this);
			if (result_pattern_CreateInheritanceRule_12_1_preparereturnvalue_black != null) {
				EOperation performOperation = (EOperation) result_pattern_CreateInheritanceRule_12_1_preparereturnvalue_black[0];

				return new Object[] { performOperation, eClass, _this };
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_12_1_preparereturnvalue_greenBF(
			EOperation performOperation) {
		IsApplicableRuleResult ruleresult = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		boolean ruleresult_success_prime = Boolean.valueOf(false);
		String ruleresult_rule_prime = "CreateInheritanceRule";
		ruleresult.setPerformOperation(performOperation);
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		ruleresult.setRule(ruleresult_rule_prime);
		return new Object[] { performOperation, ruleresult };
	}

	public static final Object[] pattern_CreateInheritanceRule_12_2_corematch_bindingFFFB(Match match) {
		EObject _localVariable_0 = match.getObject("superTable");
		EObject _localVariable_1 = match.getObject("subTable");
		EObject _localVariable_2 = match.getObject("s");
		EObject tmpSuperTable = _localVariable_0;
		EObject tmpSubTable = _localVariable_1;
		EObject tmpS = _localVariable_2;
		if (tmpSuperTable instanceof DBTable) {
			DBTable superTable = (DBTable) tmpSuperTable;
			if (tmpSubTable instanceof DBTable) {
				DBTable subTable = (DBTable) tmpSubTable;
				if (tmpS instanceof DBSchema) {
					DBSchema s = (DBSchema) tmpS;
					return new Object[] { superTable, subTable, s, match };
				}
			}
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_CreateInheritanceRule_12_2_corematch_blackFBFBFFBB(
			DBTable superTable, DBTable subTable, DBSchema s, Match match) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!subTable.equals(superTable)) {
			for (ClassToTable supCorr : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(superTable,
					ClassToTable.class, "target")) {
				CDClass superClass = supCorr.getSource();
				if (superClass != null) {
					for (PackageToSchema p2s : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(s,
							PackageToSchema.class, "target")) {
						CDPackage p = p2s.getSource();
						if (p != null) {
							_result.add(new Object[] { supCorr, superTable, superClass, subTable, p2s, p, s, match });
						}

					}
				}

			}
		}
		return _result;
	}

	public static final Iterable<Object[]> pattern_CreateInheritanceRule_12_3_findcontext_blackBBBBBBB(
			ClassToTable supCorr, DBTable superTable, CDClass superClass, DBTable subTable, PackageToSchema p2s,
			CDPackage p, DBSchema s) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!subTable.equals(superTable)) {
			if (superTable.equals(supCorr.getTarget())) {
				if (p.equals(p2s.getSource())) {
					if (s.getTables().contains(superTable)) {
						if (superClass.equals(supCorr.getSource())) {
							if (s.getTables().contains(subTable)) {
								if (s.equals(p2s.getTarget())) {
									if (p.getClasses().contains(superClass)) {
										_result.add(
												new Object[] { supCorr, superTable, superClass, subTable, p2s, p, s });
									}
								}
							}
						}
					}
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_12_3_findcontext_greenBBBBBBBFFFFFFFF(
			ClassToTable supCorr, DBTable superTable, CDClass superClass, DBTable subTable, PackageToSchema p2s,
			CDPackage p, DBSchema s) {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		EMoflonEdge supCorr__superTable____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p2s__p____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s__superTable____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge supCorr__superClass____source = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge s__subTable____tables = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p2s__s____target = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		EMoflonEdge p__superClass____classes = RuntimeFactory.eINSTANCE.createEMoflonEdge();
		String supCorr__superTable____target_name_prime = "target";
		String p2s__p____source_name_prime = "source";
		String s__superTable____tables_name_prime = "tables";
		String supCorr__superClass____source_name_prime = "source";
		String s__subTable____tables_name_prime = "tables";
		String p2s__s____target_name_prime = "target";
		String p__superClass____classes_name_prime = "classes";
		isApplicableMatch.getAllContextElements().add(supCorr);
		isApplicableMatch.getAllContextElements().add(superTable);
		isApplicableMatch.getAllContextElements().add(superClass);
		isApplicableMatch.getAllContextElements().add(subTable);
		isApplicableMatch.getAllContextElements().add(p2s);
		isApplicableMatch.getAllContextElements().add(p);
		isApplicableMatch.getAllContextElements().add(s);
		supCorr__superTable____target.setSrc(supCorr);
		supCorr__superTable____target.setTrg(superTable);
		isApplicableMatch.getAllContextElements().add(supCorr__superTable____target);
		p2s__p____source.setSrc(p2s);
		p2s__p____source.setTrg(p);
		isApplicableMatch.getAllContextElements().add(p2s__p____source);
		s__superTable____tables.setSrc(s);
		s__superTable____tables.setTrg(superTable);
		isApplicableMatch.getAllContextElements().add(s__superTable____tables);
		supCorr__superClass____source.setSrc(supCorr);
		supCorr__superClass____source.setTrg(superClass);
		isApplicableMatch.getAllContextElements().add(supCorr__superClass____source);
		s__subTable____tables.setSrc(s);
		s__subTable____tables.setTrg(subTable);
		isApplicableMatch.getAllContextElements().add(s__subTable____tables);
		p2s__s____target.setSrc(p2s);
		p2s__s____target.setTrg(s);
		isApplicableMatch.getAllContextElements().add(p2s__s____target);
		p__superClass____classes.setSrc(p);
		p__superClass____classes.setTrg(superClass);
		isApplicableMatch.getAllContextElements().add(p__superClass____classes);
		supCorr__superTable____target.setName(supCorr__superTable____target_name_prime);
		p2s__p____source.setName(p2s__p____source_name_prime);
		s__superTable____tables.setName(s__superTable____tables_name_prime);
		supCorr__superClass____source.setName(supCorr__superClass____source_name_prime);
		s__subTable____tables.setName(s__subTable____tables_name_prime);
		p2s__s____target.setName(p2s__s____target_name_prime);
		p__superClass____classes.setName(p__superClass____classes_name_prime);
		return new Object[] { supCorr, superTable, superClass, subTable, p2s, p, s, isApplicableMatch,
				supCorr__superTable____target, p2s__p____source, s__superTable____tables, supCorr__superClass____source,
				s__subTable____tables, p2s__s____target, p__superClass____classes };
	}

	public static final Object[] pattern_CreateInheritanceRule_12_4_solveCSP_bindingFBBBBBBBBB(
			CreateInheritanceRule _this, IsApplicableMatch isApplicableMatch, ClassToTable supCorr, DBTable superTable,
			CDClass superClass, DBTable subTable, PackageToSchema p2s, CDPackage p, DBSchema s) {
		CSP _localVariable_0 = _this.isApplicable_solveCsp_BWD(isApplicableMatch, supCorr, superTable, superClass,
				subTable, p2s, p, s);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, supCorr, superTable, superClass, subTable, p2s, p, s };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_12_4_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_CreateInheritanceRule_12_4_solveCSP_bindingAndBlackFBBBBBBBBB(
			CreateInheritanceRule _this, IsApplicableMatch isApplicableMatch, ClassToTable supCorr, DBTable superTable,
			CDClass superClass, DBTable subTable, PackageToSchema p2s, CDPackage p, DBSchema s) {
		Object[] result_pattern_CreateInheritanceRule_12_4_solveCSP_binding = pattern_CreateInheritanceRule_12_4_solveCSP_bindingFBBBBBBBBB(
				_this, isApplicableMatch, supCorr, superTable, superClass, subTable, p2s, p, s);
		if (result_pattern_CreateInheritanceRule_12_4_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_CreateInheritanceRule_12_4_solveCSP_binding[0];

			Object[] result_pattern_CreateInheritanceRule_12_4_solveCSP_black = pattern_CreateInheritanceRule_12_4_solveCSP_blackB(
					csp);
			if (result_pattern_CreateInheritanceRule_12_4_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, supCorr, superTable, superClass, subTable, p2s, p,
						s };
			}
		}
		return null;
	}

	public static final boolean pattern_CreateInheritanceRule_12_5_checkCSP_expressionFBB(CreateInheritanceRule _this,
			CSP csp) {
		boolean _localVariable_0 = _this.isApplicable_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_12_6_addmatchtoruleresult_blackBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final Object[] pattern_CreateInheritanceRule_12_6_addmatchtoruleresult_greenBB(
			IsApplicableRuleResult ruleresult, IsApplicableMatch isApplicableMatch) {
		ruleresult.getIsApplicableMatch().add(isApplicableMatch);
		boolean ruleresult_success_prime = Boolean.valueOf(true);
		String isApplicableMatch_ruleName_prime = "CreateInheritanceRule";
		ruleresult.setSuccess(Boolean.valueOf(ruleresult_success_prime));
		isApplicableMatch.setRuleName(isApplicableMatch_ruleName_prime);
		return new Object[] { ruleresult, isApplicableMatch };
	}

	public static final IsApplicableRuleResult pattern_CreateInheritanceRule_12_7_expressionFB(
			IsApplicableRuleResult ruleresult) {
		IsApplicableRuleResult _result = ruleresult;
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_20_1_preparereturnvalue_bindingFB(
			CreateInheritanceRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass __eClass = _localVariable_0;
		if (__eClass != null) {
			return new Object[] { __eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_20_1_preparereturnvalue_blackFBBF(EClass __eClass,
			CreateInheritanceRule _this) {
		for (EOperation __performOperation : __eClass.getEOperations()) {
			String __performOperation_name = __performOperation.getName();
			if (__performOperation_name.equals("isApplicable_FWD")) {
				for (EOperation isApplicableCC : __eClass.getEOperations()) {
					if (!__performOperation.equals(isApplicableCC)) {
						String isApplicableCC_name = isApplicableCC.getName();
						if (isApplicableCC_name.equals("isApplicable_CC")) {
							return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
						}

					}
				}
			}

		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_20_1_preparereturnvalue_bindingAndBlackFFBF(
			CreateInheritanceRule _this) {
		Object[] result_pattern_CreateInheritanceRule_20_1_preparereturnvalue_binding = pattern_CreateInheritanceRule_20_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_CreateInheritanceRule_20_1_preparereturnvalue_binding != null) {
			EClass __eClass = (EClass) result_pattern_CreateInheritanceRule_20_1_preparereturnvalue_binding[0];

			Object[] result_pattern_CreateInheritanceRule_20_1_preparereturnvalue_black = pattern_CreateInheritanceRule_20_1_preparereturnvalue_blackFBBF(
					__eClass, _this);
			if (result_pattern_CreateInheritanceRule_20_1_preparereturnvalue_black != null) {
				EOperation __performOperation = (EOperation) result_pattern_CreateInheritanceRule_20_1_preparereturnvalue_black[0];
				EOperation isApplicableCC = (EOperation) result_pattern_CreateInheritanceRule_20_1_preparereturnvalue_black[3];

				return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_20_1_preparereturnvalue_greenF() {
		EObjectContainer __result = RuntimeFactory.eINSTANCE.createEObjectContainer();
		return new Object[] { __result };
	}

	public static final Iterable<Object[]> pattern_CreateInheritanceRule_20_2_testcorematchandDECs_blackFFFB(
			EMoflonEdge _edge_classes) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		EObject tmpP = _edge_classes.getSrc();
		if (tmpP instanceof CDPackage) {
			CDPackage p = (CDPackage) tmpP;
			EObject tmpSubClass = _edge_classes.getTrg();
			if (tmpSubClass instanceof CDClass) {
				CDClass subClass = (CDClass) tmpSubClass;
				if (p.getClasses().contains(subClass)) {
					CDClass superClass = subClass.getSuperClass();
					if (superClass != null) {
						if (!subClass.equals(superClass)) {
							if (p.getClasses().contains(superClass)) {
								_result.add(new Object[] { superClass, subClass, p, _edge_classes });
							}
						}
					}

				}
			}

		}

		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_20_2_testcorematchandDECs_greenFB(EClass __eClass) {
		Match match = RuntimeFactory.eINSTANCE.createMatch();
		String __eClass_name = __eClass.getName();
		String match_ruleName_prime = __eClass_name;
		match.setRuleName(match_ruleName_prime);
		return new Object[] { match, __eClass };

	}

	public static final boolean pattern_CreateInheritanceRule_20_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBBB(
			CreateInheritanceRule _this, Match match, CDClass superClass, CDClass subClass, CDPackage p) {
		boolean _localVariable_0 = _this.isAppropriate_FWD(match, superClass, subClass, p);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final boolean pattern_CreateInheritanceRule_20_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
			CreateInheritanceRule _this, Match match) {
		boolean _localVariable_0 = _this.checkTypes_FWD(match);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_20_5_Addmatchtoruleresult_blackBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		if (!__performOperation.equals(isApplicableCC)) {
			return new Object[] { match, __performOperation, __result, isApplicableCC };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_20_5_Addmatchtoruleresult_greenBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		__result.getContents().add(match);
		match.setIsApplicableOperation(__performOperation);
		match.setIsApplicableCCOperation(isApplicableCC);
		return new Object[] { match, __performOperation, __result, isApplicableCC };
	}

	public static final EObjectContainer pattern_CreateInheritanceRule_20_6_expressionFB(EObjectContainer __result) {
		EObjectContainer _result = __result;
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_21_1_preparereturnvalue_bindingFB(
			CreateInheritanceRule _this) {
		EClass _localVariable_0 = _this.eClass();
		EClass __eClass = _localVariable_0;
		if (__eClass != null) {
			return new Object[] { __eClass, _this };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_21_1_preparereturnvalue_blackFBBF(EClass __eClass,
			CreateInheritanceRule _this) {
		for (EOperation __performOperation : __eClass.getEOperations()) {
			String __performOperation_name = __performOperation.getName();
			if (__performOperation_name.equals("isApplicable_BWD")) {
				for (EOperation isApplicableCC : __eClass.getEOperations()) {
					if (!__performOperation.equals(isApplicableCC)) {
						String isApplicableCC_name = isApplicableCC.getName();
						if (isApplicableCC_name.equals("isApplicable_CC")) {
							return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
						}

					}
				}
			}

		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_21_1_preparereturnvalue_bindingAndBlackFFBF(
			CreateInheritanceRule _this) {
		Object[] result_pattern_CreateInheritanceRule_21_1_preparereturnvalue_binding = pattern_CreateInheritanceRule_21_1_preparereturnvalue_bindingFB(
				_this);
		if (result_pattern_CreateInheritanceRule_21_1_preparereturnvalue_binding != null) {
			EClass __eClass = (EClass) result_pattern_CreateInheritanceRule_21_1_preparereturnvalue_binding[0];

			Object[] result_pattern_CreateInheritanceRule_21_1_preparereturnvalue_black = pattern_CreateInheritanceRule_21_1_preparereturnvalue_blackFBBF(
					__eClass, _this);
			if (result_pattern_CreateInheritanceRule_21_1_preparereturnvalue_black != null) {
				EOperation __performOperation = (EOperation) result_pattern_CreateInheritanceRule_21_1_preparereturnvalue_black[0];
				EOperation isApplicableCC = (EOperation) result_pattern_CreateInheritanceRule_21_1_preparereturnvalue_black[3];

				return new Object[] { __performOperation, __eClass, _this, isApplicableCC };
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_21_1_preparereturnvalue_greenF() {
		EObjectContainer __result = RuntimeFactory.eINSTANCE.createEObjectContainer();
		return new Object[] { __result };
	}

	public static final Iterable<Object[]> pattern_CreateInheritanceRule_21_2_testcorematchandDECs_blackFFFB(
			EMoflonEdge _edge_tables) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		EObject tmpS = _edge_tables.getSrc();
		if (tmpS instanceof DBSchema) {
			DBSchema s = (DBSchema) tmpS;
			EObject tmpSubTable = _edge_tables.getTrg();
			if (tmpSubTable instanceof DBTable) {
				DBTable subTable = (DBTable) tmpSubTable;
				if (s.getTables().contains(subTable)) {
					for (EObject tmpSuperTable : s.getTables()) {
						if (tmpSuperTable instanceof DBTable) {
							DBTable superTable = (DBTable) tmpSuperTable;
							if (!subTable.equals(superTable)) {
								_result.add(new Object[] { superTable, subTable, s, _edge_tables });
							}
						}
					}
				}
			}

		}

		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_21_2_testcorematchandDECs_greenFB(EClass __eClass) {
		Match match = RuntimeFactory.eINSTANCE.createMatch();
		String __eClass_name = __eClass.getName();
		String match_ruleName_prime = __eClass_name;
		match.setRuleName(match_ruleName_prime);
		return new Object[] { match, __eClass };

	}

	public static final boolean pattern_CreateInheritanceRule_21_3_bookkeepingwithgenericisAppropriatemethod_expressionFBBBBB(
			CreateInheritanceRule _this, Match match, DBTable superTable, DBTable subTable, DBSchema s) {
		boolean _localVariable_0 = _this.isAppropriate_BWD(match, superTable, subTable, s);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final boolean pattern_CreateInheritanceRule_21_4_Ensurethatthecorrecttypesofelementsarematched_expressionFBB(
			CreateInheritanceRule _this, Match match) {
		boolean _localVariable_0 = _this.checkTypes_BWD(match);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_21_5_Addmatchtoruleresult_blackBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		if (!__performOperation.equals(isApplicableCC)) {
			return new Object[] { match, __performOperation, __result, isApplicableCC };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_21_5_Addmatchtoruleresult_greenBBBB(Match match,
			EOperation __performOperation, EObjectContainer __result, EOperation isApplicableCC) {
		__result.getContents().add(match);
		match.setIsApplicableOperation(__performOperation);
		match.setIsApplicableCCOperation(isApplicableCC);
		return new Object[] { match, __performOperation, __result, isApplicableCC };
	}

	public static final EObjectContainer pattern_CreateInheritanceRule_21_6_expressionFB(EObjectContainer __result) {
		EObjectContainer _result = __result;
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_24_1_prepare_blackB(CreateInheritanceRule _this) {
		return new Object[] { _this };
	}

	public static final Object[] pattern_CreateInheritanceRule_24_1_prepare_greenF() {
		IsApplicableRuleResult result = RuntimeFactory.eINSTANCE.createIsApplicableRuleResult();
		return new Object[] { result };
	}

	public static final Object[] pattern_CreateInheritanceRule_24_2_matchsrctrgcontext_bindingFFFFFFBB(
			Match targetMatch, Match sourceMatch) {
		EObject _localVariable_0 = targetMatch.getObject("superTable");
		EObject _localVariable_1 = sourceMatch.getObject("superClass");
		EObject _localVariable_2 = targetMatch.getObject("subTable");
		EObject _localVariable_3 = sourceMatch.getObject("subClass");
		EObject _localVariable_4 = sourceMatch.getObject("p");
		EObject _localVariable_5 = targetMatch.getObject("s");
		EObject tmpSuperTable = _localVariable_0;
		EObject tmpSuperClass = _localVariable_1;
		EObject tmpSubTable = _localVariable_2;
		EObject tmpSubClass = _localVariable_3;
		EObject tmpP = _localVariable_4;
		EObject tmpS = _localVariable_5;
		if (tmpSuperTable instanceof DBTable) {
			DBTable superTable = (DBTable) tmpSuperTable;
			if (tmpSuperClass instanceof CDClass) {
				CDClass superClass = (CDClass) tmpSuperClass;
				if (tmpSubTable instanceof DBTable) {
					DBTable subTable = (DBTable) tmpSubTable;
					if (tmpSubClass instanceof CDClass) {
						CDClass subClass = (CDClass) tmpSubClass;
						if (tmpP instanceof CDPackage) {
							CDPackage p = (CDPackage) tmpP;
							if (tmpS instanceof DBSchema) {
								DBSchema s = (DBSchema) tmpS;
								return new Object[] { superTable, superClass, subTable, subClass, p, s, targetMatch,
										sourceMatch };
							}
						}
					}
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_24_2_matchsrctrgcontext_blackBBBBBBBB(DBTable superTable,
			CDClass superClass, DBTable subTable, CDClass subClass, CDPackage p, DBSchema s, Match sourceMatch,
			Match targetMatch) {
		if (!subTable.equals(superTable)) {
			if (!subClass.equals(superClass)) {
				if (!sourceMatch.equals(targetMatch)) {
					return new Object[] { superTable, superClass, subTable, subClass, p, s, sourceMatch, targetMatch };
				}
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_24_2_matchsrctrgcontext_bindingAndBlackFFFFFFBB(
			Match sourceMatch, Match targetMatch) {
		Object[] result_pattern_CreateInheritanceRule_24_2_matchsrctrgcontext_binding = pattern_CreateInheritanceRule_24_2_matchsrctrgcontext_bindingFFFFFFBB(
				targetMatch, sourceMatch);
		if (result_pattern_CreateInheritanceRule_24_2_matchsrctrgcontext_binding != null) {
			DBTable superTable = (DBTable) result_pattern_CreateInheritanceRule_24_2_matchsrctrgcontext_binding[0];
			CDClass superClass = (CDClass) result_pattern_CreateInheritanceRule_24_2_matchsrctrgcontext_binding[1];
			DBTable subTable = (DBTable) result_pattern_CreateInheritanceRule_24_2_matchsrctrgcontext_binding[2];
			CDClass subClass = (CDClass) result_pattern_CreateInheritanceRule_24_2_matchsrctrgcontext_binding[3];
			CDPackage p = (CDPackage) result_pattern_CreateInheritanceRule_24_2_matchsrctrgcontext_binding[4];
			DBSchema s = (DBSchema) result_pattern_CreateInheritanceRule_24_2_matchsrctrgcontext_binding[5];

			Object[] result_pattern_CreateInheritanceRule_24_2_matchsrctrgcontext_black = pattern_CreateInheritanceRule_24_2_matchsrctrgcontext_blackBBBBBBBB(
					superTable, superClass, subTable, subClass, p, s, sourceMatch, targetMatch);
			if (result_pattern_CreateInheritanceRule_24_2_matchsrctrgcontext_black != null) {

				return new Object[] { superTable, superClass, subTable, subClass, p, s, sourceMatch, targetMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_24_3_solvecsp_bindingFBBBBBBBBB(
			CreateInheritanceRule _this, DBTable superTable, CDClass superClass, DBTable subTable, CDClass subClass,
			CDPackage p, DBSchema s, Match sourceMatch, Match targetMatch) {
		CSP _localVariable_6 = _this.isApplicable_solveCsp_CC(superTable, superClass, subTable, subClass, p, s,
				sourceMatch, targetMatch);
		CSP csp = _localVariable_6;
		if (csp != null) {
			return new Object[] { csp, _this, superTable, superClass, subTable, subClass, p, s, sourceMatch,
					targetMatch };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_24_3_solvecsp_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_CreateInheritanceRule_24_3_solvecsp_bindingAndBlackFBBBBBBBBB(
			CreateInheritanceRule _this, DBTable superTable, CDClass superClass, DBTable subTable, CDClass subClass,
			CDPackage p, DBSchema s, Match sourceMatch, Match targetMatch) {
		Object[] result_pattern_CreateInheritanceRule_24_3_solvecsp_binding = pattern_CreateInheritanceRule_24_3_solvecsp_bindingFBBBBBBBBB(
				_this, superTable, superClass, subTable, subClass, p, s, sourceMatch, targetMatch);
		if (result_pattern_CreateInheritanceRule_24_3_solvecsp_binding != null) {
			CSP csp = (CSP) result_pattern_CreateInheritanceRule_24_3_solvecsp_binding[0];

			Object[] result_pattern_CreateInheritanceRule_24_3_solvecsp_black = pattern_CreateInheritanceRule_24_3_solvecsp_blackB(
					csp);
			if (result_pattern_CreateInheritanceRule_24_3_solvecsp_black != null) {

				return new Object[] { csp, _this, superTable, superClass, subTable, subClass, p, s, sourceMatch,
						targetMatch };
			}
		}
		return null;
	}

	public static final boolean pattern_CreateInheritanceRule_24_4_checkCSP_expressionFB(CSP csp) {
		boolean _localVariable_0 = csp.check();
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Iterable<Object[]> pattern_CreateInheritanceRule_24_5_matchcorrcontext_blackFBBFBBBB(
			DBTable superTable, CDClass superClass, CDPackage p, DBSchema s, Match sourceMatch, Match targetMatch) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		if (!sourceMatch.equals(targetMatch)) {
			for (ClassToTable supCorr : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(superTable,
					ClassToTable.class, "target")) {
				if (superClass.equals(supCorr.getSource())) {
					for (PackageToSchema p2s : org.moflon.core.utilities.eMoflonEMFUtil.getOppositeReferenceTyped(p,
							PackageToSchema.class, "source")) {
						if (s.equals(p2s.getTarget())) {
							_result.add(new Object[] { supCorr, superTable, superClass, p2s, p, s, sourceMatch,
									targetMatch });
						}
					}
				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_24_5_matchcorrcontext_greenBBBBF(ClassToTable supCorr,
			PackageToSchema p2s, Match sourceMatch, Match targetMatch) {
		CCMatch ccMatch = RuntimeFactory.eINSTANCE.createCCMatch();
		String ccMatch_ruleName_prime = "CreateInheritanceRule";
		ccMatch.setSourceMatch(sourceMatch);
		ccMatch.setTargetMatch(targetMatch);
		ccMatch.getAllContextElements().add(supCorr);
		ccMatch.getAllContextElements().add(p2s);
		ccMatch.setRuleName(ccMatch_ruleName_prime);
		return new Object[] { supCorr, p2s, sourceMatch, targetMatch, ccMatch };
	}

	public static final Object[] pattern_CreateInheritanceRule_24_6_createcorrespondence_blackBBBBBBB(
			DBTable superTable, CDClass superClass, DBTable subTable, CDClass subClass, CDPackage p, DBSchema s,
			CCMatch ccMatch) {
		if (!subTable.equals(superTable)) {
			if (!subClass.equals(superClass)) {
				return new Object[] { superTable, superClass, subTable, subClass, p, s, ccMatch };
			}
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_24_6_createcorrespondence_greenFFBBBB(CDClass superClass,
			DBTable subTable, CDClass subClass, CCMatch ccMatch) {
		SuperClassToTable transitiveCorr = CDToDBFactory.eINSTANCE.createSuperClassToTable();
		ClassToTable subCorr = CDToDBFactory.eINSTANCE.createClassToTable();
		transitiveCorr.setSource(superClass);
		transitiveCorr.setTarget(subTable);
		ccMatch.getCreateCorr().add(transitiveCorr);
		subCorr.setSource(subClass);
		subCorr.setTarget(subTable);
		ccMatch.getCreateCorr().add(subCorr);
		return new Object[] { transitiveCorr, subCorr, superClass, subTable, subClass, ccMatch };
	}

	public static final Object[] pattern_CreateInheritanceRule_24_7_addtoreturnedresult_blackBB(
			IsApplicableRuleResult result, CCMatch ccMatch) {
		return new Object[] { result, ccMatch };
	}

	public static final Object[] pattern_CreateInheritanceRule_24_7_addtoreturnedresult_greenBB(
			IsApplicableRuleResult result, CCMatch ccMatch) {
		result.getIsApplicableMatch().add(ccMatch);
		boolean result_success_prime = Boolean.valueOf(true);
		String ccMatch_ruleName_prime = "CreateInheritanceRule";
		result.setSuccess(Boolean.valueOf(result_success_prime));
		ccMatch.setRuleName(ccMatch_ruleName_prime);
		return new Object[] { result, ccMatch };
	}

	public static final IsApplicableRuleResult pattern_CreateInheritanceRule_24_8_expressionFB(
			IsApplicableRuleResult result) {
		IsApplicableRuleResult _result = result;
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_27_1_matchtggpattern_blackBBB(CDClass superClass,
			CDClass subClass, CDPackage p) {
		if (!subClass.equals(superClass)) {
			if (p.getClasses().contains(subClass)) {
				if (superClass.equals(subClass.getSuperClass())) {
					if (p.getClasses().contains(superClass)) {
						return new Object[] { superClass, subClass, p };
					}
				}
			}
		}
		return null;
	}

	public static final boolean pattern_CreateInheritanceRule_27_2_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_CreateInheritanceRule_27_3_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_28_1_matchtggpattern_blackBBB(DBTable superTable,
			DBTable subTable, DBSchema s) {
		if (!subTable.equals(superTable)) {
			if (s.getTables().contains(superTable)) {
				if (s.getTables().contains(subTable)) {
					return new Object[] { superTable, subTable, s };
				}
			}
		}
		return null;
	}

	public static final boolean pattern_CreateInheritanceRule_28_2_expressionF() {
		boolean _result = Boolean.valueOf(true);
		return _result;
	}

	public static final boolean pattern_CreateInheritanceRule_28_3_expressionF() {
		boolean _result = Boolean.valueOf(false);
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_29_1_createresult_blackB(CreateInheritanceRule _this) {
		return new Object[] { _this };
	}

	public static final Object[] pattern_CreateInheritanceRule_29_1_createresult_greenFF() {
		IsApplicableMatch isApplicableMatch = RuntimeFactory.eINSTANCE.createIsApplicableMatch();
		ModelgeneratorRuleResult ruleResult = RuntimeFactory.eINSTANCE.createModelgeneratorRuleResult();
		boolean ruleResult_success_prime = Boolean.valueOf(false);
		ruleResult.setSuccess(Boolean.valueOf(ruleResult_success_prime));
		return new Object[] { isApplicableMatch, ruleResult };
	}

	public static final Object[] pattern_CreateInheritanceRule_29_2_isapplicablecore_black_nac_0BB(
			ModelgeneratorRuleResult ruleResult, ClassToTable supCorr) {
		if (ruleResult.getCorrObjects().contains(supCorr)) {
			return new Object[] { ruleResult, supCorr };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_29_2_isapplicablecore_black_nac_1BB(
			ModelgeneratorRuleResult ruleResult, DBTable superTable) {
		if (ruleResult.getTargetObjects().contains(superTable)) {
			return new Object[] { ruleResult, superTable };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_29_2_isapplicablecore_black_nac_2BB(
			ModelgeneratorRuleResult ruleResult, DBSchema s) {
		if (ruleResult.getTargetObjects().contains(s)) {
			return new Object[] { ruleResult, s };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_29_2_isapplicablecore_black_nac_3BB(
			ModelgeneratorRuleResult ruleResult, PackageToSchema p2s) {
		if (ruleResult.getCorrObjects().contains(p2s)) {
			return new Object[] { ruleResult, p2s };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_29_2_isapplicablecore_black_nac_4BB(
			ModelgeneratorRuleResult ruleResult, CDPackage p) {
		if (ruleResult.getSourceObjects().contains(p)) {
			return new Object[] { ruleResult, p };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_29_2_isapplicablecore_black_nac_5BB(
			ModelgeneratorRuleResult ruleResult, CDClass superClass) {
		if (ruleResult.getSourceObjects().contains(superClass)) {
			return new Object[] { ruleResult, superClass };
		}
		return null;
	}

	public static final Iterable<Object[]> pattern_CreateInheritanceRule_29_2_isapplicablecore_blackFFFFFFFBB(
			RuleEntryContainer ruleEntryContainer, ModelgeneratorRuleResult ruleResult) {
		LinkedList<Object[]> _result = new LinkedList<Object[]>();
		for (RuleEntryList supCorrList : ruleEntryContainer.getRuleEntryList()) {
			for (EObject tmpSupCorr : supCorrList.getEntryObjects()) {
				if (tmpSupCorr instanceof ClassToTable) {
					ClassToTable supCorr = (ClassToTable) tmpSupCorr;
					DBTable superTable = supCorr.getTarget();
					if (superTable != null) {
						CDClass superClass = supCorr.getSource();
						if (superClass != null) {
							if (pattern_CreateInheritanceRule_29_2_isapplicablecore_black_nac_0BB(ruleResult,
									supCorr) == null) {
								if (pattern_CreateInheritanceRule_29_2_isapplicablecore_black_nac_1BB(ruleResult,
										superTable) == null) {
									if (pattern_CreateInheritanceRule_29_2_isapplicablecore_black_nac_5BB(ruleResult,
											superClass) == null) {
										for (DBSchema s : org.moflon.core.utilities.eMoflonEMFUtil
												.getOppositeReferenceTyped(superTable, DBSchema.class, "tables")) {
											if (pattern_CreateInheritanceRule_29_2_isapplicablecore_black_nac_2BB(
													ruleResult, s) == null) {
												for (CDPackage p : org.moflon.core.utilities.eMoflonEMFUtil
														.getOppositeReferenceTyped(superClass, CDPackage.class,
																"classes")) {
													if (pattern_CreateInheritanceRule_29_2_isapplicablecore_black_nac_4BB(
															ruleResult, p) == null) {
														for (PackageToSchema p2s : org.moflon.core.utilities.eMoflonEMFUtil
																.getOppositeReferenceTyped(s, PackageToSchema.class,
																		"target")) {
															if (p.equals(p2s.getSource())) {
																if (pattern_CreateInheritanceRule_29_2_isapplicablecore_black_nac_3BB(
																		ruleResult, p2s) == null) {
																	_result.add(new Object[] { supCorrList, supCorr,
																			superTable, s, p2s, p, superClass,
																			ruleEntryContainer, ruleResult });
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}

					}

				}
			}
		}
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_29_3_solveCSP_bindingFBBBBBBBBB(
			CreateInheritanceRule _this, IsApplicableMatch isApplicableMatch, ClassToTable supCorr, DBTable superTable,
			CDClass superClass, PackageToSchema p2s, CDPackage p, DBSchema s, ModelgeneratorRuleResult ruleResult) {
		CSP _localVariable_0 = _this.generateModel_solveCsp_BWD(isApplicableMatch, supCorr, superTable, superClass, p2s,
				p, s, ruleResult);
		CSP csp = _localVariable_0;
		if (csp != null) {
			return new Object[] { csp, _this, isApplicableMatch, supCorr, superTable, superClass, p2s, p, s,
					ruleResult };
		}
		return null;
	}

	public static final Object[] pattern_CreateInheritanceRule_29_3_solveCSP_blackB(CSP csp) {
		return new Object[] { csp };
	}

	public static final Object[] pattern_CreateInheritanceRule_29_3_solveCSP_bindingAndBlackFBBBBBBBBB(
			CreateInheritanceRule _this, IsApplicableMatch isApplicableMatch, ClassToTable supCorr, DBTable superTable,
			CDClass superClass, PackageToSchema p2s, CDPackage p, DBSchema s, ModelgeneratorRuleResult ruleResult) {
		Object[] result_pattern_CreateInheritanceRule_29_3_solveCSP_binding = pattern_CreateInheritanceRule_29_3_solveCSP_bindingFBBBBBBBBB(
				_this, isApplicableMatch, supCorr, superTable, superClass, p2s, p, s, ruleResult);
		if (result_pattern_CreateInheritanceRule_29_3_solveCSP_binding != null) {
			CSP csp = (CSP) result_pattern_CreateInheritanceRule_29_3_solveCSP_binding[0];

			Object[] result_pattern_CreateInheritanceRule_29_3_solveCSP_black = pattern_CreateInheritanceRule_29_3_solveCSP_blackB(
					csp);
			if (result_pattern_CreateInheritanceRule_29_3_solveCSP_black != null) {

				return new Object[] { csp, _this, isApplicableMatch, supCorr, superTable, superClass, p2s, p, s,
						ruleResult };
			}
		}
		return null;
	}

	public static final boolean pattern_CreateInheritanceRule_29_4_checkCSP_expressionFBB(CreateInheritanceRule _this,
			CSP csp) {
		boolean _localVariable_0 = _this.generateModel_checkCsp_BWD(csp);
		boolean _result = Boolean.valueOf(_localVariable_0);
		return _result;
	}

	public static final Object[] pattern_CreateInheritanceRule_29_5_checknacs_blackBBBBBB(ClassToTable supCorr,
			DBTable superTable, CDClass superClass, PackageToSchema p2s, CDPackage p, DBSchema s) {
		return new Object[] { supCorr, superTable, superClass, p2s, p, s };
	}

	public static final Object[] pattern_CreateInheritanceRule_29_6_perform_blackBBBBBBB(ClassToTable supCorr,
			DBTable superTable, CDClass superClass, PackageToSchema p2s, CDPackage p, DBSchema s,
			ModelgeneratorRuleResult ruleResult) {
		return new Object[] { supCorr, superTable, superClass, p2s, p, s, ruleResult };
	}

	public static final Object[] pattern_CreateInheritanceRule_29_6_perform_greenFFBFFBBBB(CDClass superClass,
			CDPackage p, DBSchema s, ModelgeneratorRuleResult ruleResult, CSP csp) {
		SuperClassToTable transitiveCorr = CDToDBFactory.eINSTANCE.createSuperClassToTable();
		ClassToTable subCorr = CDToDBFactory.eINSTANCE.createClassToTable();
		DBTable subTable = DatabaseSchemataFactory.eINSTANCE.createDBTable();
		CDClass subClass = ClassDiagramsFactory.eINSTANCE.createCDClass();
		Object _localVariable_0 = csp.getValue("subTable", "name");
		Object _localVariable_1 = csp.getValue("subClass", "name");
		boolean ruleResult_success_prime = Boolean.valueOf(true);
		int _localVariable_2 = ruleResult.getIncrementedPerformCount();
		transitiveCorr.setSource(superClass);
		ruleResult.getCorrObjects().add(transitiveCorr);
		ruleResult.getCorrObjects().add(subCorr);
		transitiveCorr.setTarget(subTable);
		subCorr.setTarget(subTable);
		s.getTables().add(subTable);
		ruleResult.getTargetObjects().add(subTable);
		subCorr.setSource(subClass);
		p.getClasses().add(subClass);
		subClass.setSuperClass(superClass);
		ruleResult.getSourceObjects().add(subClass);
		String subTable_name_prime = (String) _localVariable_0;
		String subClass_name_prime = (String) _localVariable_1;
		ruleResult.setSuccess(Boolean.valueOf(ruleResult_success_prime));
		int ruleResult_performCount_prime = Integer.valueOf(_localVariable_2);
		subTable.setName(subTable_name_prime);
		subClass.setName(subClass_name_prime);
		ruleResult.setPerformCount(Integer.valueOf(ruleResult_performCount_prime));
		return new Object[] { transitiveCorr, subCorr, superClass, subTable, subClass, p, s, ruleResult, csp };
	}

	public static final ModelgeneratorRuleResult pattern_CreateInheritanceRule_29_7_expressionFB(
			ModelgeneratorRuleResult ruleResult) {
		ModelgeneratorRuleResult _result = ruleResult;
		return _result;
	}

	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //CreateInheritanceRuleImpl
