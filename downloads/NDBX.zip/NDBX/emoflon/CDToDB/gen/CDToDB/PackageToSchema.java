/**
 */
package CDToDB;

import ClassDiagrams.CDPackage;

import DatabaseSchemata.DBSchema;

import org.eclipse.emf.ecore.EObject;

import org.moflon.tgg.runtime.AbstractCorrespondence;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Package To Schema</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link CDToDB.PackageToSchema#getSource <em>Source</em>}</li>
 *   <li>{@link CDToDB.PackageToSchema#getTarget <em>Target</em>}</li>
 * </ul>
 * </p>
 *
 * @see CDToDB.CDToDBPackage#getPackageToSchema()
 * @model
 * @generated
 */
public interface PackageToSchema extends EObject, AbstractCorrespondence {
	/**
	 * Returns the value of the '<em><b>Source</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Source</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' reference.
	 * @see #setSource(CDPackage)
	 * @see CDToDB.CDToDBPackage#getPackageToSchema_Source()
	 * @model required="true"
	 * @generated
	 */
	CDPackage getSource();

	/**
	 * Sets the value of the '{@link CDToDB.PackageToSchema#getSource <em>Source</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' reference.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(CDPackage value);

	/**
	 * Returns the value of the '<em><b>Target</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Target</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Target</em>' reference.
	 * @see #setTarget(DBSchema)
	 * @see CDToDB.CDToDBPackage#getPackageToSchema_Target()
	 * @model required="true"
	 * @generated
	 */
	DBSchema getTarget();

	/**
	 * Sets the value of the '{@link CDToDB.PackageToSchema#getTarget <em>Target</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Target</em>' reference.
	 * @see #getTarget()
	 * @generated
	 */
	void setTarget(DBSchema value);
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // PackageToSchema
