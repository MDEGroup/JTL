# LOGS METAMODEL

Ecore metamodel representing logs files automatically created from the CSY's simulator.

Project contents: 

> metamodels/Logs.ecore: Ecore metamodel representing logs.
> models/traces.xmi: Sample model conforms to Logs.ecore (manually created) 
> models/hackathon.xmi: Sample model conforms to Logs.ecore (automatically generated via python script from the simulator) 
> text/trace2_subset.csv: Sample textual logs

