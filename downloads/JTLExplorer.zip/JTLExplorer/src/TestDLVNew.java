import it.unical.mat.wrapper.*;
import it.unical.mat.wrapper.Predicate.ResultLiteral;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class TestDLVNew {

	/**
	 * @param args
	 * @throws DLVInvocationException 
	 * @throws IOException 
	 */
	public static void main(String[] args) throws DLVInvocationException, IOException {
		
		/* I create a new instance of DLVInputProgram */
		DLVInputProgram inputProgram = new DLVInputProgramImpl();

		/* I add some file to the DLVInputProgram */
		File aspTransformation = new File("resources/transformations/DesignSpaceExplorer.dl");
		inputProgram.addFile(aspTransformation.getPath());

		String srcMetamodelName = "x_smallAR";
		String metamodelName = "x_smallAROut";

		/* I detect the current OS to create a new instance of DLVInvocation*/
		String solverPath = "";
		String os = System.getProperty("os.name");
		if (os.toLowerCase().contains("win")) {
			solverPath = "lib/dl-complex.win";
		} 
		else if (os.toLowerCase().contains("mac")) {
			solverPath = "lib/dl-complex.mac";			
		}
		else if (os.toLowerCase().contains("nix") || os.toLowerCase().contains("nux")) {
			solverPath = "lib/dl-complex.unix";		
		}
		/* I create a new instance of DLVInvocation using the DLVWrapper class specifying a path for DLV executable */
		File solverExecutable = new File(solverPath);
		DLVInvocation invocation = DLVWrapper.getInstance().createInvocation(solverExecutable.getPath());
		invocation.setInputProgram(inputProgram);
		/* Sets the max number of models computed in the DLV execution. If n is 0, all models are computed. This method deletes each option that contains the string "-n=" and adds a new option "-n='n'. */
		//invocation.setNumberOfModels(10);
		//The options can be eliminated with the respective methods:
		/* Remove any n� of models option */
		//invocation.resetNumberOfModels();

		/* I create a new observer that receives a notification for the models computed and store them in a list */
		/*
		final List <ModelResult> models = new ArrayList<ModelResult>();
		ModelHandler modelHandler = new ModelHandler(){

			final public void handleResult(DLVInvocation obsd, ModelResult res) {

				models.add(res);

			}

		};*/

		/* Subscribe the handler from the DLVInvocation */
		//invocation.subscribe(modelHandler);

		/* I create a new observer that receive a notification for the predicates computed with a specified name and store them in a list */
		/*
		final List <PredicateResult> predicates = new ArrayList<PredicateResult>();
		PredicateHandlerWithName predicateHandler = new PredicateHandlerWithName(){

			public void handleResult(DLVInvocation obsd, PredicateResult res) {

				predicates.add(res);

			}


			public List <String> getPredicateNames() {

				List <String> predicates = new ArrayList<String>();
			    //predicates.add( PREDICATE NAME1 );
			    //predicates.add( PREDICATE NAME2 );
			    return predicates;

			}

		};*/

		/* Subscribe the handler from the DLVInvocation */
		//invocation.subscribe(predicateHandler);

		/* The ModelBufferedHandler is a concrete observer that works like Enumeration. NOTE: the ModelBufferedHandler subscribe itself to the DLVInvocation */
		ModelBufferedHandler modelBufferedHandler = new ModelBufferedHandler(invocation);

		/* Start the DLV execution */
		invocation.run();

		/* If I want to wait for the execution to finish, I can use this method */
		//invocation.waitUntilExecutionFinishes();

		/* At the end of execution, I can control the errors created by DLV invocation */
		//List <DLVError> errors = invocation.getErrors();
		/* Scroll all models computed */
		/*
		while(modelBufferedHandler.hasMoreModels()){

			Model model = modelBufferedHandler.nextModel();
			while(model.hasMorePredicates()){

				Predicate predicate = model.nextPredicate();
			    while(predicate.hasMoreLiterals()){

			    	Literal literal = predicate.nextLiteral();

			    }

			}

		}*/

		String result = "";
		String nodes = "";
		String edges = "";
		String props = "";
		String srcNodes = "";
		String srcEdges = "";
		String srcProps = "";
		String traces = "";
		String current = "";
		Boolean isFirstPredicate = false;
		Boolean isFirstLiteral;
		int i=0;

		while (modelBufferedHandler.hasMoreModels()) {
			
			Model model = modelBufferedHandler.nextModel();
			i++;
			result += "\n%%%% Target Model " + i + "\nmodel(m" + i + ", " + metamodelName + ").\n";
			nodes = "";
			edges = "";
			props = "";
			model.firstPredicate();
			isFirstPredicate = true;
			//result = model.toString();
			while(model.hasMorePredicates()) {
				
				Predicate predicate;
				if (isFirstPredicate) {
					 predicate = model.firstPredicate();
					 isFirstPredicate = false;
				}
				else predicate = model.nextPredicate();
				predicate.firstLiteral();
				isFirstLiteral = true;

		    	while (predicate.hasMoreLiterals()) {
	
		    		ResultLiteral literal;
		    		if (isFirstLiteral) {
		    			literal = predicate.firstLiteral();
		    			isFirstLiteral = false;
		    		}
		    		else literal = predicate.nextResultLiteral();
					current = literal.toString();
					//System.out.println(current);
					if (current.startsWith("nodex") && current.contains(metamodelName)) {
						nodes += current.replaceAll("nodex", "node") + "\n";
					} else if (current.startsWith("edgex") && current.contains(metamodelName)) {
							edges += current.replaceAll("edgex", "edge") + "\n";
						} else if (current.startsWith("propx") && current.contains(metamodelName)) {
								props += current.replaceAll("propx", "prop") + "\n";
							}
					
					if (current.startsWith("node(") && current.contains(srcMetamodelName)) {
						srcNodes += current + "\n";
					} else if (current.startsWith("edge(") && current.contains(srcMetamodelName)) {
							srcEdges += current + "\n";
						} else if (current.startsWith("prop(") && current.contains(srcMetamodelName)) {
								srcProps += current + "\n";
							}
					
					if (current.startsWith("trace") && current.contains(srcMetamodelName)) {
						traces += current + "\n";
					}
				}
			}
			result += nodes + edges + props;				
			//result += "\n%%%% Source Model \nmodel(source, " + srcMetamodelName + ").\n";
			//result += srcNodes + srcEdges + srcProps;
			//result += "\n%%%% Traces\n";
			//result += traces;
			System.out.println("Model " + i + "\n");
			writeToFile(result, "resources/models/result.dl");
		}
	}	
		
		///
		
		/*while (myEngine.hasMoreModel()) {
		    Model model = myEngine.nextModel();
		    System.out.println(model);
		}*/
		/*
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}*/
	
	
	private static void writeToFile(String content, String filePath) {
		try{
			// Create file 
			FileWriter fstream = new FileWriter(filePath);
			BufferedWriter out = new BufferedWriter(fstream);
			out.write(content);
			//Close the output stream
			out.close();
		}catch (Exception e){
			System.err.println("Error: " + e.getMessage());
		}
	}
	
	/*
	private static String readFile(String filePath) {
		String result = "";
		try{
			// Create file 
			FileReader fstream = new FileReader(filePath);
			BufferedReader out = new BufferedReader(fstream);
			while(out.ready()) {
				result += out.readLine() + "\n";
			}
			//Close the output stream
			out.close();
		}catch (Exception e){
			System.err.println("Error: " + e.getMessage());
		}
		return result;
	}

	/*
	private static String fixPath(String path) {
		return path.replaceAll("\\\\", "\\\\\\\\");
	}*/

}